<?php
/**
 * Staging site synchronization.
 *
 * Handles bidirectional sync between staging and live sites,
 * as well as remote local-live synchronization via the REST API.
 *
 * @package    FiveDPBR
 * @subpackage FiveDPBR/includes/staging
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class FiveDPBR_Staging_Sync
 *
 * @since 1.0.0
 */
class FiveDPBR_Staging_Sync {

	/**
	 * Push staging changes to live.
	 *
	 * Retrieves pending changes from the change log and applies them
	 * to the live site database and files. URL search-replace is performed
	 * on database changes to correctly translate staging URLs to live URLs.
	 *
	 * @param int   $staging_id Staging site ID.
	 * @param array $options    Sync options.
	 * @return array|WP_Error Sync report or error.
	 */
	public static function sync_to_live( $staging_id, $options = array() ) {
		global $wpdb;

		$defaults = array(
			'sync_db'          => true,
			'sync_files'       => true,
			'selective_tables' => array(),
			'selective_dirs'   => array(),
		);

		$options = wp_parse_args( $options, $defaults );

		// Get the staging site record.
		$staging = FiveDPBR_Staging_Engine::get_staging_site( $staging_id );

		if ( ! $staging ) {
			return new WP_Error( 'not_found', __( 'Staging site not found.', '5dp-backup-restore' ) );
		}

		if ( 'active' !== $staging->status ) {
			return new WP_Error( 'not_active', __( 'Staging site is not active.', '5dp-backup-restore' ) );
		}

		$report = array(
			'direction'     => 'staging_to_live',
			'staging_id'    => $staging_id,
			'db_changes'    => 0,
			'files_synced'  => 0,
			'errors'        => array(),
			'started_at'    => current_time( 'mysql', true ),
			'completed_at'  => '',
		);

		FiveDPBR_Logger::info(
			'staging',
			sprintf( 'Sync to live started for staging "%s".', $staging->name )
		);

		// Get pending changes from the STAGING site's change log table.
		$stg_prefix = $staging->staging_prefix;
		$changes    = self::get_pending_changes( $staging_id, 'staging', $stg_prefix );

		// Collect change IDs upfront to avoid race condition with mark_all_synced.
		$change_ids = wp_list_pluck( $changes, 'id' );

		// Sync database changes.
		if ( $options['sync_db'] ) {
			$db_result = self::apply_db_changes_to_live( $staging, $changes, $options );

			if ( is_wp_error( $db_result ) ) {
				$report['errors'][] = $db_result->get_error_message();
			} else {
				$report['db_changes'] = $db_result;
			}
		}

		// Sync file changes.
		if ( $options['sync_files'] ) {
			$file_result = self::apply_file_changes_to_live( $staging, $options );

			if ( is_wp_error( $file_result ) ) {
				$report['errors'][] = $file_result->get_error_message();
			} else {
				$report['files_synced'] = $file_result;
			}
		}

		// Mark only the changes we fetched at sync start (not new ones created during sync).
		if ( ! empty( $change_ids ) ) {
			FiveDPBR_Staging_Tracker::mark_synced_by_ids( $change_ids, $stg_prefix );
		}

		$report['completed_at'] = current_time( 'mysql', true );

		// Update last_sync_at and last_push_at timestamps.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update(
			$wpdb->prefix . 'fdpbr_staging',
			array(
				'last_sync_at' => $report['completed_at'],
				'last_push_at' => $report['completed_at'],
			),
			array( 'id' => $staging_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		// Store sync history entry.
		self::store_sync_history( $staging_id, $report );

		FiveDPBR_Logger::info(
			'staging',
			sprintf(
				'Sync to live completed: %d DB changes, %d files synced.',
				$report['db_changes'],
				$report['files_synced']
			),
			$report
		);

		return $report;
	}

	/**
	 * Pull live changes to staging.
	 *
	 * Reverse of sync_to_live: retrieves pending live-side changes
	 * and applies them to the staging database and files.
	 *
	 * @param int   $staging_id Staging site ID.
	 * @param array $options    Sync options.
	 * @return array|WP_Error Sync report or error.
	 */
	public static function sync_to_staging( $staging_id, $options = array() ) {
		global $wpdb;

		$defaults = array(
			'sync_db'          => true,
			'sync_files'       => true,
			'selective_tables' => array(),
			'selective_dirs'   => array(),
		);

		$options = wp_parse_args( $options, $defaults );

		$staging = FiveDPBR_Staging_Engine::get_staging_site( $staging_id );

		if ( ! $staging ) {
			return new WP_Error( 'not_found', __( 'Staging site not found.', '5dp-backup-restore' ) );
		}

		if ( 'active' !== $staging->status ) {
			return new WP_Error( 'not_active', __( 'Staging site is not active.', '5dp-backup-restore' ) );
		}

		$report = array(
			'direction'     => 'live_to_staging',
			'staging_id'    => $staging_id,
			'db_changes'    => 0,
			'files_synced'  => 0,
			'errors'        => array(),
			'started_at'    => current_time( 'mysql', true ),
			'completed_at'  => '',
		);

		FiveDPBR_Logger::info(
			'staging',
			sprintf( 'Sync to staging started for staging "%s".', $staging->name )
		);

		// Get pending changes from the LIVE site's change log table.
		$stg_prefix = $staging->staging_prefix;
		$changes    = self::get_pending_changes( $staging_id, 'live' );

		// Collect change IDs upfront to avoid race condition with mark_all_synced.
		$change_ids = wp_list_pluck( $changes, 'id' );

		// Sync database changes.
		if ( $options['sync_db'] ) {
			$db_result = self::apply_db_changes_to_staging( $staging, $changes, $options );

			if ( is_wp_error( $db_result ) ) {
				$report['errors'][] = $db_result->get_error_message();
			} else {
				$report['db_changes'] = $db_result;
			}
		}

		// Sync file changes.
		if ( $options['sync_files'] ) {
			$file_result = self::apply_file_changes_to_staging( $staging, $options );

			if ( is_wp_error( $file_result ) ) {
				$report['errors'][] = $file_result->get_error_message();
			} else {
				$report['files_synced'] = $file_result;
			}
		}

		// Mark only the changes we fetched at sync start (not new ones created during sync).
		if ( ! empty( $change_ids ) ) {
			FiveDPBR_Staging_Tracker::mark_synced_by_ids( $change_ids );
		}

		$report['completed_at'] = current_time( 'mysql', true );

		// Update last_sync_at timestamp.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update(
			$wpdb->prefix . 'fdpbr_staging',
			array( 'last_sync_at' => $report['completed_at'] ),
			array( 'id' => $staging_id ),
			array( '%s' ),
			array( '%d' )
		);

		// Store sync history entry.
		self::store_sync_history( $staging_id, $report );

		FiveDPBR_Logger::info(
			'staging',
			sprintf(
				'Sync to staging completed: %d DB changes, %d files synced.',
				$report['db_changes'],
				$report['files_synced']
			),
			$report
		);

		return $report;
	}

	/**
	 * Handle remote local-live 2-way sync.
	 *
	 * Supports push, pull, and two-way directions for syncing with a remote site.
	 * For push: packages local changes and POSTs to the remote endpoint.
	 * For pull: GETs remote changes and applies them locally.
	 * For two_way: merges changes from both sides, detecting conflicts.
	 *
	 * @param array $args Sync arguments.
	 * @return array|WP_Error Sync report with conflicts if any.
	 */
	public static function sync_remote( $args = array() ) {
		$defaults = array(
			'remote_url'  => '',
			'remote_key'  => '',
			'direction'   => 'push',
			'sync_db'     => true,
			'sync_files'  => true,
		);

		$args = wp_parse_args( $args, $defaults );

		if ( empty( $args['remote_url'] ) || empty( $args['remote_key'] ) ) {
			return new WP_Error( 'missing_args', __( 'Remote URL and API key are required.', '5dp-backup-restore' ) );
		}

		$remote_url = untrailingslashit( $args['remote_url'] );
		$remote_key = $args['remote_key'];

		$report = array(
			'direction'    => $args['direction'],
			'remote_url'   => $remote_url,
			'pushed'       => 0,
			'pulled'       => 0,
			'conflicts'    => array(),
			'errors'       => array(),
			'started_at'   => current_time( 'mysql', true ),
			'completed_at' => '',
		);

		FiveDPBR_Logger::info(
			'staging',
			sprintf( 'Remote sync started (%s) with %s.', $args['direction'], $remote_url )
		);

		$headers = array(
			'X-FDPBR-Migration-Key' => $remote_key,
			'Content-Type' => 'application/json',
		);

		switch ( $args['direction'] ) {
			case 'push':
				$result = self::remote_push( $remote_url, $headers, $args );

				if ( is_wp_error( $result ) ) {
					$report['errors'][] = $result->get_error_message();
				} else {
					$report['pushed'] = $result;
				}
				break;

			case 'pull':
				$result = self::remote_pull( $remote_url, $headers, $args );

				if ( is_wp_error( $result ) ) {
					$report['errors'][] = $result->get_error_message();
				} else {
					$report['pulled'] = $result;
				}
				break;

			case 'two_way':
				$result = self::remote_two_way( $remote_url, $headers, $args );

				if ( is_wp_error( $result ) ) {
					$report['errors'][] = $result->get_error_message();
				} else {
					$report['pushed']    = $result['pushed'];
					$report['pulled']    = $result['pulled'];
					$report['conflicts'] = $result['conflicts'];
				}
				break;

			default:
				return new WP_Error(
					'invalid_direction',
					sprintf(
						/* translators: %s: Direction value */
						__( 'Invalid sync direction: %s', '5dp-backup-restore' ),
						$args['direction']
					)
				);
		}

		$report['completed_at'] = current_time( 'mysql', true );

		FiveDPBR_Logger::info(
			'staging',
			sprintf(
				'Remote sync completed (%s): pushed %d, pulled %d, %d conflicts.',
				$args['direction'],
				$report['pushed'],
				$report['pulled'],
				count( $report['conflicts'] )
			),
			$report
		);

		// Log sync event on the remote site.
		$parts = array();
		if ( $report['pushed'] > 0 ) {
			$parts[] = $report['pushed'] . ' file(s) pushed';
		}
		if ( $report['pulled'] > 0 ) {
			$parts[] = $report['pulled'] . ' file(s) pulled';
		}
		$detail_msg = ! empty( $parts ) ? implode( ', ', $parts ) : 'No file changes';
		if ( ! empty( $report['errors'] ) ) {
			$detail_msg .= ' — ' . count( $report['errors'] ) . ' error(s)';
		}

		wp_remote_post(
			$remote_url . '/wp-json/fdpbr/v1/staging/log-sync',
			array(
				'headers'   => $headers,
				'body'      => wp_json_encode( array(
					'direction' => $args['direction'],
					'message'   => ucfirst( $args['direction'] ) . ' sync completed',
					'details'   => $detail_msg,
					'from'      => home_url(),
				) ),
				'timeout'   => 10,
				'sslverify' => false,
			)
		);

		// Also log locally.
		$local_log = get_option( 'fdpbr_remote_sync_log', array() );
		array_unshift( $local_log, array(
			'direction' => $args['direction'],
			'message'   => ucfirst( $args['direction'] ) . ' sync completed',
			'details'   => $detail_msg,
			'from'      => $remote_url,
			'timestamp' => current_time( 'mysql', true ),
		) );
		$local_log = array_slice( $local_log, 0, 50 );
		update_option( 'fdpbr_remote_sync_log', $local_log, false );

		return $report;
	}

	/**
	 * Get pending changes from the change log.
	 *
	 * @param int    $staging_id     Staging site ID.
	 * @param string $source         Source filter ('live' or 'staging'). Empty for all.
	 * @param string $table_prefix   Optional table prefix override (e.g., staging prefix).
	 * @return array Array of change log entries.
	 */
	public static function get_pending_changes( $staging_id, $source = '', $table_prefix = '' ) {
		global $wpdb;

		$prefix = ! empty( $table_prefix ) ? $table_prefix : $wpdb->prefix;
		$table  = $prefix . 'fdpbr_change_log';
		$where  = 'staging_id = %d AND synced = 0';
		$values = array( $staging_id );

		if ( ! empty( $source ) ) {
			$where   .= ' AND source = %s';
			$values[] = $source;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE {$where} ORDER BY detected_at ASC",
				$values
			)
		);

		return $results ? $results : array();
	}

	/**
	 * Resolve a sync conflict.
	 *
	 * Applies the chosen resolution strategy (keep_local, keep_remote, or skip)
	 * to a specific change log entry.
	 *
	 * @param int    $change_id  Change log entry ID.
	 * @param string $resolution Resolution strategy: 'keep_local', 'keep_remote', or 'skip'.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public static function resolve_conflict( $change_id, $resolution ) {
		global $wpdb;

		$table = $wpdb->prefix . 'fdpbr_change_log';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$change = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $change_id )
		);

		if ( ! $change ) {
			return new WP_Error( 'not_found', __( 'Change log entry not found.', '5dp-backup-restore' ) );
		}

		$valid_resolutions = array( 'keep_local', 'keep_remote', 'skip' );

		if ( ! in_array( $resolution, $valid_resolutions, true ) ) {
			return new WP_Error(
				'invalid_resolution',
				sprintf(
					/* translators: %s: Resolution value */
					__( 'Invalid conflict resolution: %s', '5dp-backup-restore' ),
					$resolution
				)
			);
		}

		switch ( $resolution ) {
			case 'keep_local':
				// Mark the remote change as synced (effectively discarding it).
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->update(
					$table,
					array(
						'synced'    => 1,
						'resolved'  => 'keep_local',
					),
					array( 'id' => $change_id ),
					array( '%d', '%s' ),
					array( '%d' )
				);
				break;

			case 'keep_remote':
				// Apply the remote change.
				$staging = FiveDPBR_Staging_Engine::get_staging_site( $change->staging_id );

				if ( ! $staging ) {
					return new WP_Error( 'staging_not_found', __( 'Associated staging site not found.', '5dp-backup-restore' ) );
				}

				$apply_result = self::apply_single_change( $change, $staging );

				if ( is_wp_error( $apply_result ) ) {
					return $apply_result;
				}

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->update(
					$table,
					array(
						'synced'    => 1,
						'resolved'  => 'keep_remote',
					),
					array( 'id' => $change_id ),
					array( '%d', '%s' ),
					array( '%d' )
				);
				break;

			case 'skip':
				// Mark as synced without applying.
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->update(
					$table,
					array(
						'synced'    => 1,
						'resolved'  => 'skipped',
					),
					array( 'id' => $change_id ),
					array( '%d', '%s' ),
					array( '%d' )
				);
				break;
		}

		FiveDPBR_Logger::info(
			'staging',
			sprintf( 'Conflict resolved for change %d: %s.', $change_id, $resolution )
		);

		return true;
	}

	// =========================================================================
	// Private: Sync History
	// =========================================================================

	/**
	 * Store a sync history entry in the options table.
	 *
	 * @param int   $staging_id Staging site ID.
	 * @param array $report     Sync report.
	 */
	private static function store_sync_history( $staging_id, $report ) {
		$history   = get_option( 'fdpbr_sync_history', array() );
		$history[] = array(
			'staging_id'   => $staging_id,
			'direction'    => $report['direction'],
			'db_changes'   => $report['db_changes'],
			'files_synced' => $report['files_synced'],
			'errors'       => count( $report['errors'] ),
			'completed_at' => $report['completed_at'],
		);

		// Keep only the last 50 entries.
		$history = array_slice( $history, -50 );
		update_option( 'fdpbr_sync_history', $history, false );
	}

	// =========================================================================
	// Private: Database Sync Helpers
	// =========================================================================

	/**
	 * Apply database changes from staging to live.
	 *
	 * @param object $staging Staging site record.
	 * @param array  $changes Array of change log entries.
	 * @param array  $options Sync options.
	 * @return int|WP_Error Number of changes applied or error.
	 */
	private static function apply_db_changes_to_live( $staging, $changes, $options ) {
		global $wpdb;

		$applied       = 0;
		$change_table  = $staging->staging_prefix . 'fdpbr_change_log';

		// Filter to DB-related changes only (posts, options).
		$db_changes = array_filter( $changes, function ( $change ) {
			return in_array( $change->object_type, array( 'post', 'option', 'term', 'nav_menu' ), true );
		} );

		// If selective tables are specified, filter further.
		if ( ! empty( $options['selective_tables'] ) ) {
			$db_changes = array_filter( $db_changes, function ( $change ) use ( $options ) {
				return in_array( $change->object_type, $options['selective_tables'], true );
			} );
		}

		FiveDPBR_Logger::info(
			'staging',
			sprintf(
				'[DIAG] apply_db_changes_to_live: total_changes=%d, db_changes=%d, stg_prefix=%s',
				count( $changes ), count( $db_changes ), $staging->staging_prefix
			)
		);

		foreach ( $db_changes as $change ) {
			FiveDPBR_Logger::info(
				'staging',
				sprintf(
					'[DIAG] Change entry: id=%d, type=%s, object_type=%s, object_id=%d, source=%s, synced=%d',
					$change->id, $change->change_type, $change->object_type, $change->object_id, $change->source, $change->synced
				)
			);
		}

		// URL search-replace pairs for translating staging URLs to live.
		$pairs = FiveDPBR_Search_Replace::get_migration_pairs(
			$staging->staging_url,
			$staging->source_url,
			$staging->staging_dir,
			ABSPATH
		);

		foreach ( $db_changes as $change ) {
			$result = self::apply_single_change_to_live( $change, $staging, $pairs );

			if ( is_wp_error( $result ) ) {
				FiveDPBR_Logger::warning(
					'staging',
					sprintf( 'Failed to apply change %d to live: %s', $change->id, $result->get_error_message() )
				);
				continue;
			}

			// Mark change as synced in the staging change log table.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->update(
				$change_table,
				array( 'synced' => 1 ),
				array( 'id' => $change->id ),
				array( '%d' ),
				array( '%d' )
			);

			++$applied;
		}

		return $applied;
	}

	/**
	 * Apply database changes from live to staging.
	 *
	 * @param object $staging Staging site record.
	 * @param array  $changes Array of change log entries.
	 * @param array  $options Sync options.
	 * @return int|WP_Error Number of changes applied or error.
	 */
	private static function apply_db_changes_to_staging( $staging, $changes, $options ) {
		global $wpdb;

		$applied = 0;

		$db_changes = array_filter( $changes, function ( $change ) {
			return in_array( $change->object_type, array( 'post', 'option', 'term', 'nav_menu' ), true );
		} );

		if ( ! empty( $options['selective_tables'] ) ) {
			$db_changes = array_filter( $db_changes, function ( $change ) use ( $options ) {
				return in_array( $change->object_type, $options['selective_tables'], true );
			} );
		}

		// URL search-replace pairs for translating live URLs to staging.
		$pairs = FiveDPBR_Search_Replace::get_migration_pairs(
			$staging->source_url,
			$staging->staging_url,
			ABSPATH,
			$staging->staging_dir
		);

		foreach ( $db_changes as $change ) {
			$result = self::apply_single_change_to_staging( $change, $staging, $pairs );

			if ( is_wp_error( $result ) ) {
				FiveDPBR_Logger::warning(
					'staging',
					sprintf( 'Failed to apply change %d to staging: %s', $change->id, $result->get_error_message() )
				);
				continue;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$wpdb->prefix . 'fdpbr_change_log',
				array( 'synced' => 1 ),
				array( 'id' => $change->id ),
				array( '%d' ),
				array( '%d' )
			);

			++$applied;
		}

		return $applied;
	}

	/**
	 * Apply a single change record to the live database.
	 *
	 * @param object $change Change log entry.
	 * @param object $staging Staging site record.
	 * @param array  $pairs   Search-replace pairs.
	 * @return true|WP_Error
	 */
	private static function apply_single_change_to_live( $change, $staging, $pairs ) {
		global $wpdb;

		$object_data = json_decode( $change->object_data, true );

		if ( null === $object_data ) {
			return new WP_Error( 'invalid_data', __( 'Invalid change data.', '5dp-backup-restore' ) );
		}

		// Apply URL search-replace to the data.
		$object_data_json = wp_json_encode( $object_data );
		foreach ( $pairs as $pair ) {
			$object_data_json = str_replace( $pair['search'], $pair['replace'], $object_data_json );
		}
		$object_data = json_decode( $object_data_json, true );

		// Determine live table prefix — can't use $wpdb->posts because if this
		// runs on the staging site, $wpdb->prefix is the staging prefix.
		$live_prefix = self::get_live_prefix( $staging );

		switch ( $change->object_type ) {
			case 'post':
				return self::apply_post_change_to_table( $live_prefix . 'posts', $change->change_type, $change->object_id, $object_data );

			case 'option':
				return self::apply_option_change_to_table( $live_prefix . 'options', $change->change_type, $object_data );

			default:
				return new WP_Error(
					'unsupported_type',
					sprintf(
						/* translators: %s: Object type */
						__( 'Unsupported object type for live sync: %s', '5dp-backup-restore' ),
						$change->object_type
					)
				);
		}
	}

	/**
	 * Apply a single change record to the staging database.
	 *
	 * @param object $change  Change log entry.
	 * @param object $staging Staging site record.
	 * @param array  $pairs   Search-replace pairs.
	 * @return true|WP_Error
	 */
	private static function apply_single_change_to_staging( $change, $staging, $pairs ) {
		global $wpdb;

		$object_data = json_decode( $change->object_data, true );

		if ( null === $object_data ) {
			return new WP_Error( 'invalid_data', __( 'Invalid change data.', '5dp-backup-restore' ) );
		}

		// Apply URL search-replace to the data.
		$object_data_json = wp_json_encode( $object_data );
		foreach ( $pairs as $pair ) {
			$object_data_json = str_replace( $pair['search'], $pair['replace'], $object_data_json );
		}
		$object_data = json_decode( $object_data_json, true );

		$staging_prefix = $staging->staging_prefix;

		switch ( $change->object_type ) {
			case 'post':
				$table = $staging_prefix . 'posts';
				return self::apply_post_change_to_table( $table, $change->change_type, $change->object_id, $object_data );

			case 'option':
				$table = $staging_prefix . 'options';
				return self::apply_option_change_to_table( $table, $change->change_type, $object_data );

			default:
				return new WP_Error(
					'unsupported_type',
					sprintf(
						/* translators: %s: Object type */
						__( 'Unsupported object type for staging sync: %s', '5dp-backup-restore' ),
						$change->object_type
					)
				);
		}
	}

	/**
	 * Apply a post change to a specific table.
	 *
	 * @param string $table       Table name.
	 * @param string $change_type Change type (create, update, delete).
	 * @param int    $object_id   Post ID.
	 * @param array  $object_data Post data.
	 * @return true|WP_Error
	 */
	private static function apply_post_change_to_table( $table, $change_type, $object_id, $object_data ) {
		global $wpdb;

		FiveDPBR_Logger::info(
			'staging',
			sprintf(
				'[DIAG] apply_post_change_to_table: table=%s, change_type=%s, object_id=%d, wpdb_prefix=%s, data_keys=%s',
				$table, $change_type, $object_id, $wpdb->prefix, implode( ',', array_keys( $object_data ) )
			)
		);

		// Extract post meta (not a wp_posts column) for separate handling.
		$post_meta = array();
		if ( isset( $object_data['meta'] ) ) {
			$post_meta = $object_data['meta'];
			unset( $object_data['meta'] );
		}

		switch ( $change_type ) {
			case 'create':
			case 'update':
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$exists = $wpdb->get_var(
					$wpdb->prepare( "SELECT ID FROM `{$table}` WHERE ID = %d", $object_id )
				);

				FiveDPBR_Logger::info(
					'staging',
					sprintf( '[DIAG] Post %d exists in %s: %s', $object_id, $table, $exists ? 'YES' : 'NO' )
				);

				if ( $exists ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
					$result = $wpdb->update( $table, $object_data, array( 'ID' => $object_id ) );
				} else {
					$object_data['ID'] = $object_id;
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
					$result = $wpdb->insert( $table, $object_data );
				}

				FiveDPBR_Logger::info(
					'staging',
					sprintf(
						'[DIAG] DB %s result: %s, last_error: %s, last_query: %s',
						$exists ? 'UPDATE' : 'INSERT',
						var_export( $result, true ),
						$wpdb->last_error,
						$wpdb->last_query
					)
				);

				if ( false === $result ) {
					FiveDPBR_Logger::warning(
						'staging',
						sprintf( 'DB write failed for post %d in %s: %s', $object_id, $table, $wpdb->last_error )
					);
					return new WP_Error( 'db_error', $wpdb->last_error );
				}

				// Verify the post actually exists after write.
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$verify = $wpdb->get_row(
					$wpdb->prepare( "SELECT ID, post_title, post_status, post_type FROM `{$table}` WHERE ID = %d", $object_id )
				);
				FiveDPBR_Logger::info(
					'staging',
					sprintf(
						'[DIAG] VERIFY after write: %s',
						$verify ? sprintf( 'ID=%d title="%s" status=%s type=%s', $verify->ID, $verify->post_title, $verify->post_status, $verify->post_type ) : 'NOT FOUND!'
					)
				);

				// Sync post meta to the corresponding postmeta table.
				if ( ! empty( $post_meta ) ) {
					// Derive postmeta table from posts table name (wp_posts → wp_postmeta).
					$meta_table = preg_replace( '/posts$/', 'postmeta', $table );
					self::sync_post_meta( $meta_table, $object_id, $post_meta );
				}

				return true;

			case 'delete':
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->delete( $table, array( 'ID' => $object_id ) );
				return true;

			default:
				return new WP_Error( 'invalid_change_type', __( 'Invalid change type.', '5dp-backup-restore' ) );
		}
	}

	/**
	 * Apply an option change to a specific table.
	 *
	 * @param string $table       Table name.
	 * @param string $change_type Change type (create, update, delete).
	 * @param array  $object_data Option data with 'option_name' and 'option_value'.
	 * @return true|WP_Error
	 */
	private static function apply_option_change_to_table( $table, $change_type, $object_data ) {
		global $wpdb;

		$option_name = isset( $object_data['option_name'] ) ? $object_data['option_name'] : '';

		if ( empty( $option_name ) ) {
			return new WP_Error( 'missing_option_name', __( 'Option name is required.', '5dp-backup-restore' ) );
		}

		// Never sync site-identity options — these are different per environment.
		$protected_options = array( 'siteurl', 'home', 'rewrite_rules', 'db_version' );
		if ( in_array( $option_name, $protected_options, true ) ) {
			return true; // Silently skip.
		}

		// Never sync prefix-dependent option keys (e.g., wp_user_roles, stg1_user_roles).
		if ( preg_match( '/^[a-z0-9]+_user_roles$/', $option_name ) ) {
			return true;
		}

		switch ( $change_type ) {
			case 'create':
			case 'update':
				$option_value = isset( $object_data['option_value'] ) ? $object_data['option_value'] : '';

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$exists = $wpdb->get_var(
					$wpdb->prepare( "SELECT option_id FROM `{$table}` WHERE option_name = %s", $option_name )
				);

				if ( $exists ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
					$wpdb->update(
						$table,
						array( 'option_value' => $option_value ),
						array( 'option_name' => $option_name )
					);
				} else {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
					$wpdb->insert(
						$table,
						array(
							'option_name'  => $option_name,
							'option_value' => $option_value,
							'autoload'     => isset( $object_data['autoload'] ) ? $object_data['autoload'] : 'yes',
						)
					);
				}

				return true;

			case 'delete':
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->delete( $table, array( 'option_name' => $option_name ) );
				return true;

			default:
				return new WP_Error( 'invalid_change_type', __( 'Invalid change type.', '5dp-backup-restore' ) );
		}
	}

	/**
	 * Get the live (non-staging) table prefix.
	 *
	 * When sync runs from the staging site, $wpdb->prefix is the staging prefix.
	 * This method detects that and finds the actual live prefix by querying
	 * for existing tables in the database.
	 *
	 * @param object $staging Staging site record.
	 * @return string Live table prefix.
	 */
	private static function get_live_prefix( $staging ) {
		global $wpdb;

		// If current prefix is NOT the staging prefix, we're already on the live site.
		if ( $wpdb->prefix !== $staging->staging_prefix ) {
			return $wpdb->prefix;
		}

		// We're on the staging site. Read the live $table_prefix from the
		// parent directory's wp-config.php (the live site's config).
		$staging_dir  = trailingslashit( wp_normalize_path( $staging->staging_dir ) );
		$live_abspath = trailingslashit( wp_normalize_path( dirname( rtrim( $staging_dir, '/' ) ) ) );
		$wp_config    = $live_abspath . 'wp-config.php';

		if ( file_exists( $wp_config ) ) {
			$contents = file_get_contents( $wp_config ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( preg_match( '/\$table_prefix\s*=\s*[\'"]([^\'"]+)[\'"]/', $contents, $matches ) ) {
				return $matches[1];
			}
		}

		// Fallback: assume standard 'wp_' prefix.
		return 'wp_';
	}

	/**
	 * Sync post meta to a postmeta table.
	 *
	 * @param string $meta_table Postmeta table name.
	 * @param int    $post_id    Post ID.
	 * @param array  $meta       Meta data array ( key => array of values ).
	 */
	private static function sync_post_meta( $meta_table, $post_id, $meta ) {
		global $wpdb;

		foreach ( $meta as $meta_key => $values ) {
			// Delete existing meta for this key so we can re-insert fresh values.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->delete( $meta_table, array( 'post_id' => $post_id, 'meta_key' => $meta_key ) );

			foreach ( (array) $values as $value ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->insert(
					$meta_table,
					array(
						'post_id'    => $post_id,
						'meta_key'   => $meta_key,
						'meta_value' => is_array( $value ) ? maybe_serialize( $value ) : $value,
					)
				);
			}
		}
	}

	/**
	 * Apply a single change (generic, used for conflict resolution).
	 *
	 * @param object $change  Change log entry.
	 * @param object $staging Staging site record.
	 * @return true|WP_Error
	 */
	private static function apply_single_change( $change, $staging ) {
		if ( 'staging' === $change->source ) {
			$pairs = FiveDPBR_Search_Replace::get_migration_pairs(
				$staging->staging_url,
				$staging->source_url,
				$staging->staging_dir,
				ABSPATH
			);
			return self::apply_single_change_to_live( $change, $staging, $pairs );
		} else {
			$pairs = FiveDPBR_Search_Replace::get_migration_pairs(
				$staging->source_url,
				$staging->staging_url,
				ABSPATH,
				$staging->staging_dir
			);
			return self::apply_single_change_to_staging( $change, $staging, $pairs );
		}
	}

	// =========================================================================
	// Private: File Sync Helpers
	// =========================================================================

	/**
	 * Apply file changes from staging to live.
	 *
	 * @param object $staging Staging site record.
	 * @param array  $options Sync options.
	 * @return int|WP_Error Number of files synced or error.
	 */
	private static function apply_file_changes_to_live( $staging, $options ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		WP_Filesystem();
		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			return new WP_Error( 'filesystem', __( 'Could not initialize WP_Filesystem.', '5dp-backup-restore' ) );
		}

		$staging_dir = trailingslashit( wp_normalize_path( $staging->staging_dir ) );
		$live_dir    = trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) );
		$synced      = 0;

		// Determine directories to sync.
		$dirs_to_sync = array( 'themes/', 'plugins/', 'uploads/' );

		if ( ! empty( $options['selective_dirs'] ) ) {
			$dirs_to_sync = array_map( 'trailingslashit', $options['selective_dirs'] );
		}

		foreach ( $dirs_to_sync as $dir ) {
			$source = $staging_dir . $dir;
			$dest   = $live_dir . $dir;

			if ( ! $wp_filesystem->is_dir( $source ) ) {
				continue;
			}

			$result = self::sync_directory( $source, $dest );

			if ( is_wp_error( $result ) ) {
				FiveDPBR_Logger::warning(
					'staging',
					sprintf( 'Error syncing directory %s to live: %s', $dir, $result->get_error_message() )
				);
				continue;
			}

			$synced += $result;
		}

		return $synced;
	}

	/**
	 * Apply file changes from live to staging.
	 *
	 * @param object $staging Staging site record.
	 * @param array  $options Sync options.
	 * @return int|WP_Error Number of files synced or error.
	 */
	private static function apply_file_changes_to_staging( $staging, $options ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		WP_Filesystem();
		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			return new WP_Error( 'filesystem', __( 'Could not initialize WP_Filesystem.', '5dp-backup-restore' ) );
		}

		$staging_dir = trailingslashit( wp_normalize_path( $staging->staging_dir ) );
		$live_dir    = trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) );
		$synced      = 0;

		$dirs_to_sync = array( 'themes/', 'plugins/', 'uploads/' );

		if ( ! empty( $options['selective_dirs'] ) ) {
			$dirs_to_sync = array_map( 'trailingslashit', $options['selective_dirs'] );
		}

		foreach ( $dirs_to_sync as $dir ) {
			$source = $live_dir . $dir;
			$dest   = $staging_dir . $dir;

			if ( ! $wp_filesystem->is_dir( $source ) ) {
				continue;
			}

			if ( ! $wp_filesystem->is_dir( $dest ) ) {
				wp_mkdir_p( $dest );
			}

			$result = self::sync_directory( $source, $dest );

			if ( is_wp_error( $result ) ) {
				FiveDPBR_Logger::warning(
					'staging',
					sprintf( 'Error syncing directory %s to staging: %s', $dir, $result->get_error_message() )
				);
				continue;
			}

			$synced += $result;
		}

		return $synced;
	}

	/**
	 * Sync files from one directory to another.
	 *
	 * Compares files by hash and only copies changed files.
	 *
	 * @param string $source Source directory.
	 * @param string $dest   Destination directory.
	 * @return int|WP_Error Number of files copied or error.
	 */
	private static function sync_directory( $source, $dest ) {
		global $wp_filesystem;

		$source = trailingslashit( wp_normalize_path( $source ) );
		$dest   = trailingslashit( wp_normalize_path( $dest ) );

		$dirlist = $wp_filesystem->dirlist( $source, true, false );

		if ( false === $dirlist ) {
			return new WP_Error( 'dir_read', sprintf( 'Cannot read directory: %s', $source ) );
		}

		// Skip the plugin's own directory to prevent self-overwrite during sync.
		$plugin_dir_name = defined( 'FDPBR_PLUGIN_BASENAME' )
			? dirname( FDPBR_PLUGIN_BASENAME )
			: '5dp-backup-restore';

		$copied = 0;

		foreach ( $dirlist as $name => $item ) {
			// Skip our own plugin directory.
			if ( $name === $plugin_dir_name ) {
				continue;
			}

			$source_path = $source . $name;
			$dest_path   = $dest . $name;

			if ( 'd' === $item['type'] ) {
				if ( ! $wp_filesystem->is_dir( $dest_path ) ) {
					$wp_filesystem->mkdir( $dest_path );
				}

				$sub_result = self::sync_directory( $source_path . '/', $dest_path . '/' );

				if ( ! is_wp_error( $sub_result ) ) {
					$copied += $sub_result;
				}
			} else {
				// Only copy if the file has changed (compare by size and modification time).
				$should_copy = true;

				if ( $wp_filesystem->exists( $dest_path ) ) {
					$source_size = $wp_filesystem->size( $source_path );
					$dest_size   = $wp_filesystem->size( $dest_path );

					$source_mtime = $wp_filesystem->mtime( $source_path );
					$dest_mtime   = $wp_filesystem->mtime( $dest_path );

					if ( $source_size === $dest_size && $source_mtime <= $dest_mtime ) {
						$should_copy = false;
					}
				}

				if ( $should_copy ) {
					$result = $wp_filesystem->copy( $source_path, $dest_path, true );

					if ( $result ) {
						++$copied;
					}
				}
			}
		}

		return $copied;
	}

	// =========================================================================
	// Private: Remote Sync Helpers
	// =========================================================================

	/**
	 * Push local changes to the remote site.
	 *
	 * @param string $remote_url Remote site URL.
	 * @param array  $headers    Request headers.
	 * @param array  $args       Sync arguments.
	 * @return int|WP_Error Number of changes pushed or error.
	 */
	private static function remote_push( $remote_url, $headers, $args ) {
		$db_result   = 0;
		$file_result = 0;

		// Push DB changes.
		if ( ! empty( $args['sync_db'] ) ) {
			$local_changes = self::package_local_changes( $args );

			if ( ! empty( $local_changes ) ) {
				$response = wp_remote_post(
					$remote_url . '/wp-json/fdpbr/v1/staging/push',
					array(
						'headers'   => $headers,
						'body'      => wp_json_encode( $local_changes ),
						'timeout'   => 60,
						'sslverify' => false,
					)
				);

				if ( is_wp_error( $response ) ) {
					return $response;
				}

				$code = wp_remote_retrieve_response_code( $response );

				if ( 200 !== $code ) {
					return new WP_Error(
						'remote_push_failed',
						sprintf( __( 'Remote push failed with HTTP %d.', '5dp-backup-restore' ), $code )
					);
				}

				$body      = json_decode( wp_remote_retrieve_body( $response ), true );
				$db_result = isset( $body['applied'] ) ? (int) $body['applied'] : count( $local_changes );
			}
		}

		// Push file changes.
		if ( ! empty( $args['sync_files'] ) ) {
			$file_result = self::remote_push_files( $remote_url, $headers );

			if ( is_wp_error( $file_result ) ) {
				FiveDPBR_Logger::warning( 'staging', 'File push error: ' . $file_result->get_error_message() );
				$file_result = 0;
			}
		}

		return $db_result + $file_result;
	}

	/**
	 * Pull changes from the remote site.
	 *
	 * @param string $remote_url Remote site URL.
	 * @param array  $headers    Request headers.
	 * @param array  $args       Sync arguments.
	 * @return int|WP_Error Number of changes pulled or error.
	 */
	private static function remote_pull( $remote_url, $headers, $args ) {
		$db_result   = 0;
		$file_result = 0;

		// Pull DB changes.
		if ( ! empty( $args['sync_db'] ) ) {
			$response = wp_remote_get(
				$remote_url . '/wp-json/fdpbr/v1/staging/pull',
				array(
					'headers'   => $headers,
					'timeout'   => 60,
					'sslverify' => false,
				)
			);

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$code = wp_remote_retrieve_response_code( $response );

			if ( 200 !== $code ) {
				return new WP_Error(
					'remote_pull_failed',
					sprintf( __( 'Remote pull failed with HTTP %d.', '5dp-backup-restore' ), $code )
				);
			}

			$body           = json_decode( wp_remote_retrieve_body( $response ), true );
			$remote_changes = isset( $body['changes'] ) ? $body['changes'] : array();

			if ( ! empty( $remote_changes ) ) {
				$db_result = self::apply_remote_changes( $remote_changes );
			}
		}

		// Pull file changes.
		if ( ! empty( $args['sync_files'] ) ) {
			$file_result = self::remote_pull_files( $remote_url, $headers );

			if ( is_wp_error( $file_result ) ) {
				FiveDPBR_Logger::warning( 'staging', 'File pull error: ' . $file_result->get_error_message() );
				$file_result = 0;
			}
		}

		return $db_result + $file_result;
	}

	/**
	 * Perform two-way sync with the remote site.
	 *
	 * Gets changes from both sides, detects conflicts (same object modified on both),
	 * and merges non-conflicting changes.
	 *
	 * @param string $remote_url Remote site URL.
	 * @param array  $headers    Request headers.
	 * @param array  $args       Sync arguments.
	 * @return array|WP_Error Array with pushed, pulled, and conflicts counts.
	 */
	private static function remote_two_way( $remote_url, $headers, $args ) {
		$pushed = 0;
		$pulled = 0;
		$conflicts = array();

		// DB two-way sync.
		if ( ! empty( $args['sync_db'] ) ) {
			$response = wp_remote_get(
				$remote_url . '/wp-json/fdpbr/v1/staging/pull',
				array(
					'headers'   => $headers,
					'timeout'   => 60,
					'sslverify' => false,
				)
			);

			if ( ! is_wp_error( $response ) ) {
				$body           = json_decode( wp_remote_retrieve_body( $response ), true );
				$remote_changes = isset( $body['changes'] ) ? $body['changes'] : array();
				$local_changes  = self::package_local_changes( $args );

				$remote_keys = array();
				foreach ( $remote_changes as $rc ) {
					$key = $rc['object_type'] . ':' . $rc['object_id'];
					$remote_keys[ $key ] = $rc;
				}

				$safe_local = array();
				foreach ( $local_changes as $lc ) {
					$key = $lc['object_type'] . ':' . $lc['object_id'];
					if ( isset( $remote_keys[ $key ] ) ) {
						$conflicts[] = array( 'local' => $lc, 'remote' => $remote_keys[ $key ], 'key' => $key );
						unset( $remote_keys[ $key ] );
					} else {
						$safe_local[] = $lc;
					}
				}

				$safe_remote = array_values( $remote_keys );

				if ( ! empty( $safe_local ) ) {
					$push_response = wp_remote_post(
						$remote_url . '/wp-json/fdpbr/v1/staging/push',
						array(
							'headers'   => $headers,
							'body'      => wp_json_encode( $safe_local ),
							'timeout'   => 60,
							'sslverify' => false,
						)
					);
					if ( ! is_wp_error( $push_response ) && 200 === wp_remote_retrieve_response_code( $push_response ) ) {
						$pushed = count( $safe_local );
					}
				}

				if ( ! empty( $safe_remote ) ) {
					$pulled = self::apply_remote_changes( $safe_remote );
				}
			}
		}

		// File two-way sync: push local files then pull remote files.
		if ( ! empty( $args['sync_files'] ) ) {
			$push_files = self::remote_push_files( $remote_url, $headers );
			if ( ! is_wp_error( $push_files ) ) {
				$pushed += $push_files;
			}

			$pull_files = self::remote_pull_files( $remote_url, $headers );
			if ( ! is_wp_error( $pull_files ) ) {
				$pulled += $pull_files;
			}
		}

		return array(
			'pushed'    => $pushed,
			'pulled'    => $pulled,
			'conflicts' => $conflicts,
		);
	}

	// =========================================================================
	// Private: Remote File Sync
	// =========================================================================

	/**
	 * Push changed files to a remote site.
	 *
	 * 1. Hash local wp-content/{themes,plugins,uploads}
	 * 2. Send manifest to remote /staging/compare-files
	 * 3. Send only the files the remote needs
	 * 4. Delete files remote has but source doesn't
	 *
	 * @param string $remote_url Remote site URL.
	 * @param array  $headers    Request headers.
	 * @return int|WP_Error Number of files transferred or error.
	 */
	private static function remote_push_files( $remote_url, $headers ) {
		// 1. Hash local files.
		$local_hashes = FiveDPBR_Staging_Tracker::get_content_hashes();

		if ( empty( $local_hashes ) ) {
			return 0;
		}

		FiveDPBR_Logger::info( 'staging', sprintf( 'File push: hashed %d local files.', count( $local_hashes ) ) );

		// 2. Compare with remote.
		$compare_response = wp_remote_post(
			$remote_url . '/wp-json/fdpbr/v1/staging/compare-files',
			array(
				'headers'   => array_merge( $headers, array( 'Content-Type' => 'application/json' ) ),
				'body'      => wp_json_encode( array( 'files' => $local_hashes ) ),
				'timeout'   => 120,
				'sslverify' => false,
			)
		);

		if ( is_wp_error( $compare_response ) ) {
			return $compare_response;
		}

		$compare_body = json_decode( wp_remote_retrieve_body( $compare_response ), true );

		if ( empty( $compare_body['success'] ) ) {
			return new WP_Error( 'compare_failed', __( 'File comparison failed.', '5dp-backup-restore' ) );
		}

		$needed  = isset( $compare_body['needed'] ) ? $compare_body['needed'] : array();
		$deleted = isset( $compare_body['deleted'] ) ? $compare_body['deleted'] : array();

		FiveDPBR_Logger::info( 'staging', sprintf( 'File push: %d files to send, %d to delete.', count( $needed ), count( $deleted ) ) );

		$transferred = 0;
		$chunk_size  = 10 * 1024 * 1024; // 10MB
		$content_dir = trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) );

		// 3. Send needed files.
		foreach ( $needed as $file_path ) {
			$abs = $content_dir . $file_path;

			if ( ! file_exists( $abs ) ) {
				continue;
			}

			$size        = filesize( $abs );
			$total_parts = ( $size > $chunk_size ) ? (int) ceil( $size / $chunk_size ) : 1;

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
			$fh = fopen( $abs, 'r' );

			for ( $part = 0; $part < $total_parts; $part++ ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
				$chunk = fread( $fh, $chunk_size );

				$send_response = wp_remote_post(
					$remote_url . '/wp-json/fdpbr/v1/staging/receive-file',
					array(
						'headers'   => array_merge( $headers, array(
							'Content-Type'       => 'application/octet-stream',
							'X-FDPBR-File-Path'  => $file_path,
							'X-FDPBR-Part-Index' => $part,
							'X-FDPBR-Total-Parts' => $total_parts,
						) ),
						'body'      => $chunk,
						'timeout'   => 60,
						'sslverify' => false,
					)
				);

				if ( is_wp_error( $send_response ) ) {
					FiveDPBR_Logger::warning( 'staging', sprintf( 'Failed to send file %s part %d: %s', $file_path, $part, $send_response->get_error_message() ) );
					break;
				}
			}

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			fclose( $fh );
			++$transferred;
		}

		// 4. Delete removed files on remote.
		if ( ! empty( $deleted ) ) {
			wp_remote_post(
				$remote_url . '/wp-json/fdpbr/v1/staging/delete-files',
				array(
					'headers'   => array_merge( $headers, array( 'Content-Type' => 'application/json' ) ),
					'body'      => wp_json_encode( array( 'files' => $deleted ) ),
					'timeout'   => 30,
					'sslverify' => false,
				)
			);
		}

		FiveDPBR_Logger::info( 'staging', sprintf( 'File push complete: %d files transferred.', $transferred ) );

		return $transferred;
	}

	/**
	 * Pull changed files from a remote site.
	 *
	 * 1. Get remote's hash manifest
	 * 2. Compare with local hashes
	 * 3. Download files that differ
	 * 4. Delete local files not on remote
	 *
	 * @param string $remote_url Remote site URL.
	 * @param array  $headers    Request headers.
	 * @return int|WP_Error Number of files transferred or error.
	 */
	private static function remote_pull_files( $remote_url, $headers ) {
		// 1. Get remote hash manifest.
		$manifest_response = wp_remote_get(
			$remote_url . '/wp-json/fdpbr/v1/staging/hash-manifest',
			array(
				'headers'   => $headers,
				'timeout'   => 120,
				'sslverify' => false,
			)
		);

		if ( is_wp_error( $manifest_response ) ) {
			return $manifest_response;
		}

		$manifest_body = json_decode( wp_remote_retrieve_body( $manifest_response ), true );

		if ( empty( $manifest_body['success'] ) ) {
			return new WP_Error( 'manifest_failed', __( 'Failed to get remote file manifest.', '5dp-backup-restore' ) );
		}

		$remote_files = isset( $manifest_body['files'] ) ? $manifest_body['files'] : array();

		if ( empty( $remote_files ) ) {
			return 0;
		}

		// 2. Compare with local.
		$local_files = FiveDPBR_Staging_Tracker::get_content_hashes();

		$needed  = array();
		$deleted = array();

		foreach ( $remote_files as $path => $hash ) {
			if ( ! isset( $local_files[ $path ] ) || $local_files[ $path ] !== $hash ) {
				$needed[] = $path;
			}
		}

		foreach ( $local_files as $path => $hash ) {
			if ( ! isset( $remote_files[ $path ] ) ) {
				$deleted[] = $path;
			}
		}

		FiveDPBR_Logger::info( 'staging', sprintf( 'File pull: %d files to download, %d to delete.', count( $needed ), count( $deleted ) ) );

		$content_dir  = trailingslashit( wp_normalize_path( WP_CONTENT_DIR ) );
		$transferred  = 0;

		// 3. Download needed files.
		foreach ( $needed as $file_path ) {
			// First request to get file (or first part).
			$file_response = wp_remote_get(
				add_query_arg( 'path', $file_path, $remote_url . '/wp-json/fdpbr/v1/staging/serve-file' ),
				array(
					'headers'   => $headers,
					'timeout'   => 60,
					'sslverify' => false,
				)
			);

			if ( is_wp_error( $file_response ) ) {
				FiveDPBR_Logger::warning( 'staging', sprintf( 'Failed to pull file %s: %s', $file_path, $file_response->get_error_message() ) );
				continue;
			}

			$file_body = json_decode( wp_remote_retrieve_body( $file_response ), true );

			if ( empty( $file_body['success'] ) || empty( $file_body['content'] ) ) {
				continue;
			}

			$dest = $content_dir . $file_path;
			wp_mkdir_p( dirname( $dest ) );

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents,WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			file_put_contents( $dest, base64_decode( $file_body['content'] ) );

			// Handle multi-part files.
			$total_parts = isset( $file_body['total_parts'] ) ? (int) $file_body['total_parts'] : 1;

			for ( $part = 1; $part < $total_parts; $part++ ) {
				$part_response = wp_remote_get(
					add_query_arg( array( 'path' => $file_path, 'part' => $part ), $remote_url . '/wp-json/fdpbr/v1/staging/serve-file' ),
					array(
						'headers'   => $headers,
						'timeout'   => 60,
						'sslverify' => false,
					)
				);

				if ( is_wp_error( $part_response ) ) {
					break;
				}

				$part_body = json_decode( wp_remote_retrieve_body( $part_response ), true );

				if ( ! empty( $part_body['content'] ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents,WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
					file_put_contents( $dest, base64_decode( $part_body['content'] ), FILE_APPEND );
				}
			}

			++$transferred;
		}

		// 4. Delete local files not on remote.
		foreach ( $deleted as $file_path ) {
			// Validate path safety.
			$allowed = false;
			foreach ( array( 'themes/', 'plugins/', 'uploads/' ) as $prefix ) {
				if ( 0 === strpos( $file_path, $prefix ) ) {
					$allowed = true;
					break;
				}
			}
			if ( ! $allowed || false !== strpos( $file_path, '..' ) ) {
				continue;
			}

			$abs = $content_dir . $file_path;
			if ( file_exists( $abs ) ) {
				wp_delete_file( $abs );
			}
		}

		FiveDPBR_Logger::info( 'staging', sprintf( 'File pull complete: %d files transferred, %d deleted.', $transferred, count( $deleted ) ) );

		return $transferred;
	}

	/**
	 * Package local changes for serving to a remote pull request.
	 *
	 * @return array Packaged changes.
	 */
	public static function package_local_changes_for_remote() {
		return self::package_local_changes();
	}

	/**
	 * Package local changes for remote push.
	 *
	 * @param array $args Sync arguments.
	 * @return array Packaged changes.
	 */
	public static function package_local_changes( $args = array() ) {
		global $wpdb;

		// Get recent changes that haven't been synced.
		$table = $wpdb->prefix . 'fdpbr_change_log';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$changes = $wpdb->get_results(
			"SELECT * FROM {$table} WHERE synced = 0 AND source = 'live' ORDER BY created_at ASC"
		);

		if ( empty( $changes ) ) {
			return array();
		}

		$packaged = array();

		foreach ( $changes as $change ) {
			$packaged[] = array(
				'object_type' => $change->object_type,
				'object_id'   => $change->object_id,
				'change_type' => $change->change_type,
				'object_data' => $change->object_data,
				'created_at'  => $change->created_at,
			);
		}

		return $packaged;
	}

	/**
	 * Apply remote changes locally.
	 *
	 * @param array $changes Array of change data from remote.
	 * @return int Number of changes applied.
	 */
	public static function apply_remote_changes( $changes ) {
		global $wpdb;

		$applied = 0;

		foreach ( $changes as $change ) {
			$object_data = is_string( $change['object_data'] )
				? json_decode( $change['object_data'], true )
				: $change['object_data'];

			if ( null === $object_data ) {
				continue;
			}

			$change_type = $change['change_type'];
			$object_type = $change['object_type'];
			$object_id   = isset( $change['object_id'] ) ? $change['object_id'] : 0;

			switch ( $object_type ) {
				case 'post':
					$result = self::apply_post_change_to_table( $wpdb->posts, $change_type, $object_id, $object_data );
					break;

				case 'option':
					$result = self::apply_option_change_to_table( $wpdb->options, $change_type, $object_data );
					break;

				default:
					$result = new WP_Error( 'unsupported', 'Unsupported type.' );
					break;
			}

			if ( ! is_wp_error( $result ) ) {
				++$applied;
			}
		}

		return $applied;
	}
}
