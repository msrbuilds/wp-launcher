<?php
/**
 * REST API controller.
 *
 * Central REST controller that registers all plugin REST API routes,
 * including migration and staging sync endpoints.
 *
 * @package    FiveDPBR
 * @subpackage FiveDPBR/api
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class FiveDPBR_REST_Controller
 *
 * @since 1.0.0
 */
class FiveDPBR_REST_Controller extends WP_REST_Controller {

	/**
	 * REST API namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'fdpbr/v1';

	/**
	 * Initialize the REST controller.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		$instance = new self();
		add_action( 'rest_api_init', array( $instance, 'register_routes' ) );
	}

	/**
	 * Register all REST API routes.
	 *
	 * Delegates migration routes to FiveDPBR_Migration_API and registers
	 * staging sync routes directly.
	 *
	 * @since 1.0.0
	 */
	public function register_routes() {
		// Migration routes are registered by FiveDPBR_Migration_API::register_routes().
		// They are loaded via FiveDPBR_Migration_API::init() and fire on rest_api_init.

		// -----------------------------------------------------------------
		// Staging Sync Routes
		// -----------------------------------------------------------------

		// GET /fdpbr/v1/staging/ping — Verify connection and key.
		register_rest_route(
			$this->namespace,
			'/staging/ping',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'endpoint_staging_ping' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// POST /fdpbr/v1/staging/pair — Pair with a remote staging site.
		register_rest_route(
			$this->namespace,
			'/staging/pair',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'endpoint_staging_pair' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// POST /fdpbr/v1/staging/changes — Get pending changes for sync.
		register_rest_route(
			$this->namespace,
			'/staging/changes',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'endpoint_staging_changes' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// POST /fdpbr/v1/staging/sync — Synchronize changes.
		register_rest_route(
			$this->namespace,
			'/staging/sync',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'endpoint_staging_sync' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// POST /fdpbr/v1/staging/push — Receive push data from the other site.
		register_rest_route(
			$this->namespace,
			'/staging/push',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'endpoint_staging_push' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// POST /fdpbr/v1/staging/pull — Serve pull data to the requesting site.
		register_rest_route(
			$this->namespace,
			'/staging/pull',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'endpoint_staging_pull' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// POST /fdpbr/v1/staging/compare-files — Compare file hashes.
		register_rest_route(
			$this->namespace,
			'/staging/compare-files',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'endpoint_staging_compare_files' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// POST /fdpbr/v1/staging/receive-file — Receive a file chunk.
		register_rest_route(
			$this->namespace,
			'/staging/receive-file',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'endpoint_staging_receive_file' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// POST /fdpbr/v1/staging/delete-files — Delete files no longer needed.
		register_rest_route(
			$this->namespace,
			'/staging/delete-files',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'endpoint_staging_delete_files' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// GET /fdpbr/v1/staging/hash-manifest — Return file hash manifest.
		register_rest_route(
			$this->namespace,
			'/staging/hash-manifest',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'endpoint_staging_hash_manifest' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// GET /fdpbr/v1/staging/serve-file — Serve a file for pull.
		register_rest_route(
			$this->namespace,
			'/staging/serve-file',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'endpoint_staging_serve_file' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// POST /fdpbr/v1/staging/log-sync — Log a sync event from the remote site.
		register_rest_route(
			$this->namespace,
			'/staging/log-sync',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'endpoint_staging_log_sync' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);

		// GET /fdpbr/v1/staging/sync-log — Get sync log entries.
		register_rest_route(
			$this->namespace,
			'/staging/sync-log',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'endpoint_staging_get_sync_log' ),
				'permission_callback' => array( $this, 'check_staging_permission' ),
			)
		);
	}

	// =========================================================================
	// Permission Callbacks
	// =========================================================================

	/**
	 * Check staging endpoint permissions.
	 *
	 * Validates the migration key from the request header.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return bool|WP_Error True if authorized, WP_Error otherwise.
	 */
	public function check_staging_permission( $request ) {
		return FiveDPBR_Migration_API::validate_migration_key( $request );
	}

	// =========================================================================
	// Staging Endpoints
	// =========================================================================

	/**
	 * Endpoint: Ping — verify connection and API key.
	 *
	 * @since 1.0.75
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function endpoint_staging_ping( $request ) {
		return new WP_REST_Response(
			array(
				'status'   => 'ok',
				'site_url' => home_url(),
				'wp'       => get_bloginfo( 'version' ),
				'plugin'   => defined( 'FDPBR_VERSION' ) ? FDPBR_VERSION : 'unknown',
			),
			200
		);
	}

	/**
	 * Endpoint: Pair with a remote staging site.
	 *
	 * Establishes the link between production and staging environments.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function endpoint_staging_pair( $request ) {
		$params     = $request->get_json_params();
		$remote_url = isset( $params['remote_url'] ) ? esc_url_raw( $params['remote_url'] ) : '';
		$site_type  = isset( $params['site_type'] ) ? sanitize_text_field( $params['site_type'] ) : '';

		if ( empty( $remote_url ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => __( 'Remote URL is required.', '5dp-backup-restore' ),
				),
				400
			);
		}

		// Store the pairing info.
		update_option( 'fdpbr_staging_pair', array(
			'remote_url' => untrailingslashit( $remote_url ),
			'site_type'  => $site_type,
			'paired_at'  => current_time( 'mysql', true ),
		), false );

		FiveDPBR_Logger::info(
			'staging',
			sprintf( 'Staging pair established with %s (type: %s).', $remote_url, $site_type )
		);

		global $wp_version;

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Pairing successful.', '5dp-backup-restore' ),
				'data'    => array(
					'site_url'       => home_url(),
					'wp_version'     => $wp_version,
					'plugin_version' => defined( 'FDPBR_VERSION' ) ? FDPBR_VERSION : '1.0.0',
				),
			),
			200
		);
	}

	/**
	 * Endpoint: Get pending changes for staging sync.
	 *
	 * Returns a list of files and database tables that have changed
	 * since the last sync.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function endpoint_staging_changes( $request ) {
		$params    = $request->get_json_params();
		$since     = isset( $params['since'] ) ? sanitize_text_field( $params['since'] ) : '';
		$direction = isset( $params['direction'] ) ? sanitize_text_field( $params['direction'] ) : 'pull';

		FiveDPBR_Logger::info( 'staging', sprintf( 'Staging changes requested (since: %s, direction: %s).', $since, $direction ) );

		// TODO: Implement change detection in a future staging phase.
		// For now, return an empty change set.
		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'files'     => array(),
					'tables'    => array(),
					'since'     => $since,
					'direction' => $direction,
					'timestamp' => current_time( 'mysql', true ),
				),
			),
			200
		);
	}

	/**
	 * Endpoint: Synchronize staging changes.
	 *
	 * Applies a set of changes between production and staging.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function endpoint_staging_sync( $request ) {
		$params    = $request->get_json_params();
		$direction = isset( $params['direction'] ) ? sanitize_text_field( $params['direction'] ) : 'pull';
		$scope     = isset( $params['scope'] ) ? $params['scope'] : array();

		FiveDPBR_Logger::info( 'staging', sprintf( 'Staging sync initiated (direction: %s).', $direction ) );

		// TODO: Implement full sync in a future staging phase.
		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Sync initiated.', '5dp-backup-restore' ),
				'data'    => array(
					'direction' => $direction,
					'scope'     => $scope,
					'timestamp' => current_time( 'mysql', true ),
				),
			),
			200
		);
	}

	/**
	 * Endpoint: Receive push data from the other site.
	 *
	 * Accepts file and database changes pushed from a remote site.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function endpoint_staging_push( $request ) {
		$body    = $request->get_body();
		$changes = json_decode( $body, true );

		if ( empty( $changes ) || ! is_array( $changes ) ) {
			return new WP_REST_Response(
				array( 'success' => false, 'message' => __( 'No changes provided.', '5dp-backup-restore' ) ),
				400
			);
		}

		FiveDPBR_Logger::info( 'staging', sprintf( 'Push received: %d changes.', count( $changes ) ) );

		$applied = FiveDPBR_Staging_Sync::apply_remote_changes( $changes );

		return new WP_REST_Response(
			array(
				'success' => true,
				'applied' => $applied,
			),
			200
		);
	}

	/**
	 * Endpoint: Serve pull data to the requesting site.
	 *
	 * Packages and serves changes that the remote site is pulling.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response
	 */
	public function endpoint_staging_pull( $request ) {
		FiveDPBR_Logger::info( 'staging', 'Pull request received.' );

		$changes = FiveDPBR_Staging_Sync::package_local_changes_for_remote();

		return new WP_REST_Response(
			array(
				'success' => true,
				'changes' => $changes,
			),
			200
		);
	}

	// =========================================================================
	// File Sync Endpoints
	// =========================================================================

	/**
	 * Endpoint: Compare file hashes.
	 *
	 * Receives source file hashes, compares with local files,
	 * returns lists of needed and deleted files.
	 *
	 * @since 1.0.76
	 */
	public function endpoint_staging_compare_files( $request ) {
		$params       = $request->get_json_params();
		$source_files = isset( $params['files'] ) ? $params['files'] : array();

		if ( empty( $source_files ) ) {
			return new WP_REST_Response(
				array( 'success' => false, 'message' => __( 'No file hashes provided.', '5dp-backup-restore' ) ),
				400
			);
		}

		$local_files = FiveDPBR_Staging_Tracker::get_content_hashes();

		$needed  = array();
		$deleted = array();

		// Files in source but not here, or with different hashes → we need them.
		foreach ( $source_files as $path => $hash ) {
			if ( ! isset( $local_files[ $path ] ) || $local_files[ $path ] !== $hash ) {
				$needed[] = $path;
			}
		}

		// Files here but not in source → should be deleted.
		foreach ( $local_files as $path => $hash ) {
			if ( ! isset( $source_files[ $path ] ) ) {
				$deleted[] = $path;
			}
		}

		FiveDPBR_Logger::info( 'staging', sprintf( 'File comparison: %d needed, %d to delete.', count( $needed ), count( $deleted ) ) );

		return new WP_REST_Response(
			array(
				'success' => true,
				'needed'  => $needed,
				'deleted' => $deleted,
			),
			200
		);
	}

	/**
	 * Validate a relative wp-content file path for safety.
	 *
	 * @param string $path Relative path.
	 * @return bool|WP_Error True if valid, WP_Error if not.
	 */
	private function validate_file_path( $path ) {
		$allowed_prefixes = array( 'themes/', 'plugins/', 'uploads/' );
		$valid            = false;

		foreach ( $allowed_prefixes as $prefix ) {
			if ( 0 === strpos( $path, $prefix ) ) {
				$valid = true;
				break;
			}
		}

		if ( ! $valid ) {
			return new WP_Error( 'invalid_path', __( 'Path must start with themes/, plugins/, or uploads/.', '5dp-backup-restore' ) );
		}

		if ( false !== strpos( $path, '..' ) ) {
			return new WP_Error( 'traversal', __( 'Directory traversal not allowed.', '5dp-backup-restore' ) );
		}

		// Skip our own plugin directory.
		$own_dir = 'plugins/' . dirname( FDPBR_PLUGIN_BASENAME ) . '/';
		if ( 0 === strpos( $path, $own_dir ) ) {
			return new WP_Error( 'self_skip', __( 'Cannot modify the plugin\'s own files.', '5dp-backup-restore' ) );
		}

		return true;
	}

	/**
	 * Endpoint: Receive a file (or chunk).
	 *
	 * @since 1.0.76
	 */
	public function endpoint_staging_receive_file( $request ) {
		$file_path   = $request->get_header( 'X-FDPBR-File-Path' );
		$part_index  = (int) $request->get_header( 'X-FDPBR-Part-Index' );
		$total_parts = (int) $request->get_header( 'X-FDPBR-Total-Parts' );

		if ( empty( $file_path ) ) {
			return new WP_REST_Response(
				array( 'success' => false, 'message' => __( 'Missing file path header.', '5dp-backup-restore' ) ),
				400
			);
		}

		$valid = $this->validate_file_path( $file_path );
		if ( is_wp_error( $valid ) ) {
			return new WP_REST_Response(
				array( 'success' => false, 'message' => $valid->get_error_message() ),
				400
			);
		}

		$body = $request->get_body();
		if ( empty( $body ) ) {
			return new WP_REST_Response(
				array( 'success' => false, 'message' => __( 'Empty file body.', '5dp-backup-restore' ) ),
				400
			);
		}

		$dest = wp_normalize_path( WP_CONTENT_DIR . '/' . $file_path );
		wp_mkdir_p( dirname( $dest ) );

		if ( $total_parts > 1 && $part_index > 0 ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			$written = file_put_contents( $dest, $body, FILE_APPEND );
		} else {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			$written = file_put_contents( $dest, $body );
		}

		if ( false === $written ) {
			return new WP_REST_Response(
				array( 'success' => false, 'message' => __( 'Failed to write file.', '5dp-backup-restore' ) ),
				500
			);
		}

		$complete = ( $total_parts <= 1 ) || ( $part_index + 1 >= $total_parts );

		if ( $complete ) {
			FiveDPBR_Logger::info( 'staging', sprintf( 'File received: %s (%s)', $file_path, size_format( filesize( $dest ) ) ) );
		}

		return new WP_REST_Response(
			array( 'success' => true, 'complete' => $complete ),
			200
		);
	}

	/**
	 * Endpoint: Delete files.
	 *
	 * @since 1.0.76
	 */
	public function endpoint_staging_delete_files( $request ) {
		$params = $request->get_json_params();
		$files  = isset( $params['files'] ) ? $params['files'] : array();

		if ( empty( $files ) ) {
			return new WP_REST_Response(
				array( 'success' => true, 'deleted' => 0 ),
				200
			);
		}

		$deleted = 0;

		foreach ( $files as $file_path ) {
			$valid = $this->validate_file_path( $file_path );
			if ( is_wp_error( $valid ) ) {
				continue;
			}

			$abs = wp_normalize_path( WP_CONTENT_DIR . '/' . $file_path );
			if ( file_exists( $abs ) ) {
				wp_delete_file( $abs );
				++$deleted;
			}
		}

		FiveDPBR_Logger::info( 'staging', sprintf( 'Deleted %d files from remote request.', $deleted ) );

		return new WP_REST_Response(
			array( 'success' => true, 'deleted' => $deleted ),
			200
		);
	}

	/**
	 * Endpoint: Return file hash manifest.
	 *
	 * @since 1.0.76
	 */
	public function endpoint_staging_hash_manifest( $request ) {
		$hashes = FiveDPBR_Staging_Tracker::get_content_hashes();

		return new WP_REST_Response(
			array(
				'success' => true,
				'files'   => $hashes,
			),
			200
		);
	}

	/**
	 * Endpoint: Serve a file for pull.
	 *
	 * @since 1.0.76
	 */
	public function endpoint_staging_serve_file( $request ) {
		$file_path = $request->get_param( 'path' );

		if ( empty( $file_path ) ) {
			return new WP_REST_Response(
				array( 'success' => false, 'message' => __( 'Missing path parameter.', '5dp-backup-restore' ) ),
				400
			);
		}

		$valid = $this->validate_file_path( $file_path );
		if ( is_wp_error( $valid ) ) {
			return new WP_REST_Response(
				array( 'success' => false, 'message' => $valid->get_error_message() ),
				400
			);
		}

		$abs = wp_normalize_path( WP_CONTENT_DIR . '/' . $file_path );

		if ( ! file_exists( $abs ) ) {
			return new WP_REST_Response(
				array( 'success' => false, 'message' => __( 'File not found.', '5dp-backup-restore' ) ),
				404
			);
		}

		$size = filesize( $abs );

		// For files under 10MB, serve directly.
		if ( $size <= 10 * 1024 * 1024 ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$content = file_get_contents( $abs );

			return new WP_REST_Response(
				array(
					'success'  => true,
					'content'  => base64_encode( $content ),
					'size'     => $size,
					'encoding' => 'base64',
				),
				200
			);
		}

		// For large files, serve the requested part.
		$part       = (int) $request->get_param( 'part' );
		$chunk_size = 10 * 1024 * 1024;
		$total      = (int) ceil( $size / $chunk_size );
		$offset     = $part * $chunk_size;
		$length     = min( $chunk_size, $size - $offset );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		$fh = fopen( $abs, 'r' );
		fseek( $fh, $offset );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
		$chunk = fread( $fh, $length );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		fclose( $fh );

		return new WP_REST_Response(
			array(
				'success'     => true,
				'content'     => base64_encode( $chunk ),
				'part'        => $part,
				'total_parts' => $total,
				'size'        => $size,
				'encoding'    => 'base64',
			),
			200
		);
	}

	/**
	 * Endpoint: Log a sync event from the remote site.
	 *
	 * @since 1.0.83
	 */
	public function endpoint_staging_log_sync( $request ) {
		$params = $request->get_json_params();

		$entry = array(
			'direction'  => isset( $params['direction'] ) ? sanitize_text_field( $params['direction'] ) : '',
			'message'    => isset( $params['message'] ) ? sanitize_text_field( $params['message'] ) : '',
			'details'    => isset( $params['details'] ) ? sanitize_text_field( $params['details'] ) : '',
			'from'       => isset( $params['from'] ) ? esc_url_raw( $params['from'] ) : '',
			'timestamp'  => current_time( 'mysql', true ),
		);

		$log = get_option( 'fdpbr_remote_sync_log', array() );
		array_unshift( $log, $entry );
		$log = array_slice( $log, 0, 50 ); // Keep last 50 entries.
		update_option( 'fdpbr_remote_sync_log', $log, false );

		return new WP_REST_Response( array( 'success' => true ), 200 );
	}

	/**
	 * Endpoint: Get sync log entries.
	 *
	 * @since 1.0.83
	 */
	public function endpoint_staging_get_sync_log( $request ) {
		$log = get_option( 'fdpbr_remote_sync_log', array() );

		return new WP_REST_Response(
			array(
				'success' => true,
				'entries' => $log,
			),
			200
		);
	}
}
