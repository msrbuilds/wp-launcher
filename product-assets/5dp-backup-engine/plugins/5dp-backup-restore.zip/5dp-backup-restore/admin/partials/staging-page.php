<?php
/**
 * Staging page template.
 *
 * @package    FiveDPBR
 * @subpackage FiveDPBR/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
global $wpdb;
$staging_table = $wpdb->prefix . 'fdpbr_staging';
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
$staging_sites = $wpdb->get_results( "SELECT * FROM {$staging_table} WHERE status != 'deleted' ORDER BY created_at DESC" );
// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

$active_tab = isset( $_GET['staging_tab'] ) ? sanitize_key( $_GET['staging_tab'] ) : 'server'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>
<div class="fdpbr-app">
	<?php include FDPBR_PLUGIN_DIR . 'admin/partials/header-nav.php'; ?>

	<div class="fdpbr-content">

		<!-- Staging Tabs -->
		<div class="fdpbr-section-card">
			<div class="fdpbr-section-card__header">
				<div>
					<h2><?php esc_html_e( 'Staging', '5dp-backup-restore' ); ?></h2>
					<p class="fdpbr-section-card__desc"><?php esc_html_e( 'Create staging copies of your site and sync changes.', '5dp-backup-restore' ); ?></p>
				</div>
			</div>
			<div class="fdpbr-section-card__body" style="padding: 0;">

				<!-- Tab Navigation -->
				<div class="fdpbr-tab-nav">
					<a href="<?php echo esc_url( add_query_arg( 'staging_tab', 'server' ) ); ?>"
					   class="fdpbr-tab-nav__item <?php echo 'server' === $active_tab ? 'fdpbr-tab-nav__item--active' : ''; ?>">
						<span class="dashicons dashicons-admin-multisite"></span>
						<?php esc_html_e( 'Server Staging', '5dp-backup-restore' ); ?>
					</a>
					<a href="<?php echo esc_url( add_query_arg( 'staging_tab', 'local' ) ); ?>"
					   class="fdpbr-tab-nav__item <?php echo 'local' === $active_tab ? 'fdpbr-tab-nav__item--active' : ''; ?>">
						<span class="dashicons dashicons-laptop"></span>
						<?php esc_html_e( 'Local ↔ Live', '5dp-backup-restore' ); ?>
					</a>
				</div>

				<?php if ( 'server' === $active_tab ) : ?>
					<!-- Server Staging -->
					<div class="fdpbr-section-card__body">
						<?php if ( empty( $staging_sites ) ) : ?>
							<div class="fdpbr-empty-state">
								<div class="fdpbr-empty-state__icon">
									<span class="dashicons dashicons-admin-multisite"></span>
								</div>
								<h3 class="fdpbr-empty-state__title"><?php esc_html_e( 'No Staging Sites', '5dp-backup-restore' ); ?></h3>
								<p class="fdpbr-empty-state__desc"><?php esc_html_e( 'Create a staging copy to safely test changes before going live.', '5dp-backup-restore' ); ?></p>
							</div>
						<?php else : ?>
							<div class="fdpbr-feature-grid">
								<?php
								$is_staging = defined( 'FDPBR_IS_STAGING' ) && FDPBR_IS_STAGING;
								foreach ( $staging_sites as $site ) :
									// Count pending changes for each direction.
									$stg_log_table  = $site->staging_prefix . 'fdpbr_change_log';
									$live_log_table = $wpdb->prefix . 'fdpbr_change_log';

									// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
									$pending_push = (int) $wpdb->get_var(
										$wpdb->prepare( "SELECT COUNT(*) FROM {$stg_log_table} WHERE staging_id = %d AND source = 'staging' AND synced = 0", $site->id )
									);
									// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
									$pending_pull = (int) $wpdb->get_var(
										$wpdb->prepare( "SELECT COUNT(*) FROM {$live_log_table} WHERE staging_id = %d AND source = 'live' AND synced = 0", $site->id )
									);

									// Direction labels depend on which site we're on.
									// to_live = apply staging changes to live DB.
									// to_staging = apply live changes to staging DB.
									if ( $is_staging ) {
										$to_live_label    = __( 'Push to Live', '5dp-backup-restore' );
										$to_staging_label = __( 'Pull from Live', '5dp-backup-restore' );
									} else {
										$to_live_label    = __( 'Pull from Staging', '5dp-backup-restore' );
										$to_staging_label = __( 'Push to Staging', '5dp-backup-restore' );
									}
								?>
									<div class="fdpbr-storage-card fdpbr-staging-card">
										<div class="fdpbr-storage-card__header">
											<div class="fdpbr-storage-card__header-left">
												<h3><?php echo esc_html( $site->name ); ?></h3>
												<span class="fdpbr-badge fdpbr-badge--<?php echo 'active' === $site->status ? 'success' : 'inactive'; ?>">
													<?php echo esc_html( ucfirst( $site->status ) ); ?>
												</span>
											</div>
											<div class="fdpbr-storage-card__header-actions">
												<a href="<?php echo esc_url( $site->staging_url ); ?>" target="_blank" class="fdpbr-staging-action-link"><span class="dashicons dashicons-external"></span> <?php esc_html_e( 'Open', '5dp-backup-restore' ); ?></a>
												<button type="button" class="fdpbr-staging-action-link fdpbr-staging-action-link--danger fdpbr-delete-staging" data-id="<?php echo esc_attr( $site->id ); ?>"><span class="dashicons dashicons-trash"></span> <?php esc_html_e( 'Delete', '5dp-backup-restore' ); ?></button>
											</div>
										</div>
										<div class="fdpbr-storage-card__body">
											<p class="fdpbr-storage-card__meta">
												<?php echo esc_html( $site->staging_url ); ?>
											</p>
											<?php if ( $site->last_sync_at ) : ?>
												<p class="fdpbr-storage-card__meta">
													<?php
													/* translators: %s: human time diff */
													printf( esc_html__( 'Last synced %s ago', '5dp-backup-restore' ), esc_html( human_time_diff( strtotime( $site->last_sync_at ) ) ) );
													?>
												</p>
											<?php endif; ?>
										</div>

										<!-- Sync Panel (always visible) -->
										<div class="fdpbr-sync-panel fdpbr-sync-panel--open" data-id="<?php echo esc_attr( $site->id ); ?>">
											<div class="fdpbr-sync-panel__direction">
												<span class="fdpbr-sync-panel__label"><?php esc_html_e( 'Direction', '5dp-backup-restore' ); ?></span>
												<div class="fdpbr-btn-group" data-name="sync_direction">
													<button type="button" class="fdpbr-btn-group__item fdpbr-btn-group__item--active" data-value="to_live">
														<?php echo esc_html( $to_live_label ); ?>
														<?php if ( $pending_push > 0 ) : ?>
															<span class="fdpbr-sync-pending-count" data-direction="push"><?php echo esc_html( $pending_push ); ?></span>
														<?php endif; ?>
													</button>
													<button type="button" class="fdpbr-btn-group__item" data-value="to_staging">
														<?php echo esc_html( $to_staging_label ); ?>
														<?php if ( $pending_pull > 0 ) : ?>
															<span class="fdpbr-sync-pending-count" data-direction="pull"><?php echo esc_html( $pending_pull ); ?></span>
														<?php endif; ?>
													</button>
												</div>
											</div>
											<div class="fdpbr-sync-panel__center">
												<label class="fdpbr-sync-panel__check">
													<input type="checkbox" class="fdpbr-sync-db" checked>
													<span class="fdpbr-check-box"></span>
													<?php esc_html_e( 'Database', '5dp-backup-restore' ); ?>
												</label>
												<label class="fdpbr-sync-panel__check">
													<input type="checkbox" class="fdpbr-sync-files" checked>
													<span class="fdpbr-check-box"></span>
													<?php esc_html_e( 'Files', '5dp-backup-restore' ); ?>
												</label>
											</div>
											<div class="fdpbr-sync-panel__center">
												<button type="button" class="fdpbr-btn fdpbr-btn--primary fdpbr-btn--small fdpbr-start-sync"><?php esc_html_e( 'Start Sync', '5dp-backup-restore' ); ?></button>
											</div>
											<div class="fdpbr-sync-panel__result" style="display: none;"></div>
										</div>
									</div>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>

						<div class="fdpbr-staging-create">
							<input type="text" class="fdpbr-input fdpbr-staging-create__input" id="fdpbr-staging-name" value="staging" placeholder="<?php esc_attr_e( 'Directory name', '5dp-backup-restore' ); ?>">
							<button type="button" id="fdpbr-create-staging" class="fdpbr-btn fdpbr-btn--primary">
								<span class="dashicons dashicons-plus"></span>
								<?php esc_html_e( 'Create Staging Site', '5dp-backup-restore' ); ?>
							</button>
						</div>
					</div>

				<?php
				// --- Change Log Section ---
				if ( ! empty( $staging_sites ) ) :
						$live_log = $wpdb->prefix . 'fdpbr_change_log';

						// Build UNION query to combine live + staging change logs.
						$union_parts = array( "SELECT * FROM {$live_log}" );
						foreach ( $staging_sites as $_stg ) {
							$stg_log = $_stg->staging_prefix . 'fdpbr_change_log';
							// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
							$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $stg_log ) );
							if ( $exists ) {
								$union_parts[] = "SELECT * FROM {$stg_log}";
							}
						}
						$union_sql = '(' . implode( ' UNION ALL ', $union_parts ) . ') AS combined_log';

						// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$initial_changes = $wpdb->get_results(
							"SELECT * FROM {$union_sql} ORDER BY detected_at DESC LIMIT 50"
						);
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$change_total = (int) $wpdb->get_var(
							"SELECT COUNT(*) FROM {$union_sql}"
						);

						$sync_history = get_option( 'fdpbr_sync_history', array() );
						$sync_history = array_reverse( $sync_history );
						$sync_history = array_slice( $sync_history, 0, 10 );
					?>
					<div class="fdpbr-section-card fdpbr-changelog-section">
						<div class="fdpbr-changelog-section__header" style="padding: 20px 24px 0;">
							<div>
								<h3 style="margin: 0; font-size: 15px; font-weight: 600; color: var(--fdpbr-gray-800);"><?php esc_html_e( 'Change Log', '5dp-backup-restore' ); ?></h3>
								<p style="margin: 2px 0 0; font-size: 12px; color: var(--fdpbr-gray-500);"><?php esc_html_e( 'Track changes between live and staging sites.', '5dp-backup-restore' ); ?></p>
							</div>
							<div class="fdpbr-changelog-filters">
								<select class="fdpbr-select fdpbr-changelog-filter" data-filter="source">
									<option value=""><?php esc_html_e( 'All Sources', '5dp-backup-restore' ); ?></option>
									<option value="live"><?php esc_html_e( 'Live', '5dp-backup-restore' ); ?></option>
									<option value="staging"><?php esc_html_e( 'Staging', '5dp-backup-restore' ); ?></option>
								</select>
								<select class="fdpbr-select fdpbr-changelog-filter" data-filter="synced">
									<option value=""><?php esc_html_e( 'All Status', '5dp-backup-restore' ); ?></option>
									<option value="pending"><?php esc_html_e( 'Pending', '5dp-backup-restore' ); ?></option>
									<option value="synced"><?php esc_html_e( 'Synced', '5dp-backup-restore' ); ?></option>
								</select>
								<select class="fdpbr-select fdpbr-changelog-filter" data-filter="change_type">
									<option value=""><?php esc_html_e( 'All Types', '5dp-backup-restore' ); ?></option>
									<option value="create"><?php esc_html_e( 'Created', '5dp-backup-restore' ); ?></option>
									<option value="update"><?php esc_html_e( 'Updated', '5dp-backup-restore' ); ?></option>
									<option value="delete"><?php esc_html_e( 'Deleted', '5dp-backup-restore' ); ?></option>
								</select>
							</div>
						</div>

						<?php if ( ! empty( $sync_history ) ) : ?>
						<div class="fdpbr-sync-history-summary">
							<h4 class="fdpbr-sync-history-summary__title"><?php esc_html_e( 'Recent Syncs', '5dp-backup-restore' ); ?></h4>
							<div class="fdpbr-sync-history-list">
								<?php
								foreach ( $sync_history as $h ) :
									$dir_label = ( 'staging_to_live' === $h['direction'] ) ? __( 'Push to Live', '5dp-backup-restore' ) : __( 'Pull to Staging', '5dp-backup-restore' );
									$dir_badge = ( 'staging_to_live' === $h['direction'] ) ? 'info' : 'success';
									$parts     = array();
									if ( ! empty( $h['db_changes'] ) ) {
										$parts[] = $h['db_changes'] . ' DB';
									}
									if ( ! empty( $h['files_synced'] ) ) {
										$parts[] = $h['files_synced'] . ' files';
									}
									$detail = ! empty( $parts ) ? implode( ', ', $parts ) : __( 'No changes', '5dp-backup-restore' );
								?>
								<div class="fdpbr-sync-history-item">
									<span class="fdpbr-badge fdpbr-badge--<?php echo esc_attr( $dir_badge ); ?>"><?php echo esc_html( $dir_label ); ?></span>
									<span class="fdpbr-sync-history-item__detail"><?php echo esc_html( $detail ); ?></span>
									<?php if ( ! empty( $h['errors'] ) ) : ?>
										<span class="fdpbr-badge fdpbr-badge--danger"><?php echo esc_html( $h['errors'] ); ?> error<?php echo (int) $h['errors'] !== 1 ? 's' : ''; ?></span>
									<?php endif; ?>
									<span class="fdpbr-sync-history-item__time"><?php echo esc_html( human_time_diff( strtotime( $h['completed_at'] ) ) ); ?> ago</span>
								</div>
								<?php endforeach; ?>
							</div>
						</div>
						<?php endif; ?>

						<div id="fdpbr-changelog-container">
							<?php if ( empty( $initial_changes ) ) : ?>
								<div class="fdpbr-changelog-empty">
									<span class="dashicons dashicons-list-view"></span>
									<p><?php esc_html_e( 'No changes tracked yet. Changes will appear here as you edit content.', '5dp-backup-restore' ); ?></p>
								</div>
							<?php else : ?>
								<table class="fdpbr-table" id="fdpbr-changelog-table">
									<thead>
										<tr>
											<th><?php esc_html_e( 'Type', '5dp-backup-restore' ); ?></th>
											<th><?php esc_html_e( 'Object', '5dp-backup-restore' ); ?></th>
											<th><?php esc_html_e( 'Source', '5dp-backup-restore' ); ?></th>
											<th><?php esc_html_e( 'Status', '5dp-backup-restore' ); ?></th>
											<th><?php esc_html_e( 'Date', '5dp-backup-restore' ); ?></th>
										</tr>
									</thead>
									<tbody id="fdpbr-changelog-tbody">
										<?php
										foreach ( $initial_changes as $change ) :
											$cdata = json_decode( $change->object_data, true );

											switch ( $change->object_type ) {
												case 'post':
													$clabel   = isset( $cdata['post_title'] ) ? $cdata['post_title'] : 'Post #' . $change->object_id;
													$obj_icon = 'dashicons-admin-post';
													break;
												case 'option':
													$clabel   = isset( $cdata['option_name'] ) ? $cdata['option_name'] : 'Option';
													$obj_icon = 'dashicons-admin-generic';
													break;
												case 'term':
													$clabel   = isset( $cdata['name'] ) ? $cdata['name'] : 'Term #' . $change->object_id;
													$obj_icon = 'dashicons-tag';
													break;
												case 'nav_menu':
													$clabel   = 'Menu #' . $change->object_id;
													$obj_icon = 'dashicons-menu';
													break;
												case 'widget':
													$clabel   = isset( $cdata['option_name'] ) ? $cdata['option_name'] : 'Widget';
													$obj_icon = 'dashicons-welcome-widgets-menus';
													break;
												default:
													$clabel   = $change->object_type . ' #' . $change->object_id;
													$obj_icon = 'dashicons-admin-generic';
											}

											$type_badges  = array( 'create' => 'success', 'update' => 'warning', 'delete' => 'danger' );
											$type_badge   = isset( $type_badges[ $change->change_type ] ) ? $type_badges[ $change->change_type ] : 'info';
											$source_badge = ( 'live' === $change->source ) ? 'info' : 'success';
											$status_badge = $change->synced ? 'success' : 'warning';
											$status_text  = $change->synced ? __( 'Synced', '5dp-backup-restore' ) : __( 'Pending', '5dp-backup-restore' );
										?>
										<tr>
											<td><span class="fdpbr-badge fdpbr-badge--<?php echo esc_attr( $type_badge ); ?>"><?php echo esc_html( ucfirst( $change->change_type ) ); ?></span></td>
											<td>
												<span class="dashicons <?php echo esc_attr( $obj_icon ); ?>" style="font-size: 14px; width: 14px; height: 14px; margin-right: 4px; color: var(--fdpbr-gray-400);"></span>
												<?php echo esc_html( $clabel ); ?>
											</td>
											<td><span class="fdpbr-badge fdpbr-badge--<?php echo esc_attr( $source_badge ); ?>"><?php echo esc_html( ucfirst( $change->source ) ); ?></span></td>
											<td><span class="fdpbr-badge fdpbr-badge--<?php echo esc_attr( $status_badge ); ?>"><?php echo esc_html( $status_text ); ?></span></td>
											<td title="<?php echo esc_attr( $change->detected_at ); ?>"><?php echo esc_html( human_time_diff( strtotime( $change->detected_at ) ) ); ?> ago</td>
										</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
								<?php if ( $change_total > 50 ) : ?>
								<div style="padding: 16px; text-align: center;">
									<button type="button" id="fdpbr-changelog-load-more" class="fdpbr-btn fdpbr-btn--ghost fdpbr-btn--small" data-offset="50" data-total="<?php echo esc_attr( $change_total ); ?>">
										<?php
										/* translators: %d: number of remaining entries */
										printf( esc_html__( 'Load More (%d remaining)', '5dp-backup-restore' ), $change_total - 50 );
										?>
									</button>
								</div>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					</div>
					<?php endif; ?>

				<?php else : ?>
					<!-- Local ↔ Live -->
					<?php
					// Check local-initiated pairing (this site connected to a remote).
					$pairings       = get_option( 'fdpbr_remote_pairings', array() );
					$active_pairing = ! empty( $pairings ) ? end( $pairings ) : null;

					// Check remote-initiated pairing (a remote site connected to us).
					$remote_pair = get_option( 'fdpbr_staging_pair', null );

					if ( ! empty( $active_pairing ) ) {
						$is_paired    = true;
						$paired_url   = $active_pairing['remote_url'];
						$paired_key   = $active_pairing['remote_key'];
						$paired_at    = $active_pairing['paired_at'];
						$is_initiator = true; // We initiated the connection.
					} elseif ( ! empty( $remote_pair ) ) {
						$is_paired    = true;
						$paired_url   = $remote_pair['remote_url'];
						$paired_key   = ''; // We don't store the remote's key — they connect to us.
						$paired_at    = $remote_pair['paired_at'];
						$is_initiator = false; // Remote initiated.
					} else {
						$is_paired    = false;
						$is_initiator = false;
					}
					?>
					<div class="fdpbr-section-card__body">
						<?php if ( $is_initiator ) : ?>
						<!-- ===== Initiator (Local Site): Form + Sync Controls ===== -->
						<div class="fdpbr-fields-stack" id="fdpbr-remote-connect-form">
							<div class="fdpbr-field">
								<label class="fdpbr-field__label"><?php esc_html_e( 'Remote Site URL', '5dp-backup-restore' ); ?></label>
								<input type="url" class="fdpbr-input" id="fdpbr-remote-site-url"
									value="<?php echo esc_attr( $paired_url ); ?>"
									placeholder="https://example.com">
							</div>

							<div class="fdpbr-field">
								<label class="fdpbr-field__label"><?php esc_html_e( 'Remote Site Key', '5dp-backup-restore' ); ?></label>
								<input type="text" class="fdpbr-input" id="fdpbr-remote-site-key-display"
									value="<?php echo esc_attr( str_repeat( '*', max( 0, strlen( $paired_key ) - 8 ) ) . substr( $paired_key, -8 ) ); ?>"
									placeholder="<?php esc_attr_e( 'Enter the migration key from the remote site', '5dp-backup-restore' ); ?>"
									readonly>
								<input type="hidden" id="fdpbr-remote-site-key" value="<?php echo esc_attr( $paired_key ); ?>">
							</div>

							<div style="display: flex; gap: 12px; align-items: center;">
								<button type="button" id="fdpbr-disconnect-remote" class="fdpbr-btn fdpbr-btn--danger">
									<span class="dashicons dashicons-dismiss" style="margin-top: 3px;"></span>
									<?php esc_html_e( 'Disconnect', '5dp-backup-restore' ); ?>
								</button>
							</div>

							<!-- Sync Options -->
							<div class="fdpbr-sync-panel__center" style="justify-content: flex-start;">
								<label class="fdpbr-sync-panel__check">
									<input type="checkbox" id="fdpbr-remote-sync-db" checked>
									<span class="fdpbr-check-box"></span>
									<?php esc_html_e( 'Database', '5dp-backup-restore' ); ?>
								</label>
								<label class="fdpbr-sync-panel__check">
									<input type="checkbox" id="fdpbr-remote-sync-files" checked>
									<span class="fdpbr-check-box"></span>
									<?php esc_html_e( 'Files (themes, plugins, uploads)', '5dp-backup-restore' ); ?>
								</label>
							</div>

							<!-- Sync Actions -->
							<div style="display: flex; gap: 12px; flex-wrap: wrap;">
								<button type="button" id="fdpbr-pull-from-live" class="fdpbr-btn fdpbr-btn--secondary">
									<span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
									<?php esc_html_e( 'Pull from Live', '5dp-backup-restore' ); ?>
									<span class="fdpbr-sync-pending-count" id="fdpbr-remote-pull-count" style="display: none;"></span>
								</button>
								<button type="button" id="fdpbr-push-to-live" class="fdpbr-btn fdpbr-btn--secondary">
									<span class="dashicons dashicons-upload" style="margin-top: 3px;"></span>
									<?php esc_html_e( 'Push to Live', '5dp-backup-restore' ); ?>
									<span class="fdpbr-sync-pending-count" id="fdpbr-remote-push-count" style="display: none;"></span>
								</button>
								<button type="button" id="fdpbr-two-way-sync" class="fdpbr-btn fdpbr-btn--secondary">
									<span class="dashicons dashicons-update" style="margin-top: 3px;"></span>
									<?php esc_html_e( '2-Way Sync', '5dp-backup-restore' ); ?>
								</button>
							</div>

							<!-- Sync Activity Log -->
							<div class="fdpbr-mini-log" id="fdpbr-remote-sync-log" style="display: none;">
								<div class="fdpbr-mini-log__header">
									<span class="dashicons dashicons-list-view"></span>
									<?php esc_html_e( 'Sync Activity', '5dp-backup-restore' ); ?>
								</div>
								<div class="fdpbr-mini-log__body" id="fdpbr-remote-sync-log-body"></div>
							</div>
						</div>

						<?php elseif ( ! $is_paired ) : ?>
						<!-- ===== Unpaired: Connection Form ===== -->
						<div class="fdpbr-fields-stack" id="fdpbr-remote-connect-form">
							<div class="fdpbr-field">
								<label class="fdpbr-field__label"><?php esc_html_e( 'Pair with Remote Site', '5dp-backup-restore' ); ?></label>
								<p class="fdpbr-field__help"><?php esc_html_e( 'Connect your local development environment with a live site for 2-way sync.', '5dp-backup-restore' ); ?></p>
							</div>

							<div class="fdpbr-field">
								<label class="fdpbr-field__label"><?php esc_html_e( 'Remote Site URL', '5dp-backup-restore' ); ?></label>
								<input type="url" class="fdpbr-input" id="fdpbr-remote-site-url" placeholder="https://example.com">
							</div>

							<div class="fdpbr-field">
								<label class="fdpbr-field__label"><?php esc_html_e( 'Remote Site Key', '5dp-backup-restore' ); ?></label>
								<input type="text" class="fdpbr-input" id="fdpbr-remote-site-key"
									placeholder="<?php esc_attr_e( 'Enter the migration key from the remote site', '5dp-backup-restore' ); ?>">
							</div>

							<div>
								<button type="button" id="fdpbr-pair-remote" class="fdpbr-btn fdpbr-btn--primary">
									<?php esc_html_e( 'Connect & Pair', '5dp-backup-restore' ); ?>
								</button>
							</div>
						</div>

						<?php else : ?>
						<!-- ===== Non-initiator (Live/Remote Site): Connected Dashboard ===== -->
						<div class="fdpbr-fields-stack" id="fdpbr-remote-sync-dashboard">
							<div class="fdpbr-remote-connected-banner">
								<div class="fdpbr-remote-connected-banner__info">
									<span class="fdpbr-remote-connected-banner__icon dashicons dashicons-yes-alt"></span>
									<div>
										<strong><?php esc_html_e( 'Paired with', '5dp-backup-restore' ); ?></strong>
										<a href="<?php echo esc_url( $paired_url ); ?>" target="_blank" class="fdpbr-remote-connected-banner__url">
											<?php echo esc_html( preg_replace( '#^https?://#', '', $paired_url ) ); ?>
											<span class="dashicons dashicons-external" style="font-size: 14px; width: 14px; height: 14px; vertical-align: middle;"></span>
										</a>
										<span class="fdpbr-pairing-date"><?php
											printf( esc_html__( 'since %s', '5dp-backup-restore' ), esc_html( $paired_at ) );
										?></span>
									</div>
								</div>
								<button type="button" id="fdpbr-disconnect-remote" class="fdpbr-remote-connected-banner__disconnect" title="<?php esc_attr_e( 'Disconnect', '5dp-backup-restore' ); ?>">
									<span class="dashicons dashicons-dismiss"></span>
									<?php esc_html_e( 'Disconnect', '5dp-backup-restore' ); ?>
								</button>
							</div>

							<input type="hidden" id="fdpbr-remote-site-url" value="<?php echo esc_attr( $paired_url ); ?>">
							<input type="hidden" id="fdpbr-remote-site-key" value="">

							<p class="fdpbr-field__help" style="margin: 0;">
								<?php esc_html_e( 'This site was paired by the remote site. Push/pull operations are managed from the remote site.', '5dp-backup-restore' ); ?>
							</p>

							<!-- Sync Activity Log (always visible on live site) -->
							<?php $sync_log = get_option( 'fdpbr_remote_sync_log', array() ); ?>
							<div class="fdpbr-mini-log" id="fdpbr-remote-sync-log">
								<div class="fdpbr-mini-log__header">
									<span class="dashicons dashicons-list-view"></span>
									<?php esc_html_e( 'Sync Activity', '5dp-backup-restore' ); ?>
								</div>
								<div class="fdpbr-mini-log__body" id="fdpbr-remote-sync-log-body">
									<?php if ( empty( $sync_log ) ) : ?>
										<div class="fdpbr-mini-log__line fdpbr-mini-log__line--info"><?php esc_html_e( 'No sync activity yet.', '5dp-backup-restore' ); ?></div>
									<?php else : ?>
										<?php foreach ( $sync_log as $log_entry ) :
											$dir_icons = array( 'push' => '↑', 'pull' => '↓', 'two_way' => '↕' );
											$dir_icon  = isset( $dir_icons[ $log_entry['direction'] ] ) ? $dir_icons[ $log_entry['direction'] ] : '•';
											$time_str  = ! empty( $log_entry['timestamp'] ) ? human_time_diff( strtotime( $log_entry['timestamp'] ) ) . ' ago' : '';
										?>
										<div class="fdpbr-mini-log__line fdpbr-mini-log__line--success">
											<span class="fdpbr-mini-log__time"><?php echo esc_html( $time_str ); ?></span>
											<span class="fdpbr-mini-log__msg"><?php echo esc_html( $dir_icon . ' ' . $log_entry['message'] . ' — ' . $log_entry['details'] ); ?></span>
										</div>
										<?php endforeach; ?>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<?php endif; ?>
					</div>
				<?php endif; ?>

			</div>
		</div>

	</div>
</div>
