/**
 * 5DP Backup & Restore - Storage Page JavaScript
 *
 * Handles storage provider configuration, testing, and disconnection
 * via a modal-based UI with setup guides.
 *
 * @package FiveDPBR
 * @since   1.0.85
 */

(function( $ ) {
	'use strict';

	/**
	 * Setup guides for each storage provider.
	 * Each guide contains step-by-step HTML instructions.
	 */
	var setupGuides = {

		s3: '<h4>Amazon S3 / S3-Compatible Setup</h4>' +
			'<ol>' +
			'<li>Log in to the <strong>AWS Console</strong> &rarr; IAM &rarr; Users &rarr; Create a new user (or use existing).</li>' +
			'<li>Attach the <strong>AmazonS3FullAccess</strong> policy (or create a custom policy with <code>s3:PutObject</code>, <code>s3:GetObject</code>, <code>s3:ListBucket</code>, <code>s3:DeleteObject</code>).</li>' +
			'<li>Go to <strong>Security credentials</strong> tab &rarr; Create access key &rarr; Copy the <strong>Access Key ID</strong> and <strong>Secret Access Key</strong>.</li>' +
			'<li>Go to <strong>S3</strong> &rarr; Create a bucket (or use existing). Note the <strong>bucket name</strong> and <strong>region</strong>.</li>' +
			'</ol>' +
			'<p><strong>S3-Compatible services</strong> (Wasabi, DigitalOcean Spaces, Backblaze B2, MinIO, Cloudflare R2):<br>' +
			'Use the same fields but enter the service\'s <strong>Custom Endpoint</strong> URL, e.g.:<br>' +
			'<code>https://s3.wasabisys.com</code> &bull; <code>https://nyc3.digitaloceanspaces.com</code> &bull; <code>https://s3.us-west-001.backblazeb2.com</code></p>',

		gcs: '<h4>Google Cloud Storage Setup</h4>' +
			'<ol>' +
			'<li>Go to <strong>Google Cloud Console</strong> &rarr; select or create a project.</li>' +
			'<li>Navigate to <strong>Cloud Storage</strong> &rarr; Create a bucket. Note the <strong>bucket name</strong>.</li>' +
			'<li>Go to <strong>IAM & Admin</strong> &rarr; <strong>Service Accounts</strong> &rarr; Create a service account.</li>' +
			'<li>Grant it the <strong>Storage Object Admin</strong> role (or <code>storage.objects.*</code> permissions).</li>' +
			'<li>Click the service account &rarr; <strong>Keys</strong> tab &rarr; Add Key &rarr; Create new key &rarr; <strong>JSON</strong>.</li>' +
			'<li>A JSON file will download. Open it in a text editor and <strong>paste the entire contents</strong> into the "Service Account JSON Key" field below.</li>' +
			'</ol>',

		gdrive: '<h4>Google Drive Setup</h4>' +
			'<ol>' +
			'<li>Go to <strong>Google Cloud Console</strong> &rarr; APIs &amp; Services &rarr; <strong>Enable</strong> the Google Drive API.</li>' +
			'<li>Go to <strong>Credentials</strong> &rarr; Create Credentials &rarr; <strong>OAuth client ID</strong> &rarr; Application type: <strong>Web application</strong>.</li>' +
			'<li>Add <code>' + window.location.origin + '</code> as an authorized redirect URI.</li>' +
			'<li>Copy the <strong>Client ID</strong> and <strong>Client Secret</strong>.</li>' +
			'<li>To get tokens, use the <a href="https://developers.google.com/oauthplayground/" target="_blank" rel="noopener">Google OAuth Playground</a>:<br>' +
			'&bull; Click the gear icon &rarr; check "Use your own OAuth credentials" &rarr; enter your Client ID &amp; Secret.<br>' +
			'&bull; In Step 1, authorize scope: <code>https://www.googleapis.com/auth/drive.file</code><br>' +
			'&bull; In Step 2, exchange the authorization code for tokens.<br>' +
			'&bull; Copy the <strong>Access Token</strong> and <strong>Refresh Token</strong>.</li>' +
			'<li><strong>Folder ID</strong> (optional): Open the target folder in Google Drive &mdash; the ID is the last part of the URL:<br>' +
			'<code>https://drive.google.com/drive/folders/<strong>FOLDER_ID_HERE</strong></code></li>' +
			'</ol>',

		dropbox: '<h4>Dropbox Setup</h4>' +
			'<ol>' +
			'<li>Go to <a href="https://www.dropbox.com/developers/apps" target="_blank" rel="noopener">Dropbox App Console</a> &rarr; <strong>Create App</strong>.</li>' +
			'<li>Choose <strong>Scoped access</strong> &rarr; <strong>Full Dropbox</strong> (or App folder) &rarr; name your app.</li>' +
			'<li>In the app Settings tab, copy the <strong>App Key</strong> and <strong>App Secret</strong>.</li>' +
			'<li>Under Permissions tab, enable: <code>files.metadata.read</code>, <code>files.content.write</code>, <code>files.content.read</code>. Click Submit.</li>' +
			'<li>To get tokens, use the OAuth 2 flow:<br>' +
			'&bull; Visit: <code>https://www.dropbox.com/oauth2/authorize?client_id=YOUR_APP_KEY&amp;response_type=code&amp;token_access_type=offline</code><br>' +
			'&bull; Authorize the app and copy the <strong>authorization code</strong>.<br>' +
			'&bull; Exchange it for tokens via curl or Postman:<br>' +
			'<code>curl -X POST https://api.dropboxapi.com/oauth2/token -d code=AUTH_CODE -d grant_type=authorization_code -d client_id=APP_KEY -d client_secret=APP_SECRET</code><br>' +
			'&bull; Copy the <strong>access_token</strong> and <strong>refresh_token</strong> from the response.</li>' +
			'</ol>',

		onedrive: '<h4>OneDrive / Microsoft Setup</h4>' +
			'<ol>' +
			'<li>Go to <a href="https://portal.azure.com/#blade/Microsoft_AAD_RegisteredApps/ApplicationsListBlade" target="_blank" rel="noopener">Azure Portal &rarr; App Registrations</a> &rarr; <strong>New registration</strong>.</li>' +
			'<li>Name your app. Under Redirect URI, select <strong>Web</strong> and enter: <code>' + window.location.origin + '</code></li>' +
			'<li>Copy the <strong>Application (client) ID</strong>.</li>' +
			'<li>Go to <strong>Certificates &amp; Secrets</strong> &rarr; New client secret &rarr; copy the <strong>Value</strong> (this is your Client Secret).</li>' +
			'<li>Go to <strong>API Permissions</strong> &rarr; Add permission &rarr; Microsoft Graph &rarr; Delegated &rarr; add <code>Files.ReadWrite</code>, <code>offline_access</code>.</li>' +
			'<li>To get tokens:<br>' +
			'&bull; Visit: <code>https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id=YOUR_CLIENT_ID&amp;response_type=code&amp;redirect_uri=' + encodeURIComponent( window.location.origin ) + '&amp;scope=Files.ReadWrite%20offline_access</code><br>' +
			'&bull; Authorize and copy the <strong>code</strong> from the redirect URL.<br>' +
			'&bull; Exchange for tokens:<br>' +
			'<code>curl -X POST https://login.microsoftonline.com/common/oauth2/v2.0/token -d client_id=YOUR_CLIENT_ID -d client_secret=YOUR_SECRET -d code=AUTH_CODE -d redirect_uri=YOUR_REDIRECT_URI -d grant_type=authorization_code</code><br>' +
			'&bull; Copy the <strong>access_token</strong> and <strong>refresh_token</strong>.</li>' +
			'</ol>',

		ftp: '<h4>FTP Setup</h4>' +
			'<ol>' +
			'<li>Get FTP credentials from your hosting control panel (cPanel, Plesk, etc.) or your server administrator.</li>' +
			'<li>You need: <strong>Host</strong> (e.g., <code>ftp.example.com</code>), <strong>Username</strong>, and <strong>Password</strong>.</li>' +
			'<li>The default port is <strong>21</strong>. Only change if your host uses a non-standard port.</li>' +
			'<li><strong>Remote Path</strong>: The directory on the remote server where backups will be stored (e.g., <code>/backups</code>). Created automatically if it doesn\'t exist.</li>' +
			'<li><strong>Passive Mode</strong>: Leave enabled (recommended). Only disable if your server specifically requires active mode.</li>' +
			'</ol>' +
			'<p><strong>Note:</strong> FTP transfers data unencrypted. Use SFTP for secure transfers when possible.</p>',

		sftp: '<h4>SFTP Setup</h4>' +
			'<ol>' +
			'<li>Get SFTP credentials from your hosting control panel or server administrator.</li>' +
			'<li>You need: <strong>Host</strong>, <strong>Username</strong>, and either a <strong>Password</strong> or <strong>Private Key</strong>.</li>' +
			'<li>The default port is <strong>22</strong>. Only change if your host uses a non-standard port.</li>' +
			'<li><strong>Password vs Private Key</strong>: You can use either one. For key-based auth, paste the full PEM private key content (starts with <code>-----BEGIN RSA PRIVATE KEY-----</code> or <code>-----BEGIN OPENSSH PRIVATE KEY-----</code>).</li>' +
			'<li><strong>Generating a key pair</strong> (if needed):<br>' +
			'&bull; Run: <code>ssh-keygen -t rsa -b 4096 -f my_backup_key</code><br>' +
			'&bull; Add the <strong>public key</strong> (<code>my_backup_key.pub</code>) to the server\'s <code>~/.ssh/authorized_keys</code>.<br>' +
			'&bull; Paste the <strong>private key</strong> (<code>my_backup_key</code>) contents into the field below.</li>' +
			'</ol>',

		webdav: '<h4>WebDAV Setup</h4>' +
			'<ol>' +
			'<li>Get the <strong>WebDAV URL</strong> from your provider. Common services:<br>' +
			'&bull; <strong>Nextcloud</strong>: <code>https://your-nextcloud.com/remote.php/dav/files/USERNAME/</code><br>' +
			'&bull; <strong>ownCloud</strong>: <code>https://your-owncloud.com/remote.php/webdav/</code><br>' +
			'&bull; <strong>Box.com</strong>: <code>https://dav.box.com/dav</code><br>' +
			'&bull; <strong>4shared</strong>: <code>https://webdav.4shared.com/</code></li>' +
			'<li>Enter your <strong>Username</strong> and <strong>Password</strong> (some services may require an app-specific password).</li>' +
			'<li><strong>Remote Path</strong>: The directory where backups will be stored (e.g., <code>/backups</code>). Created automatically if supported by the server.</li>' +
			'</ol>'
	};

	var StorageManager = {

		init: function() {
			this.bindConfigure();
			this.bindTest();
		},

		/**
		 * Build and open the configuration modal for a provider.
		 */
		bindConfigure: function() {
			var self = this;

			$( document ).on( 'click', '.fdpbr-configure-storage', function() {
				var provider = $( this ).data( 'provider' );
				var info     = self.getProviderInfo( provider );

				if ( ! info ) {
					FDPBR.showToast( 'Unknown provider.', 'error' );
					return;
				}

				self.openModal( provider, info );
			});
		},

		/**
		 * Test connection button (on the card, not in modal).
		 */
		bindTest: function() {
			$( document ).on( 'click', '.fdpbr-test-storage', function( e ) {
				e.stopPropagation();
				var $btn     = $( this );
				var provider = $btn.data( 'provider' );
				var btnText  = $btn.text();

				$btn.text( 'Testing...' ).prop( 'disabled', true );

				$.ajax({
					url:  fdpbrAdmin.ajax_url,
					type: 'POST',
					data: {
						action:   'fdpbr_test_storage',
						nonce:    fdpbrAdmin.nonce,
						provider: provider
					},
					success: function( response ) {
						if ( response.success ) {
							FDPBR.showToast( response.data.message || 'Connection successful!', 'success' );
						} else {
							FDPBR.showToast( response.data.message || 'Connection failed.', 'error' );
						}
					},
					error: function() {
						FDPBR.showToast( 'Network error.', 'error' );
					},
					complete: function() {
						$btn.text( btnText ).prop( 'disabled', false );
					}
				});
			});
		},

		/**
		 * Get provider info from localized data.
		 */
		getProviderInfo: function( slug ) {
			if ( typeof fdpbrStorage === 'undefined' || ! fdpbrStorage.providers ) {
				return null;
			}
			return fdpbrStorage.providers[ slug ] || null;
		},

		/**
		 * Open the configuration modal.
		 */
		openModal: function( provider, info ) {
			var self = this;

			// Remove any existing modal.
			$( '.fdpbr-modal-overlay' ).remove();

			var isConfigured = info.configured || false;
			var title        = info.name;
			var fields       = info.fields || [];
			var saved        = info.saved || {};

			// Build field HTML.
			var fieldsHtml = '';

			// Setup guide (collapsible).
			var guide = setupGuides[ provider ] || '';
			if ( guide ) {
				fieldsHtml += '<div class="fdpbr-setup-guide">' +
					'<button type="button" class="fdpbr-setup-guide__toggle">' +
						'<span class="dashicons dashicons-editor-help"></span> How to get these credentials' +
						'<span class="fdpbr-setup-guide__arrow dashicons dashicons-arrow-down-alt2"></span>' +
					'</button>' +
					'<div class="fdpbr-setup-guide__content" style="display:none;">' + guide + '</div>' +
				'</div>';
			}

			if ( fields.length === 0 ) {
				// Local storage — no fields.
				fieldsHtml += '<p class="fdpbr-field__help">Local storage uses the default backup directory on your server. No configuration needed.</p>' +
					'<p class="fdpbr-field__help"><strong>Path:</strong> <code>wp-content/5dp-backups/</code></p>';
			} else {
				for ( var i = 0; i < fields.length; i++ ) {
					var f     = fields[ i ];
					var val   = saved[ f.name ] || f['default'] || '';
					var type  = f.type || 'text';
					var req   = f.required ? ' required' : '';

					fieldsHtml += '<div class="fdpbr-field">';
					fieldsHtml += '<label class="fdpbr-field__label">' + self.esc( f.label );
					if ( f.required ) {
						fieldsHtml += ' <span style="color: var(--fdpbr-danger);">*</span>';
					}
					fieldsHtml += '</label>';

					if ( type === 'checkbox' ) {
						var checked = ( val === '1' || val === true || val === 'true' ) ? ' checked' : '';
						fieldsHtml += '<label class="fdpbr-sync-panel__check">' +
							'<input type="checkbox" class="fdpbr-storage-field" data-name="' + self.esc( f.name ) + '"' + checked + '>' +
							'<span class="fdpbr-check-box"></span> ' + self.esc( f.label ) +
							'</label>';
					} else if ( type === 'textarea' ) {
						fieldsHtml += '<textarea class="fdpbr-input fdpbr-storage-field fdpbr-storage-textarea" data-name="' + self.esc( f.name ) + '"' +
							( f.placeholder ? ' placeholder="' + self.esc( f.placeholder ) + '"' : '' ) +
							' rows="5"' + req + '>' + self.esc( val ) + '</textarea>';
					} else {
						fieldsHtml += '<input type="' + type + '" class="fdpbr-input fdpbr-storage-field" data-name="' + self.esc( f.name ) + '"' +
							' value="' + self.esc( val ) + '"' +
							( f.placeholder ? ' placeholder="' + self.esc( f.placeholder ) + '"' : '' ) +
							req + '>';
					}

					if ( f.description ) {
						fieldsHtml += '<p class="fdpbr-field__desc">' + self.esc( f.description ) + '</p>';
					}

					fieldsHtml += '</div>';
				}
			}

			var footerHtml = '<span class="fdpbr-modal__status" id="fdpbr-modal-status"></span>';

			if ( isConfigured ) {
				footerHtml += '<button type="button" class="fdpbr-btn fdpbr-btn--danger fdpbr-btn--small" id="fdpbr-modal-disconnect">Disconnect</button>';
			}

			if ( fields.length > 0 ) {
				footerHtml += '<button type="button" class="fdpbr-btn fdpbr-btn--secondary fdpbr-btn--small" id="fdpbr-modal-test">Test Connection</button>';
				footerHtml += '<button type="button" class="fdpbr-btn fdpbr-btn--primary fdpbr-btn--small" id="fdpbr-modal-save">Save</button>';
			} else {
				// Local storage — just test.
				footerHtml += '<button type="button" class="fdpbr-btn fdpbr-btn--primary fdpbr-btn--small" id="fdpbr-modal-save">Save & Test</button>';
			}

			var html = '<div class="fdpbr-modal-overlay">' +
				'<div class="fdpbr-modal">' +
					'<div class="fdpbr-modal__header">' +
						'<h3>' + self.esc( title ) + '</h3>' +
						'<button type="button" class="fdpbr-modal__close" title="Close">&times;</button>' +
					'</div>' +
					'<div class="fdpbr-modal__body">' + fieldsHtml + '</div>' +
					'<div class="fdpbr-modal__footer">' + footerHtml + '</div>' +
				'</div>' +
			'</div>';

			$( 'body' ).append( html );

			var $overlay = $( '.fdpbr-modal-overlay' );

			// Setup guide toggle.
			$overlay.find( '.fdpbr-setup-guide__toggle' ).on( 'click', function() {
				var $content = $( this ).next( '.fdpbr-setup-guide__content' );
				var $arrow   = $( this ).find( '.fdpbr-setup-guide__arrow' );
				$content.slideToggle( 200 );
				$arrow.toggleClass( 'fdpbr-setup-guide__arrow--open' );
			});

			// Close handlers.
			$overlay.find( '.fdpbr-modal__close' ).on( 'click', function() {
				$overlay.remove();
			});
			$overlay.on( 'click', function( e ) {
				if ( $( e.target ).is( '.fdpbr-modal-overlay' ) ) {
					$overlay.remove();
				}
			});
			$( document ).on( 'keydown.fdpbrModal', function( e ) {
				if ( 27 === e.keyCode ) {
					$overlay.remove();
					$( document ).off( 'keydown.fdpbrModal' );
				}
			});

			// Save handler.
			$overlay.find( '#fdpbr-modal-save' ).on( 'click', function() {
				self.saveProvider( provider, $overlay );
			});

			// Test handler.
			$overlay.find( '#fdpbr-modal-test' ).on( 'click', function() {
				self.testProvider( provider, $overlay );
			});

			// Disconnect handler.
			$overlay.find( '#fdpbr-modal-disconnect' ).on( 'click', function() {
				self.disconnectProvider( provider, $overlay );
			});
		},

		/**
		 * Collect credential values from the modal form.
		 */
		collectCredentials: function( $overlay ) {
			var creds = {};
			$overlay.find( '.fdpbr-storage-field' ).each( function() {
				var name = $( this ).data( 'name' );
				if ( $( this ).is( ':checkbox' ) ) {
					creds[ name ] = $( this ).is( ':checked' ) ? '1' : '0';
				} else {
					creds[ name ] = $( this ).val();
				}
			});
			return creds;
		},

		/**
		 * Set modal status message.
		 */
		setStatus: function( $overlay, message, type ) {
			var $status = $overlay.find( '#fdpbr-modal-status' );
			$status.text( message )
				.removeClass( 'fdpbr-modal__status--success fdpbr-modal__status--error' );
			if ( type ) {
				$status.addClass( 'fdpbr-modal__status--' + type );
			}
		},

		/**
		 * Save provider credentials.
		 */
		saveProvider: function( provider, $overlay ) {
			var self  = this;
			var creds = self.collectCredentials( $overlay );
			var $btn  = $overlay.find( '#fdpbr-modal-save' );
			var btnText = $btn.text();

			$btn.text( 'Saving...' ).prop( 'disabled', true );
			self.setStatus( $overlay, '', '' );

			$.ajax({
				url:  fdpbrAdmin.ajax_url,
				type: 'POST',
				data: {
					action:      'fdpbr_save_storage',
					nonce:       fdpbrAdmin.nonce,
					provider:    provider,
					credentials: creds
				},
				success: function( response ) {
					if ( response.success ) {
						self.setStatus( $overlay, response.data.message || 'Saved!', 'success' );
						FDPBR.showToast( 'Settings saved.', 'success' );

						// Update the card badge.
						var $card = $( '.fdpbr-storage-card[data-provider="' + provider + '"]' );
						$card.find( '.fdpbr-badge' )
							.removeClass( 'fdpbr-badge--inactive' )
							.addClass( 'fdpbr-badge--success' )
							.text( 'Connected' );
						$card.find( '.fdpbr-configure-storage' ).text( 'Edit' );

						// Add test button if not present.
						if ( ! $card.find( '.fdpbr-test-storage' ).length ) {
							$card.find( '.fdpbr-storage-card__footer' ).append(
								' <button type="button" class="fdpbr-btn fdpbr-btn--ghost fdpbr-btn--small fdpbr-test-storage" data-provider="' + provider + '">Test</button>'
							);
						}

						// Update local provider info.
						if ( fdpbrStorage && fdpbrStorage.providers && fdpbrStorage.providers[ provider ] ) {
							fdpbrStorage.providers[ provider ].configured = true;
							fdpbrStorage.providers[ provider ].saved = creds;
						}

						// Close modal after brief delay.
						setTimeout( function() { $overlay.remove(); }, 800 );
					} else {
						self.setStatus( $overlay, response.data.message || 'Save failed.', 'error' );
					}
				},
				error: function() {
					self.setStatus( $overlay, 'Network error.', 'error' );
				},
				complete: function() {
					$btn.text( btnText ).prop( 'disabled', false );
				}
			});
		},

		/**
		 * Test provider connection.
		 */
		testProvider: function( provider, $overlay ) {
			var self  = this;
			var creds = self.collectCredentials( $overlay );
			var $btn  = $overlay.find( '#fdpbr-modal-test' );
			var btnText = $btn.text();

			$btn.text( 'Testing...' ).prop( 'disabled', true );
			self.setStatus( $overlay, '', '' );

			$.ajax({
				url:  fdpbrAdmin.ajax_url,
				type: 'POST',
				data: {
					action:      'fdpbr_test_storage',
					nonce:       fdpbrAdmin.nonce,
					provider:    provider,
					credentials: creds
				},
				success: function( response ) {
					if ( response.success ) {
						self.setStatus( $overlay, response.data.message || 'Connection successful!', 'success' );
					} else {
						self.setStatus( $overlay, response.data.message || 'Connection failed.', 'error' );
					}
				},
				error: function() {
					self.setStatus( $overlay, 'Network error.', 'error' );
				},
				complete: function() {
					$btn.text( btnText ).prop( 'disabled', false );
				}
			});
		},

		/**
		 * Disconnect a provider.
		 */
		disconnectProvider: function( provider, $overlay ) {
			var self = this;

			if ( ! confirm( 'Are you sure you want to disconnect this storage provider?' ) ) {
				return;
			}

			var $btn = $overlay.find( '#fdpbr-modal-disconnect' );
			$btn.text( 'Disconnecting...' ).prop( 'disabled', true );

			$.ajax({
				url:  fdpbrAdmin.ajax_url,
				type: 'POST',
				data: {
					action:   'fdpbr_disconnect_storage',
					nonce:    fdpbrAdmin.nonce,
					provider: provider
				},
				success: function( response ) {
					if ( response.success ) {
						FDPBR.showToast( 'Disconnected.', 'success' );

						// Update the card badge.
						var $card = $( '.fdpbr-storage-card[data-provider="' + provider + '"]' );
						$card.find( '.fdpbr-badge' )
							.removeClass( 'fdpbr-badge--success' )
							.addClass( 'fdpbr-badge--inactive' )
							.text( 'Not configured' );
						$card.find( '.fdpbr-configure-storage' ).text( 'Configure' );
						$card.find( '.fdpbr-test-storage' ).remove();

						// Update local provider info.
						if ( fdpbrStorage && fdpbrStorage.providers && fdpbrStorage.providers[ provider ] ) {
							fdpbrStorage.providers[ provider ].configured = false;
							fdpbrStorage.providers[ provider ].saved = {};
						}

						$overlay.remove();
					} else {
						self.setStatus( $overlay, response.data.message || 'Disconnect failed.', 'error' );
						$btn.text( 'Disconnect' ).prop( 'disabled', false );
					}
				},
				error: function() {
					self.setStatus( $overlay, 'Network error.', 'error' );
					$btn.text( 'Disconnect' ).prop( 'disabled', false );
				}
			});
		},

		/**
		 * HTML-escape a string.
		 */
		esc: function( text ) {
			var div = document.createElement( 'div' );
			div.appendChild( document.createTextNode( text || '' ) );
			return div.innerHTML;
		}
	};

	$( document ).ready( function() {
		StorageManager.init();
	});

})( jQuery );
