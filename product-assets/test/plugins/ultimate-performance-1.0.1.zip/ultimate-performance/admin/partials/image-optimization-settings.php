<?php
/**
 * Image Optimization settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$img_settings = Ultimate_Performance_Settings::get_module_settings( 'image_optimization' );
$has_gd       = function_exists( 'imagecreatefromjpeg' );
$has_webp     = function_exists( 'imagewebp' );
$tools        = Ultimate_Performance_Image_Optimizer::detect_tools();
$exec_ok      = Ultimate_Performance_Image_Optimizer::is_exec_available();

$has_any_cli = false;
foreach ( $tools as $slug => $tool ) {
	if ( 'gd' !== $slug && ! empty( $tool['available'] ) ) {
		$has_any_cli = true;
		break;
	}
}
?>
<form class="up-settings-form" data-module="image_optimization">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Image Optimization', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Optimize images for faster page loads, better Core Web Vitals, and reduced bandwidth usage.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $img_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- Optimization Tools Status -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Optimization Tools', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Server-side CLI tools provide significantly better compression than PHP GD alone. Install them for maximum savings.', 'ultimate-performance' ); ?></p>
			</div>
			<button type="button" id="up-refresh-tools" class="up-btn up-btn--secondary up-btn--small">
				<span class="dashicons dashicons-update" style="font-size: 14px; width: 14px; height: 14px;"></span>
				<?php esc_html_e( 'Re-detect', 'ultimate-performance' ); ?>
			</button>
		</div>

		<?php if ( ! $exec_ok ) : ?>
		<div style="padding: 12px 24px;">
			<div class="up-tools-notice up-tools-notice--warning">
				<span class="dashicons dashicons-warning"></span>
				<span><?php esc_html_e( 'PHP exec() is disabled on this server. CLI tools cannot be used. Only PHP GD will be available for image processing.', 'ultimate-performance' ); ?></span>
			</div>
		</div>
		<?php endif; ?>

		<div class="up-tools-grid" id="up-tools-grid">
			<?php foreach ( $tools as $slug => $tool ) : ?>
			<div class="up-tool-item <?php echo ! empty( $tool['available'] ) ? 'up-tool-item--available' : 'up-tool-item--missing'; ?>">
				<div class="up-tool-item__status">
					<?php if ( ! empty( $tool['available'] ) ) : ?>
						<span class="dashicons dashicons-yes-alt up-tool-item__icon--ok"></span>
					<?php else : ?>
						<span class="dashicons dashicons-dismiss up-tool-item__icon--no"></span>
					<?php endif; ?>
				</div>
				<div class="up-tool-item__info">
					<strong class="up-tool-item__name"><?php echo esc_html( $tool['label'] ); ?></strong>
					<span class="up-tool-item__desc"><?php echo esc_html( $tool['desc'] ); ?></span>
					<?php if ( ! empty( $tool['available'] ) && ! empty( $tool['version'] ) ) : ?>
						<span class="up-tool-item__version"><?php
							/* translators: %s: version string */
							printf( esc_html__( 'v%s', 'ultimate-performance' ), esc_html( $tool['version'] ) );
						?></span>
					<?php elseif ( empty( $tool['available'] ) && 'gd' !== $slug ) : ?>
						<span class="up-tool-item__hint"><?php esc_html_e( 'Not installed', 'ultimate-performance' ); ?></span>
					<?php endif; ?>
				</div>
			</div>
			<?php endforeach; ?>
		</div>

		<?php if ( ! $has_any_cli ) : ?>
		<div style="padding: 0 24px 16px;">
			<div class="up-tools-notice up-tools-notice--info">
				<span class="dashicons dashicons-info"></span>
				<div>
					<strong><?php esc_html_e( 'Install CLI tools for better compression', 'ultimate-performance' ); ?></strong>
					<p style="margin: 4px 0 0;"><?php esc_html_e( 'On Ubuntu/Debian:', 'ultimate-performance' ); ?> <code>sudo apt install jpegoptim pngquant optipng webp gifsicle</code></p>
					<p style="margin: 4px 0 0;"><?php esc_html_e( 'On CentOS/RHEL:', 'ultimate-performance' ); ?> <code>sudo yum install jpegoptim pngquant optipng libwebp-tools gifsicle</code></p>
					<p style="margin: 4px 0 0;"><?php esc_html_e( 'On macOS:', 'ultimate-performance' ); ?> <code>brew install jpegoptim pngquant optipng webp gifsicle</code></p>
				</div>
			</div>
		</div>
		<?php endif; ?>
	</div>

	<!-- Lazy Loading -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Lazy Loading', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Defer loading of offscreen images and iframes until the user scrolls near them.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--purple">
					<span class="dashicons dashicons-format-image"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Lazy Load Images', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Adds loading="lazy" and decoding="async" to offscreen images.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="lazy_load_images" value="1" <?php checked( $img_settings['lazy_load_images'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-video-alt3"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Lazy Load Iframes', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Adds loading="lazy" to iframes (YouTube, maps, embeds).', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="lazy_load_iframes" value="1" <?php checked( $img_settings['lazy_load_iframes'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-inline-field">
				<label for="lazy_load_exclude_first" class="up-inline-field__label"><?php esc_html_e( 'Exclude First N Images', 'ultimate-performance' ); ?></label>
				<input type="number" name="lazy_load_exclude_first" id="lazy_load_exclude_first" class="up-input--small" min="0" max="20" value="<?php echo absint( $img_settings['lazy_load_exclude_first'] ); ?>">
				<p class="up-field__hint" style="margin-left: 0; margin-top: 4px;"><?php esc_html_e( 'Number of above-the-fold images to skip. Recommended: 3.', 'ultimate-performance' ); ?></p>
			</div>

			<div class="up-field">
				<label for="lazy_load_exclusions" class="up-field__label"><?php esc_html_e( 'Exclusions', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'CSS classes or strings to exclude from lazy loading. One per line. You can also add data-no-lazy to any element.', 'ultimate-performance' ); ?></p>
				<textarea name="lazy_load_exclusions" id="lazy_load_exclusions" class="up-textarea" rows="3" placeholder="no-lazy&#10;hero-image"><?php echo esc_textarea( $img_settings['lazy_load_exclusions'] ); ?></textarea>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Image Dimensions -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Image Dimensions', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Automatically add missing width and height attributes to prevent Cumulative Layout Shift (CLS).', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-image-crop"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Add Missing Dimensions', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Detects images without width/height and adds them from file metadata.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="add_missing_dimensions" value="1" <?php checked( $img_settings['add_missing_dimensions'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- WebP Conversion -->
	<?php
	$best_webp_tool = Ultimate_Performance_Image_Optimizer::get_best_tool( 'image/jpeg', 'webp' );
	if ( 'none' === $best_webp_tool ) : ?>
	<div class="up-section-card" style="border-color: #f59e0b;">
		<div class="up-section-card__body" style="padding: 16px 24px;">
			<p style="color: #b45309; margin: 0;">
				<span class="dashicons dashicons-warning" style="vertical-align: middle;"></span>
				<?php esc_html_e( 'No WebP conversion tool is available. Install the cwebp binary or enable GD WebP support.', 'ultimate-performance' ); ?>
			</p>
		</div>
	</div>
	<?php endif; ?>

	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'WebP Conversion', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Generate WebP copies of uploaded images and serve them to supported browsers via the picture element.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--orange">
					<span class="dashicons dashicons-images-alt2"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'WebP Conversion', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Creates .webp copies on upload. Rewrites img tags to picture elements with WebP source.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="webp_conversion" value="1" <?php checked( $img_settings['webp_conversion'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-inline-field">
				<label for="webp_quality" class="up-inline-field__label"><?php esc_html_e( 'WebP Quality', 'ultimate-performance' ); ?></label>
				<input type="number" name="webp_quality" id="webp_quality" class="up-input--small" min="1" max="100" value="<?php echo absint( $img_settings['webp_quality'] ); ?>">
				<p class="up-field__hint" style="margin-left: 0; margin-top: 4px;"><?php esc_html_e( 'Quality level for WebP files. Lower = smaller file. Default: 80.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label class="up-field__label"><?php esc_html_e( 'Bulk Convert Existing Images', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Convert all existing JPEG/PNG images in your Media Library to WebP. New uploads are converted automatically.', 'ultimate-performance' ); ?></p>
				<div style="display: flex; align-items: center; gap: 12px; margin-top: 8px;">
					<button type="button" id="up-bulk-webp" class="up-btn up-btn--secondary up-btn--small" <?php echo 'none' !== $best_webp_tool ? '' : 'disabled'; ?>>
						<span class="dashicons dashicons-images-alt2" style="font-size: 14px; width: 14px; height: 14px;"></span>
						<?php esc_html_e( 'Convert Existing Images', 'ultimate-performance' ); ?>
					</button>
					<span id="up-bulk-webp-status" style="font-size: 13px; color: var(--up-gray-500);"></span>
				</div>
				<div id="up-bulk-webp-progress" style="display: none; margin-top: 8px;">
					<div style="background: #e5e7eb; border-radius: 4px; height: 6px; overflow: hidden;">
						<div id="up-bulk-webp-bar" style="background: var(--up-primary); height: 100%; width: 0%; transition: width 0.3s;"></div>
					</div>
				</div>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Compression -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Compression', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Re-compress uploaded images to reduce file sizes without noticeable quality loss.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--rose">
					<span class="dashicons dashicons-media-archive"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Compress on Upload', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Re-compresses JPEG and PNG images when uploaded to the Media Library.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="compression_enabled" value="1" <?php checked( $img_settings['compression_enabled'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-inline-field">
				<label for="compression_quality" class="up-inline-field__label"><?php esc_html_e( 'Compression Quality', 'ultimate-performance' ); ?></label>
				<input type="number" name="compression_quality" id="compression_quality" class="up-input--small" min="1" max="100" value="<?php echo absint( $img_settings['compression_quality'] ); ?>">
				<p class="up-field__hint" style="margin-left: 0; margin-top: 4px;"><?php esc_html_e( 'JPEG quality level. Lower = smaller file. Default: 82.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label class="up-field__label"><?php esc_html_e( 'Bulk Compress Existing Images', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Compress all existing JPEG/PNG images in your Media Library. New uploads are compressed automatically.', 'ultimate-performance' ); ?></p>
				<div style="display: flex; align-items: center; gap: 12px; margin-top: 8px;">
					<?php
					$best_compress_tool = Ultimate_Performance_Image_Optimizer::get_best_tool( 'image/jpeg', 'compress' );
					?>
					<button type="button" id="up-bulk-compress" class="up-btn up-btn--secondary up-btn--small" <?php echo 'none' !== $best_compress_tool ? '' : 'disabled'; ?>>
						<span class="dashicons dashicons-media-archive" style="font-size: 14px; width: 14px; height: 14px;"></span>
						<?php esc_html_e( 'Compress Existing Images', 'ultimate-performance' ); ?>
					</button>
					<span id="up-bulk-compress-status" style="font-size: 13px; color: var(--up-gray-500);"></span>
				</div>
				<div id="up-bulk-compress-progress" style="display: none; margin-top: 8px;">
					<div style="background: #e5e7eb; border-radius: 4px; height: 6px; overflow: hidden;">
						<div id="up-bulk-compress-bar" style="background: var(--up-primary); height: 100%; width: 0%; transition: width 0.3s;"></div>
					</div>
				</div>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
