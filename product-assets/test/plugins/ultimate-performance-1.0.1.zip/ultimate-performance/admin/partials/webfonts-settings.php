<?php
/**
 * Web Fonts settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$wf_settings = Ultimate_Performance_Settings::get_module_settings( 'webfonts' );
?>
<form class="up-settings-form" data-module="webfonts">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Web Fonts', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Optimize web fonts for faster loading, GDPR compliance, and better Core Web Vitals scores.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $wf_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- Google Fonts -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Google Fonts', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Optimize Google Fonts loading by hosting them locally and controlling font rendering behavior.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--purple">
					<span class="dashicons dashicons-download"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Local Google Fonts', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Download Google Fonts and serve them locally for GDPR compliance and faster loading.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="local_google_fonts" value="1" <?php checked( $wf_settings['local_google_fonts'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-editor-textcolor"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'font-display: swap', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Prevents invisible text during font loading (FOIT). Shows fallback font while custom font loads.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="font_display_swap" value="1" <?php checked( $wf_settings['font_display_swap'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-performance"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Preload Font Files', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Add preload hints for locally hosted font files. Requires Local Google Fonts to be enabled.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="preload_fonts" value="1" <?php checked( $wf_settings['preload_fonts'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>

<!-- Font Management (outside form) -->
<div class="up-section-card">
	<div class="up-section-card__header">
		<div>
			<h2><?php esc_html_e( 'Font Management', 'ultimate-performance' ); ?></h2>
			<p class="up-section-card__desc"><?php esc_html_e( 'Manage locally hosted font files. Clear to force re-download on next page load.', 'ultimate-performance' ); ?></p>
		</div>
	</div>

	<?php
	$fonts_dir = WP_CONTENT_DIR . '/fonts/ultimate-performance/';
	$fonts_url = content_url( '/fonts/ultimate-performance/' );
	$font_map  = get_transient( 'up_local_fonts_map' );

	if ( is_array( $font_map ) && ! empty( $font_map ) ) :
	?>
	<div style="padding: 0 24px 16px;">
		<table class="widefat striped" style="border: 1px solid #e5e7eb; border-radius: 6px; overflow: hidden;">
			<thead>
				<tr>
					<th style="padding: 10px 12px; font-size: 12px; text-transform: uppercase; color: #6b7280;"><?php esc_html_e( 'Font Families', 'ultimate-performance' ); ?></th>
					<th style="padding: 10px 12px; font-size: 12px; text-transform: uppercase; color: #6b7280;"><?php esc_html_e( 'Files', 'ultimate-performance' ); ?></th>
					<th style="padding: 10px 12px; font-size: 12px; text-transform: uppercase; color: #6b7280;"><?php esc_html_e( 'Size', 'ultimate-performance' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $font_map as $url_hash => $css_path ) :
					$font_subdir  = $fonts_dir . $url_hash . '/';
					$css_file     = $fonts_dir . $url_hash . '.css';

					// Extract font family names from CSS.
					$families = array();
					if ( file_exists( $css_file ) ) {
						$css_content = file_get_contents( $css_file );
						if ( preg_match_all( '/font-family:\s*[\'"]?([^;\'"]+)[\'"]?\s*;/i', $css_content, $fam_matches ) ) {
							$families = array_unique( $fam_matches[1] );
						}
					}

					// Count font files and total size.
					$file_count = 0;
					$total_size = 0;
					if ( is_dir( $font_subdir ) ) {
						$font_files = glob( $font_subdir . '*.woff2' );
						if ( ! $font_files ) {
							$font_files = glob( $font_subdir . '*.woff' );
						}
						if ( $font_files ) {
							$file_count = count( $font_files );
							foreach ( $font_files as $ff ) {
								$total_size += filesize( $ff );
							}
						}
					}

					$family_label = ! empty( $families ) ? implode( ', ', $families ) : $url_hash;
				?>
				<tr>
					<td style="padding: 10px 12px;">
						<strong style="color: #111827;"><?php echo esc_html( $family_label ); ?></strong>
					</td>
					<td style="padding: 10px 12px; color: #6b7280;">
						<?php
						printf(
							/* translators: %d: number of font files */
							esc_html( _n( '%d file', '%d files', $file_count, 'ultimate-performance' ) ),
							(int) $file_count
						);
						?>
					</td>
					<td style="padding: 10px 12px; color: #6b7280;">
						<?php echo esc_html( size_format( $total_size ) ); ?>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php else : ?>
	<div style="padding: 0 24px 16px;">
		<p style="color: #9ca3af; font-size: 13px; margin: 0;"><?php esc_html_e( 'No fonts downloaded yet. Enable "Local Google Fonts" and visit the front-end to trigger download.', 'ultimate-performance' ); ?></p>
	</div>
	<?php endif; ?>

	<div class="up-section-card__footer">
		<button type="button" class="up-btn up-btn--danger up-btn--small" id="up-clear-fonts">
			<?php esc_html_e( 'Clear Local Fonts', 'ultimate-performance' ); ?>
		</button>
	</div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
