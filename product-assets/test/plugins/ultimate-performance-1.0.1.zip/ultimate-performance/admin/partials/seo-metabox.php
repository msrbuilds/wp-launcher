<?php
/**
 * SEO meta box template for post/page editor.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.3.0
 *
 * @var WP_Post $post Current post object (passed by render_meta_box).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

wp_nonce_field( 'up_seo_meta', 'up_seo_meta_nonce' );

$seo_title    = get_post_meta( $post->ID, '_up_seo_title', true );
$seo_desc     = get_post_meta( $post->ID, '_up_seo_description', true );
$seo_noindex  = get_post_meta( $post->ID, '_up_seo_noindex', true );
$seo_nofollow = get_post_meta( $post->ID, '_up_seo_nofollow', true );
$og_title     = get_post_meta( $post->ID, '_up_seo_og_title', true );
$og_desc      = get_post_meta( $post->ID, '_up_seo_og_description', true );
$og_image     = get_post_meta( $post->ID, '_up_seo_og_image', true );
?>

<div class="up-seo-meta">
	<!-- SEO Title -->
	<div>
		<label for="_up_seo_title"><?php esc_html_e( 'SEO Title', 'ultimate-performance' ); ?></label>
		<input type="text" id="_up_seo_title" name="_up_seo_title" value="<?php echo esc_attr( $seo_title ); ?>" placeholder="<?php echo esc_attr( $post->post_title ); ?>">
		<p class="description"><?php esc_html_e( 'Recommended: 50-60 characters. Leave empty to use the post title.', 'ultimate-performance' ); ?></p>
	</div>

	<!-- Meta Description -->
	<div>
		<label for="_up_seo_description"><?php esc_html_e( 'Meta Description', 'ultimate-performance' ); ?></label>
		<textarea id="_up_seo_description" name="_up_seo_description" rows="3" placeholder="<?php esc_attr_e( 'Auto-generated from content if left empty.', 'ultimate-performance' ); ?>"><?php echo esc_textarea( $seo_desc ); ?></textarea>
		<p class="description"><?php esc_html_e( 'Recommended: 150-160 characters.', 'ultimate-performance' ); ?></p>
	</div>

	<!-- Robots -->
	<div style="display: flex; gap: 20px;">
		<div class="up-seo-checkbox">
			<input type="checkbox" id="_up_seo_noindex" name="_up_seo_noindex" value="1" <?php checked( $seo_noindex ); ?>>
			<label for="_up_seo_noindex"><?php esc_html_e( 'Noindex this page', 'ultimate-performance' ); ?></label>
		</div>
		<div class="up-seo-checkbox">
			<input type="checkbox" id="_up_seo_nofollow" name="_up_seo_nofollow" value="1" <?php checked( $seo_nofollow ); ?>>
			<label for="_up_seo_nofollow"><?php esc_html_e( 'Nofollow this page', 'ultimate-performance' ); ?></label>
		</div>
	</div>

	<hr>
	<p class="up-seo-section-title"><?php esc_html_e( 'Social Media Overrides', 'ultimate-performance' ); ?></p>

	<!-- OG Title -->
	<div>
		<label for="_up_seo_og_title"><?php esc_html_e( 'Social Title', 'ultimate-performance' ); ?></label>
		<input type="text" id="_up_seo_og_title" name="_up_seo_og_title" value="<?php echo esc_attr( $og_title ); ?>" placeholder="<?php esc_attr_e( 'Falls back to SEO Title, then post title.', 'ultimate-performance' ); ?>">
	</div>

	<!-- OG Description -->
	<div>
		<label for="_up_seo_og_description"><?php esc_html_e( 'Social Description', 'ultimate-performance' ); ?></label>
		<textarea id="_up_seo_og_description" name="_up_seo_og_description" rows="2" placeholder="<?php esc_attr_e( 'Falls back to meta description.', 'ultimate-performance' ); ?>"><?php echo esc_textarea( $og_desc ); ?></textarea>
	</div>

	<!-- OG Image -->
	<div>
		<label for="_up_seo_og_image"><?php esc_html_e( 'Social Image URL', 'ultimate-performance' ); ?></label>
		<input type="url" id="_up_seo_og_image" name="_up_seo_og_image" value="<?php echo esc_url( $og_image ); ?>" placeholder="<?php esc_attr_e( 'Falls back to featured image, then default.', 'ultimate-performance' ); ?>">
		<p class="description"><?php esc_html_e( 'Recommended: 1200x630 pixels. Used for Open Graph and Twitter Cards.', 'ultimate-performance' ); ?></p>
	</div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
