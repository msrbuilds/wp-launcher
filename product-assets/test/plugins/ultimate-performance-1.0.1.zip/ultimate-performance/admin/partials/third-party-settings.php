<?php
/**
 * Third-Party Scripts settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$tp_settings = Ultimate_Performance_Settings::get_module_settings( 'third_party' );
?>
<form class="up-settings-form" data-module="third_party">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Third-Party Scripts', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Manage analytics and tracking scripts with built-in performance optimizations like delayed loading.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $tp_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- Analytics & Tracking -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Analytics & Tracking', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Enter your tracking IDs below. Leave empty to skip a service. Scripts are injected with optimized loading.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="ga4_id" class="up-field__label">
					<span class="dashicons dashicons-chart-bar" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #f59e0b;"></span>
					<?php esc_html_e( 'Google Analytics 4 (GA4)', 'ultimate-performance' ); ?>
				</label>
				<p class="up-field__hint"><?php esc_html_e( 'Measurement ID starting with G-. Example: G-XXXXXXXXXX', 'ultimate-performance' ); ?></p>
				<input type="text" name="ga4_id" id="ga4_id" class="up-input" value="<?php echo esc_attr( $tp_settings['ga4_id'] ); ?>" placeholder="G-XXXXXXXXXX">
			</div>

			<div class="up-field">
				<label for="gtm_id" class="up-field__label">
					<span class="dashicons dashicons-tag" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #3b82f6;"></span>
					<?php esc_html_e( 'Google Tag Manager (GTM)', 'ultimate-performance' ); ?>
				</label>
				<p class="up-field__hint"><?php esc_html_e( 'Container ID starting with GTM-. Example: GTM-XXXXXXX', 'ultimate-performance' ); ?></p>
				<input type="text" name="gtm_id" id="gtm_id" class="up-input" value="<?php echo esc_attr( $tp_settings['gtm_id'] ); ?>" placeholder="GTM-XXXXXXX">
			</div>

			<div class="up-field">
				<label for="clarity_id" class="up-field__label">
					<span class="dashicons dashicons-visibility" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #8b5cf6;"></span>
					<?php esc_html_e( 'Microsoft Clarity', 'ultimate-performance' ); ?>
				</label>
				<p class="up-field__hint"><?php esc_html_e( 'Project ID from your Clarity dashboard.', 'ultimate-performance' ); ?></p>
				<input type="text" name="clarity_id" id="clarity_id" class="up-input" value="<?php echo esc_attr( $tp_settings['clarity_id'] ); ?>" placeholder="abc123def">
			</div>

			<div class="up-field">
				<label for="meta_pixel_id" class="up-field__label">
					<span class="dashicons dashicons-share" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle; margin-right: 4px; color: #2563eb;"></span>
					<?php esc_html_e( 'Meta Pixel (Facebook)', 'ultimate-performance' ); ?>
				</label>
				<p class="up-field__hint"><?php esc_html_e( 'Pixel ID from your Meta Events Manager.', 'ultimate-performance' ); ?></p>
				<input type="text" name="meta_pixel_id" id="meta_pixel_id" class="up-input" value="<?php echo esc_attr( $tp_settings['meta_pixel_id'] ); ?>" placeholder="123456789012345">
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Custom Scripts -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Custom Scripts', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Add custom tracking or third-party scripts. Include full script tags.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="custom_head_scripts" class="up-field__label"><?php esc_html_e( 'Head Scripts', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Scripts injected in the <head> section. Include opening and closing script tags.', 'ultimate-performance' ); ?></p>
				<textarea name="custom_head_scripts" id="custom_head_scripts" class="up-textarea" rows="4" placeholder="<script>&#10;// Your custom head script&#10;</script>"><?php echo esc_textarea( $tp_settings['custom_head_scripts'] ); ?></textarea>
			</div>

			<div class="up-field">
				<label for="custom_body_scripts" class="up-field__label"><?php esc_html_e( 'Body Scripts', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Scripts injected after the opening <body> tag. Include opening and closing script tags.', 'ultimate-performance' ); ?></p>
				<textarea name="custom_body_scripts" id="custom_body_scripts" class="up-textarea" rows="4" placeholder="<script>&#10;// Your custom body script&#10;</script>"><?php echo esc_textarea( $tp_settings['custom_body_scripts'] ); ?></textarea>
			</div>

			<div class="up-field">
				<label for="custom_footer_scripts" class="up-field__label"><?php esc_html_e( 'Footer Scripts', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Scripts injected before the closing </body> tag. Include opening and closing script tags.', 'ultimate-performance' ); ?></p>
				<textarea name="custom_footer_scripts" id="custom_footer_scripts" class="up-textarea" rows="4" placeholder="<script>&#10;// Your custom footer script&#10;</script>"><?php echo esc_textarea( $tp_settings['custom_footer_scripts'] ); ?></textarea>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Performance -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Performance', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Optimize third-party script loading to minimize impact on page performance.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--orange">
					<span class="dashicons dashicons-clock"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Delay Until Interaction', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Hold all third-party scripts until the user interacts with the page (mouse, scroll, keyboard, touch).', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="delay_third_party" value="1" <?php checked( $tp_settings['delay_third_party'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-admin-site-alt3"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'DNS Prefetch', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Automatically add DNS prefetch hints for configured third-party services.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="dns_prefetch_third_party" value="1" <?php checked( $tp_settings['dns_prefetch_third_party'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
