<?php
/**
 * Speed Test settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$st_settings = Ultimate_Performance_Settings::get_module_settings( 'speed_test' );
?>
<!-- Settings Form -->
<form class="up-settings-form" data-module="speed_test">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Speed Test', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Test your site performance using Google PageSpeed Insights. Get a performance score and Core Web Vitals metrics.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $st_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- API Key -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'API Configuration', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'An API key is optional but recommended for higher rate limits. Get one free from the Google Cloud Console.', 'ultimate-performance' ); ?>
					<a href="#" class="up-guide-link" data-guide="pagespeed_api" onclick="event.preventDefault(); UPGuides.open('pagespeed_api');"><?php esc_html_e( 'Setup Guide', 'ultimate-performance' ); ?></a>
				</p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="api_key" class="up-field__label"><?php esc_html_e( 'PageSpeed API Key', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Optional. Leave empty to use the public API (limited to ~25 requests/day).', 'ultimate-performance' ); ?></p>
				<?php if ( ! empty( $st_settings['api_key'] ) ) : ?>
				<div class="up-api-key-masked" style="display: flex; gap: 8px; align-items: center;">
					<input type="text" class="up-input" value="<?php echo esc_attr( str_repeat( "\xE2\x80\xA2", 8 ) . substr( $st_settings['api_key'], -4 ) ); ?>" readonly style="flex: 1;">
					<input type="hidden" name="api_key" id="api_key" value="__KEEP__">
					<button type="button" class="up-btn up-btn--small up-key-change" data-placeholder="AIza..."><?php esc_html_e( 'Change', 'ultimate-performance' ); ?></button>
					<button type="button" class="up-btn up-btn--small up-btn--danger up-key-remove" data-placeholder="AIza..."><?php esc_html_e( 'Remove', 'ultimate-performance' ); ?></button>
				</div>
				<?php else : ?>
				<input type="text" name="api_key" id="api_key" class="up-input" value="" placeholder="AIza...">
				<?php endif; ?>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>

<!-- Speed Test Tool (separate from settings form) -->
<div class="up-section-card">
	<div class="up-section-card__header">
		<div>
			<h2><?php esc_html_e( 'Run Speed Test', 'ultimate-performance' ); ?></h2>
			<p class="up-section-card__desc"><?php esc_html_e( 'Enter a URL to analyze. Use PSI API for a comprehensive Lighthouse report, or Quick Test for instant browser-based metrics.', 'ultimate-performance' ); ?></p>
		</div>
	</div>

	<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
		<div class="up-field">
			<div class="up-speed-test-bar">
				<input type="url" id="up-speed-test-url" class="up-input" placeholder="<?php esc_attr_e( 'https://example.com', 'ultimate-performance' ); ?>" value="<?php echo esc_url( home_url( '/' ) ); ?>">
				<div class="up-speed-test-toggles">
					<div class="up-strategy-toggle" id="up-test-mode-toggle">
						<button type="button" class="up-strategy-btn up-strategy-btn--active" data-mode="psi"><?php esc_html_e( 'PSI API', 'ultimate-performance' ); ?></button>
						<button type="button" class="up-strategy-btn" data-mode="quick"><?php esc_html_e( 'Quick Test', 'ultimate-performance' ); ?></button>
					</div>
					<div class="up-strategy-toggle" id="up-strategy-toggle">
						<button type="button" class="up-strategy-btn up-strategy-btn--active" data-strategy="mobile"><?php esc_html_e( 'Mobile', 'ultimate-performance' ); ?></button>
						<button type="button" class="up-strategy-btn" data-strategy="desktop"><?php esc_html_e( 'Desktop', 'ultimate-performance' ); ?></button>
					</div>
				</div>
				<button type="button" class="up-btn up-btn--primary" id="up-run-speed-test">
					<?php esc_html_e( 'Run Test', 'ultimate-performance' ); ?>
				</button>
			</div>
		</div>
	</div>

	<div id="up-speed-test-results" style="padding: 0 24px 24px;"></div>
</div>

<!-- Guide Sidebar Overlay -->
<div class="up-guide-overlay" id="up-guide-overlay"></div>
<div class="up-guide-sidebar" id="up-guide-sidebar">
	<div class="up-guide-sidebar__header">
		<h3 class="up-guide-sidebar__title" id="up-guide-title"></h3>
		<button type="button" class="up-guide-sidebar__close" id="up-guide-close" aria-label="<?php esc_attr_e( 'Close', 'ultimate-performance' ); ?>">
			<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
		</button>
	</div>
	<div class="up-guide-sidebar__body" id="up-guide-body"></div>
</div>

<script>
var UPGuides = (function() {
	'use strict';

	var guides = {
		pagespeed_api: {
			title: '<?php echo esc_js( __( 'PageSpeed API Key Setup Guide', 'ultimate-performance' ) ); ?>',
			html: '<div class="up-guide-content">'
				+ '<div class="up-guide-intro">'
				+ '<p>The <strong>Google PageSpeed Insights API</strong> allows you to test your site\'s performance programmatically. Without an API key you\'re limited to ~25 requests/day via the public endpoint. With a key, you get up to <strong>25,000 requests/day</strong> for free.</p>'
				+ '</div>'
				+ '<h4>Step 1: Create a Google Cloud Project</h4>'
				+ '<ol>'
				+ '<li>Go to the <strong>Google Cloud Console</strong> at <code>console.cloud.google.com</code>.</li>'
				+ '<li>If you don\'t have a Google Cloud account, sign up &mdash; no credit card is required for the free tier.</li>'
				+ '<li>Click the project dropdown at the top and select <strong>"New Project"</strong>.</li>'
				+ '<li>Name it something like <code>WordPress Speed Test</code> and click <strong>"Create"</strong>.</li>'
				+ '</ol>'
				+ '<h4>Step 2: Enable the PageSpeed Insights API</h4>'
				+ '<ol>'
				+ '<li>In your new project, go to <strong>APIs & Services</strong> &rarr; <strong>"Library"</strong>.</li>'
				+ '<li>Search for <strong>"PageSpeed Insights API"</strong>.</li>'
				+ '<li>Click on it and press the <strong>"Enable"</strong> button.</li>'
				+ '</ol>'
				+ '<h4>Step 3: Create an API Key</h4>'
				+ '<ol>'
				+ '<li>Go to <strong>APIs & Services</strong> &rarr; <strong>"Credentials"</strong>.</li>'
				+ '<li>Click <strong>"+ Create Credentials"</strong> &rarr; <strong>"API key"</strong>.</li>'
				+ '<li>Your new API key will be generated immediately &mdash; copy it.</li>'
				+ '</ol>'
				+ '<h4>Step 4: Restrict the API Key (Recommended)</h4>'
				+ '<ol>'
				+ '<li>Click <strong>"Edit API key"</strong> (or find it in the Credentials list and click the pencil icon).</li>'
				+ '<li>Under <strong>API restrictions</strong>, select <strong>"Restrict key"</strong>.</li>'
				+ '<li>Choose <strong>"PageSpeed Insights API"</strong> from the dropdown and save.</li>'
				+ '<li>This ensures the key can only be used for PageSpeed requests, limiting abuse if it\'s ever exposed.</li>'
				+ '</ol>'
				+ '<h4>Step 5: Add the Key to Ultimate Performance</h4>'
				+ '<ol>'
				+ '<li>Paste your API key into the <strong>"PageSpeed API Key"</strong> field above.</li>'
				+ '<li>Click <strong>"Save Settings"</strong>.</li>'
				+ '<li>Run a speed test to verify it\'s working &mdash; you should no longer hit rate limits.</li>'
				+ '</ol>'
				+ '<div class="up-guide-tip">'
				+ '<strong>Tip:</strong> The free quota of 25,000 requests/day is more than enough for any WordPress site. If you\'re also using the key for other projects, you can monitor usage in <strong>APIs & Services &rarr; Dashboard</strong> in Google Cloud Console.'
				+ '</div>'
				+ '</div>'
		}
	};

	function open( guideKey ) {
		var guide = guides[ guideKey ];
		if ( ! guide ) return;

		document.getElementById( 'up-guide-title' ).textContent = guide.title;
		document.getElementById( 'up-guide-body' ).innerHTML = guide.html;
		document.getElementById( 'up-guide-overlay' ).classList.add( 'up-guide-overlay--visible' );
		document.getElementById( 'up-guide-sidebar' ).classList.add( 'up-guide-sidebar--visible' );
		document.body.style.overflow = 'hidden';
	}

	function close() {
		document.getElementById( 'up-guide-overlay' ).classList.remove( 'up-guide-overlay--visible' );
		document.getElementById( 'up-guide-sidebar' ).classList.remove( 'up-guide-sidebar--visible' );
		document.body.style.overflow = '';
	}

	document.addEventListener( 'DOMContentLoaded', function() {
		document.getElementById( 'up-guide-close' ).addEventListener( 'click', close );
		document.getElementById( 'up-guide-overlay' ).addEventListener( 'click', close );
		document.addEventListener( 'keydown', function( e ) {
			if ( e.key === 'Escape' ) close();
		});
	});

	return { open: open, close: close };
})();
</script>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
