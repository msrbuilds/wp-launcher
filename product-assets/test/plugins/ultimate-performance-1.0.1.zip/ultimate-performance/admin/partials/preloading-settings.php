<?php
/**
 * Preloading & Resource Hints settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$pl_settings = Ultimate_Performance_Settings::get_module_settings( 'preloading' );

$eagerness_options = array(
	'conservative' => __( 'Conservative', 'ultimate-performance' ),
	'moderate'     => __( 'Moderate', 'ultimate-performance' ),
	'eager'        => __( 'Eager', 'ultimate-performance' ),
);
?>
<form class="up-settings-form" data-module="preloading">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Preloading & Resource Hints', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Tell browsers to prefetch DNS, preconnect to origins, and preload critical assets for faster page loads.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $pl_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- Resource Hints -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Resource Hints', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Enter one URL or domain per line. These hints help the browser resolve DNS, establish connections, and fetch resources earlier.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack">
			<div class="up-field">
				<label for="dns_prefetch" class="up-field__label"><?php esc_html_e( 'DNS Prefetch', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Resolve DNS for external domains early. Enter domains like: fonts.googleapis.com', 'ultimate-performance' ); ?></p>
				<textarea name="dns_prefetch" id="dns_prefetch" class="up-textarea" rows="4" placeholder="fonts.googleapis.com&#10;cdn.jsdelivr.net"><?php echo esc_textarea( $pl_settings['dns_prefetch'] ); ?></textarea>
			</div>

			<div class="up-field">
				<label for="preconnect" class="up-field__label"><?php esc_html_e( 'Preconnect', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Establish early connections (DNS + TCP + TLS). Enter origins like: https://fonts.gstatic.com', 'ultimate-performance' ); ?></p>
				<textarea name="preconnect" id="preconnect" class="up-textarea" rows="4" placeholder="https://fonts.gstatic.com&#10;https://cdn.example.com"><?php echo esc_textarea( $pl_settings['preconnect'] ); ?></textarea>
			</div>

			<div class="up-field">
				<label for="preload_urls" class="up-field__label"><?php esc_html_e( 'Preload URLs', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Preload critical assets (fonts, CSS, JS). The resource type is auto-detected from the file extension.', 'ultimate-performance' ); ?></p>
				<textarea name="preload_urls" id="preload_urls" class="up-textarea" rows="4" placeholder="/wp-content/themes/your-theme/fonts/custom-font.woff2&#10;/wp-content/themes/your-theme/style.css"><?php echo esc_textarea( $pl_settings['preload_urls'] ); ?></textarea>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Page Prefetching -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Page Prefetching', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Prefetch or prerender pages before the user clicks, making navigation feel instant.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--purple">
					<span class="dashicons dashicons-admin-links"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Instant Page (Hover Prefetch)', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Prefetches pages when users hover over links. Lightweight and widely supported.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="instant_page" value="1" <?php checked( $pl_settings['instant_page'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-superhero"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Speculation Rules API', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Uses the browser\'s Speculation Rules API to prerender pages. Chromium-based browsers only.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="speculation_rules" value="1" <?php checked( $pl_settings['speculation_rules'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-row" style="margin-top: 16px;">
			<div class="up-inline-field">
				<label for="speculation_eagerness" class="up-inline-field__label"><?php esc_html_e( 'Speculation Eagerness', 'ultimate-performance' ); ?></label>
				<select name="speculation_eagerness" id="speculation_eagerness" class="up-select" style="width:auto;min-width:160px;">
					<?php foreach ( $eagerness_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $pl_settings['speculation_eagerness'], $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="up-field__hint" style="margin-left: 0; margin-top: 4px;"><?php esc_html_e( 'Conservative: on click. Moderate: on hover. Eager: on link visible.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
