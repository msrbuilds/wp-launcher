<?php
/**
 * Tabbed settings page template.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$modules     = Ultimate_Performance_Settings::get_modules();
$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'bloat-removal'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Tab navigation; no data modification.
$settings    = get_option( Ultimate_Performance_Settings::OPTION_NAME, Ultimate_Performance_Settings::get_defaults() );

$current_page = 'modules';
?>
<div class="wrap up-app">

	<?php include UP_PLUGIN_DIR . 'admin/partials/header-nav.php'; ?>

	<div class="up-content">
		<div class="up-settings-layout">
			<!-- Sidebar Navigation -->
			<nav class="up-settings-nav">
				<?php foreach ( $modules as $key => $module ) : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=ultimate-performance-settings&tab=' . $module['tab'] ) ); ?>"
					   class="up-settings-nav__link <?php echo ( $current_tab === $module['tab'] ) ? 'up-settings-nav__link--active' : ''; ?>">
						<span class="dashicons <?php echo esc_attr( $module['icon'] ); ?>"></span>
						<?php echo esc_html( $module['label'] ); ?>
					</a>
				<?php endforeach; ?>
			</nav>

			<!-- Tab Content -->
			<div class="up-settings-content">
				<?php
				switch ( $current_tab ) {
					case 'bloat-removal':
						include UP_PLUGIN_DIR . 'admin/partials/bloat-removal-settings.php';
						break;
					case 'database':
						include UP_PLUGIN_DIR . 'admin/partials/database-settings.php';
						break;
					case 'preloading':
						include UP_PLUGIN_DIR . 'admin/partials/preloading-settings.php';
						break;
					case 'css-js':
						include UP_PLUGIN_DIR . 'admin/partials/css-js-settings.php';
						break;
					case 'caching':
						include UP_PLUGIN_DIR . 'admin/partials/cache-settings.php';
						break;
					case 'images':
						include UP_PLUGIN_DIR . 'admin/partials/image-optimization-settings.php';
						break;
					case 'webfonts':
						include UP_PLUGIN_DIR . 'admin/partials/webfonts-settings.php';
						break;
					case 'cdn':
						include UP_PLUGIN_DIR . 'admin/partials/cdn-settings.php';
						break;
					case 'third-party':
						include UP_PLUGIN_DIR . 'admin/partials/third-party-settings.php';
						break;
					case 'script-manager':
						include UP_PLUGIN_DIR . 'admin/partials/script-manager-settings.php';
						break;
					case 'security-headers':
						include UP_PLUGIN_DIR . 'admin/partials/security-headers-settings.php';
						break;
					case 'woocommerce':
						include UP_PLUGIN_DIR . 'admin/partials/woocommerce-settings.php';
						break;
					default:
						?>
						<div class="up-section-card">
							<div class="up-placeholder">
								<div class="up-placeholder__icon">
									<span class="dashicons dashicons-hammer"></span>
								</div>
								<h2><?php esc_html_e( 'Coming Soon', 'ultimate-performance' ); ?></h2>
								<p><?php esc_html_e( 'This module is planned for a future release.', 'ultimate-performance' ); ?></p>
							</div>
						</div>
						<?php
						break;
				}
				?>
			</div>
		</div>
	</div>

	<div class="up-toast" id="up-toast" style="display:none;">
		<span class="up-toast__message"></span>
	</div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
