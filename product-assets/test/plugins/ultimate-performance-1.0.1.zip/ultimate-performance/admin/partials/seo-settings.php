<?php
/**
 * Basic SEO settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$seo_settings = Ultimate_Performance_Settings::get_module_settings( 'seo' );
$seo_conflict = Ultimate_Performance_Seo::check_seo_conflict();
?>
<form class="up-settings-form" data-module="seo">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Basic SEO', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Essential on-page SEO: meta tags, Open Graph, Twitter Cards, canonical URLs, robots meta, and JSON-LD schema markup.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $seo_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>

		<?php if ( $seo_conflict ) : ?>
			<div class="up-notice up-notice--warning" style="margin: 0 20px 20px; padding: 12px 16px; background: #fff3cd; border-left: 4px solid #ffc107; border-radius: 4px;">
				<p style="margin: 0;">
					<?php
					printf(
						/* translators: %s: SEO plugin name */
						esc_html__( 'SEO features are auto-disabled because %s is active. Deactivate it to use our SEO module, or keep this module disabled to avoid conflicts.', 'ultimate-performance' ),
						'<strong>' . esc_html( $seo_conflict ) . '</strong>'
					);
					?>
				</p>
			</div>
		<?php endif; ?>
	</div>

	<!-- Meta Tags -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Meta Tags', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Control how your pages appear in search engine results.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--purple">
					<span class="dashicons dashicons-edit"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Meta Title', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Set custom SEO titles for posts and pages via the meta box. Enables title-tag theme support.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="meta_title" value="1" <?php checked( $seo_settings['meta_title'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-text"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Meta Description', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Auto-generates meta descriptions from content or excerpt. Can be overridden per post.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="meta_description" value="1" <?php checked( $seo_settings['meta_description'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-admin-links"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Canonical URLs', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Outputs canonical link tags to prevent duplicate content issues in search engines.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="canonical_urls" value="1" <?php checked( $seo_settings['canonical_urls'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Social Media -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Social Media', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Control how your content appears when shared on social networks.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--blue">
					<span class="dashicons dashicons-share"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Open Graph Tags', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Adds og:title, og:description, og:image, and og:url tags for rich previews on Facebook, LinkedIn, and other platforms.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="og_tags" value="1" <?php checked( $seo_settings['og_tags'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--sky">
					<span class="dashicons dashicons-share-alt"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Twitter Cards', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Adds twitter:card, twitter:title, twitter:description, and twitter:image tags for rich link previews on X/Twitter.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="twitter_cards" value="1" <?php checked( $seo_settings['twitter_cards'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack">
			<div class="up-field">
				<label for="twitter_site" class="up-field__label"><?php esc_html_e( 'Twitter/X @Handle', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Your site\'s Twitter/X handle (e.g., @yourbrand). Used in twitter:site tag.', 'ultimate-performance' ); ?></p>
				<input type="text" name="twitter_site" id="twitter_site" class="up-input" value="<?php echo esc_attr( $seo_settings['twitter_site'] ); ?>" placeholder="@yourbrand">
			</div>

			<div class="up-field">
				<label for="default_og_image" class="up-field__label"><?php esc_html_e( 'Default Social Image', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Fallback image URL used for Open Graph and Twitter Cards when a post has no featured image. Recommended size: 1200x630 pixels.', 'ultimate-performance' ); ?></p>
				<input type="url" name="default_og_image" id="default_og_image" class="up-input" value="<?php echo esc_url( $seo_settings['default_og_image'] ); ?>" placeholder="https://example.com/default-share.jpg">
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Robots & Indexing -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Robots & Indexing', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Control which pages search engines should index. Per-post overrides available in the SEO meta box.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--orange">
					<span class="dashicons dashicons-visibility"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Robots Meta', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Enables robots meta tag output. Required for the noindex settings below and per-post noindex/nofollow.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="robots_meta" value="1" <?php checked( $seo_settings['robots_meta'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--rose">
					<span class="dashicons dashicons-search"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Noindex Search Results', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Adds noindex to search result pages to prevent thin content indexing.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="noindex_search" value="1" <?php checked( $seo_settings['noindex_search'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--rose">
					<span class="dashicons dashicons-category"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Noindex Archives', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Adds noindex to date, category, and tag archive pages.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="noindex_archives" value="1" <?php checked( $seo_settings['noindex_archives'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--rose">
					<span class="dashicons dashicons-admin-users"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Noindex Author Archives', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Adds noindex to author archive pages to prevent duplicate content.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="noindex_author" value="1" <?php checked( $seo_settings['noindex_author'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Schema Markup -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Schema Markup', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'JSON-LD structured data for rich results in Google, Bing, and other search engines.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--green">
					<span class="dashicons dashicons-editor-code"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'JSON-LD Schema', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Outputs WebSite, Organization, Article, and BreadcrumbList schemas. Enables sitelinks search box and rich snippets.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="schema_markup" value="1" <?php checked( $seo_settings['schema_markup'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack">
			<div class="up-field">
				<label for="schema_org_name" class="up-field__label"><?php esc_html_e( 'Organization Name', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Name used in the Organization schema. Defaults to your site name if left empty.', 'ultimate-performance' ); ?></p>
				<input type="text" name="schema_org_name" id="schema_org_name" class="up-input" value="<?php echo esc_attr( $seo_settings['schema_org_name'] ); ?>" placeholder="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
			</div>

			<div class="up-field">
				<label for="schema_org_logo" class="up-field__label"><?php esc_html_e( 'Organization Logo URL', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'URL of your organization logo for schema markup. Recommended: 112x112px minimum, square or landscape format.', 'ultimate-performance' ); ?></p>
				<input type="url" name="schema_org_logo" id="schema_org_logo" class="up-input" value="<?php echo esc_url( $seo_settings['schema_org_logo'] ); ?>" placeholder="https://example.com/logo.png">
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
