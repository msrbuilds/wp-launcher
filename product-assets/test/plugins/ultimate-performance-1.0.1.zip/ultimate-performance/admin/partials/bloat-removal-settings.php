<?php
/**
 * Bloat Removal settings tab partial.
 *
 * Uses card-based layout with per-section save buttons.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$br_settings = Ultimate_Performance_Settings::get_module_settings( 'bloat_removal' );

$heartbeat_options = array(
	'default' => __( 'Default', 'ultimate-performance' ),
	'disable' => __( 'Disable', 'ultimate-performance' ),
	'15'      => __( '15 seconds', 'ultimate-performance' ),
	'30'      => __( '30 seconds', 'ultimate-performance' ),
	'60'      => __( '60 seconds', 'ultimate-performance' ),
	'120'     => __( '120 seconds', 'ultimate-performance' ),
);
?>
<form class="up-settings-form" data-module="bloat_removal">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Bloat Removal', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Remove unnecessary default WordPress scripts, styles, and meta tags that add bloat to your pages.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $br_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- Head Cleanup -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Head Cleanup', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Remove unnecessary meta tags and links from the HTML head section.', 'ultimate-performance' ); ?></p>
			</div>
			<label class="up-switch up-toggle-all">
				<input type="checkbox" class="up-toggle-all__input">
				<span class="up-switch__slider"></span>
				<span class="up-switch__label"><?php esc_html_e( 'Toggle All', 'ultimate-performance' ); ?></span>
			</label>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--rose">
					<span class="dashicons dashicons-no-alt"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove WLW Manifest Link', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes Windows Live Writer manifest link.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="remove_wlw_manifest" value="1" <?php checked( $br_settings['remove_wlw_manifest'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-no-alt"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove RSD Link', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes Really Simple Discovery link.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="remove_rsd_link" value="1" <?php checked( $br_settings['remove_rsd_link'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-admin-links"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove Shortlinks', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes ?p= shortlink meta tag and HTTP header.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="remove_shortlinks" value="1" <?php checked( $br_settings['remove_shortlinks'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--orange">
					<span class="dashicons dashicons-shield"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove WordPress Version', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Hides WP version from head and asset URLs.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="remove_wp_version" value="1" <?php checked( $br_settings['remove_wp_version'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--purple">
					<span class="dashicons dashicons-rest-api"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove REST API Links', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes REST API discovery link tags from head.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_rest_api_links" value="1" <?php checked( $br_settings['disable_rest_api_links'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--sky">
					<span class="dashicons dashicons-rss"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove RSS Feed Links', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes RSS feed discovery links from head.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_rss_feeds" value="1" <?php checked( $br_settings['disable_rss_feeds'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Scripts & Styles -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Scripts & Styles', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Remove unnecessary scripts and stylesheets from the frontend.', 'ultimate-performance' ); ?></p>
			</div>
			<label class="up-switch up-toggle-all">
				<input type="checkbox" class="up-toggle-all__input">
				<span class="up-switch__slider"></span>
				<span class="up-switch__label"><?php esc_html_e( 'Toggle All', 'ultimate-performance' ); ?></span>
			</label>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--rose">
					<span class="dashicons dashicons-smiley"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Disable WordPress Emojis', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes emoji detection script and inline CSS.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_emojis" value="1" <?php checked( $br_settings['disable_emojis'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-embed-generic"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Disable oEmbed / Embeds', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes wp-embed.min.js and oEmbed discovery.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_embeds" value="1" <?php checked( $br_settings['disable_embeds'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-art"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove Dashicons (Frontend)', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes dashicons CSS for non-logged-in users.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="remove_dashicons" value="1" <?php checked( $br_settings['remove_dashicons'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--orange">
					<span class="dashicons dashicons-media-code"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove jQuery Migrate', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes legacy jQuery compatibility layer.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="remove_jquery_migrate" value="1" <?php checked( $br_settings['remove_jquery_migrate'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--purple">
					<span class="dashicons dashicons-admin-appearance"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Disable Global Styles', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes wp_global_styles and classic-theme-styles inline CSS.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_global_styles" value="1" <?php checked( $br_settings['disable_global_styles'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--sky">
					<span class="dashicons dashicons-testimonial"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove Comment Reply JS', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Only loads comment-reply.js on pages with open comments.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="remove_comment_reply_js" value="1" <?php checked( $br_settings['remove_comment_reply_js'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- WordPress Features -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'WordPress Features', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Disable WordPress core features you don\'t need.', 'ultimate-performance' ); ?></p>
			</div>
			<label class="up-switch up-toggle-all">
				<input type="checkbox" class="up-toggle-all__input">
				<span class="up-switch__slider"></span>
				<span class="up-switch__label"><?php esc_html_e( 'Toggle All', 'ultimate-performance' ); ?></span>
			</label>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--rose">
					<span class="dashicons dashicons-warning"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Disable XML-RPC', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Disables XML-RPC interface and removes X-Pingback header.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_xmlrpc" value="1" <?php checked( $br_settings['disable_xmlrpc'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-controls-repeat"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Disable Self-Pingbacks', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Prevents WordPress from pinging your own site.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_self_pingbacks" value="1" <?php checked( $br_settings['disable_self_pingbacks'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-translation"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Disable Login Language Switcher', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes the language dropdown on the login page.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_login_language" value="1" <?php checked( $br_settings['disable_login_language'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Heartbeat API -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Heartbeat API', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Control the WordPress Heartbeat API frequency in different areas. The Heartbeat API sends AJAX requests that can impact server performance.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-select-grid">
			<div class="up-select-card">
				<label for="heartbeat_frontend" class="up-select-card__label"><?php esc_html_e( 'Frontend', 'ultimate-performance' ); ?></label>
				<p class="up-select-card__hint"><?php esc_html_e( 'Controls Heartbeat on public pages.', 'ultimate-performance' ); ?></p>
				<select name="heartbeat_frontend" id="heartbeat_frontend" class="up-select">
					<?php foreach ( $heartbeat_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $br_settings['heartbeat_frontend'], $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="up-select-card">
				<label for="heartbeat_admin" class="up-select-card__label"><?php esc_html_e( 'Admin Pages', 'ultimate-performance' ); ?></label>
				<p class="up-select-card__hint"><?php esc_html_e( 'Controls Heartbeat on admin screens.', 'ultimate-performance' ); ?></p>
				<select name="heartbeat_admin" id="heartbeat_admin" class="up-select">
					<?php foreach ( $heartbeat_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $br_settings['heartbeat_admin'], $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="up-select-card">
				<label for="heartbeat_editor" class="up-select-card__label"><?php esc_html_e( 'Post Editor', 'ultimate-performance' ); ?></label>
				<p class="up-select-card__hint"><?php esc_html_e( 'Controls Heartbeat in the editor.', 'ultimate-performance' ); ?></p>
				<select name="heartbeat_editor" id="heartbeat_editor" class="up-select">
					<?php foreach ( $heartbeat_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $br_settings['heartbeat_editor'], $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
