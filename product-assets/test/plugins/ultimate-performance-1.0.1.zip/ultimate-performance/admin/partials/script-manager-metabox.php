<?php
/**
 * Script Manager metabox partial for post/page editor.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$is_published = ( 'publish' === $post->post_status );
?>
<div id="up-script-manager-metabox">
	<p class="description" style="margin-bottom: 12px;">
		<?php esc_html_e( 'Scan this page to see all frontend scripts and styles. Check any to disable on this page. Changes are saved when you update the post.', 'ultimate-performance' ); ?>
	</p>

	<?php if ( $is_published ) : ?>
		<button type="button" class="button button-primary" id="up-scan-assets" data-post-id="<?php echo absint( $post->ID ); ?>">
			<?php esc_html_e( 'Scan Assets', 'ultimate-performance' ); ?>
		</button>
		<span id="up-scan-hint" style="display: none; margin-left: 8px; font-size: 12px; color: #6b7280;">
			<?php esc_html_e( 'Fetching frontend page to detect assets...', 'ultimate-performance' ); ?>
		</span>
	<?php else : ?>
		<p class="description" style="color: #b45309; margin: 0;">
			<span class="dashicons dashicons-info" style="font-size: 16px; width: 16px; height: 16px; vertical-align: text-bottom;"></span>
			<?php esc_html_e( 'Publish this post first to scan its frontend assets.', 'ultimate-performance' ); ?>
		</p>
	<?php endif; ?>

	<div id="up-script-manager-results" style="margin-top: 12px;"></div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
