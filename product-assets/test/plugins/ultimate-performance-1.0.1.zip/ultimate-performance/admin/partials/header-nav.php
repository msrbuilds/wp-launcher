<?php
/**
 * Shared top navigation bar for all plugin admin pages.
 *
 * Expects $current_page to be set before inclusion:
 *   'dashboard', 'settings', or 'database'
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$current_page = isset( $current_page ) ? $current_page : 'dashboard';
?>
<div class="up-topbar">
	<div class="up-topbar__brand">
		<span class="up-topbar__icon dashicons dashicons-performance"></span>
		<span class="up-topbar__name"><?php esc_html_e( 'Ultimate Performance', 'ultimate-performance' ); ?></span>
		<span class="up-topbar__version"><?php echo esc_html( 'v' . UP_VERSION ); ?></span>
	</div>
	<nav class="up-topbar__nav">
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=ultimate-performance' ) ); ?>"
		   class="up-topbar__tab <?php echo 'dashboard' === $current_page ? 'up-topbar__tab--active' : ''; ?>">
			<span class="dashicons dashicons-dashboard"></span>
			<?php esc_html_e( 'Dashboard', 'ultimate-performance' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=ultimate-performance-presets' ) ); ?>"
		   class="up-topbar__tab <?php echo 'presets' === $current_page ? 'up-topbar__tab--active' : ''; ?>">
			<span class="dashicons dashicons-controls-repeat"></span>
			<?php esc_html_e( 'Presets', 'ultimate-performance' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=ultimate-performance-settings' ) ); ?>"
		   class="up-topbar__tab <?php echo 'modules' === $current_page ? 'up-topbar__tab--active' : ''; ?>">
			<span class="dashicons dashicons-screenoptions"></span>
			<?php esc_html_e( 'Optimize', 'ultimate-performance' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=ultimate-performance-speed-test' ) ); ?>"
		   class="up-topbar__tab <?php echo 'speed-test' === $current_page ? 'up-topbar__tab--active' : ''; ?>">
			<span class="dashicons dashicons-chart-bar"></span>
			<?php esc_html_e( 'Speed Test', 'ultimate-performance' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=ultimate-performance-seo' ) ); ?>"
		   class="up-topbar__tab <?php echo 'seo' === $current_page ? 'up-topbar__tab--active' : ''; ?>">
			<span class="dashicons dashicons-search"></span>
			<?php esc_html_e( 'SEO', 'ultimate-performance' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=ultimate-performance-ai' ) ); ?>"
		   class="up-topbar__tab <?php echo 'ai' === $current_page ? 'up-topbar__tab--active' : ''; ?>">
			<span class="dashicons dashicons-admin-generic"></span>
			<?php esc_html_e( 'AI Assistant', 'ultimate-performance' ); ?>
		</a>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=ultimate-performance-static-site' ) ); ?>"
		   class="up-topbar__tab <?php echo 'static-site' === $current_page ? 'up-topbar__tab--active' : ''; ?>">
			<span class="dashicons dashicons-media-code"></span>
			<?php esc_html_e( 'Static Site', 'ultimate-performance' ); ?>
		</a>
	</nav>
	<div class="up-topbar__actions">
		<button type="button" id="up-header-purge-cache" class="up-btn up-btn--danger up-btn--small">
			<span class="dashicons dashicons-trash" style="font-size: 14px; width: 14px; height: 14px;"></span>
			<?php esc_html_e( 'Clear Cache', 'ultimate-performance' ); ?>
		</button>
	</div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
