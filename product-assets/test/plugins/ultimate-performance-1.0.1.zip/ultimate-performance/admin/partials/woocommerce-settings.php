<?php
/**
 * WooCommerce Optimization settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$wc_settings = Ultimate_Performance_Settings::get_module_settings( 'woocommerce' );
$wc_active   = class_exists( 'WooCommerce' );
?>
<form class="up-settings-form" data-module="woocommerce">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'WooCommerce Optimization', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Reduce page weight by conditionally removing WooCommerce scripts and styles on pages that don\'t need them.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $wc_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<?php if ( ! $wc_active ) : ?>
	<!-- WooCommerce Not Active Notice -->
	<div class="up-section-card">
		<div class="up-fields-stack" style="padding-top: 0; margin-top: 0;">
			<div class="up-notice up-notice--warning" style="margin: 20px 24px;">
				<span class="dashicons dashicons-warning"></span>
				<?php esc_html_e( 'WooCommerce is not currently active. These optimizations will only take effect when WooCommerce is installed and activated.', 'ultimate-performance' ); ?>
			</div>
		</div>
	</div>
	<?php endif; ?>

	<!-- Script Optimization -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Script & Style Optimization', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Remove unnecessary WooCommerce assets from pages where they are not needed.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<!-- Disable Cart Fragments -->
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--purple">
					<span class="dashicons dashicons-cart"></span>
				</div>
				<div class="up-feature-card__info">
					<h4 class="up-feature-card__title"><?php esc_html_e( 'Disable Cart Fragments', 'ultimate-performance' ); ?></h4>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Remove cart AJAX calls on non-shop pages', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_cart_fragments" value="1" <?php checked( $wc_settings['disable_cart_fragments'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<!-- Dequeue WC Scripts -->
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-editor-code"></span>
				</div>
				<div class="up-feature-card__info">
					<h4 class="up-feature-card__title"><?php esc_html_e( 'Dequeue WC Scripts', 'ultimate-performance' ); ?></h4>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Remove all WC scripts & styles on non-WC pages', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="dequeue_wc_scripts" value="1" <?php checked( $wc_settings['dequeue_wc_scripts'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<!-- Disable Password Strength -->
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--orange">
					<span class="dashicons dashicons-lock"></span>
				</div>
				<div class="up-feature-card__info">
					<h4 class="up-feature-card__title"><?php esc_html_e( 'Disable Password Meter', 'ultimate-performance' ); ?></h4>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Remove password strength meter on non-account pages', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_password_strength" value="1" <?php checked( $wc_settings['disable_password_strength'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<!-- Disable WC Widgets CSS -->
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--sky">
					<span class="dashicons dashicons-admin-appearance"></span>
				</div>
				<div class="up-feature-card__info">
					<h4 class="up-feature-card__title"><?php esc_html_e( 'Disable Smallscreen CSS', 'ultimate-performance' ); ?></h4>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Remove WooCommerce smallscreen stylesheet', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="disable_wc_widgets_css" value="1" <?php checked( $wc_settings['disable_wc_widgets_css'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
