<?php
/**
 * Dedicated SEO page template.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$current_page = 'seo';
?>
<div class="wrap up-app">

	<?php include UP_PLUGIN_DIR . 'admin/partials/header-nav.php'; ?>

	<div class="up-content">
		<?php include UP_PLUGIN_DIR . 'admin/partials/seo-settings.php'; ?>
	</div>

	<div class="up-toast" id="up-toast" style="display:none;">
		<span class="up-toast__message"></span>
	</div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
