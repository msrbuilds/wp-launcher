<?php
/**
 * CSS / JS Optimization settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$cssjs_settings = Ultimate_Performance_Settings::get_module_settings( 'css_js' );
?>
<form class="up-settings-form" data-module="css_js">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'CSS / JS Optimization', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Minify, defer, and delay CSS and JavaScript files to improve page load speed.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $cssjs_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- Minification -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Minification', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Reduce file sizes by removing comments, whitespace, and unnecessary characters.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--purple">
					<span class="dashicons dashicons-admin-customizer"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Minify CSS', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Minifies CSS files and serves them from cache.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="minify_css" value="1" <?php checked( $cssjs_settings['minify_css'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-editor-code"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Minify JavaScript', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Minifies JS files (skips already .min.js files).', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="minify_js" value="1" <?php checked( $cssjs_settings['minify_js'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-html"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Minify HTML', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Removes HTML comments and collapses whitespace between tags.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="minify_html" value="1" <?php checked( $cssjs_settings['minify_html'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack">
			<div class="up-field">
				<label for="exclude_minify_css" class="up-field__label"><?php esc_html_e( 'Exclude from CSS Minification', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Style handles to skip minification for. One per line. Use * for wildcard (e.g., elementor-*).', 'ultimate-performance' ); ?></p>
				<textarea name="exclude_minify_css" id="exclude_minify_css" class="up-textarea" rows="3" placeholder="style-handle&#10;elementor-*"><?php echo esc_textarea( $cssjs_settings['exclude_minify_css'] ); ?></textarea>
			</div>

			<div class="up-field">
				<label for="exclude_minify_js" class="up-field__label"><?php esc_html_e( 'Exclude from JS Minification', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Script handles to skip minification for. One per line. Use * for wildcard (e.g., wc-*).', 'ultimate-performance' ); ?></p>
				<textarea name="exclude_minify_js" id="exclude_minify_js" class="up-textarea" rows="3" placeholder="script-handle&#10;wc-*"><?php echo esc_textarea( $cssjs_settings['exclude_minify_js'] ); ?></textarea>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- CSS Loading -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'CSS Loading', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Control how CSS files are loaded to eliminate render-blocking stylesheets and improve First Contentful Paint (FCP).', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--sky">
					<span class="dashicons dashicons-admin-customizer"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Load CSS Asynchronously', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Loads stylesheets without blocking page rendering. Fixes the "Render blocking requests" PageSpeed warning for CSS files. Uses a noscript fallback for non-JS browsers.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="async_css" value="1" <?php checked( $cssjs_settings['async_css'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="exclude_async_css" class="up-field__label"><?php esc_html_e( 'Exclude from Async CSS', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Style handles to keep render-blocking (loaded normally). One per line. Use * for wildcard. Add critical above-the-fold CSS handles here if you notice a flash of unstyled content (FOUC).', 'ultimate-performance' ); ?></p>
				<textarea name="exclude_async_css" id="exclude_async_css" class="up-textarea" rows="3" placeholder="style-handle&#10;elementor-*"><?php echo esc_textarea( $cssjs_settings['exclude_async_css'] ); ?></textarea>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Used CSS (UCSS) -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Used CSS (UCSS)', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Analyze pages and strip away CSS rules that are not used, dramatically reducing file sizes and improving load times.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--purple">
					<span class="dashicons dashicons-editor-strikethrough"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title">
						<?php esc_html_e( 'Remove Unused CSS', 'ultimate-performance' ); ?>
						<span class="up-badge"><?php esc_html_e( 'Advanced', 'ultimate-performance' ); ?></span>
					</h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Analyze each page and remove CSS rules that aren\'t used. Dramatically reduces CSS file size.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="ucss_enabled" value="1" <?php checked( $cssjs_settings['ucss_enabled'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-art"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title">
						<?php esc_html_e( 'Critical CSS', 'ultimate-performance' ); ?>
						<span class="up-badge"><?php esc_html_e( 'Advanced', 'ultimate-performance' ); ?></span>
					</h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Extract above-the-fold CSS and inline it for instant rendering. Remaining CSS loads asynchronously.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="ucss_critical_css" value="1" <?php checked( $cssjs_settings['ucss_critical_css'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 16px;">
			<div class="up-field">
				<label class="up-field__label"><?php esc_html_e( 'Generation Method', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Choose how Used CSS is generated for each page.', 'ultimate-performance' ); ?></p>
				<div class="up-pill-group">
					<label class="up-pill">
						<input type="radio" name="ucss_generation_method" value="php"
							<?php checked( $cssjs_settings['ucss_generation_method'], 'php' ); ?>>
						<span class="up-pill__label"><?php esc_html_e( 'PHP Engine (Built-in)', 'ultimate-performance' ); ?></span>
					</label>
					<label class="up-pill">
						<input type="radio" name="ucss_generation_method" value="api"
							<?php checked( $cssjs_settings['ucss_generation_method'], 'api' ); ?>>
						<span class="up-pill__label"><?php esc_html_e( 'External API', 'ultimate-performance' ); ?></span>
					</label>
				</div>
			</div>

			<div class="up-field">
				<div class="up-inline-field">
					<label for="ucss_cache_lifespan" class="up-inline-field__label"><?php esc_html_e( 'Cache Lifespan', 'ultimate-performance' ); ?></label>
					<input type="number" name="ucss_cache_lifespan" id="ucss_cache_lifespan" class="up-input--small" min="1" max="365" value="<?php echo absint( $cssjs_settings['ucss_cache_lifespan'] ); ?>">
					<p class="up-field__hint" style="margin-left: 0; margin-top: 4px;"><?php esc_html_e( 'Regenerate UCSS every N days.', 'ultimate-performance' ); ?></p>
				</div>
			</div>

			<div class="up-field">
				<label for="ucss_safelist" class="up-field__label"><?php esc_html_e( 'Safelist Patterns', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'CSS selectors to always keep (one per line, wildcard * supported).', 'ultimate-performance' ); ?></p>
				<textarea name="ucss_safelist" id="ucss_safelist" class="up-textarea" rows="3" placeholder=".wp-block-*&#10;.elementor-*&#10;#wpadminbar"><?php echo esc_textarea( $cssjs_settings['ucss_safelist'] ); ?></textarea>
			</div>

			<div class="up-field">
				<label for="ucss_exclude_urls" class="up-field__label"><?php esc_html_e( 'Excluded URLs', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'URLs to skip UCSS generation (one per line, wildcard * supported).', 'ultimate-performance' ); ?></p>
				<textarea name="ucss_exclude_urls" id="ucss_exclude_urls" class="up-textarea" rows="3" placeholder="/cart/*&#10;/checkout/*&#10;/my-account/*"><?php echo esc_textarea( $cssjs_settings['ucss_exclude_urls'] ); ?></textarea>
			</div>

			<div class="up-field">
				<label for="ucss_exclude_handles" class="up-field__label"><?php esc_html_e( 'Excluded Handles', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Stylesheet handles to never process (one per line).', 'ultimate-performance' ); ?></p>
				<textarea name="ucss_exclude_handles" id="ucss_exclude_handles" class="up-textarea" rows="3" placeholder="admin-bar&#10;dashicons"><?php echo esc_textarea( $cssjs_settings['ucss_exclude_handles'] ); ?></textarea>
			</div>
		</div>

		<!-- UCSS Status -->
		<div class="up-fields-stack" style="margin-top: 16px;">
			<div class="up-field">
				<label class="up-field__label"><?php esc_html_e( 'UCSS Status', 'ultimate-performance' ); ?></label>
				<div id="up-ucss-status" style="padding: 12px; background: var(--up-gray-50); border-radius: 8px; font-size: 13px; color: var(--up-gray-500);">
					<?php esc_html_e( 'Loading UCSS status...', 'ultimate-performance' ); ?>
				</div>
				<div style="margin-top: 10px;">
					<button type="button" class="up-btn up-btn--small" id="up-ucss-purge-btn">
						<?php esc_html_e( 'Purge UCSS Cache', 'ultimate-performance' ); ?>
					</button>
				</div>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- JavaScript Loading -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'JavaScript Loading', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Control how JavaScript files are loaded to reduce render-blocking and improve perceived performance.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--orange">
					<span class="dashicons dashicons-controls-forward"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Defer JavaScript', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Adds defer attribute to scripts so they load without blocking rendering.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="defer_js" value="1" <?php checked( $cssjs_settings['defer_js'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--rose">
					<span class="dashicons dashicons-clock"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Delay JavaScript', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Delays non-critical scripts until user interaction (click, scroll, mousemove).', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="delay_js" value="1" <?php checked( $cssjs_settings['delay_js'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--amber">
					<span class="dashicons dashicons-download"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Move jQuery to Footer', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Moves jQuery from the &lt;head&gt; to the footer, eliminating it as a render-blocking resource. Fixes the PageSpeed "Render blocking resources" warning for jQuery.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="move_jquery_to_footer" value="1" <?php checked( $cssjs_settings['move_jquery_to_footer'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 16px;">
			<div class="up-field">
				<label for="exclude_defer_js" class="up-field__label"><?php esc_html_e( 'Exclude from Defer', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Script handles to exclude from deferring. One per line. Use * for wildcard (e.g., wc-*).', 'ultimate-performance' ); ?></p>
				<textarea name="exclude_defer_js" id="exclude_defer_js" class="up-textarea" rows="3" placeholder="script-handle&#10;wc-*"><?php echo esc_textarea( $cssjs_settings['exclude_defer_js'] ); ?></textarea>
			</div>

			<div class="up-field">
				<label for="exclude_delay_js" class="up-field__label"><?php esc_html_e( 'Exclude from Delay', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Script handles to exclude from delaying. One per line. Use * for wildcard (e.g., wc-*).', 'ultimate-performance' ); ?></p>
				<textarea name="exclude_delay_js" id="exclude_delay_js" class="up-textarea" rows="3" placeholder="script-handle&#10;wc-*"><?php echo esc_textarea( $cssjs_settings['exclude_delay_js'] ); ?></textarea>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Cleanup -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Cleanup', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Clean up asset URLs for better caching and cleaner source code.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--sky">
					<span class="dashicons dashicons-editor-removeformatting"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove Query Strings', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Strips ?ver= query strings from CSS/JS URLs for better CDN and proxy caching.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="remove_query_strings" value="1" <?php checked( $cssjs_settings['remove_query_strings'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
