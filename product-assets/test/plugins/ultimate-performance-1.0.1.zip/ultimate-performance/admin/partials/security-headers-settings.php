<?php
/**
 * Security Headers settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$sh_settings = Ultimate_Performance_Settings::get_module_settings( 'security_headers' );
?>
<form class="up-settings-form" data-module="security_headers">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Security Headers', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Add HTTP security headers to protect your site against common attacks like clickjacking, MIME sniffing, and cross-site scripting.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $sh_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- Basic Headers -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Basic Headers', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Configure common HTTP security headers. These are applied to all frontend responses.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<!-- X-Content-Type-Options -->
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-shield"></span>
				</div>
				<div class="up-feature-card__info">
					<h4 class="up-feature-card__title"><?php esc_html_e( 'X-Content-Type-Options', 'ultimate-performance' ); ?></h4>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Prevent MIME-type sniffing (nosniff)', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="x_content_type_options" value="1" <?php checked( $sh_settings['x_content_type_options'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<!-- X-XSS-Protection -->
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--rose">
					<span class="dashicons dashicons-shield-alt"></span>
				</div>
				<div class="up-feature-card__info">
					<h4 class="up-feature-card__title"><?php esc_html_e( 'X-XSS-Protection', 'ultimate-performance' ); ?></h4>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Enable browser XSS filter (1; mode=block)', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="x_xss_protection" value="1" <?php checked( $sh_settings['x_xss_protection'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-select-grid">
			<!-- X-Frame-Options -->
			<div class="up-select-card">
				<label class="up-select-card__label" for="x_frame_options"><?php esc_html_e( 'X-Frame-Options', 'ultimate-performance' ); ?></label>
				<span class="up-select-card__hint"><?php esc_html_e( 'Prevent your site from being embedded in iframes.', 'ultimate-performance' ); ?></span>
				<select name="x_frame_options" id="x_frame_options" class="up-select">
					<option value="SAMEORIGIN" <?php selected( $sh_settings['x_frame_options'], 'SAMEORIGIN' ); ?>><?php esc_html_e( 'SAMEORIGIN', 'ultimate-performance' ); ?></option>
					<option value="DENY" <?php selected( $sh_settings['x_frame_options'], 'DENY' ); ?>><?php esc_html_e( 'DENY', 'ultimate-performance' ); ?></option>
					<option value="disabled" <?php selected( $sh_settings['x_frame_options'], 'disabled' ); ?>><?php esc_html_e( 'Disabled', 'ultimate-performance' ); ?></option>
				</select>
			</div>

			<!-- Referrer-Policy -->
			<div class="up-select-card">
				<label class="up-select-card__label" for="referrer_policy"><?php esc_html_e( 'Referrer-Policy', 'ultimate-performance' ); ?></label>
				<span class="up-select-card__hint"><?php esc_html_e( 'Control how much referrer info is shared.', 'ultimate-performance' ); ?></span>
				<select name="referrer_policy" id="referrer_policy" class="up-select">
					<option value="no-referrer" <?php selected( $sh_settings['referrer_policy'], 'no-referrer' ); ?>>no-referrer</option>
					<option value="no-referrer-when-downgrade" <?php selected( $sh_settings['referrer_policy'], 'no-referrer-when-downgrade' ); ?>>no-referrer-when-downgrade</option>
					<option value="origin" <?php selected( $sh_settings['referrer_policy'], 'origin' ); ?>>origin</option>
					<option value="origin-when-cross-origin" <?php selected( $sh_settings['referrer_policy'], 'origin-when-cross-origin' ); ?>>origin-when-cross-origin</option>
					<option value="same-origin" <?php selected( $sh_settings['referrer_policy'], 'same-origin' ); ?>>same-origin</option>
					<option value="strict-origin" <?php selected( $sh_settings['referrer_policy'], 'strict-origin' ); ?>>strict-origin</option>
					<option value="strict-origin-when-cross-origin" <?php selected( $sh_settings['referrer_policy'], 'strict-origin-when-cross-origin' ); ?>>strict-origin-when-cross-origin</option>
					<option value="unsafe-url" <?php selected( $sh_settings['referrer_policy'], 'unsafe-url' ); ?>>unsafe-url</option>
					<option value="disabled" <?php selected( $sh_settings['referrer_policy'], 'disabled' ); ?>><?php esc_html_e( 'Disabled', 'ultimate-performance' ); ?></option>
				</select>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- HSTS -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'HTTP Strict Transport Security (HSTS)', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Force browsers to only communicate with your site over HTTPS. Only enable this if your site fully supports HTTPS.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-notice up-notice--warning" style="margin: 0 24px;">
				<span class="dashicons dashicons-warning"></span>
				<?php esc_html_e( 'Warning: Only enable HSTS if your site is fully served over HTTPS. Misconfiguration can make your site inaccessible.', 'ultimate-performance' ); ?>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--orange">
					<span class="dashicons dashicons-lock"></span>
				</div>
				<div class="up-feature-card__info">
					<h4 class="up-feature-card__title"><?php esc_html_e( 'Enable HSTS', 'ultimate-performance' ); ?></h4>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Send Strict-Transport-Security header', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="hsts_enabled" value="1" <?php checked( $sh_settings['hsts_enabled'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-networking"></span>
				</div>
				<div class="up-feature-card__info">
					<h4 class="up-feature-card__title"><?php esc_html_e( 'Include Subdomains', 'ultimate-performance' ); ?></h4>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Apply HSTS to all subdomains', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="hsts_include_subdomains" value="1" <?php checked( $sh_settings['hsts_include_subdomains'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-inline-field">
				<span class="up-inline-field__label"><?php esc_html_e( 'Max Age', 'ultimate-performance' ); ?></span>
				<span class="up-inline-field__hint"><?php esc_html_e( 'Duration in seconds (default: 31536000 = 1 year)', 'ultimate-performance' ); ?></span>
				<input type="number" name="hsts_max_age" class="up-input--small" value="<?php echo absint( $sh_settings['hsts_max_age'] ); ?>" min="0" step="1" style="width: 120px;">
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Permissions Policy -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Permissions Policy', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Control which browser features can be used on your site (camera, microphone, geolocation, etc).', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="permissions_policy" class="up-field__label"><?php esc_html_e( 'Policy String', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Enter the raw Permissions-Policy header value. Example: camera=(), microphone=(), geolocation=()', 'ultimate-performance' ); ?></p>
				<textarea name="permissions_policy" id="permissions_policy" class="up-textarea" rows="3" placeholder="camera=(), microphone=(), geolocation=()"><?php echo esc_textarea( $sh_settings['permissions_policy'] ); ?></textarea>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
