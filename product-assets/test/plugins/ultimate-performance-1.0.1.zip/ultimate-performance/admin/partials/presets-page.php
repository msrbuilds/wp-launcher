<?php
/**
 * Optimization Presets page template.
 *
 * Displays preset cards that let users apply pre-built
 * optimization profiles with a single click.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$presets       = Ultimate_Performance_Settings::get_presets();
$active_preset = Ultimate_Performance_Settings::get_active_preset();
$current_page  = 'presets';
?>
<div class="wrap up-app">

	<?php include UP_PLUGIN_DIR . 'admin/partials/header-nav.php'; ?>

	<div class="up-content">

		<div class="up-section-card" style="margin-bottom: 24px;">
			<div class="up-section-card__header" style="border-bottom: none;">
				<div>
					<h2><?php esc_html_e( 'Optimization Presets', 'ultimate-performance' ); ?></h2>
					<p class="up-section-card__desc">
						<?php esc_html_e( 'Quickly configure your site with a pre-built optimization profile. Each preset enables a different level of performance optimization. Your existing exclusion lists, API keys, and custom URLs will not be affected.', 'ultimate-performance' ); ?>
					</p>
				</div>
			</div>
		</div>

		<div class="up-presets-grid">
			<?php foreach ( $presets as $slug => $preset ) :
				$is_active      = ( $slug === $active_preset );
				$is_recommended = ( 'recommended' === $slug );

				$card_classes = 'up-preset-card';
				if ( $is_recommended ) {
					$card_classes .= ' up-preset-card--recommended';
				}
				if ( $is_active ) {
					$card_classes .= ' up-preset-card--active';
				}
			?>
				<div class="<?php echo esc_attr( $card_classes ); ?>" data-preset="<?php echo esc_attr( $slug ); ?>">
					<?php if ( $is_active ) : ?>
						<div class="up-preset-card__active-badge">
							<span class="dashicons dashicons-yes-alt"></span>
							<?php esc_html_e( 'Active', 'ultimate-performance' ); ?>
						</div>
					<?php endif; ?>

					<?php if ( $is_recommended && ! $is_active ) : ?>
						<div class="up-preset-card__badge">
							<?php esc_html_e( 'Recommended', 'ultimate-performance' ); ?>
						</div>
					<?php endif; ?>

					<div class="up-preset-card__header">
						<span class="dashicons <?php echo esc_attr( $preset['icon'] ); ?> up-preset-card__icon"></span>
						<h3 class="up-preset-card__title"><?php echo esc_html( $preset['label'] ); ?></h3>
						<p class="up-preset-card__desc"><?php echo esc_html( $preset['description'] ); ?></p>
					</div>

					<div class="up-preset-card__features">
						<?php foreach ( $preset['features'] as $feature ) : ?>
							<div class="up-preset-card__feature">
								<span class="dashicons dashicons-yes-alt up-preset-card__check"></span>
								<span><?php echo esc_html( $feature ); ?></span>
							</div>
						<?php endforeach; ?>
					</div>

					<div class="up-preset-card__footer">
						<?php if ( $is_active ) : ?>
							<span class="up-preset-card__active-label">
								<span class="dashicons dashicons-yes-alt"></span>
								<?php esc_html_e( 'Currently Active', 'ultimate-performance' ); ?>
							</span>
						<?php else : ?>
							<button type="button"
									class="up-btn <?php echo $is_recommended ? 'up-btn--primary' : 'up-btn--secondary'; ?> up-apply-preset"
									data-preset="<?php echo esc_attr( $slug ); ?>"
									data-preset-name="<?php echo esc_attr( $preset['label'] ); ?>">
								<?php esc_html_e( 'Apply Preset', 'ultimate-performance' ); ?>
							</button>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="up-preset-notice">
			<span class="dashicons dashicons-warning"></span>
			<span><?php esc_html_e( 'Applying a preset will overwrite your current toggle settings across all modules. Text fields, exclusion lists, and API keys are preserved. It is recommended to test your site after applying a preset.', 'ultimate-performance' ); ?></span>
		</div>

	</div>

	<div class="up-toast" id="up-toast" style="display:none;">
		<span class="up-toast__message"></span>
	</div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
