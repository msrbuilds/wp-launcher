<?php
/**
 * Dashboard page template.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$modules  = Ultimate_Performance_Settings::get_modules();
$settings = get_option( Ultimate_Performance_Settings::OPTION_NAME, Ultimate_Performance_Settings::get_defaults() );

$active_count = 0;
foreach ( $modules as $key => $module ) {
	if ( ! empty( $settings[ $key ]['enabled'] ) ) {
		$active_count++;
	}
}

$icon_colors = array( 'rose', 'indigo', 'teal', 'orange', 'purple', 'sky', 'amber', 'success', 'rose', 'indigo', 'teal', 'orange', 'purple' );

// Fetch 3 most recent speed test reports.
global $wpdb;
$reports_table  = $wpdb->prefix . 'up_speed_tests';
$recent_reports = array();
$latest_score   = null;

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $reports_table ) ) === $reports_table ) {
	// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name from $wpdb->prefix is safe.
	$recent_reports = $wpdb->get_results(
		"SELECT id, url, strategy, performance_score, lcp_ms, inp_ms, cls_score, label, raw_response, created_at
		 FROM {$reports_table} ORDER BY created_at DESC LIMIT 3",
		ARRAY_A
	);
	// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

	if ( ! empty( $recent_reports ) ) {
		$latest_score = absint( $recent_reports[0]['performance_score'] );
	}
}

// Build fix suggestions from the latest report(s).
$fix_suggestions = array();

if ( ! empty( $recent_reports ) ) {
	$fix_map = Ultimate_Performance_Speed_Test::get_audit_fix_map();

	/**
	 * Helper: check if a fix is already applied.
	 */
	$is_fix_applied = function ( $fix ) use ( $settings ) {
		$mod = isset( $settings[ $fix['module'] ] ) ? $settings[ $fix['module'] ] : array();
		if ( empty( $mod['enabled'] ) ) {
			return false;
		}
		if ( ! empty( $fix['settings'] ) ) {
			foreach ( $fix['settings'] as $fk => $fv ) {
				if ( empty( $mod[ $fk ] ) ) {
					return false;
				}
			}
		}
		return true;
	};

	// Track which audit_ids are already added so we don't duplicate.
	$seen_audits = array();

	// --- 1. PSI report suggestions (if available) ---
	foreach ( $recent_reports as $rpt ) {
		if ( 'quick' === $rpt['strategy'] || empty( $rpt['raw_response'] ) ) {
			continue;
		}
		$psi_raw   = json_decode( $rpt['raw_response'], true );
		$lh_audits = isset( $psi_raw['lighthouseResult']['audits'] ) ? $psi_raw['lighthouseResult']['audits'] : array();
		if ( empty( $lh_audits ) ) {
			continue;
		}

		foreach ( $fix_map as $fix_audit_id => $fix ) {
			if ( empty( $fix['module'] ) || isset( $seen_audits[ $fix_audit_id ] ) ) {
				continue;
			}
			if ( ! isset( $lh_audits[ $fix_audit_id ] ) ) {
				continue;
			}
			$lh_audit = $lh_audits[ $fix_audit_id ];
			if ( ! isset( $lh_audit['score'] ) || null === $lh_audit['score'] || $lh_audit['score'] >= 0.9 ) {
				continue;
			}

			$seen_audits[ $fix_audit_id ] = true;
			$fix_suggestions[] = array(
				'audit_id'        => $fix_audit_id,
				'audit_title'     => isset( $lh_audit['title'] ) ? $lh_audit['title'] : $fix_audit_id,
				'score'           => $lh_audit['score'],
				'module'          => $fix['module'],
				'tip'             => $fix['tip'],
				'already_applied' => $is_fix_applied( $fix ),
				'can_auto_fix'    => ! empty( $fix['settings'] ),
			);
		}
		break; // Only use the most recent PSI report.
	}

	// --- 2. Quick Test suggestions (always checked, fills gaps) ---
	foreach ( $recent_reports as $rpt ) {
		if ( 'quick' !== $rpt['strategy'] || empty( $rpt['raw_response'] ) ) {
			continue;
		}
		$qt_raw = json_decode( $rpt['raw_response'], true );
		if ( ! is_array( $qt_raw ) ) {
			continue;
		}

		$qt_timing = isset( $qt_raw['timing'] ) ? $qt_raw['timing'] : array();
		$qt_res    = isset( $qt_raw['resources'] ) ? $qt_raw['resources'] : array();
		$qt_bd     = isset( $qt_res['breakdown'] ) ? $qt_res['breakdown'] : array();

		$qt_checks = array(
			array(
				'condition' => isset( $qt_timing['server'] ) && $qt_timing['server'] > 600,
				'audit_id'  => 'server-response-time',
				'title'     => __( 'Slow Server Response', 'ultimate-performance' ),
				'score'     => isset( $qt_timing['server'] ) ? max( 0, min( 0.89, 1 - ( $qt_timing['server'] / 2000 ) ) ) : 0.5,
			),
			array(
				'condition' => isset( $qt_timing['ttfb'] ) && $qt_timing['ttfb'] > 800,
				'audit_id'  => 'server-response-time',
				'title'     => __( 'High Time to First Byte', 'ultimate-performance' ),
				'score'     => isset( $qt_timing['ttfb'] ) ? max( 0, min( 0.89, 1 - ( $qt_timing['ttfb'] / 3000 ) ) ) : 0.5,
			),
			array(
				'condition' => isset( $qt_bd['css'] ) && $qt_bd['css'] > 200000,
				'audit_id'  => 'unminified-css',
				'title'     => __( 'Large CSS Payload', 'ultimate-performance' ),
				'score'     => 0.4,
			),
			array(
				'condition' => isset( $qt_bd['script'] ) && $qt_bd['script'] > 300000,
				'audit_id'  => 'unminified-javascript',
				'title'     => __( 'Large JavaScript Payload', 'ultimate-performance' ),
				'score'     => 0.4,
			),
			array(
				'condition' => isset( $qt_bd['img'] ) && $qt_bd['img'] > 500000,
				'audit_id'  => 'uses-optimized-images',
				'title'     => __( 'Large Image Payload', 'ultimate-performance' ),
				'score'     => 0.3,
			),
			array(
				'condition' => isset( $qt_bd['img'] ) && $qt_bd['img'] > 200000,
				'audit_id'  => 'modern-image-formats',
				'title'     => __( 'Images Could Use Next-Gen Formats', 'ultimate-performance' ),
				'score'     => 0.5,
			),
			array(
				'condition' => isset( $qt_bd['font'] ) && $qt_bd['font'] > 100000,
				'audit_id'  => 'font-display',
				'title'     => __( 'Large Font Payload', 'ultimate-performance' ),
				'score'     => 0.5,
			),
			array(
				'condition' => isset( $qt_timing['load_time'] ) && $qt_timing['load_time'] > 3000,
				'audit_id'  => 'render-blocking-resources',
				'title'     => __( 'Slow Page Load', 'ultimate-performance' ),
				'score'     => isset( $qt_timing['load_time'] ) ? max( 0, min( 0.89, 1 - ( $qt_timing['load_time'] / 8000 ) ) ) : 0.4,
			),
			array(
				'condition' => isset( $qt_res['count'] ) && $qt_res['count'] > 60,
				'audit_id'  => 'unused-javascript',
				'title'     => __( 'Too Many Requests', 'ultimate-performance' ),
				'score'     => 0.4,
			),
			array(
				'condition' => isset( $qt_bd['img'] ) && $qt_bd['img'] > 100000,
				'audit_id'  => 'offscreen-images',
				'title'     => __( 'Images Should Be Lazy Loaded', 'ultimate-performance' ),
				'score'     => 0.5,
			),
			array(
				'condition' => isset( $qt_timing['load_time'] ) && $qt_timing['load_time'] > 2500
					&& isset( $qt_timing['ttfb'] ) && $qt_timing['ttfb'] > 400,
				'audit_id'  => 'uses-text-compression',
				'title'     => __( 'Enable GZIP Compression', 'ultimate-performance' ),
				'score'     => 0.5,
			),
		);

		foreach ( $qt_checks as $check ) {
			if ( ! $check['condition'] ) {
				continue;
			}
			if ( isset( $seen_audits[ $check['audit_id'] ] ) ) {
				continue;
			}
			$seen_audits[ $check['audit_id'] ] = true;

			if ( ! isset( $fix_map[ $check['audit_id'] ] ) ) {
				continue;
			}
			$fix = $fix_map[ $check['audit_id'] ];
			if ( empty( $fix['module'] ) ) {
				continue;
			}

			$fix_suggestions[] = array(
				'audit_id'        => $check['audit_id'],
				'audit_title'     => $check['title'],
				'score'           => $check['score'],
				'module'          => $fix['module'],
				'tip'             => $fix['tip'],
				'already_applied' => $is_fix_applied( $fix ),
				'can_auto_fix'    => ! empty( $fix['settings'] ),
			);
		}
		break; // Only use the most recent Quick Test.
	}

	// Sort by score ascending (worst first).
	usort( $fix_suggestions, function ( $a, $b ) {
		return ( $a['score'] ?? 1 ) <=> ( $b['score'] ?? 1 );
	} );
}

$current_page = 'dashboard';
?>
<div class="wrap up-app">

	<?php include UP_PLUGIN_DIR . 'admin/partials/header-nav.php'; ?>

	<div class="up-content">
		<!-- Stats Row -->
		<div class="up-stats-row">
			<div class="up-stat-card">
				<div class="up-stat-card__icon up-stat-card__icon--teal">
					<span class="dashicons dashicons-yes-alt"></span>
				</div>
				<div class="up-stat-card__info">
					<span class="up-stat-card__number"><?php echo absint( $active_count ); ?></span>
					<span class="up-stat-card__label"><?php esc_html_e( 'Active Modules', 'ultimate-performance' ); ?></span>
				</div>
			</div>
			<div class="up-stat-card">
				<div class="up-stat-card__icon up-stat-card__icon--orange">
					<span class="dashicons dashicons-screenoptions"></span>
				</div>
				<div class="up-stat-card__info">
					<span class="up-stat-card__number"><?php echo absint( count( $modules ) ); ?></span>
					<span class="up-stat-card__label"><?php esc_html_e( 'Total Modules', 'ultimate-performance' ); ?></span>
				</div>
			</div>
			<div class="up-stat-card">
				<div class="up-stat-card__icon up-stat-card__icon--purple">
					<span class="dashicons dashicons-dashboard"></span>
				</div>
				<div class="up-stat-card__info">
					<span class="up-stat-card__number"><?php echo null !== $latest_score ? absint( $latest_score ) : '--'; ?></span>
					<span class="up-stat-card__label"><?php esc_html_e( 'Latest Score', 'ultimate-performance' ); ?></span>
				</div>
			</div>
		</div>

		<!-- Recent Speed Test Reports -->
		<div class="up-recent-reports__header">
			<h2 class="up-recent-reports__title"><?php esc_html_e( 'Recent Speed Tests', 'ultimate-performance' ); ?></h2>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=ultimate-performance-speed-test' ) ); ?>" class="up-btn up-btn--small">
				<?php echo ! empty( $recent_reports ) ? esc_html__( 'View All', 'ultimate-performance' ) : esc_html__( 'Run Speed Test', 'ultimate-performance' ); ?>
			</a>
		</div>

		<?php if ( ! empty( $recent_reports ) ) : ?>
		<div class="up-recent-reports-grid">
			<?php
			foreach ( $recent_reports as $report ) :
				$r_score    = absint( $report['performance_score'] );
				$r_strategy = $report['strategy'];
				$r_url      = $report['url'] ? preg_replace( '#^https?://#', '', $report['url'] ) : '';
				$r_label    = ! empty( $report['label'] ) ? $report['label'] : '';
				$r_date     = $report['created_at'] ? mysql2date( 'M j, g:i a', $report['created_at'] ) : '';

				// Score color.
				if ( $r_score >= 90 ) {
					$score_color = '#059669';
					$score_bg    = 'rgba(5,150,105,0.08)';
				} elseif ( $r_score >= 50 ) {
					$score_color = '#D97706';
					$score_bg    = 'rgba(217,119,6,0.08)';
				} else {
					$score_color = '#DC2626';
					$score_bg    = 'rgba(220,38,38,0.08)';
				}

				// Strategy icon & label.
				if ( 'quick' === $r_strategy ) {
					$strat_icon  = 'dashicons-performance';
					$strat_label = __( 'Quick', 'ultimate-performance' );
				} elseif ( 'desktop' === $r_strategy ) {
					$strat_icon  = 'dashicons-desktop';
					$strat_label = __( 'Desktop', 'ultimate-performance' );
				} else {
					$strat_icon  = 'dashicons-smartphone';
					$strat_label = __( 'Mobile', 'ultimate-performance' );
				}

				// SVG gauge dimensions.
				$gauge_size    = 80;
				$gauge_radius  = 34;
				$gauge_stroke  = 6;
				$circumference = 2 * 3.14159 * $gauge_radius;
				$dash_offset   = $circumference - ( $r_score / 100 ) * $circumference;

				// Extract metrics from raw_response.
				$raw       = json_decode( $report['raw_response'], true );
				$is_quick  = 'quick' === $r_strategy;
				$card_metrics = array();

				if ( $is_quick && is_array( $raw ) ) {
					$timing = isset( $raw['timing'] ) ? $raw['timing'] : array();
					if ( ! empty( $timing['ttfb'] ) ) {
						$card_metrics[] = array( 'label' => 'TTFB', 'value' => round( $timing['ttfb'] ) . ' ms' );
					}
					if ( ! empty( $timing['fcp'] ) ) {
						$card_metrics[] = array( 'label' => 'FCP', 'value' => number_format( $timing['fcp'] / 1000, 1 ) . ' s' );
					}
					if ( ! empty( $timing['dom_ready'] ) ) {
						$card_metrics[] = array( 'label' => 'DCL', 'value' => number_format( $timing['dom_ready'] / 1000, 1 ) . ' s' );
					}
					if ( ! empty( $timing['load_time'] ) ) {
						$card_metrics[] = array( 'label' => 'Load', 'value' => number_format( $timing['load_time'] / 1000, 1 ) . ' s' );
					}
				} elseif ( is_array( $raw ) ) {
					$lh     = isset( $raw['lighthouseResult']['audits'] ) ? $raw['lighthouseResult']['audits'] : array();
					$psi_map = array(
						'first-contentful-paint'  => 'FCP',
						'largest-contentful-paint' => 'LCP',
						'total-blocking-time'     => 'TBT',
						'cumulative-layout-shift'  => 'CLS',
						'speed-index'             => 'SI',
						'server-response-time'    => 'TTFB',
					);
					foreach ( $psi_map as $audit_key => $metric_label ) {
						if ( ! isset( $lh[ $audit_key ] ) ) {
							continue;
						}
						$audit  = $lh[ $audit_key ];
						$m_val  = '';

						// Use numericValue for a clean formatted output.
						if ( isset( $audit['numericValue'] ) ) {
							$num = (float) $audit['numericValue'];
							if ( 'CLS' === $metric_label ) {
								$m_val = number_format( $num, 3 );
							} elseif ( $num >= 1000 ) {
								$m_val = number_format( $num / 1000, 1 ) . ' s';
							} else {
								$m_val = round( $num ) . ' ms';
							}
						} elseif ( isset( $audit['displayValue'] ) ) {
							$m_val = wp_strip_all_tags( $audit['displayValue'] );
						} else {
							continue;
						}

						$card_metrics[] = array(
							'label' => $metric_label,
							'value' => $m_val,
							'score' => isset( $audit['score'] ) ? (float) $audit['score'] : null,
						);
					}
				}
			?>
			<div class="up-report-card">
				<div class="up-report-card__top">
					<div class="up-report-card__gauge" style="background: <?php echo esc_attr( $score_bg ); ?>;">
						<svg width="<?php echo absint( $gauge_size ); ?>" height="<?php echo absint( $gauge_size ); ?>" viewBox="0 0 <?php echo absint( $gauge_size ); ?> <?php echo absint( $gauge_size ); ?>">
							<circle cx="<?php echo absint( $gauge_size / 2 ); ?>" cy="<?php echo absint( $gauge_size / 2 ); ?>" r="<?php echo absint( $gauge_radius ); ?>" fill="none" stroke="rgba(0,0,0,0.06)" stroke-width="<?php echo absint( $gauge_stroke ); ?>"/>
							<circle cx="<?php echo absint( $gauge_size / 2 ); ?>" cy="<?php echo absint( $gauge_size / 2 ); ?>" r="<?php echo absint( $gauge_radius ); ?>" fill="none" stroke="<?php echo esc_attr( $score_color ); ?>" stroke-width="<?php echo absint( $gauge_stroke ); ?>" stroke-linecap="round" stroke-dasharray="<?php echo esc_attr( round( $circumference, 2 ) ); ?>" stroke-dashoffset="<?php echo esc_attr( round( $dash_offset, 2 ) ); ?>" transform="rotate(-90 <?php echo absint( $gauge_size / 2 ); ?> <?php echo absint( $gauge_size / 2 ); ?>)"/>
							<text x="50%" y="50%" text-anchor="middle" dominant-baseline="central" fill="<?php echo esc_attr( $score_color ); ?>" font-size="22" font-weight="700"><?php echo absint( $r_score ); ?></text>
						</svg>
					</div>
					<div class="up-report-card__info">
						<div class="up-report-card__url" title="<?php echo esc_attr( $r_url ); ?>"><?php echo esc_html( $r_url ); ?></div>
						<?php if ( $r_label ) : ?>
							<div class="up-report-card__label"><?php echo esc_html( $r_label ); ?></div>
						<?php endif; ?>
						<div class="up-report-card__meta">
							<span class="up-report-card__badge">
								<span class="dashicons <?php echo esc_attr( $strat_icon ); ?>"></span>
								<?php echo esc_html( $strat_label ); ?>
							</span>
							<span class="up-report-card__date"><?php echo esc_html( $r_date ); ?></span>
						</div>
					</div>
				</div>
				<?php if ( ! empty( $card_metrics ) ) : ?>
				<div class="up-report-card__metrics">
					<?php foreach ( $card_metrics as $m ) :
						$m_color = '#374151';
						if ( isset( $m['score'] ) && null !== $m['score'] ) {
							if ( $m['score'] >= 0.9 ) {
								$m_color = '#059669';
							} elseif ( $m['score'] >= 0.5 ) {
								$m_color = '#D97706';
							} else {
								$m_color = '#DC2626';
							}
						}
					?>
					<div class="up-report-card__metric">
						<span class="up-report-card__metric-value" style="color: <?php echo esc_attr( $m_color ); ?>;"><?php echo esc_html( $m['value'] ); ?></span>
						<span class="up-report-card__metric-label"><?php echo esc_html( $m['label'] ); ?></span>
					</div>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
			</div>
			<?php endforeach; ?>
		</div>
		<?php else : ?>
		<div class="up-recent-reports-empty">
			<span class="dashicons dashicons-chart-bar"></span>
			<p><?php esc_html_e( 'No speed tests yet. Run your first test to track performance.', 'ultimate-performance' ); ?></p>
		</div>
		<?php endif; ?>

		<!-- Suggested Fixes -->
		<?php if ( ! empty( $recent_reports ) ) : ?>
		<div class="up-section-card" style="margin-bottom: 28px;">
			<div class="up-section-card__header">
				<div>
					<h2><?php esc_html_e( 'Suggested Fixes', 'ultimate-performance' ); ?></h2>
					<p class="up-section-card__desc"><?php esc_html_e( 'Recommendations based on your latest speed test. Apply with one click.', 'ultimate-performance' ); ?></p>
				</div>
			</div>

			<?php if ( ! empty( $fix_suggestions ) ) : ?>
			<div class="up-fix-list">
				<?php foreach ( $fix_suggestions as $suggestion ) :
					// Severity color.
					if ( $suggestion['score'] < 0.5 ) {
						$sev_color = '#DC2626';
					} else {
						$sev_color = '#D97706';
					}

					$mod_label = isset( $modules[ $suggestion['module'] ]['label'] )
						? $modules[ $suggestion['module'] ]['label']
						: $suggestion['module'];
					$mod_tab = isset( $modules[ $suggestion['module'] ]['tab'] )
						? $modules[ $suggestion['module'] ]['tab']
						: '';
				?>
				<div class="up-fix-item<?php echo $suggestion['already_applied'] ? ' up-fix-item--applied' : ''; ?>" data-audit-id="<?php echo esc_attr( $suggestion['audit_id'] ); ?>">
					<div class="up-fix-item__dot" style="background: <?php echo esc_attr( $suggestion['already_applied'] ? '#059669' : $sev_color ); ?>;"></div>
					<div class="up-fix-item__content">
						<div class="up-fix-item__title"><?php echo esc_html( $suggestion['audit_title'] ); ?></div>
						<div class="up-fix-item__tip"><?php echo esc_html( $suggestion['tip'] ); ?></div>
						<span class="up-fix-item__module"><?php echo esc_html( $mod_label ); ?></span>
					</div>
					<div class="up-fix-item__action">
						<?php if ( $suggestion['already_applied'] ) : ?>
							<span class="up-badge up-badge--success">
								<span class="dashicons dashicons-yes-alt" style="font-size:14px;width:14px;height:14px;margin-right:2px;"></span>
								<?php esc_html_e( 'Applied', 'ultimate-performance' ); ?>
							</span>
						<?php elseif ( $suggestion['can_auto_fix'] ) : ?>
							<button type="button" class="up-btn up-btn--small up-btn--primary up-apply-fix" data-audit-id="<?php echo esc_attr( $suggestion['audit_id'] ); ?>">
								<?php esc_html_e( 'Apply Fix', 'ultimate-performance' ); ?>
							</button>
						<?php else : ?>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=ultimate-performance-settings&tab=' . $mod_tab ) ); ?>" class="up-btn up-btn--small">
								<?php esc_html_e( 'Configure', 'ultimate-performance' ); ?>
							</a>
						<?php endif; ?>
					</div>
				</div>
				<?php endforeach; ?>
			</div>
			<?php else : ?>
			<div class="up-fix-empty">
				<span class="dashicons dashicons-yes-alt"></span>
				<p><?php esc_html_e( 'No fixable issues found. Your latest report looks good!', 'ultimate-performance' ); ?></p>
			</div>
			<?php endif; ?>
		</div>
		<?php endif; ?>

		<!-- Module Status -->
		<div class="up-section-card">
			<div class="up-section-card__header">
				<div>
					<h2><?php esc_html_e( 'Module Status', 'ultimate-performance' ); ?></h2>
					<p class="up-section-card__desc"><?php esc_html_e( 'Overview of all performance modules and their current status.', 'ultimate-performance' ); ?></p>
				</div>
			</div>

			<div class="up-module-grid">
				<?php
				$i = 0;
				foreach ( $modules as $key => $module ) :
					$is_enabled  = ! empty( $settings[ $key ]['enabled'] );
					$icon_color  = $icon_colors[ $i % count( $icon_colors ) ];
					$i++;
					?>
					<div class="up-module-card">
						<div class="up-module-card__icon up-module-card__icon--<?php echo esc_attr( $icon_color ); ?>">
							<span class="dashicons <?php echo esc_attr( $module['icon'] ); ?>"></span>
						</div>
						<div class="up-module-card__info">
							<h3 class="up-module-card__title"><?php echo esc_html( $module['label'] ); ?></h3>
							<p class="up-module-card__desc"><?php echo esc_html( $module['description'] ); ?></p>
						</div>
						<span class="up-badge <?php echo $is_enabled ? 'up-badge--success' : 'up-badge--inactive'; ?>">
							<?php echo $is_enabled ? esc_html__( 'Active', 'ultimate-performance' ) : esc_html__( 'Inactive', 'ultimate-performance' ); ?>
						</span>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

	<div class="up-toast" id="up-toast" style="display:none;">
		<span class="up-toast__message"></span>
	</div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
