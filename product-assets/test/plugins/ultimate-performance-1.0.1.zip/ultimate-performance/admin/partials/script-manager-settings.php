<?php
/**
 * Script Manager settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$sm_settings = Ultimate_Performance_Settings::get_module_settings( 'script_manager' );
?>
<form class="up-settings-form" data-module="script_manager">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Script Manager', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Disable unnecessary scripts and styles globally or per page to reduce page weight and improve load times.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $sm_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- Global Asset Disabling -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Global Asset Disabling', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Disable scripts or styles across all pages by entering their handles. One handle per line.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="global_disabled_scripts" class="up-field__label"><?php esc_html_e( 'Disabled Scripts', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Script handles to dequeue on every page. Use the per-page scanner to discover handle names.', 'ultimate-performance' ); ?></p>
				<textarea name="global_disabled_scripts" id="global_disabled_scripts" class="up-textarea" rows="3" placeholder="wp-embed&#10;jquery-migrate"><?php echo esc_textarea( $sm_settings['global_disabled_scripts'] ); ?></textarea>
			</div>

			<div class="up-field">
				<label for="global_disabled_styles" class="up-field__label"><?php esc_html_e( 'Disabled Styles', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Style handles to dequeue on every page. Use the per-page scanner to discover handle names.', 'ultimate-performance' ); ?></p>
				<textarea name="global_disabled_styles" id="global_disabled_styles" class="up-textarea" rows="3" placeholder="dashicons&#10;wp-block-library"><?php echo esc_textarea( $sm_settings['global_disabled_styles'] ); ?></textarea>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Per-Page Usage Info -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Per-Page Control', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'For per-page script and style management, use the Script Manager metabox in the post/page editor.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<p class="up-field__hint" style="margin: 0;">
					<?php esc_html_e( 'When editing any post or page, you will find a "Script Manager" metabox below the editor. Click "Scan Assets" to see all registered scripts and styles with their source plugin/theme. Check the items you want to disable on that specific page, then save the post.', 'ultimate-performance' ); ?>
				</p>
			</div>
		</div>
	</div>
</form>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
