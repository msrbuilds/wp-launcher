<?php
/**
 * Database optimization tools page / settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$db_settings = Ultimate_Performance_Settings::get_module_settings( 'database' );

$schedule_options = array(
	'disabled' => __( 'Disabled', 'ultimate-performance' ),
	'daily'    => __( 'Daily', 'ultimate-performance' ),
	'weekly'   => __( 'Weekly', 'ultimate-performance' ),
	'monthly'  => __( 'Monthly', 'ultimate-performance' ),
);

?>
	<!-- Settings Form -->
	<form class="up-settings-form" data-module="database">
		<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

		<!-- Module Enable -->
		<div class="up-section-card">
			<div class="up-section-card__header">
				<div>
					<h2><?php esc_html_e( 'Database Optimization', 'ultimate-performance' ); ?></h2>
					<p class="up-section-card__desc"><?php esc_html_e( 'Clean up database bloat and optimize tables for better performance.', 'ultimate-performance' ); ?></p>
				</div>
				<div class="up-module-enable">
					<label class="up-switch">
						<input type="checkbox" name="enabled" value="1" <?php checked( $db_settings['enabled'] ); ?>>
						<span class="up-switch__slider"></span>
						<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
					</label>
				</div>
			</div>

			<div class="up-fields-row">
				<div class="up-inline-field">
					<label for="db_schedule" class="up-inline-field__label"><?php esc_html_e( 'Scheduled Cleanup', 'ultimate-performance' ); ?></label>
					<select name="schedule" id="db_schedule" class="up-select" style="width:auto;min-width:140px;">
						<?php foreach ( $schedule_options as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $db_settings['schedule'], $value ); ?>>
								<?php echo esc_html( $label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="up-inline-field">
					<label for="revisions_keep" class="up-inline-field__label"><?php esc_html_e( 'Keep Last N Revisions', 'ultimate-performance' ); ?></label>
					<input type="number" name="revisions_keep" id="revisions_keep" class="up-input--small" min="0" max="100" value="<?php echo absint( $db_settings['revisions_keep'] ); ?>">
				</div>
			</div>

			<div class="up-section-card__footer">
				<button type="submit" class="up-btn up-btn--primary">
					<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
				</button>
			</div>
		</div>
	</form>

	<!-- Cleanup Tools -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Cleanup Tools', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Run one-click cleanup operations. Counts are loaded automatically.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-db-grid" id="up-db-tools">
			<div class="up-db-card" data-type="revisions">
				<div class="up-db-card__icon">
					<span class="dashicons dashicons-backup"></span>
				</div>
				<h4><?php esc_html_e( 'Post Revisions', 'ultimate-performance' ); ?></h4>
				<span class="up-db-card__count" data-count="revisions">--</span>
				<button type="button" class="up-btn up-btn--secondary up-btn--small up-db-clean-btn" data-type="revisions">
					<?php esc_html_e( 'Clean', 'ultimate-performance' ); ?>
				</button>
			</div>

			<div class="up-db-card" data-type="auto_drafts">
				<div class="up-db-card__icon">
					<span class="dashicons dashicons-edit"></span>
				</div>
				<h4><?php esc_html_e( 'Auto-Drafts', 'ultimate-performance' ); ?></h4>
				<span class="up-db-card__count" data-count="auto_drafts">--</span>
				<button type="button" class="up-btn up-btn--secondary up-btn--small up-db-clean-btn" data-type="auto_drafts">
					<?php esc_html_e( 'Clean', 'ultimate-performance' ); ?>
				</button>
			</div>

			<div class="up-db-card" data-type="trashed_posts">
				<div class="up-db-card__icon">
					<span class="dashicons dashicons-trash"></span>
				</div>
				<h4><?php esc_html_e( 'Trashed Posts', 'ultimate-performance' ); ?></h4>
				<span class="up-db-card__count" data-count="trashed_posts">--</span>
				<button type="button" class="up-btn up-btn--secondary up-btn--small up-db-clean-btn" data-type="trashed_posts">
					<?php esc_html_e( 'Clean', 'ultimate-performance' ); ?>
				</button>
			</div>

			<div class="up-db-card" data-type="spam_comments">
				<div class="up-db-card__icon">
					<span class="dashicons dashicons-warning"></span>
				</div>
				<h4><?php esc_html_e( 'Spam Comments', 'ultimate-performance' ); ?></h4>
				<span class="up-db-card__count" data-count="spam_comments">--</span>
				<button type="button" class="up-btn up-btn--secondary up-btn--small up-db-clean-btn" data-type="spam_comments">
					<?php esc_html_e( 'Clean', 'ultimate-performance' ); ?>
				</button>
			</div>

			<div class="up-db-card" data-type="trashed_comments">
				<div class="up-db-card__icon">
					<span class="dashicons dashicons-dismiss"></span>
				</div>
				<h4><?php esc_html_e( 'Trashed Comments', 'ultimate-performance' ); ?></h4>
				<span class="up-db-card__count" data-count="trashed_comments">--</span>
				<button type="button" class="up-btn up-btn--secondary up-btn--small up-db-clean-btn" data-type="trashed_comments">
					<?php esc_html_e( 'Clean', 'ultimate-performance' ); ?>
				</button>
			</div>

			<div class="up-db-card" data-type="expired_transients">
				<div class="up-db-card__icon">
					<span class="dashicons dashicons-clock"></span>
				</div>
				<h4><?php esc_html_e( 'Expired Transients', 'ultimate-performance' ); ?></h4>
				<span class="up-db-card__count" data-count="expired_transients">--</span>
				<button type="button" class="up-btn up-btn--secondary up-btn--small up-db-clean-btn" data-type="expired_transients">
					<?php esc_html_e( 'Clean', 'ultimate-performance' ); ?>
				</button>
			</div>

			<div class="up-db-card" data-type="orphaned_postmeta">
				<div class="up-db-card__icon">
					<span class="dashicons dashicons-database-remove"></span>
				</div>
				<h4><?php esc_html_e( 'Orphaned Post Meta', 'ultimate-performance' ); ?></h4>
				<span class="up-db-card__count" data-count="orphaned_postmeta">--</span>
				<button type="button" class="up-btn up-btn--secondary up-btn--small up-db-clean-btn" data-type="orphaned_postmeta">
					<?php esc_html_e( 'Clean', 'ultimate-performance' ); ?>
				</button>
			</div>

			<div class="up-db-card" data-type="orphaned_commentmeta">
				<div class="up-db-card__icon">
					<span class="dashicons dashicons-database-remove"></span>
				</div>
				<h4><?php esc_html_e( 'Orphaned Comment Meta', 'ultimate-performance' ); ?></h4>
				<span class="up-db-card__count" data-count="orphaned_commentmeta">--</span>
				<button type="button" class="up-btn up-btn--secondary up-btn--small up-db-clean-btn" data-type="orphaned_commentmeta">
					<?php esc_html_e( 'Clean', 'ultimate-performance' ); ?>
				</button>
			</div>

			<div class="up-db-card" data-type="orphaned_relationships">
				<div class="up-db-card__icon">
					<span class="dashicons dashicons-database-remove"></span>
				</div>
				<h4><?php esc_html_e( 'Orphaned Relationships', 'ultimate-performance' ); ?></h4>
				<span class="up-db-card__count" data-count="orphaned_relationships">--</span>
				<button type="button" class="up-btn up-btn--secondary up-btn--small up-db-clean-btn" data-type="orphaned_relationships">
					<?php esc_html_e( 'Clean', 'ultimate-performance' ); ?>
				</button>
			</div>

			<div class="up-db-card up-db-card--optimize" data-type="optimize_tables">
				<div class="up-db-card__icon">
					<span class="dashicons dashicons-performance"></span>
				</div>
				<h4><?php esc_html_e( 'Optimize Tables', 'ultimate-performance' ); ?></h4>
				<span class="up-db-card__count">&mdash;</span>
				<button type="button" class="up-btn up-btn--secondary up-btn--small up-db-clean-btn" data-type="optimize_tables">
					<?php esc_html_e( 'Optimize', 'ultimate-performance' ); ?>
				</button>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="button" class="up-btn up-btn--danger up-btn--small" id="up-db-clean-all">
				<?php esc_html_e( 'Clean All', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>

