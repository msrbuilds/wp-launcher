<?php
/**
 * AI Assistant dedicated page template.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$ai_settings  = Ultimate_Performance_Settings::get_module_settings( 'ai' );
$current_page = 'ai';
$providers    = Ultimate_Performance_Ai::PROVIDER_MODELS;

$provider_configs = array(
	'openai'    => array(
		'label'       => __( 'OpenAI', 'ultimate-performance' ),
		'key_name'    => 'openai_api_key',
		'model_name'  => 'openai_model',
		'placeholder' => 'sk-...',
		'models'      => $providers['openai'],
	),
	'gemini'    => array(
		'label'       => __( 'Google Gemini', 'ultimate-performance' ),
		'key_name'    => 'gemini_api_key',
		'model_name'  => 'gemini_model',
		'placeholder' => 'AIza...',
		'models'      => $providers['gemini'],
	),
	'anthropic' => array(
		'label'       => __( 'Anthropic', 'ultimate-performance' ),
		'key_name'    => 'anthropic_api_key',
		'model_name'  => 'anthropic_model',
		'placeholder' => 'sk-ant-...',
		'models'      => $providers['anthropic'],
	),
);
?>
<div class="wrap up-app">

	<?php include UP_PLUGIN_DIR . 'admin/partials/header-nav.php'; ?>

	<div class="up-content">
		<div class="up-two-col">

			<!-- Left Column: Settings + AI Scanner -->
			<div class="up-two-col__primary">

				<!-- API Keys Settings Card -->
				<div class="up-section-card">
					<form class="up-settings-form" data-module="ai">
						<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

						<div class="up-section-card__header">
							<div>
								<h2><?php esc_html_e( 'AI Assistant Settings', 'ultimate-performance' ); ?></h2>
								<p class="up-section-card__desc"><?php esc_html_e( 'Configure AI providers to get intelligent performance analysis and optimization recommendations.', 'ultimate-performance' ); ?></p>
							</div>
							<div class="up-module-enable">
								<label class="up-switch">
									<input type="checkbox" name="enabled" value="1" <?php checked( $ai_settings['enabled'] ); ?>>
									<span class="up-switch__slider"></span>
									<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
								</label>
							</div>
						</div>

						<!-- Active Provider Selector -->
						<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
							<div class="up-field">
								<label for="active_provider" class="up-field__label"><?php esc_html_e( 'Active Provider', 'ultimate-performance' ); ?></label>
								<p class="up-field__hint"><?php esc_html_e( 'Select which AI provider to use for analysis.', 'ultimate-performance' ); ?></p>
								<select name="active_provider" id="active_provider" class="up-input">
									<option value="openai" <?php selected( $ai_settings['active_provider'], 'openai' ); ?>><?php esc_html_e( 'OpenAI', 'ultimate-performance' ); ?></option>
									<option value="gemini" <?php selected( $ai_settings['active_provider'], 'gemini' ); ?>><?php esc_html_e( 'Google Gemini', 'ultimate-performance' ); ?></option>
									<option value="anthropic" <?php selected( $ai_settings['active_provider'], 'anthropic' ); ?>><?php esc_html_e( 'Anthropic', 'ultimate-performance' ); ?></option>
								</select>
							</div>
						</div>

						<!-- Provider Cards -->
						<?php foreach ( $provider_configs as $prov_key => $prov ) :
							$current_key   = $ai_settings[ $prov['key_name'] ];
							$current_model = $ai_settings[ $prov['model_name'] ];
						?>
						<div class="up-ai-provider-card" data-provider="<?php echo esc_attr( $prov_key ); ?>">
							<h3 class="up-field__label" style="margin-bottom: 12px; font-size: 15px;"><?php echo esc_html( $prov['label'] ); ?></h3>

							<div class="up-fields-stack" style="margin-top: 0; padding: 0;">
								<!-- API Key -->
								<div class="up-field">
									<label for="<?php echo esc_attr( $prov['key_name'] ); ?>" class="up-field__label"><?php esc_html_e( 'API Key', 'ultimate-performance' ); ?></label>
									<?php if ( ! empty( $current_key ) ) : ?>
									<div class="up-api-key-masked" style="display: flex; gap: 8px; align-items: center;">
										<input type="text" class="up-input" value="<?php echo esc_attr( str_repeat( "\xE2\x80\xA2", 8 ) . substr( $current_key, -4 ) ); ?>" readonly style="flex: 1;">
										<input type="hidden" name="<?php echo esc_attr( $prov['key_name'] ); ?>" id="<?php echo esc_attr( $prov['key_name'] ); ?>" value="__KEEP__">
										<button type="button" class="up-btn up-btn--small up-key-change" data-placeholder="<?php echo esc_attr( $prov['placeholder'] ); ?>"><?php esc_html_e( 'Change', 'ultimate-performance' ); ?></button>
										<button type="button" class="up-btn up-btn--small up-btn--danger up-key-remove" data-placeholder="<?php echo esc_attr( $prov['placeholder'] ); ?>"><?php esc_html_e( 'Remove', 'ultimate-performance' ); ?></button>
									</div>
									<?php else : ?>
									<input type="text" name="<?php echo esc_attr( $prov['key_name'] ); ?>" id="<?php echo esc_attr( $prov['key_name'] ); ?>" class="up-input" value="" placeholder="<?php echo esc_attr( $prov['placeholder'] ); ?>">
									<?php endif; ?>
								</div>

								<!-- Model Selector (Searchable) -->
								<div class="up-field">
									<label class="up-field__label"><?php esc_html_e( 'Model', 'ultimate-performance' ); ?></label>
									<div class="up-model-select" data-provider="<?php echo esc_attr( $prov_key ); ?>">
										<div class="up-model-select__input-wrap">
											<input type="text"
												   class="up-input up-model-select__search"
												   placeholder="<?php esc_attr_e( 'Search or select a model...', 'ultimate-performance' ); ?>"
												   value="<?php echo esc_attr( $current_model ); ?>"
												   autocomplete="off">
											<button type="button" class="up-model-select__refresh up-ai-refresh-models"
													data-provider="<?php echo esc_attr( $prov_key ); ?>"
													title="<?php esc_attr_e( 'Fetch latest models from API', 'ultimate-performance' ); ?>">
												<span class="dashicons dashicons-update"></span>
											</button>
										</div>
										<div class="up-model-select__dropdown" style="display:none;"></div>
										<input type="hidden"
											   name="<?php echo esc_attr( $prov['model_name'] ); ?>"
											   id="<?php echo esc_attr( $prov['model_name'] ); ?>"
											   value="<?php echo esc_attr( $current_model ); ?>">
									</div>
								</div>

								<!-- Test Connection Button -->
								<div class="up-field">
									<button type="button" class="up-btn up-btn--small up-ai-test-connection" data-provider="<?php echo esc_attr( $prov_key ); ?>">
										<?php esc_html_e( 'Test Connection', 'ultimate-performance' ); ?>
									</button>
									<span class="up-ai-connection-status" data-provider="<?php echo esc_attr( $prov_key ); ?>"></span>
								</div>
							</div>
						</div>
						<?php endforeach; ?>

						<!-- Auto-analyze toggle -->
						<div class="up-fields-stack" style="padding-top: 0;">
							<div class="up-field" style="padding: 16px 24px;">
								<label class="up-switch">
									<input type="checkbox" name="auto_analyze" value="1" <?php checked( $ai_settings['auto_analyze'] ); ?>>
									<span class="up-switch__slider"></span>
									<span class="up-switch__label"><?php esc_html_e( 'Auto-analyze speed test reports', 'ultimate-performance' ); ?></span>
								</label>
								<p class="up-field__hint"><?php esc_html_e( 'Automatically run AI analysis after each PageSpeed Insights test completes.', 'ultimate-performance' ); ?></p>
							</div>
						</div>

						<div class="up-section-card__footer">
							<button type="submit" class="up-btn up-btn--primary">
								<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
							</button>
						</div>
					</form>
				</div>

				<!-- Website AI Scanner Card -->
				<div class="up-section-card">
					<div class="up-section-card__header">
						<div>
							<h2><?php esc_html_e( 'AI Website Scanner', 'ultimate-performance' ); ?></h2>
							<p class="up-section-card__desc"><?php esc_html_e( 'Scan your website for performance issues. Analyzes HTML structure, response headers, and PageSpeed data (if available) to generate a comprehensive report.', 'ultimate-performance' ); ?></p>
						</div>
					</div>

					<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
						<div class="up-field" style="padding: 0 24px;">
							<div style="display: flex; gap: 8px; align-items: center;">
								<input type="url" id="up-ai-scan-url" class="up-input" placeholder="<?php esc_attr_e( 'https://example.com', 'ultimate-performance' ); ?>" value="<?php echo esc_url( home_url( '/' ) ); ?>" style="flex: 1;">
								<button type="button" class="up-btn up-btn--primary" id="up-ai-scan-website">
									<span class="dashicons dashicons-search" style="font-size: 14px; width: 14px; height: 14px; margin-right: 4px;"></span>
									<?php esc_html_e( 'Scan Website', 'ultimate-performance' ); ?>
								</button>
							</div>
						</div>
					</div>

					<div id="up-ai-scan-results" style="padding: 0 24px 24px;"></div>
				</div>

			</div>

			<!-- Right Column: Speed Test AI Analysis + Saved Reports -->
			<div class="up-two-col__sidebar">

				<!-- Speed Test AI Analysis Card -->
				<div class="up-section-card">
					<div class="up-section-card__header">
						<div>
							<h2><?php esc_html_e( 'Speed Test AI Analysis', 'ultimate-performance' ); ?></h2>
							<p class="up-section-card__desc"><?php esc_html_e( 'Select a saved speed test report to analyze with AI.', 'ultimate-performance' ); ?></p>
						</div>
					</div>

					<div style="padding: 0 20px 20px;">
						<select id="up-ai-report-select" class="up-input" style="width: 100%; margin-bottom: 12px;">
							<option value=""><?php esc_html_e( 'Select a speed test report...', 'ultimate-performance' ); ?></option>
						</select>
						<button type="button" class="up-btn up-btn--primary up-btn--small" id="up-ai-analyze-report" disabled>
							<span class="dashicons dashicons-lightbulb" style="font-size: 14px; width: 14px; height: 14px; margin-right: 4px;"></span>
							<?php esc_html_e( 'Analyze with AI', 'ultimate-performance' ); ?>
						</button>

						<div id="up-ai-speed-analysis" style="margin-top: 16px;"></div>
					</div>
				</div>

				<!-- Saved AI Reports Card -->
				<div class="up-section-card">
					<div class="up-section-card__header">
						<div>
							<h2><?php esc_html_e( 'Saved Reports', 'ultimate-performance' ); ?></h2>
							<p class="up-section-card__desc"><?php esc_html_e( 'Previous AI scan reports.', 'ultimate-performance' ); ?></p>
						</div>
					</div>

					<div id="up-ai-saved-reports" style="padding: 0 20px 20px;">
						<p style="color: var(--up-gray-400); text-align: center; padding: 20px 0; font-size: 13px;">
							<?php esc_html_e( 'Loading reports...', 'ultimate-performance' ); ?>
						</p>
					</div>
				</div>

			</div>
		</div>
	</div>

	<div class="up-toast" id="up-toast" style="display:none;">
		<span class="up-toast__message"></span>
	</div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
