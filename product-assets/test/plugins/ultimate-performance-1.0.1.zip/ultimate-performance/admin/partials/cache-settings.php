<?php
/**
 * Caching settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$cache_settings = Ultimate_Performance_Settings::get_module_settings( 'caching' );
?>
<form class="up-settings-form" data-module="caching">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Caching', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Cache pages, enable browser caching, and compress responses to dramatically reduce load times.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $cache_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- Page Cache -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Page Cache', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Store fully rendered HTML pages so they can be served instantly without running PHP or database queries.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--purple">
					<span class="dashicons dashicons-performance"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Enable Page Cache', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Caches pages for logged-out visitors. Automatically skips admin, AJAX, search, 404, and WooCommerce dynamic pages.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="page_cache" value="1" <?php checked( $cache_settings['page_cache'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Browser Cache & Compression -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Browser Cache & Compression', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Add .htaccess rules for browser caching, Cache-Control headers, and GZIP compression. Requires Apache with mod_expires, mod_headers, and mod_deflate.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--indigo">
					<span class="dashicons dashicons-clock"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Browser Cache', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Sets Expires and Cache-Control headers for static assets (CSS, JS, images, fonts) so browsers cache them locally. Fixes the "Use efficient cache lifetimes" PageSpeed warning.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="browser_cache" value="1" <?php checked( $cache_settings['browser_cache'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>

			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--teal">
					<span class="dashicons dashicons-download"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'GZIP Compression', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Compresses HTML, CSS, JS, XML, and SVG responses to reduce transfer sizes.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="gzip_compression" value="1" <?php checked( $cache_settings['gzip_compression'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="cache_lifespan" class="up-field__label"><?php esc_html_e( 'Cache Lifespan', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'How long browsers should cache static assets (CSS, JS, images, fonts). Longer values improve PageSpeed scores but mean visitors see updates less quickly. Google recommends at least 1 year for static assets.', 'ultimate-performance' ); ?></p>
				<select name="cache_lifespan" id="cache_lifespan" class="up-input" style="max-width: 280px;">
					<option value="1 month" <?php selected( $cache_settings['cache_lifespan'], '1 month' ); ?>><?php esc_html_e( '1 Month (2,592,000s)', 'ultimate-performance' ); ?></option>
					<option value="3 months" <?php selected( $cache_settings['cache_lifespan'], '3 months' ); ?>><?php esc_html_e( '3 Months (7,776,000s)', 'ultimate-performance' ); ?></option>
					<option value="6 months" <?php selected( $cache_settings['cache_lifespan'], '6 months' ); ?>><?php esc_html_e( '6 Months (15,552,000s)', 'ultimate-performance' ); ?></option>
					<option value="1 year" <?php selected( $cache_settings['cache_lifespan'], '1 year' ); ?>><?php esc_html_e( '1 Year (31,536,000s) — Recommended', 'ultimate-performance' ); ?></option>
				</select>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Cache Header Diagnostics -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Browser Cache Diagnostics', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Verify that browser cache headers are actually being applied to your static assets (CSS, JS, images, fonts). This checks real response headers from your server.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div style="padding: 0 24px 20px;">
			<button type="button" class="up-btn up-btn--primary up-btn--small" id="up-verify-cache-headers">
				<span class="dashicons dashicons-search" style="font-size: 14px; width: 14px; height: 14px; margin-right: 4px;"></span>
				<?php esc_html_e( 'Verify Cache Headers', 'ultimate-performance' ); ?>
			</button>
			<div id="up-cache-verify-results" style="margin-top: 12px;"></div>
		</div>
	</div>

	<!-- Exclusion Rules -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Exclusion Rules', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Define URLs and cookies that should bypass the page cache.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack">
			<div class="up-field">
				<label for="exclude_urls" class="up-field__label"><?php esc_html_e( 'Excluded URLs', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'URL patterns to exclude from page cache. One per line. Partial matches supported.', 'ultimate-performance' ); ?></p>
				<textarea name="exclude_urls" id="exclude_urls" class="up-textarea" rows="4" placeholder="/my-account/&#10;/members/"><?php echo esc_textarea( $cache_settings['exclude_urls'] ); ?></textarea>
			</div>

			<div class="up-field">
				<label for="exclude_cookies" class="up-field__label"><?php esc_html_e( 'Excluded Cookies', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Cookie names that should bypass page cache when present. One per line.', 'ultimate-performance' ); ?></p>
				<textarea name="exclude_cookies" id="exclude_cookies" class="up-textarea" rows="3" placeholder="woocommerce_items_in_cart"><?php echo esc_textarea( $cache_settings['exclude_cookies'] ); ?></textarea>
			</div>

			<div class="up-feature-card" style="margin-top: 8px;">
				<div class="up-feature-card__icon up-feature-card__icon--orange">
					<span class="dashicons dashicons-update"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Purge on Post Update', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Automatically purge cache when posts, pages, comments, or menus are updated.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="purge_on_post_update" value="1" <?php checked( $cache_settings['purge_on_post_update'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>

<!-- Cache Management (outside form) -->
<div class="up-section-card">
	<div class="up-section-card__header">
		<div>
			<h2><?php esc_html_e( 'Cache Management', 'ultimate-performance' ); ?></h2>
			<p class="up-section-card__desc"><?php esc_html_e( 'Manually purge all cached pages and minified files.', 'ultimate-performance' ); ?></p>
		</div>
	</div>

	<div class="up-section-card__footer">
		<button type="button" class="up-btn up-btn--danger up-btn--small" id="up-purge-cache">
			<?php esc_html_e( 'Purge All Cache', 'ultimate-performance' ); ?>
		</button>
	</div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>

