<?php
/**
 * Static Site Generator admin page.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$settings     = Ultimate_Performance_Settings::get_module_settings( 'static_site' );
$last_run     = get_option( 'up_static_last_run', null );
$current_page = 'static-site';
?>
<div class="wrap up-app">

	<?php include UP_PLUGIN_DIR . 'admin/partials/header-nav.php'; ?>

	<div class="up-content">
		<div class="up-two-col">

			<!-- Left Column: Settings + Generator + Log -->
			<div class="up-two-col__primary">

				<!-- Settings Card -->
				<div class="up-section-card">
					<h3 class="up-section-card__title">
						<span class="dashicons dashicons-admin-generic"></span>
						<?php esc_html_e( 'Settings', 'ultimate-performance' ); ?>
					</h3>

					<form id="up-static-settings-form" class="up-settings-form up-static-settings-form--compact" data-module="static_site">
						<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

						<!-- Top row: Delivery Method | URL Style | Batch Size -->
						<div class="up-compact-grid">
							<div class="up-field">
								<label class="up-field__label"><?php esc_html_e( 'Delivery Method', 'ultimate-performance' ); ?></label>
								<div class="up-pill-group">
									<label class="up-pill">
										<input type="radio" name="delivery_method" value="zip"
											<?php checked( $settings['delivery_method'], 'zip' ); ?>>
										<span class="up-pill__label">
											<span class="dashicons dashicons-media-archive"></span>
											<?php esc_html_e( 'ZIP Download', 'ultimate-performance' ); ?>
										</span>
									</label>
									<label class="up-pill">
										<input type="radio" name="delivery_method" value="local_dir"
											<?php checked( $settings['delivery_method'], 'local_dir' ); ?>>
										<span class="up-pill__label">
											<span class="dashicons dashicons-open-folder"></span>
											<?php esc_html_e( 'Local Directory', 'ultimate-performance' ); ?>
										</span>
									</label>
								</div>
							</div>

							<div class="up-field">
								<label class="up-field__label"><?php esc_html_e( 'URL Style', 'ultimate-performance' ); ?></label>
								<div class="up-pill-group">
									<label class="up-pill">
										<input type="radio" name="url_style" value="relative"
											<?php checked( $settings['url_style'], 'relative' ); ?>>
										<span class="up-pill__label"><?php esc_html_e( 'Relative', 'ultimate-performance' ); ?></span>
									</label>
									<label class="up-pill">
										<input type="radio" name="url_style" value="offline"
											<?php checked( $settings['url_style'], 'offline' ); ?>>
										<span class="up-pill__label"><?php esc_html_e( 'Offline', 'ultimate-performance' ); ?></span>
									</label>
									<label class="up-pill">
										<input type="radio" name="url_style" value="absolute"
											<?php checked( $settings['url_style'], 'absolute' ); ?>>
										<span class="up-pill__label"><?php esc_html_e( 'Absolute', 'ultimate-performance' ); ?></span>
									</label>
								</div>
							</div>

							<div class="up-field">
								<label class="up-field__label" for="up-batch-size">
									<?php esc_html_e( 'Batch Size', 'ultimate-performance' ); ?>
								</label>
								<div class="up-stepper">
									<button type="button" class="up-stepper__btn up-stepper__btn--minus" data-target="up-batch-size" data-step="-10">
										<span class="dashicons dashicons-minus"></span>
									</button>
									<input type="number" id="up-batch-size" name="batch_size"
										   class="up-stepper__input"
										   value="<?php echo esc_attr( $settings['batch_size'] ); ?>"
										   min="10" max="200" step="10" readonly>
									<button type="button" class="up-stepper__btn up-stepper__btn--plus" data-target="up-batch-size" data-step="10">
										<span class="dashicons dashicons-plus-alt2"></span>
									</button>
								</div>
								<p class="up-field__hint"><?php esc_html_e( 'URLs per batch (10-200)', 'ultimate-performance' ); ?></p>
							</div>

							<!-- Conditional: Output Directory -->
							<div class="up-field up-compact-grid__full" id="up-field-output-dir"
								 style="<?php echo 'local_dir' !== $settings['delivery_method'] ? 'display:none;' : ''; ?>">
								<label class="up-field__label" for="up-output-dir">
									<?php esc_html_e( 'Output Directory', 'ultimate-performance' ); ?>
								</label>
								<input type="text" id="up-output-dir" name="output_dir"
									   class="up-field__input"
									   value="<?php echo esc_attr( $settings['output_dir'] ); ?>"
									   placeholder="<?php echo esc_attr( trailingslashit( wp_upload_dir()['basedir'] ) . 'ultimate-performance/static-site/' ); ?>">
							</div>

							<!-- Conditional: Base URL -->
							<div class="up-field up-compact-grid__full" id="up-field-base-url"
								 style="<?php echo 'absolute' !== $settings['url_style'] ? 'display:none;' : ''; ?>">
								<label class="up-field__label" for="up-base-url">
									<?php esc_html_e( 'Base URL', 'ultimate-performance' ); ?>
								</label>
								<input type="url" id="up-base-url" name="base_url"
									   class="up-field__input"
									   value="<?php echo esc_attr( $settings['base_url'] ); ?>"
									   placeholder="https://static.example.com">
							</div>
						</div>

						<!-- Content to Include — feature card toggles -->
						<div class="up-field" style="padding: 0 20px;">
							<label class="up-field__label"><?php esc_html_e( 'Content to Include', 'ultimate-performance' ); ?></label>
						</div>
						<?php
						$include_types = array_map( 'trim', explode( ',', $settings['include_types'] ) );
						$type_options  = array(
							'posts'             => array( 'label' => __( 'Posts', 'ultimate-performance' ),             'icon' => 'dashicons-admin-post',    'color' => 'purple' ),
							'pages'             => array( 'label' => __( 'Pages', 'ultimate-performance' ),             'icon' => 'dashicons-admin-page',    'color' => 'indigo' ),
							'archives'          => array( 'label' => __( 'Archives', 'ultimate-performance' ),          'icon' => 'dashicons-archive',       'color' => 'teal' ),
							'categories'        => array( 'label' => __( 'Categories', 'ultimate-performance' ),        'icon' => 'dashicons-category',      'color' => 'orange' ),
							'tags'              => array( 'label' => __( 'Tags', 'ultimate-performance' ),              'icon' => 'dashicons-tag',           'color' => 'rose' ),
							'author_pages'      => array( 'label' => __( 'Author Pages', 'ultimate-performance' ),      'icon' => 'dashicons-admin-users',   'color' => 'sky' ),
							'custom_post_types' => array( 'label' => __( 'Custom Post Types', 'ultimate-performance' ), 'icon' => 'dashicons-edit',          'color' => 'amber' ),
							'theme_assets'      => array( 'label' => __( 'Theme Assets', 'ultimate-performance' ),      'icon' => 'dashicons-admin-appearance', 'color' => 'purple' ),
							'plugin_assets'     => array( 'label' => __( 'Plugin Assets', 'ultimate-performance' ),     'icon' => 'dashicons-admin-plugins', 'color' => 'indigo' ),
							'uploads'           => array( 'label' => __( 'Uploads', 'ultimate-performance' ),           'icon' => 'dashicons-upload',        'color' => 'teal' ),
						);
						?>
						<div class="up-feature-grid up-feature-grid--compact">
						<?php foreach ( $type_options as $value => $opts ) : ?>
							<div class="up-feature-card up-feature-card--sm">
								<div class="up-feature-card__icon up-feature-card__icon--<?php echo esc_attr( $opts['color'] ); ?>">
									<span class="dashicons <?php echo esc_attr( $opts['icon'] ); ?>"></span>
								</div>
								<div class="up-feature-card__info">
									<h3 class="up-feature-card__title"><?php echo esc_html( $opts['label'] ); ?></h3>
								</div>
								<label class="up-switch">
									<input type="checkbox" class="up-include-type" value="<?php echo esc_attr( $value ); ?>"
										<?php checked( in_array( $value, $include_types, true ) ); ?>>
									<span class="up-switch__slider"></span>
								</label>
							</div>
						<?php endforeach; ?>
						</div>
						<input type="hidden" name="include_types" id="up-include-types"
							   value="<?php echo esc_attr( $settings['include_types'] ); ?>">

						<!-- Additional URLs | Exclude URLs -->
						<div class="up-compact-grid" style="padding-top: 0;">
							<div class="up-compact-grid__full up-compact-grid__pair">
								<div class="up-field">
									<label class="up-field__label" for="up-additional-urls">
										<?php esc_html_e( 'Additional URLs', 'ultimate-performance' ); ?>
									</label>
									<textarea id="up-additional-urls" name="additional_urls"
											  class="up-field__textarea" rows="2"
											  placeholder="<?php esc_attr_e( 'One URL per line', 'ultimate-performance' ); ?>"
									><?php echo esc_textarea( $settings['additional_urls'] ); ?></textarea>
								</div>

								<div class="up-field">
									<label class="up-field__label" for="up-exclude-urls">
										<?php esc_html_e( 'Exclude URLs', 'ultimate-performance' ); ?>
									</label>
									<textarea id="up-exclude-urls" name="exclude_urls"
											  class="up-field__textarea" rows="2"
											  placeholder="<?php esc_attr_e( '/wp-admin/*&#10;/cart/*', 'ultimate-performance' ); ?>"
									><?php echo esc_textarea( $settings['exclude_urls'] ); ?></textarea>
									<p class="up-field__hint"><?php esc_html_e( 'Supports * wildcards.', 'ultimate-performance' ); ?></p>
								</div>
							</div>
						</div>

						<div class="up-compact-grid__footer">
							<button type="submit" class="up-btn up-btn--primary">
								<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
							</button>
						</div>
					</form>
				</div>

				<!-- Activity Log -->
				<div class="up-section-card">
					<h3 class="up-section-card__title">
						<span class="dashicons dashicons-text-page"></span>
						<?php esc_html_e( 'Activity Log', 'ultimate-performance' ); ?>
					</h3>
					<div class="up-static-log" id="up-static-log">
						<div class="up-log-entry up-log--muted"><?php esc_html_e( 'Waiting to start...', 'ultimate-performance' ); ?></div>
					</div>
				</div>

			</div>

			<!-- Right Column: Generator, Static Serving & Info -->
			<div class="up-two-col__sidebar">

				<!-- Generation Mode Tabs -->
				<div class="up-section-card">
					<div class="up-static-tabs">
						<button type="button" class="up-static-tabs__btn up-static-tabs__btn--active" data-tab="full-site">
							<span class="dashicons dashicons-admin-site-alt3"></span>
							<?php esc_html_e( 'Full Site', 'ultimate-performance' ); ?>
						</button>
						<button type="button" class="up-static-tabs__btn" data-tab="individual">
							<span class="dashicons dashicons-admin-page"></span>
							<?php esc_html_e( 'Individual Pages', 'ultimate-performance' ); ?>
						</button>
					</div>

					<!-- Full Site Panel -->
					<div class="up-static-panel up-static-panel--active" data-panel="full-site">
						<p class="up-static-panel__desc">
							<?php esc_html_e( 'Generate a complete static copy of your entire WordPress site.', 'ultimate-performance' ); ?>
						</p>

						<!-- Pipeline Progress -->
						<div class="up-pipeline" id="up-pipeline-full" style="display:none;">
							<div class="up-pipeline__step" data-phase="setup">
								<span class="up-pipeline__dot"></span>
								<span class="up-pipeline__label"><?php esc_html_e( 'Setup', 'ultimate-performance' ); ?></span>
							</div>
							<div class="up-pipeline__line"></div>
							<div class="up-pipeline__step" data-phase="discover">
								<span class="up-pipeline__dot"></span>
								<span class="up-pipeline__label"><?php esc_html_e( 'Discover', 'ultimate-performance' ); ?></span>
							</div>
							<div class="up-pipeline__line"></div>
							<div class="up-pipeline__step" data-phase="fetch">
								<span class="up-pipeline__dot"></span>
								<span class="up-pipeline__label"><?php esc_html_e( 'Fetch', 'ultimate-performance' ); ?></span>
							</div>
							<div class="up-pipeline__line"></div>
							<div class="up-pipeline__step" data-phase="rewrite">
								<span class="up-pipeline__dot"></span>
								<span class="up-pipeline__label"><?php esc_html_e( 'Rewrite', 'ultimate-performance' ); ?></span>
							</div>
							<div class="up-pipeline__line"></div>
							<div class="up-pipeline__step" data-phase="package">
								<span class="up-pipeline__dot"></span>
								<span class="up-pipeline__label"><?php esc_html_e( 'Package', 'ultimate-performance' ); ?></span>
							</div>
						</div>

						<!-- Progress Bar -->
						<div class="up-progress" id="up-static-progress" style="display:none;">
							<div class="up-progress__bar" id="up-static-bar" style="width:0;"></div>
						</div>
						<p class="up-static-status" id="up-static-status"></p>

						<div class="up-static-actions">
							<button type="button" class="up-btn up-btn--primary" id="up-static-generate">
								<span class="dashicons dashicons-download"></span>
								<?php esc_html_e( 'Generate Static Site', 'ultimate-performance' ); ?>
							</button>
							<button type="button" class="up-btn up-btn--danger" id="up-static-cancel" style="display:none;">
								<span class="dashicons dashicons-no"></span>
								<?php esc_html_e( 'Cancel', 'ultimate-performance' ); ?>
							</button>
						</div>
					</div>

					<!-- Individual Pages Panel -->
					<div class="up-static-panel" data-panel="individual">
						<p class="up-static-panel__desc">
							<?php esc_html_e( 'Search and select specific pages to generate as static HTML.', 'ultimate-performance' ); ?>
						</p>

						<!-- Search -->
						<div class="up-static-search">
							<input type="text"
								   id="up-static-search"
								   class="up-static-search__input"
								   placeholder="<?php esc_attr_e( 'Search pages by title or URL...', 'ultimate-performance' ); ?>"
								   autocomplete="off">
							<div class="up-static-search__results" id="up-static-search-results" style="display:none;"></div>
						</div>

						<!-- Selected Pages -->
						<div class="up-static-selected" id="up-static-selected">
							<p class="up-static-selected__hint" id="up-static-selected-hint">
								<?php esc_html_e( 'Search and select pages to generate.', 'ultimate-performance' ); ?>
							</p>
							<table class="up-static-selected__table" id="up-static-selected-table" style="display:none;">
								<thead>
									<tr>
										<th><?php esc_html_e( 'Title', 'ultimate-performance' ); ?></th>
										<th><?php esc_html_e( 'URL', 'ultimate-performance' ); ?></th>
										<th><?php esc_html_e( 'Type', 'ultimate-performance' ); ?></th>
										<th></th>
									</tr>
								</thead>
								<tbody id="up-static-selected-body"></tbody>
							</table>
						</div>

						<!-- Pipeline Progress (Individual) -->
						<div class="up-pipeline" id="up-pipeline-individual" style="display:none;">
							<div class="up-pipeline__step" data-phase="setup">
								<span class="up-pipeline__dot"></span>
								<span class="up-pipeline__label"><?php esc_html_e( 'Setup', 'ultimate-performance' ); ?></span>
							</div>
							<div class="up-pipeline__line"></div>
							<div class="up-pipeline__step" data-phase="fetch">
								<span class="up-pipeline__dot"></span>
								<span class="up-pipeline__label"><?php esc_html_e( 'Fetch', 'ultimate-performance' ); ?></span>
							</div>
							<div class="up-pipeline__line"></div>
							<div class="up-pipeline__step" data-phase="rewrite">
								<span class="up-pipeline__dot"></span>
								<span class="up-pipeline__label"><?php esc_html_e( 'Rewrite', 'ultimate-performance' ); ?></span>
							</div>
							<div class="up-pipeline__line"></div>
							<div class="up-pipeline__step" data-phase="package">
								<span class="up-pipeline__dot"></span>
								<span class="up-pipeline__label"><?php esc_html_e( 'Package', 'ultimate-performance' ); ?></span>
							</div>
						</div>

						<!-- Progress Bar (shared) -->
						<div class="up-progress" id="up-static-pages-progress" style="display:none;">
							<div class="up-progress__bar" id="up-static-pages-bar" style="width:0;"></div>
						</div>
						<p class="up-static-status" id="up-static-pages-status"></p>

						<div class="up-static-actions">
							<button type="button" class="up-btn up-btn--primary" id="up-static-generate-pages" disabled>
								<span class="dashicons dashicons-download"></span>
								<?php esc_html_e( 'Generate Selected Pages', 'ultimate-performance' ); ?>
							</button>
							<button type="button" class="up-btn up-btn--danger" id="up-static-cancel-pages" style="display:none;">
								<span class="dashicons dashicons-no"></span>
								<?php esc_html_e( 'Cancel', 'ultimate-performance' ); ?>
							</button>
						</div>
					</div>
				</div>

				<!-- Static Serving Card -->
				<div class="up-section-card">
					<h3 class="up-section-card__title">
						<span class="dashicons dashicons-performance"></span>
						<?php esc_html_e( 'Static Serving', 'ultimate-performance' ); ?>
					</h3>
					<div class="up-static-serve-form">
						<!-- Enable Toggle -->
						<div class="up-field" style="margin-bottom: 16px;">
							<label class="up-toggle">
								<input type="checkbox" id="up-serve-enabled" value="1"
									<?php checked( $settings['serve_enabled'] ); ?>>
								<span class="up-toggle__slider"></span>
								<span class="up-toggle__label"><?php esc_html_e( 'Enable Static Serving', 'ultimate-performance' ); ?></span>
							</label>
							<p class="up-field__hint" style="margin: 4px 0 0;">
								<?php esc_html_e( 'Serve pre-generated static HTML to visitors instead of loading WordPress dynamically.', 'ultimate-performance' ); ?>
							</p>
						</div>

						<!-- Serve Status Indicator -->
						<div id="up-serve-status" class="up-serve-status up-serve-status--inactive" style="margin-bottom: 16px;">
							<?php esc_html_e( 'Checking status...', 'ultimate-performance' ); ?>
						</div>

						<!-- Sub-options (shown when enabled) -->
						<div id="up-serve-options" style="<?php echo empty( $settings['serve_enabled'] ) ? 'display:none;' : ''; ?>">
							<div class="up-field" style="margin-bottom: 12px;">
								<label class="up-toggle">
									<input type="checkbox" id="up-serve-logged-in" value="1"
										<?php checked( $settings['serve_logged_in'] ); ?>>
									<span class="up-toggle__slider"></span>
									<span class="up-toggle__label"><?php esc_html_e( 'Serve to logged-in users', 'ultimate-performance' ); ?></span>
								</label>
							</div>

							<div class="up-field" style="margin-bottom: 12px;">
								<label class="up-field__label" for="up-serve-exclude">
									<?php esc_html_e( 'Exclude URLs from Serving', 'ultimate-performance' ); ?>
								</label>
								<textarea id="up-serve-exclude" class="up-field__textarea"
										  rows="3"
										  placeholder="<?php esc_attr_e( '/cart/*&#10;/checkout/*', 'ultimate-performance' ); ?>"
								><?php echo esc_textarea( $settings['serve_exclude_urls'] ); ?></textarea>
								<p class="up-field__hint"><?php esc_html_e( 'One URL per line. Supports * wildcards.', 'ultimate-performance' ); ?></p>
							</div>
						</div>

						<!-- Action buttons -->
						<div style="display: flex; gap: 8px;">
							<button type="button" class="up-btn up-btn--primary up-btn--small" id="up-save-serve-settings">
								<?php esc_html_e( 'Save', 'ultimate-performance' ); ?>
							</button>
							<button type="button" class="up-btn up-btn--danger up-btn--small" id="up-purge-serve">
								<?php esc_html_e( 'Purge Served Files', 'ultimate-performance' ); ?>
							</button>
						</div>
					</div>
				</div>

				<!-- Last Generation Card -->
				<?php if ( $last_run ) : ?>
				<div class="up-section-card">
					<h3 class="up-section-card__title">
						<span class="dashicons dashicons-clock"></span>
						<?php esc_html_e( 'Last Generation', 'ultimate-performance' ); ?>
					</h3>
					<div class="up-static-lastrun">
						<div class="up-static-lastrun__row">
							<span class="up-static-lastrun__label"><?php esc_html_e( 'Date:', 'ultimate-performance' ); ?></span>
							<span><?php echo esc_html( $last_run['date'] ); ?></span>
						</div>
						<div class="up-static-lastrun__row">
							<span class="up-static-lastrun__label"><?php esc_html_e( 'Pages:', 'ultimate-performance' ); ?></span>
							<span><?php echo esc_html( $last_run['total_files'] ); ?></span>
						</div>
						<div class="up-static-lastrun__row">
							<span class="up-static-lastrun__label"><?php esc_html_e( 'Size:', 'ultimate-performance' ); ?></span>
							<span><?php echo esc_html( $last_run['total_size'] ); ?></span>
						</div>
						<?php if ( ! empty( $last_run['download_url'] ) && ! empty( $last_run['file_path'] ) && file_exists( $last_run['file_path'] ) ) : ?>
						<a href="<?php echo esc_url( $last_run['download_url'] ); ?>" class="up-btn up-btn--secondary up-btn--full" style="margin-top: 10px;">
							<span class="dashicons dashicons-download"></span>
							<?php esc_html_e( 'Download ZIP', 'ultimate-performance' ); ?>
						</a>
						<?php endif; ?>
					</div>
				</div>
				<?php endif; ?>

			</div>
		</div>
	</div>

	<div class="up-toast" id="up-toast" style="display:none;">
		<span class="up-toast__message"></span>
	</div>
</div>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
