<?php
/**
 * CDN settings tab partial.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin/partials
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template partial loaded within class method scope.

$cdn_settings = Ultimate_Performance_Settings::get_module_settings( 'cdn' );
$provider     = $cdn_settings['cdn_provider'] ?? 'custom';
?>
<form class="up-settings-form" data-module="cdn">
	<?php wp_nonce_field( 'up_nonce', 'up_nonce_field' ); ?>

	<!-- Module Enable -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'CDN', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Serve static assets (CSS, JS, images, fonts) from a Content Delivery Network for faster global delivery.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="enabled" value="1" <?php checked( $cdn_settings['enabled'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable Module', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- CDN Provider -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'CDN Provider', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Select your CDN provider for optimized configuration and cache purge integration.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-cdn-providers">
			<?php
			$providers = array(
				'cloudflare' => array(
					'name' => 'Cloudflare',
					'desc' => __( 'Reverse proxy CDN. No URL rewriting needed.', 'ultimate-performance' ),
					'icon' => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M16.5 9.4l-1.1-.3c-.1-.4-.3-.7-.6-1l.4-1.1c.1-.3 0-.6-.2-.8l-.7-.7c-.2-.2-.5-.3-.8-.2l-1.1.4c-.3-.2-.6-.4-1-.5L11.1 4c-.1-.3-.3-.5-.6-.5h-1c-.3 0-.6.2-.6.5l-.3 1.1c-.4.1-.7.3-1 .6l-1.1-.4c-.3-.1-.6 0-.8.2l-.7.7c-.2.2-.3.5-.2.8l.4 1.1c-.2.3-.4.6-.5 1L3.5 9.4c-.3.1-.5.3-.5.6v1c0 .3.2.6.5.6l1.1.3c.1.4.3.7.6 1l-.4 1.1c-.1.3 0 .6.2.8l.7.7c.2.2.5.3.8.2l1.1-.4c.3.2.6.4 1 .5l.3 1.2c.1.3.3.5.6.5h1c.3 0 .6-.2.6-.5l.3-1.1c.4-.1.7-.3 1-.6l1.1.4c.3.1.6 0 .8-.2l.7-.7c.2-.2.3-.5.2-.8l-.4-1.1c.2-.3.4-.6.5-1l1.2-.3c.3-.1.5-.3.5-.6v-1c0-.3-.2-.6-.5-.6zM10 12.5a2.5 2.5 0 110-5 2.5 2.5 0 010 5z"/><path d="M19 14.5l-.6-.2c-.1-.2-.2-.4-.3-.5l.2-.6c.1-.2 0-.3-.1-.4l-.4-.4c-.1-.1-.3-.2-.4-.1l-.6.2c-.2-.1-.3-.2-.5-.3L17 11.6c0-.2-.2-.3-.3-.3h-.5c-.2 0-.3.1-.3.3l-.2.6c-.2.1-.4.2-.5.3l-.6-.2c-.2-.1-.3 0-.4.1l-.4.4c-.1.1-.2.3-.1.4l.2.6c-.1.2-.2.3-.3.5l-.6.2c-.2 0-.3.2-.3.3v.6c0 .2.1.3.3.3l.6.2c.1.2.2.4.3.5l-.2.6c-.1.2 0 .3.1.4l.4.4c.1.1.3.2.4.1l.6-.2c.2.1.3.2.5.3l.2.6c0 .2.2.3.3.3h.5c.2 0 .3-.1.3-.3l.2-.6c.2-.1.4-.2.5-.3l.6.2c.2.1.3 0 .4-.1l.4-.4c.1-.1.2-.3.1-.4l-.2-.6c.1-.2.2-.3.3-.5l.6-.2c.2 0 .3-.2.3-.3v-.6c0-.1-.1-.3-.3-.3zM16.5 16.5a1.5 1.5 0 110-3 1.5 1.5 0 010 3z"/></svg>',
				),
				'bunnycdn'   => array(
					'name' => 'BunnyCDN',
					'desc' => __( 'Fast & affordable. URL: xxx.b-cdn.net', 'ultimate-performance' ),
					'icon' => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>',
				),
				'keycdn'     => array(
					'name' => 'KeyCDN',
					'desc' => __( 'Pay-as-you-go CDN. URL: xxx.kxcdn.com', 'ultimate-performance' ),
					'icon' => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.78 7.78 5.5 5.5 0 017.78-7.78zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>',
				),
				'cloudfront' => array(
					'name' => 'CloudFront',
					'desc' => __( 'AWS CDN. URL: xxx.cloudfront.net', 'ultimate-performance' ),
					'icon' => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>',
				),
				'stackpath'  => array(
					'name' => 'StackPath',
					'desc' => __( 'Edge computing CDN. URL: xxx.stackpathdns.com', 'ultimate-performance' ),
					'icon' => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><circle cx="6" cy="6" r="1"/><circle cx="6" cy="18" r="1"/></svg>',
				),
				'custom'     => array(
					'name' => __( 'Custom CDN', 'ultimate-performance' ),
					'desc' => __( 'Any CDN with a custom pull zone URL.', 'ultimate-performance' ),
					'icon' => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>',
				),
			);

			foreach ( $providers as $key => $p ) :
			?>
			<label class="up-cdn-provider">
				<input type="radio" name="cdn_provider" value="<?php echo esc_attr( $key ); ?>" <?php checked( $provider, $key ); ?>>
				<span class="up-cdn-provider__card">
					<span class="up-cdn-provider__icon"><?php echo $p['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- SVG is hardcoded above. ?></span>
					<span class="up-cdn-provider__info">
						<strong class="up-cdn-provider__name"><?php echo esc_html( $p['name'] ); ?></strong>
						<span class="up-cdn-provider__desc"><?php echo esc_html( $p['desc'] ); ?></span>
					</span>
					<?php if ( 'custom' !== $key ) : ?>
					<a href="#" class="up-guide-link" data-guide="<?php echo esc_attr( $key ); ?>" onclick="event.preventDefault(); event.stopPropagation(); UPGuides.open('<?php echo esc_js( $key ); ?>');"><?php esc_html_e( 'Setup Guide', 'ultimate-performance' ); ?></a>
					<?php endif; ?>
				</span>
			</label>
			<?php endforeach; ?>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Cloudflare Integration -->
	<div class="up-section-card up-cdn-panel" data-cdn-provider="cloudflare" <?php echo 'cloudflare' !== $provider ? 'style="display:none"' : ''; ?>>
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Cloudflare Integration', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Cloudflare is a reverse proxy — no CDN URL rewriting is needed. Connect your API to enable automatic cache purging.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="cloudflare_email" class="up-field__label"><?php esc_html_e( 'Cloudflare Email', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'The email address associated with your Cloudflare account.', 'ultimate-performance' ); ?></p>
				<input type="text" name="cloudflare_email" id="cloudflare_email" class="up-input" value="<?php echo esc_attr( $cdn_settings['cloudflare_email'] ); ?>" placeholder="you@example.com">
			</div>

			<div class="up-field">
				<label for="cloudflare_api_key" class="up-field__label"><?php esc_html_e( 'API Key', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Your Global API Key from Cloudflare dashboard > My Profile > API Tokens.', 'ultimate-performance' ); ?></p>
				<?php if ( ! empty( $cdn_settings['cloudflare_api_key'] ) ) : ?>
				<div class="up-api-key-masked" style="display: flex; gap: 8px; align-items: center;">
					<input type="text" class="up-input" value="<?php echo esc_attr( str_repeat( "\xE2\x80\xA2", 8 ) . substr( $cdn_settings['cloudflare_api_key'], -4 ) ); ?>" readonly style="flex: 1;">
					<input type="hidden" name="cloudflare_api_key" id="cloudflare_api_key" value="<?php echo esc_attr( $cdn_settings['cloudflare_api_key'] ); ?>">
					<button type="button" class="up-btn up-btn--small up-key-change" data-placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"><?php esc_html_e( 'Change', 'ultimate-performance' ); ?></button>
					<button type="button" class="up-btn up-btn--small up-btn--danger up-key-remove" data-placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"><?php esc_html_e( 'Remove', 'ultimate-performance' ); ?></button>
				</div>
				<?php else : ?>
				<input type="text" name="cloudflare_api_key" id="cloudflare_api_key" class="up-input" value="" placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
				<?php endif; ?>
			</div>

			<div class="up-field">
				<label for="cloudflare_zone_id" class="up-field__label"><?php esc_html_e( 'Zone ID', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Found in the Cloudflare dashboard under your domain > Overview (right sidebar).', 'ultimate-performance' ); ?></p>
				<input type="text" name="cloudflare_zone_id" id="cloudflare_zone_id" class="up-input" value="<?php echo esc_attr( $cdn_settings['cloudflare_zone_id'] ); ?>" placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
			</div>

			<div style="padding: 0 0 4px;">
				<button type="button" id="up-cf-test" class="up-btn up-btn--secondary up-btn--small">
					<span class="dashicons dashicons-yes-alt" style="font-size: 14px; width: 14px; height: 14px;"></span>
					<?php esc_html_e( 'Test Connection', 'ultimate-performance' ); ?>
				</button>
				<button type="button" id="up-cf-purge" class="up-btn up-btn--secondary up-btn--small">
					<span class="dashicons dashicons-trash" style="font-size: 14px; width: 14px; height: 14px;"></span>
					<?php esc_html_e( 'Purge Cloudflare Cache', 'ultimate-performance' ); ?>
				</button>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- BunnyCDN Integration -->
	<div class="up-section-card up-cdn-panel" data-cdn-provider="bunnycdn" <?php echo 'bunnycdn' !== $provider ? 'style="display:none"' : ''; ?>>
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'BunnyCDN Integration', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Connect your BunnyCDN account to enable automatic pull zone cache purging.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="bunnycdn_api_key" class="up-field__label"><?php esc_html_e( 'API Key', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Found in your BunnyCDN dashboard under Account > API Key.', 'ultimate-performance' ); ?></p>
				<?php if ( ! empty( $cdn_settings['bunnycdn_api_key'] ) ) : ?>
				<div class="up-api-key-masked" style="display: flex; gap: 8px; align-items: center;">
					<input type="text" class="up-input" value="<?php echo esc_attr( str_repeat( "\xE2\x80\xA2", 8 ) . substr( $cdn_settings['bunnycdn_api_key'], -4 ) ); ?>" readonly style="flex: 1;">
					<input type="hidden" name="bunnycdn_api_key" id="bunnycdn_api_key" value="<?php echo esc_attr( $cdn_settings['bunnycdn_api_key'] ); ?>">
					<button type="button" class="up-btn up-btn--small up-key-change" data-placeholder="xxxxxxxx-xxxx-xxxx-xxxxxxxxxxxx"><?php esc_html_e( 'Change', 'ultimate-performance' ); ?></button>
					<button type="button" class="up-btn up-btn--small up-btn--danger up-key-remove" data-placeholder="xxxxxxxx-xxxx-xxxx-xxxxxxxxxxxx"><?php esc_html_e( 'Remove', 'ultimate-performance' ); ?></button>
				</div>
				<?php else : ?>
				<input type="text" name="bunnycdn_api_key" id="bunnycdn_api_key" class="up-input" value="" placeholder="xxxxxxxx-xxxx-xxxx-xxxxxxxxxxxx">
				<?php endif; ?>
			</div>

			<div class="up-field">
				<label for="bunnycdn_pullzone_id" class="up-field__label"><?php esc_html_e( 'Pull Zone ID', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Numeric ID of your pull zone. Found in Pull Zones > your zone > General settings.', 'ultimate-performance' ); ?></p>
				<input type="text" name="bunnycdn_pullzone_id" id="bunnycdn_pullzone_id" class="up-input" value="<?php echo esc_attr( $cdn_settings['bunnycdn_pullzone_id'] ); ?>" placeholder="123456">
			</div>

			<div style="padding: 0 0 4px;">
				<button type="button" id="up-bunny-purge" class="up-btn up-btn--secondary up-btn--small">
					<span class="dashicons dashicons-trash" style="font-size: 14px; width: 14px; height: 14px;"></span>
					<?php esc_html_e( 'Purge BunnyCDN Cache', 'ultimate-performance' ); ?>
				</button>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- CDN Configuration (hidden for Cloudflare) -->
	<div class="up-section-card up-cdn-url-config" <?php echo 'cloudflare' === $provider ? 'style="display:none"' : ''; ?>>
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'CDN Configuration', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Configure the CDN URL and control which assets are served from it.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="cdn_url" class="up-field__label"><?php esc_html_e( 'CDN URL', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint" id="up-cdn-url-hint"><?php esc_html_e( 'Enter your CDN base URL including the protocol.', 'ultimate-performance' ); ?></p>
				<input type="text" name="cdn_url" id="cdn_url" class="up-input" value="<?php echo esc_attr( $cdn_settings['cdn_url'] ); ?>" placeholder="https://cdn.example.com">
			</div>

			<div class="up-field">
				<label for="included_extensions" class="up-field__label"><?php esc_html_e( 'Included File Extensions', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Comma-separated list of file extensions to serve from CDN. Leave empty to rewrite all asset URLs.', 'ultimate-performance' ); ?></p>
				<input type="text" name="included_extensions" id="included_extensions" class="up-input" value="<?php echo esc_attr( $cdn_settings['included_extensions'] ); ?>" placeholder=".css,.js,.jpg,.jpeg,.png,.gif,.webp,.woff2,.svg">
			</div>

			<div class="up-field">
				<label for="exclusion_patterns" class="up-field__label"><?php esc_html_e( 'Exclusion Patterns', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'URL patterns to exclude from CDN rewriting. One per line. Any URL containing a pattern will be skipped.', 'ultimate-performance' ); ?></p>
				<textarea name="exclusion_patterns" id="exclusion_patterns" class="up-textarea" rows="3" placeholder="/wp-admin&#10;/wp-includes/js/dist"><?php echo esc_textarea( $cdn_settings['exclusion_patterns'] ); ?></textarea>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Media Offloading -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Media Offloading', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Offload media files to cloud storage (S3-compatible). Reduces server disk usage and enables global delivery.', 'ultimate-performance' ); ?></p>
			</div>
			<div class="up-module-enable">
				<label class="up-switch">
					<input type="checkbox" name="offload_media" value="1" <?php checked( $cdn_settings['offload_media'] ); ?>>
					<span class="up-switch__slider"></span>
					<span class="up-switch__label"><?php esc_html_e( 'Enable', 'ultimate-performance' ); ?></span>
				</label>
			</div>
		</div>
	</div>

	<!-- Storage Provider -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Storage Provider', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Select where to store your media files. All providers use the S3-compatible API.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<?php
		$offload_provider  = $cdn_settings['offload_provider'] ?? 's3';
		$storage_providers = array(
			's3'        => array(
				'name' => 'Amazon S3',
				'desc' => __( 'AWS S3 object storage', 'ultimate-performance' ),
				'icon' => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 6l8-4 8 4M4 6v12l8 4M4 6l8 4M20 6v12l-8 4M20 6l-8 4m0 0v12"/></svg>',
			),
			'do_spaces' => array(
				'name' => 'DigitalOcean Spaces',
				'desc' => __( 'DO S3-compatible storage', 'ultimate-performance' ),
				'icon' => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2a10 10 0 00-6.88 17.23V16h-1.5v-3.38H7v-1.5H3.62A7.38 7.38 0 1112 4.62V2z"/></svg>',
			),
			'r2'        => array(
				'name' => 'Cloudflare R2',
				'desc' => __( 'Zero egress fees storage', 'ultimate-performance' ),
				'icon' => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="3"/><path d="M12 2v4m0 12v4M2 12h4m12 0h4m-2.93-7.07l-2.83 2.83m-8.48 8.48l-2.83 2.83m14.14 0l-2.83-2.83M6.76 6.76L3.93 3.93"/></svg>',
			),
			'b2'        => array(
				'name' => 'Backblaze B2',
				'desc' => __( 'Low-cost S3-compatible', 'ultimate-performance' ),
				'icon' => '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
			),
		);
		?>

		<div class="up-cdn-providers">
			<?php foreach ( $storage_providers as $key => $sp ) : ?>
			<label class="up-cdn-provider">
				<input type="radio" name="offload_provider" value="<?php echo esc_attr( $key ); ?>" <?php checked( $offload_provider, $key ); ?>>
				<span class="up-cdn-provider__card">
					<span class="up-cdn-provider__icon"><?php echo $sp['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- SVG is hardcoded above. ?></span>
					<span class="up-cdn-provider__info">
						<strong class="up-cdn-provider__name"><?php echo esc_html( $sp['name'] ); ?></strong>
						<span class="up-cdn-provider__desc"><?php echo esc_html( $sp['desc'] ); ?></span>
					</span>
					<a href="#" class="up-guide-link" data-guide="<?php echo esc_attr( $key ); ?>" onclick="event.preventDefault(); event.stopPropagation(); UPGuides.open('<?php echo esc_js( $key ); ?>');"><?php esc_html_e( 'Setup Guide', 'ultimate-performance' ); ?></a>
				</span>
			</label>
			<?php endforeach; ?>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Storage Credentials -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Storage Credentials', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc" id="up-offload-cred-hint"><?php esc_html_e( 'Enter your S3-compatible API credentials. All supported providers use access key / secret key authentication.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="offload_access_key" class="up-field__label"><?php esc_html_e( 'Access Key', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint" id="up-offload-access-hint"><?php esc_html_e( 'Your S3 access key ID.', 'ultimate-performance' ); ?></p>
				<?php if ( ! empty( $cdn_settings['offload_access_key'] ) ) : ?>
				<div class="up-api-key-masked" style="display: flex; gap: 8px; align-items: center;">
					<input type="text" class="up-input" value="<?php echo esc_attr( str_repeat( "\xE2\x80\xA2", 8 ) . substr( $cdn_settings['offload_access_key'], -4 ) ); ?>" readonly style="flex: 1;">
					<input type="hidden" name="offload_access_key" id="offload_access_key" value="<?php echo esc_attr( $cdn_settings['offload_access_key'] ); ?>">
					<button type="button" class="up-btn up-btn--small up-key-change" data-placeholder="AKIAIOSFODNN7EXAMPLE"><?php esc_html_e( 'Change', 'ultimate-performance' ); ?></button>
					<button type="button" class="up-btn up-btn--small up-btn--danger up-key-remove" data-placeholder="AKIAIOSFODNN7EXAMPLE"><?php esc_html_e( 'Remove', 'ultimate-performance' ); ?></button>
				</div>
				<?php else : ?>
				<input type="text" name="offload_access_key" id="offload_access_key" class="up-input" value="" placeholder="AKIAIOSFODNN7EXAMPLE">
				<?php endif; ?>
			</div>

			<div class="up-field">
				<label for="offload_secret_key" class="up-field__label"><?php esc_html_e( 'Secret Key', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Your S3 secret access key. Stored securely in the database.', 'ultimate-performance' ); ?></p>
				<?php if ( ! empty( $cdn_settings['offload_secret_key'] ) ) : ?>
				<div class="up-api-key-masked" style="display: flex; gap: 8px; align-items: center;">
					<input type="text" class="up-input" value="<?php echo esc_attr( str_repeat( "\xE2\x80\xA2", 8 ) . substr( $cdn_settings['offload_secret_key'], -4 ) ); ?>" readonly style="flex: 1;">
					<input type="hidden" name="offload_secret_key" id="offload_secret_key" value="<?php echo esc_attr( $cdn_settings['offload_secret_key'] ); ?>">
					<button type="button" class="up-btn up-btn--small up-key-change" data-placeholder="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"><?php esc_html_e( 'Change', 'ultimate-performance' ); ?></button>
					<button type="button" class="up-btn up-btn--small up-btn--danger up-key-remove" data-placeholder="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"><?php esc_html_e( 'Remove', 'ultimate-performance' ); ?></button>
				</div>
				<?php else : ?>
				<input type="text" name="offload_secret_key" id="offload_secret_key" class="up-input" value="" placeholder="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY">
				<?php endif; ?>
			</div>

			<div class="up-field">
				<label for="offload_bucket" class="up-field__label"><?php esc_html_e( 'Bucket Name', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint" id="up-offload-bucket-hint"><?php esc_html_e( 'The name of your storage bucket.', 'ultimate-performance' ); ?></p>
				<input type="text" name="offload_bucket" id="offload_bucket" class="up-input" value="<?php echo esc_attr( $cdn_settings['offload_bucket'] ); ?>" placeholder="my-wordpress-media">
			</div>

			<div class="up-field">
				<label for="offload_region" class="up-field__label"><?php esc_html_e( 'Region', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint" id="up-offload-region-hint"><?php esc_html_e( 'The region where your bucket is located.', 'ultimate-performance' ); ?></p>
				<input type="text" name="offload_region" id="offload_region" class="up-input" value="<?php echo esc_attr( $cdn_settings['offload_region'] ); ?>" placeholder="us-east-1">
			</div>

			<div class="up-field" id="up-offload-endpoint-field" <?php echo ( 'r2' !== $offload_provider ) ? 'style="display:none"' : ''; ?>>
				<label for="offload_endpoint" class="up-field__label"><?php esc_html_e( 'Custom Endpoint', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Required for Cloudflare R2. Format: {account-id}.r2.cloudflarestorage.com', 'ultimate-performance' ); ?></p>
				<input type="text" name="offload_endpoint" id="offload_endpoint" class="up-input" value="<?php echo esc_attr( $cdn_settings['offload_endpoint'] ); ?>" placeholder="xxxxxxxxxxxx.r2.cloudflarestorage.com">
			</div>

			<div style="padding: 0 0 4px; display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
				<button type="button" id="up-offload-test" class="up-btn up-btn--secondary up-btn--small">
					<span class="dashicons dashicons-yes-alt" style="font-size: 14px; width: 14px; height: 14px;"></span>
					<?php esc_html_e( 'Test Connection', 'ultimate-performance' ); ?>
				</button>
				<button type="button" id="up-configure-bucket" class="up-btn up-btn--secondary up-btn--small">
					<span class="dashicons dashicons-shield" style="font-size: 14px; width: 14px; height: 14px;"></span>
					<?php esc_html_e( 'Configure Bucket', 'ultimate-performance' ); ?>
				</button>
				<span id="up-configure-bucket-hint" style="font-size: 12px; color: var(--up-gray-400);"><?php esc_html_e( 'Sets public access policy & CORS', 'ultimate-performance' ); ?></span>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>

	<!-- Delivery & Options -->
	<div class="up-section-card">
		<div class="up-section-card__header">
			<div>
				<h2><?php esc_html_e( 'Delivery & Options', 'ultimate-performance' ); ?></h2>
				<p class="up-section-card__desc"><?php esc_html_e( 'Configure how offloaded media is served and manage storage path settings.', 'ultimate-performance' ); ?></p>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label for="offload_serve_url" class="up-field__label"><?php esc_html_e( 'Custom Serve URL', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Optional. Custom URL to serve offloaded files (e.g. a CloudFront or CDN URL in front of the bucket). Leave empty to serve directly from the bucket.', 'ultimate-performance' ); ?></p>
				<input type="text" name="offload_serve_url" id="offload_serve_url" class="up-input" value="<?php echo esc_attr( $cdn_settings['offload_serve_url'] ); ?>" placeholder="https://media.example.com">
			</div>

			<div class="up-field">
				<label for="offload_path_prefix" class="up-field__label"><?php esc_html_e( 'Path Prefix', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Folder path prefix inside the bucket. Mirrors your WordPress uploads directory structure.', 'ultimate-performance' ); ?></p>
				<input type="text" name="offload_path_prefix" id="offload_path_prefix" class="up-input" value="<?php echo esc_attr( $cdn_settings['offload_path_prefix'] ); ?>" placeholder="wp-content/uploads/">
			</div>
		</div>

		<div class="up-feature-grid">
			<div class="up-feature-card">
				<div class="up-feature-card__icon up-feature-card__icon--rose">
					<span class="dashicons dashicons-trash"></span>
				</div>
				<div class="up-feature-card__info">
					<h3 class="up-feature-card__title"><?php esc_html_e( 'Remove Local Files', 'ultimate-performance' ); ?></h3>
					<p class="up-feature-card__desc"><?php esc_html_e( 'Delete local copies after successful upload to remote storage. Saves disk space.', 'ultimate-performance' ); ?></p>
				</div>
				<label class="up-switch">
					<input type="checkbox" name="offload_remove_local" value="1" <?php checked( $cdn_settings['offload_remove_local'] ); ?>>
					<span class="up-switch__slider"></span>
				</label>
			</div>
		</div>

		<div class="up-fields-stack" style="margin-top: 0; padding-top: 0;">
			<div class="up-field">
				<label class="up-field__label"><?php esc_html_e( 'Bulk Offload Existing Media', 'ultimate-performance' ); ?></label>
				<p class="up-field__hint"><?php esc_html_e( 'Upload all existing Media Library images to your storage provider. New uploads are offloaded automatically.', 'ultimate-performance' ); ?></p>
				<div style="display: flex; align-items: center; gap: 12px; margin-top: 8px;">
					<button type="button" id="up-bulk-offload" class="up-btn up-btn--secondary up-btn--small">
						<span class="dashicons dashicons-cloud-upload" style="font-size: 14px; width: 14px; height: 14px;"></span>
						<?php esc_html_e( 'Offload Existing Media', 'ultimate-performance' ); ?>
					</button>
					<span id="up-bulk-offload-status" style="font-size: 13px; color: var(--up-gray-500);"></span>
				</div>
				<div id="up-bulk-offload-progress" style="display: none; margin-top: 8px;">
					<div style="background: #e5e7eb; border-radius: 4px; height: 6px; overflow: hidden;">
						<div id="up-bulk-offload-bar" style="background: var(--up-primary); height: 100%; width: 0%; transition: width 0.3s;"></div>
					</div>
				</div>
			</div>
		</div>

		<div class="up-section-card__footer">
			<button type="submit" class="up-btn up-btn--primary">
				<?php esc_html_e( 'Save Settings', 'ultimate-performance' ); ?>
			</button>
		</div>
	</div>
</form>

<!-- Guide Sidebar Overlay -->
<div class="up-guide-overlay" id="up-guide-overlay"></div>
<div class="up-guide-sidebar" id="up-guide-sidebar">
	<div class="up-guide-sidebar__header">
		<h3 class="up-guide-sidebar__title" id="up-guide-title"></h3>
		<button type="button" class="up-guide-sidebar__close" id="up-guide-close" aria-label="<?php esc_attr_e( 'Close', 'ultimate-performance' ); ?>">
			<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
		</button>
	</div>
	<div class="up-guide-sidebar__body" id="up-guide-body"></div>
</div>

<script>
var UPGuides = (function() {
	'use strict';

	var guides = {
		cloudflare: {
			title: 'Cloudflare Setup Guide',
			html: '<div class="up-guide-content">'
				+ '<div class="up-guide-intro">'
				+ '<p>Cloudflare is a <strong>reverse proxy CDN</strong> that sits in front of your server. Unlike traditional CDNs, it does not require URL rewriting &mdash; all traffic is routed through Cloudflare automatically once configured.</p>'
				+ '</div>'
				+ '<h4>Step 1: Create a Cloudflare Account</h4>'
				+ '<ol>'
				+ '<li>Visit <strong>cloudflare.com</strong> and sign up for a free account.</li>'
				+ '<li>Click <strong>"Add a Site"</strong> and enter your domain name.</li>'
				+ '<li>Select a plan (the <strong>Free plan</strong> is sufficient for most sites).</li>'
				+ '</ol>'
				+ '<h4>Step 2: Update Your Nameservers</h4>'
				+ '<ol>'
				+ '<li>Cloudflare will provide two nameservers (e.g. <code>anna.ns.cloudflare.com</code>).</li>'
				+ '<li>Log in to your domain registrar and replace the existing nameservers with the ones from Cloudflare.</li>'
				+ '<li>Wait for propagation (can take up to 24 hours, usually much faster).</li>'
				+ '</ol>'
				+ '<h4>Step 3: Get Your API Credentials</h4>'
				+ '<ol>'
				+ '<li>In the Cloudflare dashboard, click your profile icon (top right) &rarr; <strong>My Profile</strong>.</li>'
				+ '<li>Go to the <strong>API Tokens</strong> tab.</li>'
				+ '<li>Under <strong>Global API Key</strong>, click <strong>"View"</strong> and copy the key.</li>'
				+ '<li>Your <strong>email</strong> is the one you use to log in to Cloudflare.</li>'
				+ '</ol>'
				+ '<h4>Step 4: Find Your Zone ID</h4>'
				+ '<ol>'
				+ '<li>Go to the <strong>Overview</strong> page for your domain in Cloudflare.</li>'
				+ '<li>Scroll down the right sidebar &mdash; you\'ll see <strong>Zone ID</strong>.</li>'
				+ '<li>Copy the Zone ID string.</li>'
				+ '</ol>'
				+ '<h4>Step 5: Configure in Ultimate Performance</h4>'
				+ '<ol>'
				+ '<li>Paste your <strong>Email</strong>, <strong>API Key</strong>, and <strong>Zone ID</strong> into the fields above.</li>'
				+ '<li>Click <strong>"Test Connection"</strong> to verify the credentials work.</li>'
				+ '<li>Click <strong>"Save Settings"</strong>.</li>'
				+ '</ol>'
				+ '<div class="up-guide-tip">'
				+ '<strong>Tip:</strong> Cloudflare works as a reverse proxy, so you don\'t need to configure a CDN URL. Your site URL stays the same and Cloudflare caches assets at the edge automatically.'
				+ '</div>'
				+ '</div>'
		},

		bunnycdn: {
			title: 'BunnyCDN Setup Guide',
			html: '<div class="up-guide-content">'
				+ '<div class="up-guide-intro">'
				+ '<p>BunnyCDN is a fast and affordable <strong>pull-zone CDN</strong>. It automatically pulls content from your origin server and caches it at 100+ global edge locations.</p>'
				+ '</div>'
				+ '<h4>Step 1: Create a BunnyCDN Account</h4>'
				+ '<ol>'
				+ '<li>Visit <strong>bunny.net</strong> and sign up (14-day free trial available).</li>'
				+ '<li>Verify your email and log in to the dashboard.</li>'
				+ '</ol>'
				+ '<h4>Step 2: Create a Pull Zone</h4>'
				+ '<ol>'
				+ '<li>In the dashboard, go to <strong>CDN &rarr; Pull Zones</strong>.</li>'
				+ '<li>Click <strong>"Add Pull Zone"</strong>.</li>'
				+ '<li>Enter a name for the zone (e.g. <code>mysite-cdn</code>).</li>'
				+ '<li>Set <strong>Origin URL</strong> to your WordPress site URL (e.g. <code>https://example.com</code>).</li>'
				+ '<li>Choose pricing tiers (Standard is fine for most use cases).</li>'
				+ '<li>Click <strong>"Add Pull Zone"</strong>.</li>'
				+ '</ol>'
				+ '<h4>Step 3: Get Your Credentials</h4>'
				+ '<ol>'
				+ '<li><strong>CDN URL:</strong> Your zone will have a hostname like <code>mysite-cdn.b-cdn.net</code>. Copy this.</li>'
				+ '<li><strong>API Key:</strong> Go to <strong>Account &rarr; API Key</strong> and copy your key.</li>'
				+ '<li><strong>Pull Zone ID:</strong> Go to your pull zone settings &mdash; the numeric ID is shown in the URL or the General tab.</li>'
				+ '</ol>'
				+ '<h4>Step 4: Configure in Ultimate Performance</h4>'
				+ '<ol>'
				+ '<li>Select <strong>BunnyCDN</strong> as your CDN provider above.</li>'
				+ '<li>Enter your <strong>API Key</strong> and <strong>Pull Zone ID</strong>.</li>'
				+ '<li>In the CDN Configuration section, set the <strong>CDN URL</strong> to <code>https://mysite-cdn.b-cdn.net</code>.</li>'
				+ '<li>Click <strong>"Save Settings"</strong>.</li>'
				+ '</ol>'
				+ '<div class="up-guide-tip">'
				+ '<strong>Tip:</strong> You can set up a custom CDN hostname (e.g. <code>cdn.example.com</code>) under Pull Zone &rarr; General &rarr; Custom Hostnames in BunnyCDN. Remember to add an SSL certificate for the custom hostname.'
				+ '</div>'
				+ '</div>'
		},

		keycdn: {
			title: 'KeyCDN Setup Guide',
			html: '<div class="up-guide-content">'
				+ '<div class="up-guide-intro">'
				+ '<p>KeyCDN is a <strong>pay-as-you-go CDN</strong> with a simple pricing model. No monthly minimums, you only pay for what you use.</p>'
				+ '</div>'
				+ '<h4>Step 1: Create a KeyCDN Account</h4>'
				+ '<ol>'
				+ '<li>Visit <strong>keycdn.com</strong> and sign up for an account.</li>'
				+ '<li>You\'ll receive $25 free credit to get started.</li>'
				+ '</ol>'
				+ '<h4>Step 2: Create a Pull Zone</h4>'
				+ '<ol>'
				+ '<li>In your KeyCDN dashboard, go to <strong>Zones</strong>.</li>'
				+ '<li>Click <strong>"Add Zone"</strong>.</li>'
				+ '<li>Set <strong>Zone Type</strong> to <strong>Pull</strong>.</li>'
				+ '<li>Enter a <strong>Zone Name</strong> (e.g. <code>mysite</code>).</li>'
				+ '<li>Set <strong>Origin URL</strong> to your WordPress site URL.</li>'
				+ '<li>Click <strong>"Save"</strong>.</li>'
				+ '</ol>'
				+ '<h4>Step 3: Get Your CDN URL</h4>'
				+ '<ol>'
				+ '<li>Your zone URL will be <code>mysite-xxxx.kxcdn.com</code>.</li>'
				+ '<li>Optionally, set up a <strong>Zone Alias</strong> (custom hostname like <code>cdn.example.com</code>) under Zone settings &rarr; General &rarr; Zone Alias.</li>'
				+ '<li>If using a Zone Alias, add a CNAME DNS record pointing to your zone URL.</li>'
				+ '</ol>'
				+ '<h4>Step 4: Configure in Ultimate Performance</h4>'
				+ '<ol>'
				+ '<li>Select <strong>KeyCDN</strong> as your CDN provider.</li>'
				+ '<li>In the CDN Configuration section, set the <strong>CDN URL</strong> to <code>https://mysite-xxxx.kxcdn.com</code> (or your custom hostname).</li>'
				+ '<li>Click <strong>"Save Settings"</strong>.</li>'
				+ '</ol>'
				+ '<div class="up-guide-tip">'
				+ '<strong>Tip:</strong> Enable <strong>Secure Token</strong> in KeyCDN zone settings to restrict hotlinking. Enable <strong>CORS</strong> if you\'re serving web fonts from the CDN.'
				+ '</div>'
				+ '</div>'
		},

		cloudfront: {
			title: 'AWS CloudFront Setup Guide',
			html: '<div class="up-guide-content">'
				+ '<div class="up-guide-intro">'
				+ '<p>Amazon CloudFront is a <strong>global CDN</strong> from AWS with 400+ edge locations. It integrates seamlessly with S3 and other AWS services.</p>'
				+ '</div>'
				+ '<h4>Step 1: Prerequisites</h4>'
				+ '<ol>'
				+ '<li>You need an <strong>AWS account</strong>. Sign up at <strong>aws.amazon.com</strong> if you don\'t have one.</li>'
				+ '<li>A free tier is available with 1 TB of data transfer for the first 12 months.</li>'
				+ '</ol>'
				+ '<h4>Step 2: Create a CloudFront Distribution</h4>'
				+ '<ol>'
				+ '<li>In the AWS Console, go to <strong>CloudFront</strong>.</li>'
				+ '<li>Click <strong>"Create Distribution"</strong>.</li>'
				+ '<li>Under <strong>Origin Domain</strong>, enter your WordPress site URL (e.g. <code>example.com</code>).</li>'
				+ '<li>Set <strong>Protocol</strong> to <strong>"HTTPS Only"</strong>.</li>'
				+ '<li>Under <strong>Cache Behavior</strong>, set <strong>Viewer Protocol Policy</strong> to <strong>"Redirect HTTP to HTTPS"</strong>.</li>'
				+ '<li>Under <strong>Cache Key and Origin Requests</strong>, choose <strong>"CachingOptimized"</strong> policy.</li>'
				+ '<li>Leave other settings as defaults and click <strong>"Create Distribution"</strong>.</li>'
				+ '</ol>'
				+ '<h4>Step 3: Get Your CloudFront URL</h4>'
				+ '<ol>'
				+ '<li>Once deployed, your distribution will have a domain like <code>d1234567890.cloudfront.net</code>.</li>'
				+ '<li>Copy this domain &mdash; this is your CDN URL.</li>'
				+ '<li>Optionally, set up a <strong>CNAME</strong> (e.g. <code>cdn.example.com</code>) in your distribution settings and add a DNS record.</li>'
				+ '</ol>'
				+ '<h4>Step 4: Configure in Ultimate Performance</h4>'
				+ '<ol>'
				+ '<li>Select <strong>CloudFront</strong> as your CDN provider.</li>'
				+ '<li>In the CDN Configuration section, set the <strong>CDN URL</strong> to <code>https://d1234567890.cloudfront.net</code>.</li>'
				+ '<li>Click <strong>"Save Settings"</strong>.</li>'
				+ '</ol>'
				+ '<div class="up-guide-tip">'
				+ '<strong>Tip:</strong> For best performance, create a custom <strong>Cache Policy</strong> that ignores query strings and cookies for static assets. This increases your cache hit ratio significantly.'
				+ '</div>'
				+ '</div>'
		},

		stackpath: {
			title: 'StackPath Setup Guide',
			html: '<div class="up-guide-content">'
				+ '<div class="up-guide-intro">'
				+ '<p>StackPath offers <strong>CDN, WAF, and edge computing</strong> in a single platform. Their CDN is built on a global network optimized for speed and security.</p>'
				+ '</div>'
				+ '<h4>Step 1: Create a StackPath Account</h4>'
				+ '<ol>'
				+ '<li>Visit <strong>stackpath.com</strong> and sign up for an account.</li>'
				+ '<li>A free trial is available to get started.</li>'
				+ '</ol>'
				+ '<h4>Step 2: Create a CDN Site</h4>'
				+ '<ol>'
				+ '<li>In the StackPath portal, go to <strong>Sites</strong> &rarr; <strong>"Create Site"</strong>.</li>'
				+ '<li>Select <strong>CDN</strong> as the delivery method.</li>'
				+ '<li>Enter your WordPress site URL as the <strong>Origin</strong>.</li>'
				+ '<li>StackPath will assign an edge address like <code>mysite.stackpathdns.com</code>.</li>'
				+ '</ol>'
				+ '<h4>Step 3: Configure DNS</h4>'
				+ '<ol>'
				+ '<li>Option A: Point your CDN subdomain (e.g. <code>cdn.example.com</code>) via a <strong>CNAME record</strong> to the StackPath edge address.</li>'
				+ '<li>Option B: Use the StackPath edge address directly as your CDN URL.</li>'
				+ '</ol>'
				+ '<h4>Step 4: Configure in Ultimate Performance</h4>'
				+ '<ol>'
				+ '<li>Select <strong>StackPath</strong> as your CDN provider.</li>'
				+ '<li>In the CDN Configuration section, set the <strong>CDN URL</strong> to <code>https://mysite.stackpathdns.com</code> (or your custom CNAME).</li>'
				+ '<li>Click <strong>"Save Settings"</strong>.</li>'
				+ '</ol>'
				+ '<div class="up-guide-tip">'
				+ '<strong>Tip:</strong> Enable the <strong>WAF</strong> (Web Application Firewall) in StackPath for added security. Configure EdgeRules to set custom caching headers for WordPress static assets.'
				+ '</div>'
				+ '</div>'
		},

		s3: {
			title: 'Amazon S3 Setup Guide',
			html: '<div class="up-guide-content">'
				+ '<div class="up-guide-intro">'
				+ '<p>Amazon S3 (Simple Storage Service) is the most popular <strong>cloud object storage</strong> service. Media files are stored in an S3 bucket and served either directly or through a CDN like CloudFront.</p>'
				+ '</div>'
				+ '<h4>Step 1: Create an AWS Account</h4>'
				+ '<ol>'
				+ '<li>Visit <strong>aws.amazon.com</strong> and create an account (or sign in).</li>'
				+ '<li>The free tier includes 5 GB of S3 storage for 12 months.</li>'
				+ '</ol>'
				+ '<h4>Step 2: Create an S3 Bucket</h4>'
				+ '<ol>'
				+ '<li>Go to <strong>S3</strong> in the AWS Console.</li>'
				+ '<li>Click <strong>"Create bucket"</strong>.</li>'
				+ '<li>Enter a <strong>bucket name</strong> (globally unique, e.g. <code>mysite-media-2024</code>).</li>'
				+ '<li>Choose a <strong>region</strong> close to your primary audience (e.g. <code>us-east-1</code>).</li>'
				+ '<li><strong>Uncheck</strong> "Block all public access" if you want to serve files directly from S3 (or keep it blocked if using CloudFront).</li>'
				+ '<li>Click <strong>"Create bucket"</strong>.</li>'
				+ '</ol>'
				+ '<h4>Step 3: Create IAM Credentials</h4>'
				+ '<ol>'
				+ '<li>Go to <strong>IAM</strong> in the AWS Console.</li>'
				+ '<li>Click <strong>Users</strong> &rarr; <strong>"Create user"</strong>.</li>'
				+ '<li>Name it something like <code>wp-media-offload</code>.</li>'
				+ '<li>Under Permissions, click <strong>"Attach policies directly"</strong> and search for <strong>AmazonS3FullAccess</strong> (or create a more restrictive custom policy).</li>'
				+ '<li>After creating the user, go to <strong>Security credentials</strong> tab &rarr; <strong>"Create access key"</strong>.</li>'
				+ '<li>Select <strong>"Application running outside AWS"</strong> and create the key.</li>'
				+ '<li>Copy both the <strong>Access Key ID</strong> and <strong>Secret Access Key</strong> (the secret is only shown once!).</li>'
				+ '</ol>'
				+ '<h4>Step 4: Configure in Ultimate Performance</h4>'
				+ '<ol>'
				+ '<li>Select <strong>Amazon S3</strong> as your storage provider.</li>'
				+ '<li>Enter your <strong>Access Key</strong>, <strong>Secret Key</strong>, <strong>Bucket Name</strong>, and <strong>Region</strong>.</li>'
				+ '<li>Click <strong>"Test Connection"</strong> to verify.</li>'
				+ '<li>Click <strong>"Save Settings"</strong>.</li>'
				+ '</ol>'
				+ '<div class="up-guide-tip">'
				+ '<strong>Tip:</strong> For production, create a <strong>custom IAM policy</strong> that only grants <code>s3:PutObject</code>, <code>s3:GetObject</code>, <code>s3:DeleteObject</code>, and <code>s3:ListBucket</code> on your specific bucket. This follows the principle of least privilege.'
				+ '</div>'
				+ '</div>'
		},

		do_spaces: {
			title: 'DigitalOcean Spaces Setup Guide',
			html: '<div class="up-guide-content">'
				+ '<div class="up-guide-intro">'
				+ '<p>DigitalOcean Spaces is an <strong>S3-compatible object storage</strong> service with a built-in CDN. It offers simple pricing at $5/month for 250 GB storage + 1 TB transfer.</p>'
				+ '</div>'
				+ '<h4>Step 1: Create a Space</h4>'
				+ '<ol>'
				+ '<li>Log in to your <strong>DigitalOcean</strong> account (or create one at <strong>digitalocean.com</strong>).</li>'
				+ '<li>Go to <strong>Spaces Object Storage</strong> in the left sidebar.</li>'
				+ '<li>Click <strong>"Create a Space"</strong>.</li>'
				+ '<li>Choose a <strong>datacenter region</strong> (e.g. <code>nyc3</code>, <code>ams3</code>, <code>sgp1</code>).</li>'
				+ '<li>Enable the <strong>CDN</strong> toggle (recommended).</li>'
				+ '<li>Choose a unique <strong>Space name</strong>.</li>'
				+ '<li>Click <strong>"Create a Space"</strong>.</li>'
				+ '</ol>'
				+ '<h4>Step 2: Generate API Keys</h4>'
				+ '<ol>'
				+ '<li>Go to <strong>API</strong> in the left sidebar.</li>'
				+ '<li>Scroll to <strong>Spaces Keys</strong>.</li>'
				+ '<li>Click <strong>"Generate New Key"</strong>.</li>'
				+ '<li>Name it (e.g. <code>wp-media-offload</code>).</li>'
				+ '<li>Copy both the <strong>Key</strong> (Access Key) and <strong>Secret</strong>.</li>'
				+ '</ol>'
				+ '<h4>Step 3: Configure in Ultimate Performance</h4>'
				+ '<ol>'
				+ '<li>Select <strong>DigitalOcean Spaces</strong> as your storage provider.</li>'
				+ '<li>Enter your <strong>Access Key</strong> and <strong>Secret Key</strong>.</li>'
				+ '<li>Set <strong>Bucket Name</strong> to your Space name.</li>'
				+ '<li>Set <strong>Region</strong> to your Space\'s region (e.g. <code>nyc3</code>).</li>'
				+ '<li>Click <strong>"Test Connection"</strong> to verify.</li>'
				+ '<li>Click <strong>"Save Settings"</strong>.</li>'
				+ '</ol>'
				+ '<div class="up-guide-tip">'
				+ '<strong>Tip:</strong> If you enabled CDN for your Space, set the <strong>Custom Serve URL</strong> in Delivery & Options to your Space CDN endpoint (e.g. <code>https://myspace.nyc3.cdn.digitaloceanspaces.com</code>) for faster delivery.'
				+ '</div>'
				+ '</div>'
		},

		r2: {
			title: 'Cloudflare R2 Setup Guide',
			html: '<div class="up-guide-content">'
				+ '<div class="up-guide-intro">'
				+ '<p>Cloudflare R2 is an <strong>S3-compatible object storage</strong> service with <strong>zero egress fees</strong>. You never pay for bandwidth, making it ideal for media-heavy WordPress sites.</p>'
				+ '</div>'
				+ '<h4>Step 1: Enable R2 in Cloudflare</h4>'
				+ '<ol>'
				+ '<li>Log in to your <strong>Cloudflare</strong> dashboard.</li>'
				+ '<li>Click <strong>R2 Object Storage</strong> in the left sidebar.</li>'
				+ '<li>If prompted, add a payment method (R2 has a generous free tier: 10 GB storage, 10 million reads/month).</li>'
				+ '</ol>'
				+ '<h4>Step 2: Create an R2 Bucket</h4>'
				+ '<ol>'
				+ '<li>Click <strong>"Create bucket"</strong>.</li>'
				+ '<li>Enter a <strong>bucket name</strong> (e.g. <code>wp-media</code>).</li>'
				+ '<li>Choose a <strong>location hint</strong> (e.g. Eastern North America).</li>'
				+ '<li>Click <strong>"Create bucket"</strong>.</li>'
				+ '</ol>'
				+ '<h4>Step 3: Create API Token</h4>'
				+ '<ol>'
				+ '<li>In the R2 section, click <strong>"Manage R2 API Tokens"</strong>.</li>'
				+ '<li>Click <strong>"Create API token"</strong>.</li>'
				+ '<li>Give it a name (e.g. <code>wp-offload</code>).</li>'
				+ '<li>Set <strong>Permissions</strong> to <strong>Object Read & Write</strong>.</li>'
				+ '<li>Optionally restrict to your specific bucket.</li>'
				+ '<li>Click <strong>"Create API Token"</strong>.</li>'
				+ '<li>Copy the <strong>Access Key ID</strong> and <strong>Secret Access Key</strong>.</li>'
				+ '</ol>'
				+ '<h4>Step 4: Find Your Account ID</h4>'
				+ '<ol>'
				+ '<li>Your R2 endpoint is <code>{account-id}.r2.cloudflarestorage.com</code>.</li>'
				+ '<li>Find your <strong>Account ID</strong> on the Cloudflare dashboard sidebar (right side of Overview page).</li>'
				+ '</ol>'
				+ '<h4>Step 5: Configure in Ultimate Performance</h4>'
				+ '<ol>'
				+ '<li>Select <strong>Cloudflare R2</strong> as your storage provider.</li>'
				+ '<li>Enter your <strong>Access Key</strong> and <strong>Secret Key</strong>.</li>'
				+ '<li>Set <strong>Bucket Name</strong> to your R2 bucket name.</li>'
				+ '<li>Set <strong>Region</strong> to <code>auto</code>.</li>'
				+ '<li>Set <strong>Custom Endpoint</strong> to <code>{account-id}.r2.cloudflarestorage.com</code>.</li>'
				+ '<li>Click <strong>"Test Connection"</strong> to verify.</li>'
				+ '<li>Click <strong>"Save Settings"</strong>.</li>'
				+ '</ol>'
				+ '<div class="up-guide-tip">'
				+ '<strong>Tip:</strong> To serve R2 files publicly, enable a <strong>Custom Domain</strong> for the bucket (R2 dashboard &rarr; Settings &rarr; Public Access &rarr; Custom Domains). Set this as your <strong>Custom Serve URL</strong> in Delivery & Options.'
				+ '</div>'
				+ '</div>'
		},

		b2: {
			title: 'Backblaze B2 Setup Guide',
			html: '<div class="up-guide-content">'
				+ '<div class="up-guide-intro">'
				+ '<p>Backblaze B2 is an <strong>ultra-low-cost cloud storage</strong> service with S3-compatible API. At $0.006/GB/month for storage and free egress through Cloudflare (Bandwidth Alliance), it\'s one of the cheapest options available.</p>'
				+ '</div>'
				+ '<h4>Step 1: Create a Backblaze Account</h4>'
				+ '<ol>'
				+ '<li>Visit <strong>backblaze.com/b2</strong> and sign up.</li>'
				+ '<li>The first 10 GB of storage is free.</li>'
				+ '</ol>'
				+ '<h4>Step 2: Create a B2 Bucket</h4>'
				+ '<ol>'
				+ '<li>In the B2 dashboard, go to <strong>Buckets</strong>.</li>'
				+ '<li>Click <strong>"Create a Bucket"</strong>.</li>'
				+ '<li>Enter a <strong>bucket name</strong> (e.g. <code>mysite-media</code>).</li>'
				+ '<li>Set <strong>Files in Bucket</strong> to <strong>"Public"</strong> (needed to serve media files directly).</li>'
				+ '<li>Click <strong>"Create a Bucket"</strong>.</li>'
				+ '<li>Note the <strong>Endpoint</strong> shown (e.g. <code>s3.us-west-004.backblazeb2.com</code>).</li>'
				+ '</ol>'
				+ '<h4>Step 3: Create Application Keys</h4>'
				+ '<ol>'
				+ '<li>Go to <strong>App Keys</strong> in the B2 dashboard.</li>'
				+ '<li>Click <strong>"Add a New Application Key"</strong>.</li>'
				+ '<li>Name it (e.g. <code>wp-offload</code>).</li>'
				+ '<li>Restrict it to your bucket for security.</li>'
				+ '<li>Set <strong>Type of Access</strong> to <strong>Read and Write</strong>.</li>'
				+ '<li>Click <strong>"Create New Key"</strong>.</li>'
				+ '<li>Copy the <strong>keyID</strong> (this is your Access Key) and <strong>applicationKey</strong> (this is your Secret Key).</li>'
				+ '</ol>'
				+ '<h4>Step 4: Configure in Ultimate Performance</h4>'
				+ '<ol>'
				+ '<li>Select <strong>Backblaze B2</strong> as your storage provider.</li>'
				+ '<li>Enter your <strong>keyID</strong> as Access Key and <strong>applicationKey</strong> as Secret Key.</li>'
				+ '<li>Set <strong>Bucket Name</strong> to your B2 bucket name.</li>'
				+ '<li>Set <strong>Region</strong> to the region from your bucket endpoint (e.g. <code>us-west-004</code>).</li>'
				+ '<li>Click <strong>"Test Connection"</strong> to verify.</li>'
				+ '<li>Click <strong>"Save Settings"</strong>.</li>'
				+ '</ol>'
				+ '<div class="up-guide-tip">'
				+ '<strong>Tip:</strong> Pair Backblaze B2 with <strong>Cloudflare CDN</strong> for free bandwidth through the Bandwidth Alliance. Set Cloudflare as your CDN provider and point a Cloudflare worker or CNAME at your B2 bucket\'s friendly URL.'
				+ '</div>'
				+ '</div>'
		}
	};

	function open( guideKey ) {
		var guide = guides[ guideKey ];
		if ( ! guide ) return;

		document.getElementById( 'up-guide-title' ).textContent = guide.title;
		document.getElementById( 'up-guide-body' ).innerHTML = guide.html;
		document.getElementById( 'up-guide-overlay' ).classList.add( 'up-guide-overlay--visible' );
		document.getElementById( 'up-guide-sidebar' ).classList.add( 'up-guide-sidebar--visible' );
		document.body.style.overflow = 'hidden';
	}

	function close() {
		document.getElementById( 'up-guide-overlay' ).classList.remove( 'up-guide-overlay--visible' );
		document.getElementById( 'up-guide-sidebar' ).classList.remove( 'up-guide-sidebar--visible' );
		document.body.style.overflow = '';
	}

	// Bind close events once DOM is ready.
	document.addEventListener( 'DOMContentLoaded', function() {
		document.getElementById( 'up-guide-close' ).addEventListener( 'click', close );
		document.getElementById( 'up-guide-overlay' ).addEventListener( 'click', close );
		document.addEventListener( 'keydown', function( e ) {
			if ( e.key === 'Escape' ) close();
		});
	});

	return { open: open, close: close };
})();
</script>
<?php // phpcs:enable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound ?>
