<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/admin
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Admin
 *
 * Handles admin-facing functionality including
 * enqueueing styles/scripts and rendering admin pages.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Admin {

	/**
	 * Initialize admin bar hooks.
	 *
	 * Called directly (not via Loader) to ensure the admin bar node is always registered.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		add_action( 'admin_bar_menu', array( $this, 'add_admin_bar_node' ), 100 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_bar_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_admin_bar_assets' ) );
	}

	/**
	 * Add Clear Cache button to the WordPress admin bar.
	 *
	 * @since 1.0.0
	 * @param WP_Admin_Bar $admin_bar The admin bar instance.
	 */
	public function add_admin_bar_node( $admin_bar ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$admin_bar->add_node( array(
			'id'    => 'up-clear-cache',
			'title' => '<span class="ab-icon dashicons dashicons-performance" style="margin-top: 2px;"></span>' . __( 'Clear Cache', 'ultimate-performance' ),
			'href'  => '#',
			'meta'  => array(
				'title' => __( 'Clear all Ultimate Performance caches', 'ultimate-performance' ),
			),
		) );
	}

	/**
	 * Enqueue admin bar assets on all pages.
	 *
	 * Loads a small inline script for the admin bar Clear Cache button.
	 * Only loads when the admin bar is showing and user has the right cap.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_admin_bar_assets() {
		if ( ! is_admin_bar_showing() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_enqueue_style( 'dashicons' );

		$nonce    = wp_create_nonce( 'up_nonce' );
		$ajax_url = admin_url( 'admin-ajax.php' );
		$purging  = esc_js( __( 'Purging...', 'ultimate-performance' ) );
		$label    = esc_js( __( 'Clear Cache', 'ultimate-performance' ) );
		$success  = esc_js( __( 'Cache cleared successfully.', 'ultimate-performance' ) );
		$error    = esc_js( __( 'Failed to clear cache.', 'ultimate-performance' ) );

		wp_add_inline_style( 'dashicons', '
			#wp-admin-bar-up-clear-cache > a:hover { background: rgba(0,0,0,.1) !important; }
			#wp-admin-bar-up-clear-cache .ab-icon:before { content: "\f227"; top: 2px; }
		' );

		wp_register_script( 'up-admin-bar', false, array(), UP_VERSION, true );
		wp_enqueue_script( 'up-admin-bar' );
		wp_add_inline_script( 'up-admin-bar', '
			(function() {
				document.addEventListener("DOMContentLoaded", function() {
					var link = document.querySelector("#wp-admin-bar-up-clear-cache > a");
					if (!link) return;

					link.addEventListener("click", function(e) {
						e.preventDefault();
						var original = link.innerHTML;
						link.innerHTML = "' . $purging . '";

						var xhr = new XMLHttpRequest();
						xhr.open("POST", "' . $ajax_url . '");
						xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
						xhr.onload = function() {
							try {
								var res = JSON.parse(xhr.responseText);
								if (res.success) {
									link.innerHTML = "' . $success . '";
								} else {
									link.innerHTML = "' . $error . '";
								}
							} catch(ex) {
								link.innerHTML = "' . $error . '";
							}
							setTimeout(function() { link.innerHTML = original; }, 2000);
						};
						xhr.onerror = function() {
							link.innerHTML = "' . $error . '";
							setTimeout(function() { link.innerHTML = original; }, 2000);
						};
						xhr.send("action=up_purge_cache&nonce=' . $nonce . '");
					});
				});
			})();
		' );
	}

	/**
	 * Register the admin stylesheets.
	 *
	 * @since 1.0.0
	 * @param string $hook The current admin page hook suffix.
	 */
	public function enqueue_styles( $hook ) {
		// Load on plugin admin pages.
		if ( false !== strpos( $hook, 'ultimate-performance' ) ) {
			wp_enqueue_style(
				'ultimate-performance-admin',
				UP_PLUGIN_URL . 'admin/css/ultimate-performance-admin.css',
				array(),
				UP_VERSION
			);
		}
	}

	/**
	 * Register the admin JavaScript.
	 *
	 * @since 1.0.0
	 * @param string $hook The current admin page hook suffix.
	 */
	public function enqueue_scripts( $hook ) {
		// Load on plugin settings pages and post editor (for Script Manager metabox).
		$is_plugin_page = ( false !== strpos( $hook, 'ultimate-performance' ) );
		$is_editor      = in_array( $hook, array( 'post.php', 'post-new.php' ), true );

		if ( ! $is_plugin_page && ! $is_editor ) {
			return;
		}

		wp_enqueue_script(
			'ultimate-performance-admin',
			UP_PLUGIN_URL . 'admin/js/ultimate-performance-admin.js',
			array( 'jquery' ),
			UP_VERSION,
			true
		);

		wp_localize_script(
			'ultimate-performance-admin',
			'upAdmin',
			array(
				'ajax_url'    => admin_url( 'admin-ajax.php' ),
				'nonce'       => wp_create_nonce( 'up_nonce' ),
				'ai_models'   => class_exists( 'Ultimate_Performance_Ai' ) ? Ultimate_Performance_Ai::PROVIDER_MODELS : array(),
				'fix_status'  => class_exists( 'Ultimate_Performance_Speed_Test' ) ? Ultimate_Performance_Speed_Test::get_fix_applied_status() : array(),
				'i18n'        => array(
					'save'              => __( 'Save Settings', 'ultimate-performance' ),
					'saving'            => __( 'Saving...', 'ultimate-performance' ),
					'error'             => __( 'An error occurred.', 'ultimate-performance' ),
					'network_error'     => __( 'Network error. Please try again.', 'ultimate-performance' ),
					'confirm_clean_all' => __( 'Are you sure you want to clean all items? This cannot be undone.', 'ultimate-performance' ),
					'cleaning'          => __( 'Cleaning...', 'ultimate-performance' ),
					'clean_all'         => __( 'Clean All', 'ultimate-performance' ),
					'purging'             => __( 'Purging...', 'ultimate-performance' ),
					'confirm_clear_fonts' => __( 'Are you sure you want to delete all locally hosted font files?', 'ultimate-performance' ),
					'clearing_fonts'      => __( 'Clearing...', 'ultimate-performance' ),
					'scanning'            => __( 'Scanning...', 'ultimate-performance' ),
					'no_assets'           => __( 'No assets detected.', 'ultimate-performance' ),
					'converting_webp'     => __( 'Converting...', 'ultimate-performance' ),
					'compressing'         => __( 'Compressing...', 'ultimate-performance' ),
					'testing'              => __( 'Testing...', 'ultimate-performance' ),
					'testing_hint'         => __( 'Running PageSpeed Insights analysis. This may take up to 60 seconds...', 'ultimate-performance' ),
					'quick_testing_hint'   => __( 'Running browser-based performance test...', 'ultimate-performance' ),
					'enter_url'            => __( 'Please enter a URL to test.', 'ultimate-performance' ),
					'report_saved'         => __( 'Report saved.', 'ultimate-performance' ),
					'report_deleted'       => __( 'Report deleted.', 'ultimate-performance' ),
					'loading_report'       => __( 'Loading report...', 'ultimate-performance' ),
					'compare_select_two'   => __( 'Please select exactly 2 reports to compare.', 'ultimate-performance' ),
					'comparing'            => __( 'Comparing...', 'ultimate-performance' ),
					'confirm_delete_report' => __( 'Are you sure you want to delete this report?', 'ultimate-performance' ),
					'applied'              => __( 'Applied', 'ultimate-performance' ),
					'testing_connection'   => __( 'Testing...', 'ultimate-performance' ),
					'configuring'          => __( 'Configuring...', 'ultimate-performance' ),
					'offloading'           => __( 'Offloading...', 'ultimate-performance' ),
					/* translators: %s: preset name */
				'confirm_preset'       => __( 'Are you sure you want to apply the "%s" preset? This will overwrite your current toggle settings across all modules.', 'ultimate-performance' ),
					'applying_preset'      => __( 'Applying...', 'ultimate-performance' ),
					'currently_active'     => __( 'Currently Active', 'ultimate-performance' ),
					'apply_preset'         => __( 'Apply Preset', 'ultimate-performance' ),
					'active'               => __( 'Active', 'ultimate-performance' ),
					'recommended'          => __( 'Recommended', 'ultimate-performance' ),
					'detecting_tools'      => __( 'Detecting...', 'ultimate-performance' ),
					'tools_detected'       => __( 'Tool detection complete.', 'ultimate-performance' ),
					'not_installed'        => __( 'Not installed', 'ultimate-performance' ),
					'generate_static'      => __( 'Generate Static Site', 'ultimate-performance' ),
					'generate_selected'    => __( 'Generate Selected Pages', 'ultimate-performance' ),
					'generating'           => __( 'Generating...', 'ultimate-performance' ),
					'static_complete'      => __( 'Static site generated successfully!', 'ultimate-performance' ),
					'static_cancelled'     => __( 'Generation cancelled.', 'ultimate-performance' ),
					'confirm_generate'     => __( 'This will generate a static copy of your site. Continue?', 'ultimate-performance' ),
					'no_pages_found'       => __( 'No pages found.', 'ultimate-performance' ),
					'select_pages_hint'    => __( 'Search and select pages to generate.', 'ultimate-performance' ),
					'serve_saved'          => __( 'Serve settings saved.', 'ultimate-performance' ),
					'serve_purged'         => __( 'Served files purged.', 'ultimate-performance' ),
					/* translators: %d: number of static pages being served */
					'serving_pages'        => __( 'Serving %d static page(s)', 'ultimate-performance' ),
					/* translators: %d: number of static pages ready */
					'pages_ready'          => __( '%d page(s) ready to serve', 'ultimate-performance' ),
					'no_pages_serving'     => __( 'No pages available for serving. Generate pages first.', 'ultimate-performance' ),
					'confirm_purge_serve'  => __( 'This will delete all served static files. Continue?', 'ultimate-performance' ),
					'ai_analyzing'         => __( 'Analyzing...', 'ultimate-performance' ),
					'ai_scanning'          => __( 'Scanning website...', 'ultimate-performance' ),
					'ai_scan_hint'         => __( 'Fetching page data and analyzing with AI. This may take up to 60 seconds...', 'ultimate-performance' ),
					'ai_select_report'     => __( 'Please select a speed test report to analyze.', 'ultimate-performance' ),
					'ai_report_deleted'    => __( 'AI report deleted.', 'ultimate-performance' ),
					'ai_confirm_delete'    => __( 'Are you sure you want to delete this AI report?', 'ultimate-performance' ),
					'no_ai_reports'        => __( 'No AI reports yet. Run a website scan to generate one.', 'ultimate-performance' ),
					'checking'             => __( 'Checking...', 'ultimate-performance' ),
					'fetching_headers'     => __( 'Fetching headers from your static assets...', 'ultimate-performance' ),
					'updating'             => __( 'Updating...', 'ultimate-performance' ),
					'rewrite_rules'        => __( 'Re-write Rules', 'ultimate-performance' ),
				),
			)
		);
	}
}
