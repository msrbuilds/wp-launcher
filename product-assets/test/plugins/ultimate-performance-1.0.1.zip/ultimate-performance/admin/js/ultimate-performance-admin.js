/**
 * Ultimate Performance - Admin JavaScript
 *
 * Handles settings forms AJAX save, database tools, and toast notifications.
 *
 * @package Ultimate_Performance
 * @since   1.0.0
 */

(function( $ ) {
	'use strict';

	var UP = {

		/**
		 * Initialize all admin functionality.
		 */
		init: function() {
			this.bindSettingsForms();
			this.bindToggleAll();
			this.bindDatabaseTools();
			this.loadDatabaseCounts();
			this.bindCachePurge();
			this.bindClearFonts();
			this.bindScriptManager();
			this.bindSpeedTest();
			this.bindSpeedTestReports();
			this.bindBulkWebP();
			this.bindBulkCompress();
			this.bindRefreshTools();
			this.bindCDNProviders();
			this.bindPresets();
			this.bindFixSuggestions();
			this.bindStaticSite();
			this.bindApiKeyMask();
			this.bindAiAssistant();
			this.bindUCSS();
		},

		/**
		 * Show a toast notification.
		 *
		 * @param {string} message The message to display.
		 * @param {string} type    'success' or 'error'.
		 */
		showToast: function( message, type ) {
			var $toast = $( '#up-toast' );

			if ( ! $toast.length ) {
				$toast = $( '<div class="up-toast" id="up-toast"><span class="up-toast__message"></span></div>' );
				$( 'body' ).append( $toast );
			}

			$toast
				.removeClass( 'up-toast--success up-toast--error' )
				.addClass( 'up-toast--' + ( type || 'success' ) )
				.find( '.up-toast__message' ).text( message );

			$toast.stop( true ).fadeIn( 200 );

			setTimeout( function() {
				$toast.fadeOut( 300 );
			}, 3000 );
		},

		/**
		 * Bind "Toggle All" switches in section headers.
		 *
		 * Toggles all checkboxes within the same section card's feature grid.
		 * Also syncs the toggle-all state when individual checkboxes change.
		 */
		bindToggleAll: function() {
			// Set initial state of each toggle-all based on current checkboxes.
			$( '.up-toggle-all__input' ).each( function() {
				var $card       = $( this ).closest( '.up-section-card' );
				var $checkboxes = $card.find( '.up-feature-grid input[type="checkbox"]' );
				var allChecked  = $checkboxes.length > 0 && $checkboxes.length === $checkboxes.filter( ':checked' ).length;
				$( this ).prop( 'checked', allChecked );
			});

			// When toggle-all is clicked, check/uncheck all in that section.
			$( document ).on( 'change', '.up-toggle-all__input', function() {
				var checked     = $( this ).prop( 'checked' );
				var $card       = $( this ).closest( '.up-section-card' );
				$card.find( '.up-feature-grid input[type="checkbox"]' ).prop( 'checked', checked );
			});

			// When an individual checkbox changes, sync the toggle-all state.
			$( document ).on( 'change', '.up-feature-grid input[type="checkbox"]', function() {
				var $card       = $( this ).closest( '.up-section-card' );
				var $toggleAll  = $card.find( '.up-toggle-all__input' );
				if ( ! $toggleAll.length ) {
					return;
				}
				var $checkboxes = $card.find( '.up-feature-grid input[type="checkbox"]' );
				var allChecked  = $checkboxes.length === $checkboxes.filter( ':checked' ).length;
				$toggleAll.prop( 'checked', allChecked );
			});
		},

		/**
		 * Bind AJAX save on all settings forms.
		 *
		 * Handles per-section save buttons within a single form.
		 */
		bindSettingsForms: function() {
			var self = this;

			// Track which save button was clicked for visual feedback.
			$( document ).on( 'click', '.up-settings-form .up-btn--primary[type="submit"]', function() {
				$( this ).closest( '.up-settings-form' ).data( 'clickedBtn', $( this ) );
			});

			$( document ).on( 'submit', '.up-settings-form', function( e ) {
				e.preventDefault();

				var $form  = $( this );
				var module = $form.data( 'module' );
				var $btns  = $form.find( '.up-btn--primary' );

				if ( ! module ) {
					return;
				}

				// Disable all save buttons.
				$btns.prop( 'disabled', true );

				// Animate the clicked button.
				var $clickedBtn  = $form.data( 'clickedBtn' ) || $btns.first();
				var originalText = $clickedBtn.text();
				$clickedBtn.html( '<span class="up-spinner up-spinner--white"></span> ' + upAdmin.i18n.saving );

				var settings = {};

				// Checkboxes: unchecked = false, checked = true.
				$form.find( 'input[type="checkbox"]' ).each( function() {
					settings[ this.name ] = this.checked;
				});

				// Radio buttons.
				$form.find( 'input[type="radio"]:checked' ).each( function() {
					settings[ this.name ] = this.value;
				});

				// Selects.
				$form.find( 'select' ).each( function() {
					settings[ this.name ] = $( this ).val();
				});

				// Number inputs.
				$form.find( 'input[type="number"]' ).each( function() {
					settings[ this.name ] = parseInt( this.value, 10 ) || 0;
				});

				// Text, URL, and hidden inputs.
				$form.find( 'input[type="text"], input[type="url"], input[type="hidden"]' ).each( function() {
					settings[ this.name ] = this.value;
				});

				// Textareas.
				$form.find( 'textarea' ).each( function() {
					settings[ this.name ] = $( this ).val();
				});

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_save_settings',
						nonce: upAdmin.nonce,
						module: module,
						settings: settings
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( response.data.message, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btns.prop( 'disabled', false );
						$clickedBtn.text( originalText );
						$form.removeData( 'clickedBtn' );
					}
				});
			});
		},

		/**
		 * Bind database cleanup tool buttons.
		 */
		bindDatabaseTools: function() {
			var self = this;

			// Single cleanup button.
			$( document ).on( 'click', '.up-db-clean-btn', function() {
				var $btn  = $( this );
				var type  = $btn.data( 'type' );
				var $card = $btn.closest( '.up-db-card' );
				var label = $btn.text();

				if ( ! type ) {
					return;
				}

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span>' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_db_run_cleanup',
						nonce: upAdmin.nonce,
						type: type
					},
					success: function( response ) {
						if ( response.success ) {
							$card.find( '.up-db-card__count' ).text( '0' ).removeClass( 'has-items' );
							self.showToast( response.data.message, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});

			// Clean All button.
			$( '#up-db-clean-all' ).on( 'click', function() {
				var $btn = $( this );

				if ( ! confirm( upAdmin.i18n.confirm_clean_all ) ) {
					return;
				}

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + upAdmin.i18n.cleaning );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_db_run_all',
						nonce: upAdmin.nonce
					},
					success: function( response ) {
						if ( response.success ) {
							$( '.up-db-card__count' ).text( '0' ).removeClass( 'has-items' );
							self.showToast( response.data.message, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( upAdmin.i18n.clean_all );
					}
				});
			});
		},

		/**
		 * Load database item counts on page load.
		 */
		/**
		 * Bind cache purge button.
		 */
		bindCachePurge: function() {
			var self = this;

			$( document ).on( 'click', '#up-purge-cache, #up-header-purge-cache', function() {
				var $btn  = $( this );
				var label = $btn.text();

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + upAdmin.i18n.purging );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_purge_cache',
						nonce: upAdmin.nonce
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( response.data.message, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});

			// Verify Cache Headers diagnostic.
			$( document ).on( 'click', '#up-verify-cache-headers', function() {
				var $btn     = $( this );
				var label    = $btn.html();
				var $results = $( '#up-cache-verify-results' );

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + ( upAdmin.i18n.checking || 'Checking...' ) );
				$results.html( '<p style="color: var(--up-gray-500);">' + ( upAdmin.i18n.fetching_headers || 'Fetching headers from your static assets...' ) + '</p>' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_verify_cache_headers',
						nonce: upAdmin.nonce
					},
					timeout: 30000,
					success: function( response ) {
						if ( ! response.success ) {
							$results.html( '<p style="color: var(--up-danger);">' + self.escHtml( response.data.message || 'Error.' ) + '</p>' );
							return;
						}

						var d    = response.data;
						var html = '';

						// Status banner.
						var bannerColor = d.status === 'ok' ? 'var(--up-success)' : 'var(--up-danger)';
						var bannerIcon  = d.status === 'ok' ? 'dashicons-yes-alt' : 'dashicons-warning';
						html += '<div style="display: flex; align-items: center; gap: 8px; padding: 10px 14px; background: ' + ( d.status === 'ok' ? 'var(--up-success-light)' : 'var(--up-danger-light)' ) + '; border-radius: 6px; margin-bottom: 12px;">';
						html += '<span class="dashicons ' + bannerIcon + '" style="color: ' + bannerColor + '; font-size: 18px; width: 18px; height: 18px;"></span>';
						html += '<span style="font-size: 13px; font-weight: 500;">' + self.escHtml( d.diagnosis ) + '</span>';
						html += '</div>';

						// Server info.
						html += '<div style="font-size: 12px; color: var(--up-gray-500); margin-bottom: 10px;">';
						html += '<strong>Server:</strong> ' + self.escHtml( d.server || 'Unknown' );
						html += ' &middot; <strong>.htaccess:</strong> ' + ( d.htaccess_exists ? ( d.rules_present ? 'Rules present' : 'Exists, no rules' ) : 'Not found' );
						html += '</div>';

						// Asset results table.
						if ( d.assets && d.assets.length ) {
							html += '<table style="width: 100%; font-size: 12px; border-collapse: collapse;">';
							html += '<thead><tr style="border-bottom: 1px solid var(--up-gray-200); text-align: left;">';
							html += '<th style="padding: 6px 8px;">Asset</th>';
							html += '<th style="padding: 6px 8px;">Cache-Control</th>';
							html += '<th style="padding: 6px 8px;">Status</th>';
							html += '</tr></thead><tbody>';

							for ( var i = 0; i < d.assets.length; i++ ) {
								var a = d.assets[ i ];
								var shortUrl = a.url.length > 60 ? '...' + a.url.slice( -55 ) : a.url;
								var isOk = a.max_age !== null && a.max_age >= d.expected_max_age;
								var statusText, statusColor;

								if ( a.cache_control === 'not set' ) {
									statusText  = 'No headers';
									statusColor = 'var(--up-danger)';
								} else if ( isOk ) {
									statusText  = 'OK';
									statusColor = 'var(--up-success)';
								} else {
									statusText  = a.max_age !== null ? 'max-age=' + a.max_age + ' (expected ' + d.expected_max_age + ')' : 'Missing max-age';
									statusColor = 'var(--up-warning)';
								}

								html += '<tr style="border-bottom: 1px solid var(--up-gray-100);">';
								html += '<td style="padding: 6px 8px; word-break: break-all;" title="' + self.escHtml( a.url ) + '">' + self.escHtml( shortUrl ) + '</td>';
								html += '<td style="padding: 6px 8px; font-family: monospace; font-size: 11px;">' + self.escHtml( a.cache_control ) + '</td>';
								html += '<td style="padding: 6px 8px; color: ' + statusColor + '; font-weight: 500;">' + statusText + '</td>';
								html += '</tr>';
							}

							html += '</tbody></table>';
						} else {
							html += '<p style="color: var(--up-gray-400); font-size: 13px;">Could not find static assets to test.</p>';
						}

						// Re-write rules button (shown when rules need updating).
						if ( d.rules_need_update ) {
							html += '<div style="margin-top: 12px;">';
							html += '<button type="button" class="up-btn up-btn--primary up-btn--small" id="up-rewrite-htaccess-rules">';
							html += '<span class="dashicons dashicons-update" style="font-size: 14px; width: 14px; height: 14px; margin-right: 4px;"></span>';
							html += ( upAdmin.i18n.rewrite_rules || 'Re-write Rules' );
							html += '</button>';
							html += '<span id="up-rewrite-status" style="margin-left: 10px; font-size: 13px;"></span>';
							html += '</div>';
						}

						// LiteSpeed guidance if applicable.
						if ( d.litespeed_guidance && d.litespeed_guidance.length ) {
							html += '<div style="margin-top: 12px; padding: 12px 14px; background: var(--up-warning-light, #fef9e7); border: 1px solid var(--up-warning, #f0b429); border-radius: 6px;">';
							html += '<p style="font-size: 13px; font-weight: 600; margin: 0 0 8px;"><span class="dashicons dashicons-warning" style="color: var(--up-warning); font-size: 16px; width: 16px; height: 16px; margin-right: 4px;"></span>LiteSpeed Troubleshooting</p>';
							html += '<ol style="margin: 0; padding-left: 20px; font-size: 13px; line-height: 1.6;">';
							for ( var g = 0; g < d.litespeed_guidance.length; g++ ) {
								html += '<li style="margin-bottom: 4px;">' + self.escHtml( d.litespeed_guidance[ g ] ) + '</li>';
							}
							html += '</ol>';
							html += '</div>';
						}

						// Nginx snippet if applicable.
						if ( d.nginx_snippet ) {
							html += '<div style="margin-top: 12px;">';
							html += '<p style="font-size: 13px; font-weight: 500; margin: 0 0 6px;">Add this to your Nginx server block:</p>';
							html += '<pre style="background: var(--up-gray-800); color: #e5e7eb; padding: 12px; border-radius: 6px; font-size: 12px; overflow-x: auto; white-space: pre;">' + self.escHtml( d.nginx_snippet ) + '</pre>';
							html += '</div>';
						}

						$results.html( html );
					},
					error: function() {
						$results.html( '<p style="color: var(--up-danger);">' + upAdmin.i18n.network_error + '</p>' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).html( label );
					}
				});
			});

			// Re-write .htaccess rules button (shown inside verify results).
			$( document ).on( 'click', '#up-rewrite-htaccess-rules', function() {
				var $rwBtn  = $( this );
				var $status = $( '#up-rewrite-status' );
				var rwLabel = $rwBtn.html();

				$rwBtn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + ( upAdmin.i18n.updating || 'Updating...' ) );
				$status.html( '' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_rewrite_htaccess_rules',
						nonce: upAdmin.nonce
					},
					timeout: 15000,
					success: function( response ) {
						if ( response.success ) {
							$status.html( '<span style="color: var(--up-success);">' + self.escHtml( response.data.message ) + '</span>' );
							// Auto-trigger re-verify after a short delay.
							setTimeout( function() {
								$( '#up-verify-cache-headers' ).trigger( 'click' );
							}, 1000 );
						} else {
							$status.html( '<span style="color: var(--up-danger);">' + self.escHtml( response.data.message || 'Error.' ) + '</span>' );
						}
					},
					error: function() {
						$status.html( '<span style="color: var(--up-danger);">' + upAdmin.i18n.network_error + '</span>' );
					},
					complete: function() {
						$rwBtn.prop( 'disabled', false ).html( rwLabel );
					}
				});
			});
		},

		/**
		 * Bind clear local fonts button.
		 */
		bindClearFonts: function() {
			var self = this;

			$( document ).on( 'click', '#up-clear-fonts', function() {
				var $btn  = $( this );
				var label = $btn.text();

				if ( ! confirm( upAdmin.i18n.confirm_clear_fonts ) ) {
					return;
				}

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + upAdmin.i18n.clearing_fonts );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_clear_local_fonts',
						nonce: upAdmin.nonce
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( response.data.message, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});
		},

		/**
		 * Bind Script Manager metabox AJAX scan.
		 */
		bindScriptManager: function() {
			var self = this;

			$( document ).on( 'click', '#up-scan-assets', function() {
				var $btn       = $( this );
				var label      = $btn.text();
				var postId     = $btn.data( 'post-id' );
				var $container = $( '#up-script-manager-results' );
				var $hint      = $( '#up-scan-hint' );

				$btn.prop( 'disabled', true ).html( '<span class="spinner is-active" style="float:none;margin:0 4px 0 0;"></span> ' + upAdmin.i18n.scanning );
				$hint.show();
				$container.empty();

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					timeout: 35000,
					data: {
						action: 'up_scan_assets',
						nonce: upAdmin.nonce,
						post_id: postId
					},
					success: function( response ) {
						if ( response.success ) {
							self.renderAssetList( $container, response.data );
						} else {
							$container.html( '<p style="color:#b91c1c;">' + ( response.data.message || upAdmin.i18n.error ) + '</p>' );
						}
					},
					error: function() {
						$container.html( '<p style="color:#b91c1c;">' + upAdmin.i18n.network_error + '</p>' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
						$hint.hide();
					}
				});
			});
		},

		/**
		 * Render scanned assets as grouped checklists.
		 *
		 * @param {jQuery} $container Target container element.
		 * @param {Object} data       Response data with scripts and styles arrays.
		 */
		renderAssetList: function( $container, data ) {
			var self = this;
			var html = '';
			var types = [
				{ key: 'scripts', label: 'Scripts' },
				{ key: 'styles',  label: 'Styles' }
			];

			$.each( types, function( _, type ) {
				var items = data[ type.key ];
				if ( ! items || ! items.length ) {
					return;
				}

				// Group by source.
				var groups = {};
				$.each( items, function( _, item ) {
					var source = item.source || 'Unknown';
					if ( ! groups[ source ] ) {
						groups[ source ] = [];
					}
					groups[ source ].push( item );
				});

				var groupCount = Object.keys( groups ).length;
				html += '<h4 style="margin: 16px 0 8px; padding: 6px 0; font-size: 13px; text-transform: uppercase; color: #6b7280; border-bottom: 1px solid #e5e7eb;">';
				html += type.label + ' <span style="font-weight: 400; font-size: 12px;">(' + items.length + ' from ' + groupCount + ' sources)</span></h4>';

				$.each( groups, function( source, assets ) {
					html += '<div class="up-asset-group" style="margin-bottom: 14px; padding: 8px 10px; background: #f9fafb; border-radius: 4px;">';
					html += '<p style="margin: 0 0 6px; font-weight: 600; font-size: 12px; color: #374151;">' + self.escHtml( source ) + ' <span style="font-weight: 400; color: #9ca3af;">(' + assets.length + ')</span></p>';

					$.each( assets, function( _, asset ) {
						var checked   = asset.disabled ? ' checked' : '';
						var inputName = type.key === 'scripts' ? 'up_disabled_scripts[]' : 'up_disabled_styles[]';
						var labelStyle = asset.disabled ? 'color: #b91c1c;' : 'color: #4b5563;';
						html += '<label style="display: flex; align-items: flex-start; gap: 6px; padding: 3px 0; font-size: 12px; ' + labelStyle + ' cursor: pointer;">';
						html += '<input type="checkbox" name="' + inputName + '" value="' + self.escHtml( asset.handle ) + '"' + checked + ' style="margin-top: 2px;">';
						html += '<span><code style="font-size: 11px; background: #e5e7eb; padding: 1px 4px; border-radius: 2px;">' + self.escHtml( asset.handle ) + '</code>';
						if ( asset.src ) {
							html += '<br><span style="color: #9ca3af; font-size: 10px; word-break: break-all;">' + self.escHtml( asset.src ) + '</span>';
						}
						html += '</span></label>';
					});

					html += '</div>';
				});
			});

			if ( ! html ) {
				html = '<p>' + upAdmin.i18n.no_assets + '</p>';
			}

			$container.html( html );
		},

		/**
		 * Escape HTML entities.
		 *
		 * @param {string} str Raw string.
		 * @return {string} Escaped string.
		 */
		escHtml: function( str ) {
			if ( ! str ) return '';
			return String( str ).replace( /&/g, '&amp;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' ).replace( /"/g, '&quot;' );
		},

		/**
		 * Bind Speed Test tool.
		 */
		bindSpeedTest: function() {
			var self = this;

			$( document ).on( 'click', '#up-run-speed-test', function() {
				var $btn       = $( this );
				var label      = $btn.text();
				var url        = $( '#up-speed-test-url' ).val();
				var strategy   = $( '#up-strategy-toggle .up-strategy-btn--active' ).data( 'strategy' ) || 'mobile';
				var mode       = $( '#up-test-mode-toggle .up-strategy-btn--active' ).data( 'mode' ) || 'psi';
				var $container = $( '#up-speed-test-results' );

				if ( ! url ) {
					self.showToast( upAdmin.i18n.enter_url, 'error' );
					return;
				}

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + upAdmin.i18n.testing );

				if ( mode === 'quick' ) {
					$container.html( '<p style="color: var(--up-gray-500); text-align: center; padding: 20px;">' + upAdmin.i18n.quick_testing_hint + '</p>' );
					self.runQuickTest( url, function( data ) {
						self.renderQuickTestResults( $container, data );
						// Save Quick Test result to DB.
						self.saveQuickTestReport( url, data );
						$btn.prop( 'disabled', false ).text( label );
					}, function( error ) {
						$container.html( '<p style="color: var(--up-danger); text-align: center; padding: 20px;">' + self.escHtml( error ) + '</p>' );
						$btn.prop( 'disabled', false ).text( label );
					});
					return;
				}

				$container.html( '<p style="color: var(--up-gray-500); text-align: center; padding: 20px;">' + upAdmin.i18n.testing_hint + '</p>' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_run_speed_test',
						nonce: upAdmin.nonce,
						url: url,
						strategy: strategy
					},
					timeout: 90000,
					success: function( response ) {
						if ( response.success ) {
							self.renderSpeedTestResultsFull( $container, response.data );
							// Refresh saved reports list.
							if ( $( '#up-speed-reports-list' ).length ) {
								self.loadSpeedReports();
							}
						} else {
							$container.html( '<p style="color: var(--up-danger); text-align: center; padding: 20px;">' + self.escHtml( response.data.message || upAdmin.i18n.error ) + '</p>' );
						}
					},
					error: function() {
						$container.html( '<p style="color: var(--up-danger); text-align: center; padding: 20px;">' + upAdmin.i18n.network_error + '</p>' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});

			// Test mode toggle.
			$( document ).on( 'click', '#up-test-mode-toggle .up-strategy-btn', function() {
				$( '#up-test-mode-toggle .up-strategy-btn' ).removeClass( 'up-strategy-btn--active' );
				$( this ).addClass( 'up-strategy-btn--active' );

				// Hide strategy toggle for Quick Test mode (runs from real browser).
				var mode = $( this ).data( 'mode' );
				if ( mode === 'quick' ) {
					$( '#up-strategy-toggle' ).hide();
				} else {
					$( '#up-strategy-toggle' ).show();
				}
			});

			// Strategy toggle.
			$( document ).on( 'click', '#up-strategy-toggle .up-strategy-btn', function() {
				$( '#up-strategy-toggle .up-strategy-btn' ).removeClass( 'up-strategy-btn--active' );
				$( this ).addClass( 'up-strategy-btn--active' );
			});

			// Inline AI Analyze button inside speed test results.
			$( document ).on( 'click', '.up-inline-ai-analyze', function() {
				var $btn      = $( this );
				var reportId  = $btn.data( 'report-id' );
				var label     = $btn.html();
				var $results  = $btn.closest( '.up-speed-report' ).find( '.up-inline-ai-results' );

				if ( ! $results.length ) {
					$results = $btn.parent().next( '.up-inline-ai-results' );
				}

				if ( ! reportId ) {
					self.showToast( upAdmin.i18n.ai_select_report || 'Report not saved yet.', 'error' );
					return;
				}

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + ( upAdmin.i18n.ai_analyzing || 'Analyzing...' ) );
				$results.html( '<p style="color: var(--up-gray-500); text-align: center; padding: 20px;">' + ( upAdmin.i18n.ai_scan_hint || 'Analyzing with AI. This may take up to 60 seconds...' ) + '</p>' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_ai_analyze_speed_test',
						nonce: upAdmin.nonce,
						report_id: reportId
					},
					timeout: 120000,
					success: function( response ) {
						if ( response.success ) {
							$results.html( self.renderAiReport( response.data ) );
							// Refresh AI reports list if on speed test page.
							if ( $( '#up-ai-reports-list' ).length ) {
								self.loadAiReports();
							}
						} else {
							$results.html( '<p style="color: var(--up-danger); padding: 12px;">' + self.escHtml( response.data.message || upAdmin.i18n.error ) + '</p>' );
						}
					},
					error: function() {
						$results.html( '<p style="color: var(--up-danger); padding: 12px;">' + upAdmin.i18n.network_error + '</p>' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).html( label );
					}
				});
			});
		},

		/**
		 * Run a browser-based Quick Test using Performance APIs.
		 *
		 * Opens the target URL in a hidden iframe and collects Navigation
		 * Timing, paint timing, and resource loading metrics.
		 *
		 * @param {string}   url       The URL to test.
		 * @param {Function} onSuccess Callback with results object.
		 * @param {Function} onError   Callback with error string.
		 */
		runQuickTest: function( url, onSuccess, onError ) {
			var self     = this;
			var timeout  = 30000;
			var timer    = null;
			var done     = false;

			// Create a hidden iframe.
			var iframe = document.createElement( 'iframe' );
			iframe.style.cssText = 'position:absolute;width:1px;height:1px;left:-9999px;top:-9999px;opacity:0;pointer-events:none;';
			iframe.setAttribute( 'sandbox', 'allow-scripts allow-same-origin' );
			document.body.appendChild( iframe );

			function cleanup() {
				if ( timer ) clearTimeout( timer );
				if ( iframe && iframe.parentNode ) {
					iframe.parentNode.removeChild( iframe );
				}
			}

			function finish( data ) {
				if ( done ) return;
				done = true;
				cleanup();
				onSuccess( data );
			}

			function fail( msg ) {
				if ( done ) return;
				done = true;
				cleanup();
				onError( msg );
			}

			// Timeout fallback.
			timer = setTimeout( function() {
				fail( 'Test timed out after ' + ( timeout / 1000 ) + ' seconds. The page may be too slow to load or blocking iframe embedding.' );
			}, timeout );

			// Check if same-origin (we can only access performance APIs for same-origin pages).
			var pageOrigin = window.location.origin;
			var testOrigin;
			try {
				testOrigin = new URL( url ).origin;
			} catch ( e ) {
				fail( 'Invalid URL.' );
				return;
			}

			if ( testOrigin !== pageOrigin ) {
				// Cross-origin: we can't access iframe performance API.
				// Fall back to a fetch-based test (measure TTFB, download time, page size).
				self.runQuickTestFetch( url, finish, fail );
				return;
			}

			iframe.onload = function() {
				// Give the page a moment to finish rendering.
				setTimeout( function() {
					try {
						var iframeWin  = iframe.contentWindow;
						var iframePerf = iframeWin.performance;

						if ( ! iframePerf || ! iframePerf.timing ) {
							fail( 'Performance API not available in the loaded page.' );
							return;
						}

						var timing = iframePerf.timing;
						var navStart = timing.navigationStart;

						// Navigation Timing metrics.
						var ttfb       = timing.responseStart - navStart;
						var domReady   = timing.domContentLoadedEventEnd - navStart;
						var loadTime   = timing.loadEventEnd - navStart;
						var dnsLookup  = timing.domainLookupEnd - timing.domainLookupStart;
						var tcpConnect = timing.connectEnd - timing.connectStart;
						var sslTime    = timing.secureConnectionStart > 0 ? ( timing.connectEnd - timing.secureConnectionStart ) : 0;
						var serverTime = timing.responseEnd - timing.requestStart;
						var domParse   = timing.domInteractive - timing.responseEnd;
						var redirect   = timing.redirectEnd - timing.redirectStart;

						// Paint timing.
						var fcp = null;
						var paintEntries = iframePerf.getEntriesByType ? iframePerf.getEntriesByType( 'paint' ) : [];
						for ( var p = 0; p < paintEntries.length; p++ ) {
							if ( paintEntries[ p ].name === 'first-contentful-paint' ) {
								fcp = Math.round( paintEntries[ p ].startTime );
							}
						}

						// Resource summary.
						var resources = iframePerf.getEntriesByType ? iframePerf.getEntriesByType( 'resource' ) : [];
						var totalSize     = 0;
						var resourceCount = resources.length;
						var resourceBreakdown = { script: 0, css: 0, img: 0, font: 0, other: 0 };
						var slowestResources  = [];

						for ( var r = 0; r < resources.length; r++ ) {
							var res = resources[ r ];
							var transferSize = res.transferSize || res.encodedBodySize || 0;
							totalSize += transferSize;

							var type = res.initiatorType || 'other';
							if ( type === 'script' ) resourceBreakdown.script += transferSize;
							else if ( type === 'link' || type === 'css' ) resourceBreakdown.css += transferSize;
							else if ( type === 'img' ) resourceBreakdown.img += transferSize;
							else if ( type === 'font' || ( res.name && /\.(woff2?|ttf|otf|eot)/.test( res.name ) ) ) resourceBreakdown.font += transferSize;
							else resourceBreakdown.other += transferSize;

							slowestResources.push({
								name: res.name,
								duration: Math.round( res.duration ),
								size: transferSize,
								type: type
							});
						}

						// Sort by duration descending, take top 5.
						slowestResources.sort( function( a, b ) { return b.duration - a.duration; } );
						slowestResources = slowestResources.slice( 0, 5 );

						// Calculate a rough performance score (0-100).
						var perfScore = 100;
						// Penalize based on FCP.
						if ( fcp !== null ) {
							if ( fcp > 4000 ) perfScore -= 40;
							else if ( fcp > 2500 ) perfScore -= 25;
							else if ( fcp > 1800 ) perfScore -= 10;
						}
						// Penalize based on load time.
						if ( loadTime > 6000 ) perfScore -= 30;
						else if ( loadTime > 3000 ) perfScore -= 15;
						else if ( loadTime > 1500 ) perfScore -= 5;
						// Penalize based on TTFB.
						if ( ttfb > 1800 ) perfScore -= 20;
						else if ( ttfb > 800 ) perfScore -= 10;
						else if ( ttfb > 400 ) perfScore -= 3;
						// Penalize for too many resources.
						if ( resourceCount > 80 ) perfScore -= 10;
						else if ( resourceCount > 40 ) perfScore -= 5;

						perfScore = Math.max( 0, Math.min( 100, perfScore ) );

						finish({
							score: perfScore,
							url: url,
							timing: {
								ttfb:       ttfb,
								fcp:        fcp,
								dom_ready:  domReady,
								load_time:  loadTime,
								dns:        dnsLookup,
								tcp:        tcpConnect,
								ssl:        sslTime,
								server:     serverTime,
								dom_parse:  domParse,
								redirect:   redirect
							},
							resources: {
								count:     resourceCount,
								total_size: totalSize,
								breakdown: resourceBreakdown,
								slowest:   slowestResources
							}
						});
					} catch ( e ) {
						fail( 'Could not read performance data: ' + e.message );
					}
				}, 2000 );
			};

			iframe.onerror = function() {
				fail( 'Failed to load the page. It may be blocking iframe embedding (X-Frame-Options / CSP).' );
			};

			iframe.src = url;
		},

		/**
		 * Run a fetch-based Quick Test for cross-origin URLs.
		 *
		 * Measures TTFB, download time, and page size via fetch().
		 *
		 * @param {string}   url       URL to test.
		 * @param {Function} onSuccess Callback with results.
		 * @param {Function} onError   Callback with error string.
		 */
		runQuickTestFetch: function( url, onSuccess, onError ) {
			var startTime = performance.now();

			fetch( url, { mode: 'cors', cache: 'no-store' } )
				.then( function( response ) {
					var ttfb = Math.round( performance.now() - startTime );
					return response.text().then( function( html ) {
						var loadTime = Math.round( performance.now() - startTime );
						var pageSize = new Blob( [ html ] ).size;

						// Count resources by parsing HTML.
						var scriptCount = ( html.match( /<script[^>]+src=/gi ) || [] ).length;
						var cssCount    = ( html.match( /<link[^>]+stylesheet/gi ) || [] ).length;
						var imgCount    = ( html.match( /<img[^>]+src=/gi ) || [] ).length;
						var totalResources = scriptCount + cssCount + imgCount;

						var perfScore = 100;
						if ( ttfb > 1800 ) perfScore -= 30;
						else if ( ttfb > 800 ) perfScore -= 15;
						else if ( ttfb > 400 ) perfScore -= 5;
						if ( loadTime > 5000 ) perfScore -= 25;
						else if ( loadTime > 2000 ) perfScore -= 10;
						if ( pageSize > 500000 ) perfScore -= 15;
						else if ( pageSize > 200000 ) perfScore -= 5;
						if ( totalResources > 50 ) perfScore -= 10;
						else if ( totalResources > 30 ) perfScore -= 5;

						perfScore = Math.max( 0, Math.min( 100, perfScore ) );

						onSuccess({
							score: perfScore,
							url: url,
							cross_origin: true,
							timing: {
								ttfb:      ttfb,
								fcp:       null,
								dom_ready: null,
								load_time: loadTime,
								dns:       null,
								tcp:       null,
								ssl:       null,
								server:    null,
								dom_parse: null,
								redirect:  null
							},
							resources: {
								count: totalResources,
								total_size: pageSize,
								breakdown: {
									script: scriptCount,
									css:    cssCount,
									img:    imgCount,
									font:   0,
									other:  0
								},
								slowest: []
							},
							html_stats: {
								scripts:    scriptCount,
								stylesheets: cssCount,
								images:     imgCount,
								page_size:  pageSize
							}
						});
					});
				})
				.catch( function( err ) {
					onError( 'Failed to fetch the URL: ' + err.message + '. Cross-origin requests may be blocked by CORS.' );
				});
		},

		/**
		 * Render Quick Test browser-based results.
		 *
		 * @param {jQuery} $container Target container.
		 * @param {Object} data       Quick test results.
		 */
		renderQuickTestResults: function( $container, data ) {
			var self  = this;
			var score = data.score || 0;
			var t     = data.timing || {};
			var res   = data.resources || {};

			var html = '<div class="up-speed-report">';

			// Badge.
			html += '<div class="up-speed-report__strategy up-speed-report__strategy--quick">';
			html += '<span class="dashicons dashicons-performance"></span> Quick Test (Browser)';
			html += '</div>';

			if ( data.cross_origin ) {
				html += '<div class="up-speed-notice">';
				html += '<span class="dashicons dashicons-info-outline"></span> ';
				html += 'Cross-origin URL detected. Only fetch-based metrics are available. For full metrics, test a page on this WordPress site.';
				html += '</div>';
			}

			// Score gauge (main).
			html += '<div class="up-speed-categories">';
			html += '<div class="up-speed-category up-speed-category--main">';
			html += '<div class="up-speed-category__gauge">';
			html += self.buildGauge( score, 120, 52, 8, 28 );
			html += '</div>';
			html += '<span class="up-speed-category__label">Performance</span>';
			html += '</div>';
			html += '</div>';

			// Timing Metrics.
			html += '<div class="up-speed-section">';
			html += '<h3 class="up-speed-section__title">Timing Metrics</h3>';
			html += '<div class="up-speed-cwv">';

			var timingDefs = [
				{ key: 'ttfb',      label: 'Time to First Byte',   abbr: 'TTFB', good: 400, poor: 1800 },
				{ key: 'fcp',       label: 'First Contentful Paint', abbr: 'FCP', good: 1800, poor: 3000 },
				{ key: 'dom_ready', label: 'DOM Content Loaded',   abbr: 'DCL',  good: 1500, poor: 3500 },
				{ key: 'load_time', label: 'Full Page Load',       abbr: 'Load', good: 2500, poor: 6000 },
				{ key: 'server',    label: 'Server Response',      abbr: 'Srv',  good: 200,  poor: 600 },
				{ key: 'dom_parse', label: 'DOM Parsing',          abbr: 'DOM',  good: 500,  poor: 1500 }
			];

			for ( var i = 0; i < timingDefs.length; i++ ) {
				var td    = timingDefs[ i ];
				var val   = t[ td.key ];
				var display = val !== null && val !== undefined ? self.formatMs( val ) : '—';
				var dotClass = 'up-speed-cwv__dot';
				var color = '#6B7280';

				if ( val !== null && val !== undefined ) {
					if ( val <= td.good ) {
						dotClass += ' up-speed-cwv__dot--good';
						color = '#059669';
					} else if ( val <= td.poor ) {
						dotClass += ' up-speed-cwv__dot--warning';
						color = '#D97706';
					} else {
						dotClass += ' up-speed-cwv__dot--poor';
						color = '#DC2626';
					}
				}

				html += '<div class="up-speed-cwv__item">';
				html += '<div class="up-speed-cwv__header">';
				html += '<span class="' + dotClass + '"></span>';
				html += '<span class="up-speed-cwv__label">' + td.label + '</span>';
				html += '<span class="up-speed-cwv__abbr">' + td.abbr + '</span>';
				html += '</div>';
				html += '<div class="up-speed-cwv__value" style="color:' + color + '">' + display + '</div>';
				html += '</div>';
			}

			html += '</div>';
			html += '</div>';

			// Connection Breakdown (only for same-origin).
			if ( ! data.cross_origin && ( t.dns || t.tcp || t.ssl || t.redirect ) ) {
				html += '<div class="up-speed-section">';
				html += '<h3 class="up-speed-section__title">Connection Breakdown</h3>';
				html += '<div class="up-speed-waterfall">';

				var connDefs = [
					{ label: 'Redirect',   value: t.redirect, color: '#8B5CF6' },
					{ label: 'DNS Lookup', value: t.dns,      color: '#06B6D4' },
					{ label: 'TCP Connect', value: t.tcp,     color: '#F59E0B' },
					{ label: 'SSL/TLS',    value: t.ssl,      color: '#10B981' },
					{ label: 'Server Wait', value: ( t.ttfb - ( t.dns || 0 ) - ( t.tcp || 0 ) ), color: '#EF4444' }
				];

				var maxConn = 1;
				for ( var c = 0; c < connDefs.length; c++ ) {
					if ( connDefs[ c ].value > maxConn ) maxConn = connDefs[ c ].value;
				}

				for ( var c2 = 0; c2 < connDefs.length; c2++ ) {
					var cd = connDefs[ c2 ];
					var cdVal = cd.value || 0;
					var pct   = Math.max( 2, ( cdVal / maxConn ) * 100 );

					html += '<div class="up-speed-waterfall__row">';
					html += '<span class="up-speed-waterfall__label">' + cd.label + '</span>';
					html += '<div class="up-speed-waterfall__track">';
					html += '<div class="up-speed-waterfall__bar" style="width:' + pct + '%;background:' + cd.color + '"></div>';
					html += '</div>';
					html += '<span class="up-speed-waterfall__time">' + self.formatMs( cdVal ) + '</span>';
					html += '</div>';
				}

				html += '</div>';
				html += '</div>';
			}

			// Resource Summary.
			html += '<div class="up-speed-section">';
			html += '<h3 class="up-speed-section__title">Resources';
			html += '<span class="up-speed-section__count">' + ( res.count || 0 ) + ' requests &middot; ' + self.formatBytes( res.total_size || 0 ) + '</span>';
			html += '</h3>';

			var breakdown = res.breakdown || {};
			html += '<div class="up-speed-resource-grid">';

			var resDefs = [
				{ label: 'Scripts',     key: 'script', icon: 'dashicons-media-code',    color: '#F59E0B' },
				{ label: 'Stylesheets', key: 'css',    icon: 'dashicons-admin-customizer', color: '#8B5CF6' },
				{ label: 'Images',      key: 'img',    icon: 'dashicons-format-image',  color: '#06B6D4' },
				{ label: 'Fonts',       key: 'font',   icon: 'dashicons-editor-textcolor', color: '#EC4899' }
			];

			for ( var rd = 0; rd < resDefs.length; rd++ ) {
				var r = resDefs[ rd ];
				var rVal = breakdown[ r.key ] || 0;
				// For cross-origin, breakdown values are counts, not sizes.
				var rDisplay = data.cross_origin ? ( rVal + ' files' ) : self.formatBytes( rVal );

				html += '<div class="up-speed-resource-card">';
				html += '<span class="dashicons ' + r.icon + '" style="color:' + r.color + '"></span>';
				html += '<div>';
				html += '<div class="up-speed-resource-card__label">' + r.label + '</div>';
				html += '<div class="up-speed-resource-card__value">' + rDisplay + '</div>';
				html += '</div>';
				html += '</div>';
			}

			html += '</div>';
			html += '</div>';

			// Slowest Resources (same-origin only).
			var slowest = res.slowest || [];
			if ( slowest.length > 0 ) {
				html += '<div class="up-speed-section">';
				html += '<h3 class="up-speed-section__title">Slowest Resources';
				html += '<span class="up-speed-section__count">Top ' + slowest.length + '</span>';
				html += '</h3>';
				html += '<div class="up-speed-opps">';

				for ( var s = 0; s < slowest.length; s++ ) {
					var sr = slowest[ s ];
					var srName = sr.name || '';
					// Show just the filename from the full URL.
					try {
						var pathParts = new URL( srName ).pathname.split( '/' );
						srName = pathParts[ pathParts.length - 1 ] || srName;
					} catch ( e ) {
						srName = srName.split( '/' ).pop() || srName;
					}

					var srDotClass = 'up-speed-cwv__dot';
					if ( sr.duration > 1000 ) srDotClass += ' up-speed-cwv__dot--poor';
					else if ( sr.duration > 300 ) srDotClass += ' up-speed-cwv__dot--warning';
					else srDotClass += ' up-speed-cwv__dot--good';

					html += '<div class="up-speed-opp">';
					html += '<span class="' + srDotClass + '"></span>';
					html += '<div class="up-speed-opp__info">';
					html += '<span class="up-speed-opp__title" title="' + self.escHtml( sr.name ) + '">' + self.escHtml( srName ) + '</span>';
					html += '<span class="up-speed-opp__savings">' + self.formatMs( sr.duration );
					if ( sr.size > 0 ) html += ' &middot; ' + self.formatBytes( sr.size );
					html += '</span>';
					html += '</div>';
					html += '</div>';
				}

				html += '</div>';
				html += '</div>';
			}

			// Fix Suggestions (client-side analysis of Quick Test data).
			var qtFixes = self.buildQuickTestFixSuggestions( data );
			if ( qtFixes.length > 0 ) {
				html += self.renderFixSuggestions( qtFixes );
			}

			// Analyze with AI button (report_id populated after async save for new tests).
			var qtReportId = data.report_id || '';
			var qtDisabled = qtReportId ? '' : ' disabled';
			html += '<div class="up-speed-ai-analyze" style="text-align: center; padding: 16px 0; border-top: 1px solid var(--up-gray-100);">';
			html += '<button type="button" class="up-btn up-btn--primary up-inline-ai-analyze" data-report-id="' + qtReportId + '"' + qtDisabled + '>';
			html += '<span class="dashicons dashicons-lightbulb" style="font-size:14px;width:14px;height:14px;margin-right:4px;"></span>';
			html += 'Analyze with AI';
			html += '</button>';
			html += '</div>';
			html += '<div class="up-inline-ai-results"></div>';

			html += '</div>';
			$container.html( html );
		},

		/**
		 * Format milliseconds to a display string.
		 *
		 * @param  {number} ms Milliseconds.
		 * @return {string} Formatted string.
		 */
		formatMs: function( ms ) {
			if ( ms >= 1000 ) {
				return ( ms / 1000 ).toFixed( 1 ) + ' s';
			}
			return Math.round( ms ) + ' ms';
		},

		/**
		 * Format bytes to human-readable string.
		 *
		 * @param  {number} bytes Byte count.
		 * @return {string} Formatted string.
		 */
		formatBytes: function( bytes ) {
			if ( bytes >= 1048576 ) return ( bytes / 1048576 ).toFixed( 1 ) + ' MB';
			if ( bytes >= 1024 ) return Math.round( bytes / 1024 ) + ' KB';
			return bytes + ' B';
		},

		/**
		 * Save a Quick Test result to the database.
		 *
		 * @param {string} url  Tested URL.
		 * @param {Object} data Quick test result data.
		 */
		saveQuickTestReport: function( url, data ) {
			var self = this;

			$.ajax({
				url: upAdmin.ajax_url,
				type: 'POST',
				data: {
					action: 'up_save_quick_test',
					nonce: upAdmin.nonce,
					url: url,
					score: data.score || 0,
					data: JSON.stringify( data )
				},
				success: function( response ) {
					if ( response.success ) {
						if ( $( '#up-speed-reports-list' ).length ) {
							self.loadSpeedReports();
						}
						// Enable the inline AI analyze button with the saved report ID.
						if ( response.data.report_id ) {
							var $aiBtn = $( '#up-speed-test-results .up-inline-ai-analyze[data-report-id=""]' );
							if ( $aiBtn.length ) {
								$aiBtn.attr( 'data-report-id', response.data.report_id ).prop( 'disabled', false );
							}
						}
					}
				}
			});
		},

		/**
		 * Get color for a Lighthouse score.
		 *
		 * @param {number} score 0-100 or 0-1 score.
		 * @param {boolean} normalized If true, score is 0-1 instead of 0-100.
		 * @return {string} Hex color.
		 */
		scoreColor: function( score, normalized ) {
			if ( normalized ) score = Math.round( score * 100 );
			if ( score >= 90 ) return '#059669';
			if ( score >= 50 ) return '#D97706';
			return '#DC2626';
		},

		/**
		 * Build an SVG gauge for a score.
		 *
		 * @param {number} score  0-100 score.
		 * @param {number} size   SVG size in px.
		 * @param {number} radius Circle radius.
		 * @param {number} stroke Stroke width.
		 * @param {number} fontSize Font size for score text.
		 * @return {string} SVG markup.
		 */
		buildGauge: function( score, size, radius, stroke, fontSize ) {
			var color = this.scoreColor( score );
			var center = size / 2;
			var circumference = 2 * Math.PI * radius;
			var offset = circumference - ( score / 100 ) * circumference;

			return '<svg viewBox="0 0 ' + size + ' ' + size + '" width="' + size + '" height="' + size + '">' +
				'<circle cx="' + center + '" cy="' + center + '" r="' + radius + '" fill="none" stroke="#E5E7EB" stroke-width="' + stroke + '"/>' +
				'<circle cx="' + center + '" cy="' + center + '" r="' + radius + '" fill="none" stroke="' + color + '" stroke-width="' + stroke + '" stroke-linecap="round" ' +
				'stroke-dasharray="' + circumference + '" stroke-dashoffset="' + offset + '" transform="rotate(-90 ' + center + ' ' + center + ')"/>' +
				'<text x="' + center + '" y="' + ( center + fontSize * 0.35 ) + '" text-anchor="middle" font-size="' + fontSize + '" font-weight="700" fill="' + color + '">' + score + '</text>' +
				'</svg>';
		},

		/**
		 * Render comprehensive Speed Test results.
		 *
		 * @param {jQuery} $container Target container element.
		 * @param {Object} data       Response data with scores, metrics, opportunities.
		 */
		renderSpeedTestResults: function( $container, data ) {
			var self   = this;
			var score  = data.score || 0;
			var scores = data.scores || {};
			var strategy = data.strategy || 'mobile';

			var html = '<div class="up-speed-report">';

			// === Strategy badge ===
			var strategyIcon = strategy === 'desktop' ? 'dashicons-desktop' : 'dashicons-smartphone';
			var strategyLabel = strategy === 'desktop' ? 'Desktop' : 'Mobile';
			html += '<div class="up-speed-report__strategy">';
			html += '<span class="dashicons ' + strategyIcon + '"></span> ' + strategyLabel + ' Report';
			html += '</div>';

			// === Category Scores Row ===
			html += '<div class="up-speed-categories">';
			var catDefs = [
				{ key: 'performance',    label: 'Performance' },
				{ key: 'accessibility',  label: 'Accessibility' },
				{ key: 'best_practices', label: 'Best Practices' },
				{ key: 'seo',            label: 'SEO' }
			];

			for ( var c = 0; c < catDefs.length; c++ ) {
				var cat = catDefs[ c ];
				var catScore = scores[ cat.key ] || 0;
				var isMain = cat.key === 'performance';
				var gaugeSize = isMain ? 120 : 80;
				var gaugeRadius = isMain ? 52 : 34;
				var gaugeStroke = isMain ? 8 : 6;
				var gaugeFontSize = isMain ? 28 : 18;

				html += '<div class="up-speed-category' + ( isMain ? ' up-speed-category--main' : '' ) + '">';
				html += '<div class="up-speed-category__gauge">';
				html += self.buildGauge( catScore, gaugeSize, gaugeRadius, gaugeStroke, gaugeFontSize );
				html += '</div>';
				html += '<span class="up-speed-category__label">' + cat.label + '</span>';
				html += '</div>';
			}
			html += '</div>';

			// === Core Web Vitals ===
			html += '<div class="up-speed-section">';
			html += '<h3 class="up-speed-section__title">Core Web Vitals</h3>';
			html += '<div class="up-speed-cwv">';

			var metrics = data.metrics || {};
			var metricDefs = [
				{ key: 'fcp',  label: 'First Contentful Paint',    abbr: 'FCP' },
				{ key: 'lcp',  label: 'Largest Contentful Paint',  abbr: 'LCP' },
				{ key: 'tbt',  label: 'Total Blocking Time',       abbr: 'TBT' },
				{ key: 'cls',  label: 'Cumulative Layout Shift',   abbr: 'CLS' },
				{ key: 'si',   label: 'Speed Index',               abbr: 'SI' },
				{ key: 'ttfb', label: 'Time to First Byte',        abbr: 'TTFB' }
			];

			for ( var i = 0; i < metricDefs.length; i++ ) {
				var m = metricDefs[ i ];
				var metric = metrics[ m.key ] || {};
				var mValue = ( typeof metric === 'object' ) ? ( metric.value || '—' ) : metric;
				var mScore = ( typeof metric === 'object' ) ? metric.score : null;
				var mColor = mScore !== null ? self.scoreColor( mScore, true ) : '#6B7280';
				var dotClass = 'up-speed-cwv__dot';
				if ( mScore !== null ) {
					if ( mScore >= 0.9 ) dotClass += ' up-speed-cwv__dot--good';
					else if ( mScore >= 0.5 ) dotClass += ' up-speed-cwv__dot--warning';
					else dotClass += ' up-speed-cwv__dot--poor';
				}

				html += '<div class="up-speed-cwv__item">';
				html += '<div class="up-speed-cwv__header">';
				html += '<span class="' + dotClass + '"></span>';
				html += '<span class="up-speed-cwv__label">' + self.escHtml( m.label ) + '</span>';
				html += '<span class="up-speed-cwv__abbr">' + m.abbr + '</span>';
				html += '</div>';
				html += '<div class="up-speed-cwv__value" style="color:' + mColor + '">' + self.escHtml( mValue ) + '</div>';
				html += '</div>';
			}

			html += '</div>';
			html += '</div>';

			// === Opportunities ===
			var opportunities = data.opportunities || [];
			if ( opportunities.length > 0 ) {
				html += '<div class="up-speed-section">';
				html += '<h3 class="up-speed-section__title">Opportunities';
				html += '<span class="up-speed-section__count">' + opportunities.length + ' issue' + ( opportunities.length !== 1 ? 's' : '' ) + '</span>';
				html += '</h3>';
				html += '<div class="up-speed-opps">';

				for ( var o = 0; o < opportunities.length; o++ ) {
					var opp = opportunities[ o ];
					var oppScore = opp.score || 0;
					var oppColor = self.scoreColor( oppScore, true );
					var oppDot = 'up-speed-cwv__dot';
					if ( oppScore >= 0.9 ) oppDot += ' up-speed-cwv__dot--good';
					else if ( oppScore >= 0.5 ) oppDot += ' up-speed-cwv__dot--warning';
					else oppDot += ' up-speed-cwv__dot--poor';

					html += '<div class="up-speed-opp">';
					html += '<span class="' + oppDot + '"></span>';
					html += '<div class="up-speed-opp__info">';
					html += '<span class="up-speed-opp__title">' + self.escHtml( opp.title ) + '</span>';
					if ( opp.savings || opp.savings_size ) {
						html += '<span class="up-speed-opp__savings">';
						if ( opp.savings ) html += opp.savings;
						if ( opp.savings && opp.savings_size ) html += ' &middot; ';
						if ( opp.savings_size ) html += opp.savings_size;
						html += '</span>';
					}
					html += '</div>';
					html += '</div>';
				}

				html += '</div>';
				html += '</div>';
			}

			// === Passed Audits Summary ===
			if ( data.passed_audits ) {
				html += '<div class="up-speed-passed">';
				html += '<span class="dashicons dashicons-yes-alt"></span> ';
				html += data.passed_audits + ' / ' + data.total_audits + ' audits passed';
				html += '</div>';
			}

			html += '</div>';

			$container.html( html );
		},

		/**
		 * Render comprehensive Speed Test results (full PSI report).
		 *
		 * @param {jQuery} $container Target container.
		 * @param {Object} data       Full response data.
		 */
		renderSpeedTestResultsFull: function( $container, data ) {
			var self   = this;
			var score  = data.score || 0;
			var scores = data.scores || {};
			var strategy = data.strategy || 'mobile';

			var html = '<div class="up-speed-report up-speed-report--full">';

			// Strategy badge + report ID.
			var strategyIcon = strategy === 'desktop' ? 'dashicons-desktop' : 'dashicons-smartphone';
			var strategyLabel = strategy === 'desktop' ? 'Desktop' : 'Mobile';
			html += '<div class="up-speed-report__header">';
			html += '<div class="up-speed-report__strategy">';
			html += '<span class="dashicons ' + strategyIcon + '"></span> ' + strategyLabel + ' Report';
			html += '</div>';
			if ( data.report_id ) {
				html += '<span class="up-speed-report__saved">Report #' + data.report_id + ' saved</span>';
			}
			html += '</div>';

			// Category Scores Row.
			html += '<div class="up-speed-categories">';
			var catDefs = [
				{ key: 'performance',    label: 'Performance' },
				{ key: 'accessibility',  label: 'Accessibility' },
				{ key: 'best_practices', label: 'Best Practices' },
				{ key: 'seo',            label: 'SEO' }
			];

			for ( var c = 0; c < catDefs.length; c++ ) {
				var cat = catDefs[ c ];
				var catScore = scores[ cat.key ] || 0;
				var isMain = cat.key === 'performance';
				var gaugeSize = isMain ? 120 : 80;
				var gaugeRadius = isMain ? 52 : 34;
				var gaugeStroke = isMain ? 8 : 6;
				var gaugeFontSize = isMain ? 28 : 18;

				html += '<div class="up-speed-category' + ( isMain ? ' up-speed-category--main' : '' ) + '">';
				html += '<div class="up-speed-category__gauge">';
				html += self.buildGauge( catScore, gaugeSize, gaugeRadius, gaugeStroke, gaugeFontSize );
				html += '</div>';
				html += '<span class="up-speed-category__label">' + cat.label + '</span>';
				html += '</div>';
			}
			html += '</div>';

			// Core Web Vitals.
			html += self.renderCWVSection( data.metrics );

			// Field Data (CrUX).
			if ( data.field_data && data.field_data.metrics && Object.keys( data.field_data.metrics ).length > 0 ) {
				html += self.renderFieldData( data.field_data );
			}

			// Filmstrip.
			if ( data.screenshots && data.screenshots.filmstrip && data.screenshots.filmstrip.length > 0 ) {
				html += self.renderFilmstrip( data.screenshots );
			}

			// Opportunities (expandable).
			var opportunities = data.opportunities || [];
			if ( opportunities.length > 0 ) {
				html += self.renderDetailedOpportunities( opportunities );
			}

			// Diagnostics.
			var diagnostics = data.diagnostics || [];
			if ( diagnostics.length > 0 ) {
				html += self.renderDiagnostics( diagnostics );
			}

			// Accessibility Issues.
			var a11yAudits = data.accessibility_audits || [];
			if ( a11yAudits.length > 0 ) {
				html += self.renderCategoryAudits( 'Accessibility', a11yAudits, 'dashicons-universal-access-alt', scores.accessibility || null );
			}

			// Best Practices Issues.
			var bpAudits = data.best_practices_audits || [];
			if ( bpAudits.length > 0 ) {
				html += self.renderCategoryAudits( 'Best Practices', bpAudits, 'dashicons-awards', scores.best_practices || null );
			}

			// SEO Issues.
			var seoAudits = data.seo_audits || [];
			if ( seoAudits.length > 0 ) {
				html += self.renderCategoryAudits( 'SEO', seoAudits, 'dashicons-search', scores.seo || null );
			}

			// Fix Suggestions.
			var fixes = data.fix_suggestions || [];
			if ( fixes.length > 0 ) {
				html += self.renderFixSuggestions( fixes );
			}

			// Passed Audits.
			if ( data.passed_audits ) {
				html += '<div class="up-speed-passed">';
				html += '<span class="dashicons dashicons-yes-alt"></span> ';
				html += data.passed_audits + ' / ' + data.total_audits + ' audits passed';
				html += '</div>';
			}

			// Analyze with AI button.
			if ( data.report_id ) {
				html += '<div class="up-speed-ai-analyze" style="text-align: center; padding: 16px 0; border-top: 1px solid var(--up-gray-100);">';
				html += '<button type="button" class="up-btn up-btn--primary up-inline-ai-analyze" data-report-id="' + data.report_id + '">';
				html += '<span class="dashicons dashicons-lightbulb" style="font-size:14px;width:14px;height:14px;margin-right:4px;"></span>';
				html += 'Analyze with AI';
				html += '</button>';
				html += '</div>';
				html += '<div class="up-inline-ai-results"></div>';
			}

			html += '</div>';
			$container.html( html );

			// Bind accordions.
			$container.on( 'click', '.up-speed-accordion__header', function() {
				$( this ).closest( '.up-speed-accordion' ).toggleClass( 'up-speed-accordion--open' );
			});
		},

		/**
		 * Render Core Web Vitals section.
		 *
		 * @param  {Object} metrics Metrics data.
		 * @return {string} HTML string.
		 */
		renderCWVSection: function( metrics ) {
			var self = this;
			metrics = metrics || {};

			var html = '<div class="up-speed-section">';
			html += '<h3 class="up-speed-section__title">Core Web Vitals</h3>';
			html += '<div class="up-speed-cwv">';

			var metricDefs = [
				{ key: 'fcp',  label: 'First Contentful Paint',    abbr: 'FCP' },
				{ key: 'lcp',  label: 'Largest Contentful Paint',  abbr: 'LCP' },
				{ key: 'tbt',  label: 'Total Blocking Time',       abbr: 'TBT' },
				{ key: 'cls',  label: 'Cumulative Layout Shift',   abbr: 'CLS' },
				{ key: 'si',   label: 'Speed Index',               abbr: 'SI' },
				{ key: 'ttfb', label: 'Time to First Byte',        abbr: 'TTFB' }
			];

			for ( var i = 0; i < metricDefs.length; i++ ) {
				var m = metricDefs[ i ];
				var metric = metrics[ m.key ] || {};
				var mValue = ( typeof metric === 'object' ) ? ( metric.value || '\u2014' ) : metric;
				var mScore = ( typeof metric === 'object' ) ? metric.score : null;
				var mColor = mScore !== null ? self.scoreColor( mScore, true ) : '#6B7280';
				var dotClass = 'up-speed-cwv__dot';
				if ( mScore !== null ) {
					if ( mScore >= 0.9 ) dotClass += ' up-speed-cwv__dot--good';
					else if ( mScore >= 0.5 ) dotClass += ' up-speed-cwv__dot--warning';
					else dotClass += ' up-speed-cwv__dot--poor';
				}

				html += '<div class="up-speed-cwv__item">';
				html += '<div class="up-speed-cwv__header">';
				html += '<span class="' + dotClass + '"></span>';
				html += '<span class="up-speed-cwv__label">' + self.escHtml( m.label ) + '</span>';
				html += '<span class="up-speed-cwv__abbr">' + m.abbr + '</span>';
				html += '</div>';
				html += '<div class="up-speed-cwv__value" style="color:' + mColor + '">' + self.escHtml( mValue ) + '</div>';
				html += '</div>';
			}

			html += '</div></div>';
			return html;
		},

		/**
		 * Render Chrome UX Report (CrUX) field data with distribution bars.
		 *
		 * @param  {Object} fieldData Field data object.
		 * @return {string} HTML string.
		 */
		renderFieldData: function( fieldData ) {
			var self    = this;
			var metrics = fieldData.metrics || {};
			var keys    = Object.keys( metrics );

			if ( keys.length === 0 ) return '';

			var html = '<div class="up-speed-section">';
			html += '<h3 class="up-speed-section__title">Real-World Data (Chrome UX Report)';
			if ( fieldData.overall_category ) {
				var overallClass = fieldData.overall_category === 'FAST' ? 'good' : ( fieldData.overall_category === 'AVERAGE' ? 'warning' : 'poor' );
				html += '<span class="up-speed-section__count up-speed-section__count--' + overallClass + '">' + fieldData.overall_category + '</span>';
			}
			html += '</h3>';

			var metricNames = {
				fcp: 'First Contentful Paint',
				lcp: 'Largest Contentful Paint',
				inp: 'Interaction to Next Paint',
				cls: 'Cumulative Layout Shift',
				ttfb: 'Time to First Byte'
			};

			for ( var i = 0; i < keys.length; i++ ) {
				var k  = keys[ i ];
				var m  = metrics[ k ];
				var label = metricNames[ k ] || m.label || k.toUpperCase();
				var dists = m.distributions || [];

				html += '<div class="up-field-data__metric">';
				html += '<span class="up-field-data__label">' + self.escHtml( label ) + '</span>';

				if ( dists.length >= 3 ) {
					html += '<div class="up-field-data__bar">';
					html += '<div class="up-field-data__segment up-field-data__segment--good" style="width:' + dists[0].proportion + '%"></div>';
					html += '<div class="up-field-data__segment up-field-data__segment--needs" style="width:' + dists[1].proportion + '%"></div>';
					html += '<div class="up-field-data__segment up-field-data__segment--poor" style="width:' + dists[2].proportion + '%"></div>';
					html += '</div>';
				}

				if ( m.percentile !== null && m.percentile !== undefined ) {
					var pVal = m.percentile;
					if ( k === 'cls' ) {
						pVal = ( pVal / 100 ).toFixed( 2 );
					} else {
						pVal = self.formatMs( pVal );
					}
					var pColor = '#6B7280';
					if ( m.category === 'FAST' ) pColor = '#059669';
					else if ( m.category === 'AVERAGE' ) pColor = '#D97706';
					else if ( m.category === 'SLOW' ) pColor = '#DC2626';
					html += '<span class="up-field-data__p75" style="color:' + pColor + '">' + pVal + '</span>';
				}

				html += '</div>';
			}

			html += '</div>';
			return html;
		},

		/**
		 * Render filmstrip of page load progression.
		 *
		 * @param  {Object} screenshots Screenshots data.
		 * @return {string} HTML string.
		 */
		renderFilmstrip: function( screenshots ) {
			var self     = this;
			var filmstrip = screenshots.filmstrip || [];

			if ( filmstrip.length === 0 ) return '';

			var html = '<div class="up-speed-section">';
			html += '<h3 class="up-speed-section__title">Load Progression</h3>';
			html += '<div class="up-speed-filmstrip">';

			for ( var i = 0; i < filmstrip.length; i++ ) {
				var frame = filmstrip[ i ];
				html += '<div class="up-speed-filmstrip__frame">';
				html += '<img src="' + self.escHtml( frame.data ) + '" alt="' + self.escHtml( String( frame.timing ) ) + 'ms" loading="lazy">';
				html += '<div class="up-speed-filmstrip__time">' + self.formatMs( frame.timing ) + '</div>';
				html += '</div>';
			}

			html += '</div></div>';
			return html;
		},

		/**
		 * Render detailed opportunities with expandable items.
		 *
		 * @param  {Array} opportunities Opportunities array.
		 * @return {string} HTML string.
		 */
		renderDetailedOpportunities: function( opportunities ) {
			var self = this;

			var html = '<div class="up-speed-section">';
			html += '<h3 class="up-speed-section__title">Opportunities';
			html += '<span class="up-speed-section__count">' + opportunities.length + ' issue' + ( opportunities.length !== 1 ? 's' : '' ) + '</span>';
			html += '</h3>';

			for ( var o = 0; o < opportunities.length; o++ ) {
				var opp = opportunities[ o ];
				var hasItems = opp.items && opp.items.length > 0;
				var oppDot = 'up-speed-cwv__dot';
				if ( opp.score >= 0.9 ) oppDot += ' up-speed-cwv__dot--good';
				else if ( opp.score >= 0.5 ) oppDot += ' up-speed-cwv__dot--warning';
				else oppDot += ' up-speed-cwv__dot--poor';

				html += '<div class="up-speed-accordion' + ( hasItems ? '' : ' up-speed-accordion--no-items' ) + '">';
				html += '<div class="up-speed-accordion__header">';
				if ( hasItems ) {
					html += '<span class="up-speed-accordion__chevron dashicons dashicons-arrow-right-alt2"></span>';
				}
				html += '<span class="' + oppDot + '"></span>';
				html += '<span class="up-speed-accordion__title">' + self.escHtml( opp.title ) + '</span>';
				if ( opp.savings || opp.savings_size ) {
					html += '<span class="up-speed-opp__savings">';
					if ( opp.savings ) html += opp.savings;
					if ( opp.savings && opp.savings_size ) html += ' &middot; ';
					if ( opp.savings_size ) html += opp.savings_size;
					html += '</span>';
				}
				html += '</div>';

				if ( hasItems ) {
					html += '<div class="up-speed-accordion__body">';
					html += '<table class="up-speed-items-table">';
					html += '<thead><tr>';

					// Determine columns from first item.
					var cols = [];
					var item0 = opp.items[0];
					if ( item0.url ) cols.push({ key: 'url', label: 'Resource' });
					if ( item0.wastedBytes !== undefined ) cols.push({ key: 'wastedBytes', label: 'Wasted' });
					if ( item0.wastedMs !== undefined ) cols.push({ key: 'wastedMs', label: 'Time Saved' });
					if ( item0.totalBytes !== undefined ) cols.push({ key: 'totalBytes', label: 'Size' });
					if ( item0.element ) cols.push({ key: 'element', label: 'Element' });
					if ( item0.selector ) cols.push({ key: 'selector', label: 'Selector' });

					// Fallback: show any scalar keys.
					if ( cols.length === 0 ) {
						for ( var ck in item0 ) {
							if ( item0.hasOwnProperty( ck ) && typeof item0[ ck ] !== 'object' ) {
								cols.push({ key: ck, label: ck });
							}
						}
					}

					for ( var ci = 0; ci < cols.length; ci++ ) {
						html += '<th>' + self.escHtml( cols[ci].label ) + '</th>';
					}
					html += '</tr></thead><tbody>';

					for ( var ii = 0; ii < opp.items.length; ii++ ) {
						var item = opp.items[ ii ];
						html += '<tr>';
						for ( var cj = 0; cj < cols.length; cj++ ) {
							var val = item[ cols[cj].key ];
							html += '<td>';
							if ( cols[cj].key === 'url' && val ) {
								var shortUrl = val;
								try { shortUrl = new URL( val ).pathname.split( '/' ).pop() || val; } catch( e ) {}
								html += '<span class="up-speed-items-table__url" title="' + self.escHtml( val ) + '">' + self.escHtml( shortUrl ) + '</span>';
							} else if ( cols[cj].key === 'wastedBytes' || cols[cj].key === 'totalBytes' ) {
								html += val !== undefined ? self.formatBytes( val ) : '\u2014';
							} else if ( cols[cj].key === 'wastedMs' ) {
								html += val !== undefined ? self.formatMs( val ) : '\u2014';
							} else {
								html += val !== undefined ? self.escHtml( String( val ) ) : '\u2014';
							}
							html += '</td>';
						}
						html += '</tr>';
					}

					html += '</tbody></table>';
					html += '</div>';
				}

				html += '</div>';
			}

			html += '</div>';
			return html;
		},

		/**
		 * Render diagnostics section.
		 *
		 * @param  {Array} diagnostics Diagnostics array.
		 * @return {string} HTML string.
		 */
		renderDiagnostics: function( diagnostics ) {
			var self = this;

			var html = '<div class="up-speed-section">';
			html += '<h3 class="up-speed-section__title">Diagnostics';
			html += '<span class="up-speed-section__count">' + diagnostics.length + '</span>';
			html += '</h3>';

			for ( var d = 0; d < diagnostics.length; d++ ) {
				var diag = diagnostics[ d ];
				var hasItems = diag.items && diag.items.length > 0;
				var diagDot = 'up-speed-cwv__dot';
				if ( diag.score === null ) diagDot += '';
				else if ( diag.score >= 0.9 ) diagDot += ' up-speed-cwv__dot--good';
				else if ( diag.score >= 0.5 ) diagDot += ' up-speed-cwv__dot--warning';
				else diagDot += ' up-speed-cwv__dot--poor';

				html += '<div class="up-speed-accordion' + ( hasItems ? '' : ' up-speed-accordion--no-items' ) + '">';
				html += '<div class="up-speed-accordion__header">';
				if ( hasItems ) {
					html += '<span class="up-speed-accordion__chevron dashicons dashicons-arrow-right-alt2"></span>';
				}
				html += '<span class="' + diagDot + '"></span>';
				html += '<span class="up-speed-accordion__title">' + self.escHtml( diag.title ) + '</span>';
				if ( diag.displayValue ) {
					html += '<span class="up-speed-accordion__value">' + self.escHtml( diag.displayValue ) + '</span>';
				}
				html += '</div>';

				if ( hasItems ) {
					html += '<div class="up-speed-accordion__body">';
					html += '<table class="up-speed-items-table"><tbody>';

					for ( var di = 0; di < diag.items.length; di++ ) {
						var dItem = diag.items[ di ];
						html += '<tr>';
						for ( var dk in dItem ) {
							if ( ! dItem.hasOwnProperty( dk ) || dk === 'subItems' ) continue;
							var dVal = dItem[ dk ];
							if ( typeof dVal === 'object' ) continue;
							html += '<td>';
							if ( dk === 'url' ) {
								var shortUrl = dVal;
								try { shortUrl = new URL( dVal ).pathname.split( '/' ).pop() || dVal; } catch( e ) {}
								html += '<span class="up-speed-items-table__url" title="' + self.escHtml( dVal ) + '">' + self.escHtml( shortUrl ) + '</span>';
							} else if ( typeof dVal === 'number' && dk.indexOf( 'Bytes' ) !== -1 ) {
								html += self.formatBytes( dVal );
							} else if ( typeof dVal === 'number' && ( dk.indexOf( 'Ms' ) !== -1 || dk === 'duration' || dk === 'blockingTime' || dk === 'startTime' || dk === 'transferSize' ) ) {
								html += typeof dVal === 'number' && dVal > 100 ? self.formatMs( dVal ) : dVal;
							} else {
								html += self.escHtml( String( dVal ) );
							}
							html += '</td>';
						}
						html += '</tr>';
					}

					html += '</tbody></table>';
					html += '</div>';
				}

				html += '</div>';
			}

			html += '</div>';
			return html;
		},

		/**
		 * Render category-specific audits (Accessibility, SEO, Best Practices).
		 *
		 * @param  {string} title   Section title (e.g. "Accessibility Issues").
		 * @param  {Array}  audits  Array of failed audit objects.
		 * @param  {string} icon    Dashicon class for the section.
		 * @param  {number} score   Category score (0-100) for the badge.
		 * @return {string} HTML string.
		 */
		renderCategoryAudits: function( title, audits, icon, score ) {
			var self = this;

			var html = '<div class="up-speed-section">';
			html += '<h3 class="up-speed-section__title">';
			if ( icon ) {
				html += '<span class="dashicons ' + icon + '" style="font-size: 16px; width: 16px; height: 16px; margin-right: 4px; vertical-align: middle;"></span>';
			}
			html += title;
			html += '<span class="up-speed-section__count">' + audits.length + ' issue' + ( audits.length !== 1 ? 's' : '' ) + '</span>';
			if ( typeof score === 'number' ) {
				var scoreColor = score >= 90 ? 'var(--up-success)' : ( score >= 50 ? 'var(--up-warning)' : 'var(--up-danger)' );
				html += '<span style="margin-left: 8px; font-size: 12px; font-weight: 600; color: ' + scoreColor + ';">Score: ' + score + '</span>';
			}
			html += '</h3>';

			for ( var a = 0; a < audits.length; a++ ) {
				var audit = audits[ a ];
				var hasItems = audit.items && audit.items.length > 0;
				var dotClass = 'up-speed-cwv__dot';
				if ( audit.score !== null && audit.score !== undefined ) {
					if ( audit.score >= 0.9 ) dotClass += ' up-speed-cwv__dot--good';
					else if ( audit.score >= 0.5 ) dotClass += ' up-speed-cwv__dot--warning';
					else dotClass += ' up-speed-cwv__dot--poor';
				}

				html += '<div class="up-speed-accordion' + ( hasItems ? '' : ' up-speed-accordion--no-items' ) + '">';
				html += '<div class="up-speed-accordion__header">';
				if ( hasItems ) {
					html += '<span class="up-speed-accordion__chevron dashicons dashicons-arrow-right-alt2"></span>';
				}
				html += '<span class="' + dotClass + '"></span>';
				html += '<span class="up-speed-accordion__title">' + self.escHtml( audit.title ) + '</span>';
				if ( audit.value ) {
					html += '<span class="up-speed-accordion__value">' + self.escHtml( audit.value ) + '</span>';
				}
				html += '</div>';

				if ( hasItems ) {
					html += '<div class="up-speed-accordion__body">';
					html += '<table class="up-speed-items-table"><tbody>';

					for ( var i = 0; i < audit.items.length; i++ ) {
						var item = audit.items[ i ];
						html += '<tr>';

						// Show element snippet if available (common in a11y audits).
						if ( item.element ) {
							html += '<td><code style="font-size: 11px; background: var(--up-gray-50); padding: 2px 6px; border-radius: 3px; word-break: break-all;">' + self.escHtml( item.element ) + '</code></td>';
						}
						if ( item.selector && ! item.element ) {
							html += '<td><code style="font-size: 11px;">' + self.escHtml( item.selector ) + '</code></td>';
						}
						if ( item.explanation ) {
							html += '<td style="font-size: 12px;">' + self.escHtml( item.explanation ) + '</td>';
						}

						// Generic columns for non-node items.
						if ( ! item.element && ! item.selector && ! item.explanation ) {
							for ( var dk in item ) {
								if ( ! item.hasOwnProperty( dk ) ) continue;
								var dVal = item[ dk ];
								if ( typeof dVal === 'object' ) continue;
								html += '<td>';
								if ( dk === 'url' ) {
									var shortUrl = dVal;
									try { shortUrl = new URL( dVal ).pathname.split( '/' ).pop() || dVal; } catch( e ) {}
									html += '<span class="up-speed-items-table__url" title="' + self.escHtml( dVal ) + '">' + self.escHtml( shortUrl ) + '</span>';
								} else {
									html += self.escHtml( String( dVal ) );
								}
								html += '</td>';
							}
						}

						html += '</tr>';
					}

					html += '</tbody></table>';
					html += '</div>';
				}

				html += '</div>';
			}

			html += '</div>';
			return html;
		},

		/**
		 * Build fix suggestions from Quick Test data (client-side).
		 *
		 * Mirrors the PHP threshold checks in dashboard-tab.php so that
		 * Quick Test results on the Speed Test page also show actionable fixes.
		 *
		 * @param  {Object} data Quick Test result data.
		 * @return {Array}  Fix suggestion objects.
		 */
		buildQuickTestFixSuggestions: function( data ) {
			var t   = data.timing || {};
			var res = data.resources || {};
			var bd  = res.breakdown || {};

			var fixMap = {
				'server-response-time':      { module: 'caching',             tip: 'Enable "Page Cache" in Caching to reduce server response time.',    canAutoFix: true },
				'render-blocking-resources':  { module: 'css_js',             tip: 'Enable "Async CSS", "Defer JS", and "Move jQuery to Footer" in CSS/JS Optimization.', canAutoFix: true },
				'unminified-css':             { module: 'css_js',             tip: 'Enable "Minify CSS" in CSS/JS Optimization.',                       canAutoFix: true },
				'unminified-javascript':      { module: 'css_js',             tip: 'Enable "Minify JS" in CSS/JS Optimization.',                        canAutoFix: true },
				'uses-optimized-images':      { module: 'image_optimization', tip: 'Enable image compression in Image Optimization.',                   canAutoFix: true },
				'modern-image-formats':       { module: 'image_optimization', tip: 'Enable WebP conversion in Image Optimization.',                     canAutoFix: true },
				'offscreen-images':           { module: 'image_optimization', tip: 'Enable "Lazy Load Images" in Image Optimization.',                  canAutoFix: true },
				'font-display':               { module: 'webfonts',           tip: 'Enable "Font Display Swap" in Web Fonts.',                          canAutoFix: true },
				'unused-javascript':          { module: 'script_manager',     tip: 'Use the Script Manager to disable unused JavaScript per page.',     canAutoFix: true },
				'uses-text-compression':      { module: 'caching',            tip: 'Enable "GZIP Compression" in the Caching module.',                  canAutoFix: true }
			};

			var checks = [
				{ cond: t.server > 600,                      id: 'server-response-time',     title: 'Slow Server Response',              score: Math.max( 0, Math.min( 0.89, 1 - ( ( t.server || 0 ) / 2000 ) ) ) },
				{ cond: t.ttfb > 800,                        id: 'server-response-time',     title: 'High Time to First Byte',           score: Math.max( 0, Math.min( 0.89, 1 - ( ( t.ttfb || 0 ) / 3000 ) ) ) },
				{ cond: ( bd.css || 0 ) > 200000,            id: 'unminified-css',            title: 'Large CSS Payload',                 score: 0.4 },
				{ cond: ( bd.script || 0 ) > 300000,         id: 'unminified-javascript',     title: 'Large JavaScript Payload',          score: 0.4 },
				{ cond: ( bd.img || 0 ) > 500000,            id: 'uses-optimized-images',     title: 'Large Image Payload',               score: 0.3 },
				{ cond: ( bd.img || 0 ) > 200000,            id: 'modern-image-formats',      title: 'Images Could Use Next-Gen Formats', score: 0.5 },
				{ cond: ( bd.font || 0 ) > 100000,           id: 'font-display',              title: 'Large Font Payload',                score: 0.5 },
				{ cond: t.load_time > 3000,                  id: 'render-blocking-resources', title: 'Slow Page Load',                    score: Math.max( 0, Math.min( 0.89, 1 - ( ( t.load_time || 0 ) / 8000 ) ) ) },
				{ cond: ( res.count || 0 ) > 60,             id: 'unused-javascript',         title: 'Too Many Requests',                 score: 0.4 },
				{ cond: ( bd.img || 0 ) > 100000,            id: 'offscreen-images',          title: 'Images Should Be Lazy Loaded',      score: 0.5 },
				{ cond: t.load_time > 2500 && t.ttfb > 400,  id: 'uses-text-compression',     title: 'Enable GZIP Compression',           score: 0.5 }
			];

			var seen = {};
			var suggestions = [];

			for ( var i = 0; i < checks.length; i++ ) {
				var c = checks[ i ];
				if ( ! c.cond || seen[ c.id ] ) continue;
				seen[ c.id ] = true;

				var fm = fixMap[ c.id ];
				if ( ! fm ) continue;

				var applied = ( upAdmin.fix_status && upAdmin.fix_status[ c.id ] ) ? true : false;

				suggestions.push({
					audit_id:        c.id,
					audit_title:     c.title,
					score:           c.score,
					module:          fm.module,
					tip:             fm.tip,
					can_auto_fix:    fm.canAutoFix,
					already_applied: applied
				});
			}

			suggestions.sort( function( a, b ) { return a.score - b.score; } );
			return suggestions;
		},

		/**
		 * Render fix suggestions section with Apply Fix buttons.
		 *
		 * @param  {Array} fixes Fix suggestions array.
		 * @return {string} HTML string.
		 */
		renderFixSuggestions: function( fixes ) {
			var self = this;

			// Filter out entries with no module.
			var actionable = [];
			for ( var i = 0; i < fixes.length; i++ ) {
				if ( fixes[ i ].module ) actionable.push( fixes[ i ] );
			}
			if ( ! actionable.length ) return '';

			var html = '<div class="up-speed-section">';
			html += '<h3 class="up-speed-section__title">Suggested Fixes';
			html += '<span class="up-speed-section__count">' + actionable.length + '</span>';
			html += '</h3>';
			html += '<div class="up-fix-list">';

			var moduleTab = {
				css_js: 'css-js',
				caching: 'caching',
				image_optimization: 'images',
				preloading: 'preloading',
				webfonts: 'webfonts',
				script_manager: 'script-manager'
			};

			for ( var f = 0; f < actionable.length; f++ ) {
				var fix = actionable[ f ];
				var sevColor = fix.score < 0.5 ? '#DC2626' : '#D97706';
				var dotColor = fix.already_applied ? '#059669' : sevColor;
				var appliedClass = fix.already_applied ? ' up-fix-item--applied' : '';

				html += '<div class="up-fix-item' + appliedClass + '" data-audit-id="' + self.escHtml( fix.audit_id ) + '">';
				html += '<div class="up-fix-item__dot" style="background:' + dotColor + ';"></div>';
				html += '<div class="up-fix-item__content">';
				html += '<div class="up-fix-item__title">' + self.escHtml( fix.audit_title ) + '</div>';
				html += '<div class="up-fix-item__tip">' + self.escHtml( fix.tip ) + '</div>';
				html += '</div>';
				html += '<div class="up-fix-item__action">';

				if ( fix.already_applied ) {
					html += '<span class="up-badge up-badge--success">';
					html += '<span class="dashicons dashicons-yes-alt" style="font-size:14px;width:14px;height:14px;margin-right:2px;"></span>';
					html += ( upAdmin.i18n.applied || 'Applied' );
					html += '</span>';
				} else if ( fix.can_auto_fix ) {
					html += '<button type="button" class="up-btn up-btn--small up-btn--primary up-apply-fix" data-audit-id="' + self.escHtml( fix.audit_id ) + '">';
					html += 'Apply Fix</button>';
				} else {
					var tab = moduleTab[ fix.module ] || fix.module;
					html += '<a href="admin.php?page=ultimate-performance-settings&tab=' + tab + '" class="up-btn up-btn--small">Configure</a>';
				}

				html += '</div></div>';
			}

			html += '</div></div>';
			return html;
		},

		/**
		 * Bind saved reports management (load, delete, compare).
		 */
		bindSpeedTestReports: function() {
			var self = this;

			// Load reports list on page load.
			if ( $( '#up-speed-reports-list' ).length ) {
				self.loadSpeedReports();
			}

			// Load AI reports list on page load.
			if ( $( '#up-ai-reports-list' ).length ) {
				self.loadAiReports();
			}

			// View a saved AI report.
			$( document ).on( 'click', '.up-ai-report-item', function() {
				var idx = $( this ).data( 'ai-report-index' );
				var report = self._aiReportsCache && self._aiReportsCache[ idx ] ? self._aiReportsCache[ idx ] : null;
				if ( ! report || ! report.data ) return;

				// Use the appropriate container depending on which page we're on.
				var $container = $( '#up-speed-test-results' );
				if ( ! $container.length ) {
					$container = $( '#up-ai-scan-results' );
				}
				if ( ! $container.length ) return;

				var showScanData = report.type === 'website_scan';
				var html = '<div class="up-speed-report">';
				html += '<div class="up-speed-report__strategy" style="padding: 12px 16px; background: var(--up-gray-50); border-bottom: 1px solid var(--up-gray-100); font-size: 13px; font-weight: 500;">';
				html += '<span class="dashicons dashicons-lightbulb"></span> AI ' + ( report.type === 'website_scan' ? 'Website Scan' : 'Speed Test Analysis' );
				if ( report.url ) {
					html += ' &middot; ' + self.escHtml( report.url.replace( /^https?:\/\//, '' ) );
				}
				if ( report.created_at ) {
					html += ' &middot; ' + self.escHtml( report.created_at.substring( 0, 16 ) );
				}
				html += '</div>';
				html += self.renderAiReport( report.data, showScanData );
				html += '</div>';
				$container.html( html );
			});

			// Delete an AI report.
			$( document ).on( 'click', '.up-ai-report-delete', function( e ) {
				e.preventDefault();
				var $btn = $( this );
				var reportId = $btn.data( 'ai-report-id' );

				if ( ! confirm( upAdmin.i18n.ai_confirm_delete || 'Delete this AI report?' ) ) return;

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_ai_delete_report',
						nonce: upAdmin.nonce,
						report_id: reportId
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( upAdmin.i18n.ai_report_deleted || 'AI report deleted.', 'success' );
							self.loadAiReports();
						}
					}
				});
			});

			// Load a saved report.
			$( document ).on( 'click', '.up-report-load', function() {
				var id         = $( this ).data( 'id' );
				var $container = $( '#up-speed-test-results' );

				$container.html( '<p style="color: var(--up-gray-500); text-align: center; padding: 20px;">Loading report...</p>' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_load_speed_report',
						nonce: upAdmin.nonce,
						report_id: id
					},
					success: function( response ) {
						if ( response.success ) {
							if ( response.data.strategy === 'quick' ) {
								self.renderQuickTestResults( $container, response.data );
							} else {
								self.renderSpeedTestResultsFull( $container, response.data );
							}
						} else {
							$container.html( '<p style="color: var(--up-danger); text-align: center; padding: 20px;">' + self.escHtml( response.data.message ) + '</p>' );
						}
					}
				});
			});

			// Delete a report.
			$( document ).on( 'click', '.up-report-delete', function() {
				var id   = $( this ).data( 'id' );
				var $row = $( this ).closest( 'tr' );

				if ( ! confirm( 'Are you sure you want to delete this report?' ) ) {
					return;
				}

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_delete_speed_report',
						nonce: upAdmin.nonce,
						report_id: id
					},
					success: function( response ) {
						if ( response.success ) {
							// Remove from cached data and re-render.
							self._reportsData = self._reportsData.filter( function( r ) {
								return String( r.id ) !== String( id );
							});
							var totalPages = Math.ceil( self._reportsData.length / self._reportsPerPage );
							if ( self._reportsPage > totalPages && totalPages > 0 ) {
								self._reportsPage = totalPages;
							}
							if ( self._reportsData.length === 0 ) {
								$( '#up-speed-reports-list' ).html( '<p class="up-speed-no-reports">No saved reports yet. Run a speed test to create one.</p>' );
							} else {
								self._renderReportsPage( $( '#up-speed-reports-list' ) );
							}
							self.showToast( 'Report deleted.', 'success' );
						}
					}
				});
			});

			// Compare selected reports.
			$( document ).on( 'click', '#up-compare-run', function() {
				var checked = $( '.up-compare-check:checked' );
				if ( checked.length !== 2 ) {
					self.showToast( 'Please select exactly 2 reports to compare.', 'error' );
					return;
				}

				var idA = $( checked[0] ).val();
				var idB = $( checked[1] ).val();
				var $btn = $( this );

				$btn.prop( 'disabled', true ).text( 'Comparing...' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_compare_speed_reports',
						nonce: upAdmin.nonce,
						report_a: idA,
						report_b: idB
					},
					success: function( response ) {
						if ( response.success ) {
							$( '#up-speed-compare-card' ).show();
							self.renderComparisonReport(
								$( '#up-speed-compare-results' ),
								response.data.report_a,
								response.data.report_b
							);
						} else {
							self.showToast( response.data.message, 'error' );
						}
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( 'Compare Selected' );
					}
				});
			});

			// Enable compare button when exactly 2 checkboxes are selected.
			$( document ).on( 'change', '.up-compare-check', function() {
				var checked = $( '.up-compare-check:checked' ).length;
				$( '#up-compare-run' ).prop( 'disabled', checked !== 2 );
			});

			// Reports pagination.
			$( document ).on( 'click', '.up-reports-prev', function() {
				if ( self._reportsPage > 1 ) {
					self._reportsPage--;
					self._renderReportsPage( $( '#up-speed-reports-list' ) );
				}
			});
			$( document ).on( 'click', '.up-reports-next', function() {
				var totalPages = Math.ceil( self._reportsData.length / self._reportsPerPage );
				if ( self._reportsPage < totalPages ) {
					self._reportsPage++;
					self._renderReportsPage( $( '#up-speed-reports-list' ) );
				}
			});

			// Close comparison card.
			$( document ).on( 'click', '#up-compare-close', function() {
				$( '#up-speed-compare-card' ).hide();
			});

			// Save label inline.
			$( document ).on( 'click', '.up-report-label-save', function() {
				var $input = $( this ).siblings( '.up-report-label-input' );
				var id     = $( this ).data( 'id' );
				var label  = $input.val();

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_save_speed_report',
						nonce: upAdmin.nonce,
						report_id: id,
						label: label
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( 'Label saved.', 'success' );
							self.loadSpeedReports();
						}
					}
				});
			});
		},

		/**
		 * Load saved AI analysis reports and render in all available sidebars.
		 *
		 * Works on both the Speed Test page (#up-ai-reports-list) and the
		 * AI page (#up-ai-saved-reports).
		 */
		loadAiReports: function() {
			var self = this;

			$.ajax({
				url: upAdmin.ajax_url,
				type: 'POST',
				data: {
					action: 'up_ai_get_reports',
					nonce: upAdmin.nonce
				},
				success: function( response ) {
					if ( ! response.success ) return;
					var reports = response.data.reports || [];

					// Speed test page sidebar.
					if ( $( '#up-ai-reports-list' ).length ) {
						self.renderAiReportsList( reports );
					}

					// AI page sidebar.
					var $aiSidebar = $( '#up-ai-saved-reports' );
					if ( $aiSidebar.length ) {
						self._aiReportsCache = reports;
						if ( ! reports.length ) {
							$aiSidebar.html( '<p style="color: var(--up-gray-400); text-align: center; padding: 20px 0; font-size: 13px;">' + ( upAdmin.i18n.no_ai_reports || 'No AI reports yet. Run a website scan to generate one.' ) + '</p>' );
							return;
						}
						var html = '';
						$.each( reports, function( i, report ) {
							var scoreClass = 'up-badge--warning';
							if ( report.data && report.data.score_label === 'good' ) scoreClass = 'up-badge--success';
							if ( report.data && report.data.score_label === 'poor' ) scoreClass = 'up-badge--danger';

							html += '<div class="up-ai-report-item" data-ai-report-index="' + i + '" style="padding: 12px; border-bottom: 1px solid var(--up-gray-100); display: flex; justify-content: space-between; align-items: center; cursor: pointer;">';
							html += '<div style="min-width: 0; flex: 1;">';
							html += '<strong style="font-size: 13px; display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">' + self.escHtml( report.url || 'Website Scan' ) + '</strong>';
							html += '<span style="font-size: 12px; color: var(--up-gray-400);">' + self.escHtml( report.created_at ) + '</span>';
							if ( report.data && report.data.summary ) {
								html += '<br><span style="font-size: 12px; color: var(--up-gray-500);">' + self.escHtml( report.data.summary.substring( 0, 80 ) ) + '...</span>';
							}
							html += '</div>';
							html += '<button type="button" class="up-btn up-btn--small up-btn--danger up-ai-delete-report" data-report-id="' + report.id + '" style="flex-shrink: 0; margin-left: 8px;">';
							html += '<span class="dashicons dashicons-trash" style="font-size:14px;width:14px;height:14px;"></span>';
							html += '</button>';
							html += '</div>';
						});
						$aiSidebar.html( html );
					}
				}
			});
		},

		/**
		 * Render AI reports list in the sidebar.
		 *
		 * @param {Array} reports Array of AI report objects.
		 */
		renderAiReportsList: function( reports ) {
			var self  = this;
			var $list = $( '#up-ai-reports-list' );

			if ( ! $list.length ) return;

			if ( ! reports || reports.length === 0 ) {
				$list.html( '<p style="color: var(--up-gray-400); text-align: center; padding: 16px 0; font-size: 13px;">' + ( upAdmin.i18n.no_ai_reports || 'No AI reports yet. Run an analysis to create one.' ) + '</p>' );
				return;
			}

			var html = '<div style="display: flex; flex-direction: column; gap: 6px;">';

			for ( var i = 0; i < Math.min( reports.length, 15 ); i++ ) {
				var r = reports[ i ];
				var typeIcon = r.type === 'website_scan' ? 'dashicons-welcome-view-site' : 'dashicons-chart-bar';
				var typeLabel = r.type === 'website_scan' ? 'Scan' : 'Analysis';
				var scoreLabel = r.data && r.data.score_label ? r.data.score_label : 'needs_work';
				var scoreDot = scoreLabel === 'good' ? 'var(--up-success)' : ( scoreLabel === 'poor' ? 'var(--up-danger)' : 'var(--up-warning)' );
				var shortUrl = ( r.url || '' ).replace( /^https?:\/\//, '' );
				if ( shortUrl.length > 30 ) shortUrl = shortUrl.substring( 0, 30 ) + '...';
				var dateStr = r.created_at ? r.created_at.substring( 0, 16 ) : '';
				var summary = r.data && r.data.summary ? r.data.summary : '';
				if ( summary.length > 80 ) summary = summary.substring( 0, 80 ) + '...';

				html += '<div class="up-ai-report-item" style="padding: 8px 10px; border: 1px solid var(--up-gray-100); border-radius: 6px; cursor: pointer; transition: border-color 0.15s;" data-ai-report-index="' + i + '">';
				html += '<div style="display: flex; justify-content: space-between; align-items: center; gap: 6px;">';
				html += '<div style="display: flex; align-items: center; gap: 6px; flex: 1; min-width: 0;">';
				html += '<span style="width: 8px; height: 8px; border-radius: 50%; background: ' + scoreDot + '; flex-shrink: 0;"></span>';
				html += '<span class="dashicons ' + typeIcon + '" style="font-size: 13px; width: 13px; height: 13px; color: var(--up-gray-400); flex-shrink: 0;"></span>';
				html += '<span style="font-size: 12px; font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">' + self.escHtml( shortUrl ) + '</span>';
				html += '</div>';
				html += '<div style="display: flex; align-items: center; gap: 4px; flex-shrink: 0;">';
				html += '<span style="font-size: 10px; color: var(--up-gray-400);">' + self.escHtml( dateStr ) + '</span>';
				html += '<button class="up-ai-report-delete up-btn up-btn--small up-btn--text-danger" data-ai-report-id="' + r.id + '" title="Delete" style="padding: 2px 4px; min-width: auto;" onclick="event.stopPropagation();">';
				html += '<span class="dashicons dashicons-trash" style="font-size:12px;width:12px;height:12px;"></span>';
				html += '</button>';
				html += '</div>';
				html += '</div>';
				if ( summary ) {
					html += '<div style="font-size: 11px; color: var(--up-gray-500); margin-top: 4px; line-height: 1.4;">' + self.escHtml( summary ) + '</div>';
				}
				html += '</div>';
			}

			html += '</div>';
			$list.html( html );

			// Store reports for click handler.
			self._aiReportsCache = reports;
		},

		/**
		 * Cached AI reports data.
		 */
		_aiReportsCache: [],

		/**
		 * Load saved speed reports list.
		 */
		loadSpeedReports: function() {
			var self = this;

			$.ajax({
				url: upAdmin.ajax_url,
				type: 'POST',
				data: {
					action: 'up_load_speed_reports',
					nonce: upAdmin.nonce
				},
				success: function( response ) {
					if ( response.success ) {
						self.renderSpeedReportsList( response.data.reports );
					}
				}
			});
		},

		/**
		 * Cached reports data and current page for pagination.
		 */
		_reportsData: [],
		_reportsPage: 1,
		_reportsPerPage: 5,

		/**
		 * Render saved reports list table with pagination.
		 *
		 * @param {Array} reports Array of report objects.
		 */
		renderSpeedReportsList: function( reports ) {
			var self  = this;
			var $list = $( '#up-speed-reports-list' );

			if ( ! reports || reports.length === 0 ) {
				$list.html( '<p class="up-speed-no-reports">No saved reports yet. Run a speed test to create one.</p>' );
				return;
			}

			// Cache full data and reset to page 1.
			self._reportsData = reports;
			self._reportsPage = 1;
			self._renderReportsPage( $list );
		},

		/**
		 * Render the current page of reports.
		 *
		 * @param {jQuery} $list Container element.
		 */
		_renderReportsPage: function( $list ) {
			var self       = this;
			var reports    = self._reportsData;
			var page       = self._reportsPage;
			var perPage    = self._reportsPerPage;
			var totalPages = Math.ceil( reports.length / perPage );
			var start      = ( page - 1 ) * perPage;
			var end        = Math.min( start + perPage, reports.length );
			var pageItems  = reports.slice( start, end );

			var html = '<table class="up-speed-reports-table">';
			html += '<thead><tr>';
			html += '<th style="width:30px"></th>';
			html += '<th>URL</th>';
			html += '<th>Score</th>';
			html += '<th>Date</th>';
			html += '<th>Actions</th>';
			html += '</tr></thead><tbody>';

			for ( var i = 0; i < pageItems.length; i++ ) {
				var r = pageItems[ i ];
				var scoreColor = self.scoreColor( parseInt( r.performance_score ) || 0 );
				var stratIcon = r.strategy === 'quick' ? 'dashicons-performance' : ( r.strategy === 'desktop' ? 'dashicons-desktop' : 'dashicons-smartphone' );
				var shortUrl = r.url ? r.url.replace( /^https?:\/\//, '' ) : '';
				if ( shortUrl.length > 35 ) shortUrl = shortUrl.substring( 0, 35 ) + '...';
				var label = r.label ? '<span class="up-report-label">' + self.escHtml( r.label ) + '</span>' : '';
				var dateStr = r.created_at ? r.created_at.substring( 0, 16 ) : '';

				html += '<tr data-report-id="' + r.id + '">';
				html += '<td><input type="checkbox" class="up-compare-check" value="' + r.id + '"></td>';
				html += '<td><span class="dashicons ' + stratIcon + '" style="font-size:13px;width:13px;height:13px;color:var(--up-gray-400);vertical-align:middle;margin-right:4px;"></span>' + self.escHtml( shortUrl ) + label + '</td>';
				html += '<td><strong style="color:' + scoreColor + '">' + ( r.performance_score || 0 ) + '</strong></td>';
				html += '<td><span style="font-size:11px;color:var(--up-gray-400)">' + self.escHtml( dateStr ) + '</span></td>';
				html += '<td class="up-speed-reports-table__actions">';
				html += '<button class="up-report-load up-btn up-btn--small" data-id="' + r.id + '">View</button>';
				html += '<button class="up-report-delete up-btn up-btn--small up-btn--text-danger" data-id="' + r.id + '" title="Delete">';
				html += '<span class="dashicons dashicons-trash" style="font-size:14px;width:14px;height:14px;"></span>';
				html += '</button>';
				html += '</td>';
				html += '</tr>';
			}

			html += '</tbody></table>';

			// Pagination row.
			if ( totalPages > 1 ) {
				html += '<div style="margin-top: 12px; display: flex; justify-content: center; align-items: center; gap: 10px;">';
				html += '<button class="up-btn up-btn--small up-reports-prev"' + ( page <= 1 ? ' disabled' : '' ) + '>&#8249; Prev</button>';
				html += '<span style="font-size: 12px; color: var(--up-gray-500);">' + page + ' of ' + totalPages + '</span>';
				html += '<button class="up-btn up-btn--small up-reports-next"' + ( page >= totalPages ? ' disabled' : '' ) + '>Next &#8250;</button>';
				html += '</div>';
			}

			// Compare row.
			html += '<div style="margin-top: 10px; display: flex; gap: 8px; align-items: center;">';
			html += '<button id="up-compare-run" class="up-btn up-btn--secondary up-btn--small" disabled>Compare Selected</button>';
			html += '<span style="font-size:11px;color:var(--up-gray-400);">Select 2 reports</span>';
			html += '</div>';

			$list.html( html );
		},

		/**
		 * Render side-by-side comparison report.
		 *
		 * @param {jQuery} $container Target container.
		 * @param {Object} a          Report A data.
		 * @param {Object} b          Report B data.
		 */
		renderComparisonReport: function( $container, a, b ) {
			var self = this;

			var html = '<div class="up-speed-compare">';

			// Header.
			var labelA = a.label || 'Report #' + a.report_id;
			var labelB = b.label || 'Report #' + b.report_id;
			var dateA  = a.created_at ? a.created_at.substring( 0, 16 ) : '';
			var dateB  = b.created_at ? b.created_at.substring( 0, 16 ) : '';

			html += '<div class="up-speed-compare__header">';
			html += '<div class="up-speed-compare__col">';
			html += '<div class="up-speed-compare__label">' + self.escHtml( labelA ) + '</div>';
			html += '<div class="up-speed-compare__date">' + self.escHtml( dateA ) + '</div>';
			html += '</div>';
			html += '<div class="up-speed-compare__vs">VS</div>';
			html += '<div class="up-speed-compare__col" style="text-align:right;">';
			html += '<div class="up-speed-compare__label">' + self.escHtml( labelB ) + '</div>';
			html += '<div class="up-speed-compare__date">' + self.escHtml( dateB ) + '</div>';
			html += '</div>';
			html += '</div>';

			// Score comparison.
			var scoreA = a.score || 0;
			var scoreB = b.score || 0;
			var diff   = scoreB - scoreA;
			var diffColor = diff > 0 ? '#059669' : ( diff < 0 ? '#DC2626' : '#6B7280' );
			var arrow  = diff > 0 ? '\u25B2' : ( diff < 0 ? '\u25BC' : '\u25CF' );

			html += '<div class="up-speed-compare__scores">';
			html += '<div class="up-speed-compare__col" style="text-align:center;">';
			html += self.buildGauge( scoreA, 100, 42, 7, 22 );
			html += '</div>';
			html += '<div class="up-speed-compare__diff" style="color:' + diffColor + '">';
			html += arrow + ' ' + ( diff > 0 ? '+' : '' ) + diff;
			html += '</div>';
			html += '<div class="up-speed-compare__col" style="text-align:center;">';
			html += self.buildGauge( scoreB, 100, 42, 7, 22 );
			html += '</div>';
			html += '</div>';

			// Check if either report is a Quick Test.
			var isQuickA = a.strategy === 'quick';
			var isQuickB = b.strategy === 'quick';
			var bothQuick = isQuickA && isQuickB;
			var anyQuick  = isQuickA || isQuickB;

			// Category scores comparison (PSI reports only).
			if ( ! bothQuick ) {
				var catDefs = [
					{ key: 'performance', label: 'Performance' },
					{ key: 'accessibility', label: 'Accessibility' },
					{ key: 'best_practices', label: 'Best Practices' },
					{ key: 'seo', label: 'SEO' }
				];

				html += '<table class="up-speed-compare__table">';
				html += '<thead><tr><th>Category</th><th>' + self.escHtml( labelA ) + '</th><th>' + self.escHtml( labelB ) + '</th><th>Change</th></tr></thead>';
				html += '<tbody>';

				var scoresA = a.scores || {};
				var scoresB = b.scores || {};

				for ( var ci = 0; ci < catDefs.length; ci++ ) {
					var cat  = catDefs[ ci ];
					var sA   = isQuickA ? '\u2014' : ( scoresA[ cat.key ] || 0 );
					var sB   = isQuickB ? '\u2014' : ( scoresB[ cat.key ] || 0 );
					var cDiff, cColor, cArrow;
					if ( isQuickA || isQuickB ) {
						cDiff = 0; cColor = '#6B7280'; cArrow = '';
					} else {
						cDiff = sB - sA;
						cColor = cDiff > 0 ? '#059669' : ( cDiff < 0 ? '#DC2626' : '#6B7280' );
						cArrow = cDiff > 0 ? '\u25B2' : ( cDiff < 0 ? '\u25BC' : '' );
					}

					html += '<tr>';
					html += '<td>' + cat.label + '</td>';
					html += '<td style="color:' + ( typeof sA === 'number' ? self.scoreColor( sA ) : '#6B7280' ) + ';font-weight:600;">' + sA + '</td>';
					html += '<td style="color:' + ( typeof sB === 'number' ? self.scoreColor( sB ) : '#6B7280' ) + ';font-weight:600;">' + sB + '</td>';
					html += '<td style="color:' + cColor + ';font-weight:600;">' + ( cArrow ? cArrow + ' ' : '' ) + ( cDiff !== 0 ? ( cDiff > 0 ? '+' : '' ) + cDiff : '\u2014' ) + '</td>';
					html += '</tr>';
				}

				html += '</tbody></table>';
			}

			// Metrics comparison — use PSI metrics or Quick Test timing based on report types.
			if ( bothQuick ) {
				// Both Quick Test: compare browser timing metrics.
				var timingA = a.timing || {};
				var timingB = b.timing || {};
				var quickDefs = [
					{ key: 'ttfb',      label: 'TTFB' },
					{ key: 'fcp',       label: 'FCP' },
					{ key: 'dom_ready', label: 'DOM Loaded' },
					{ key: 'load_time', label: 'Full Load' },
					{ key: 'server',    label: 'Server' },
					{ key: 'dom_parse', label: 'DOM Parse' }
				];

				html += '<h4 style="margin:20px 0 8px;font-size:13px;color:var(--up-gray-700);">Timing Metrics</h4>';
				html += '<table class="up-speed-compare__table">';
				html += '<thead><tr><th>Metric</th><th>' + self.escHtml( labelA ) + '</th><th>' + self.escHtml( labelB ) + '</th><th>Change</th></tr></thead>';
				html += '<tbody>';

				for ( var qi = 0; qi < quickDefs.length; qi++ ) {
					var qd = quickDefs[ qi ];
					var qA = timingA[ qd.key ];
					var qB = timingB[ qd.key ];
					var qAStr = qA !== null && qA !== undefined ? self.formatMs( qA ) : '\u2014';
					var qBStr = qB !== null && qB !== undefined ? self.formatMs( qB ) : '\u2014';
					var qDiff = '', qDiffColor = '#6B7280';
					if ( qA !== null && qA !== undefined && qB !== null && qB !== undefined ) {
						var qDelta = Math.round( qB - qA );
						qDiffColor = qDelta < 0 ? '#059669' : ( qDelta > 0 ? '#DC2626' : '#6B7280' );
						qDiff = ( qDelta < 0 ? '\u25BC ' : ( qDelta > 0 ? '\u25B2 +' : '' ) ) + self.formatMs( qDelta );
					}

					html += '<tr>';
					html += '<td>' + qd.label + '</td>';
					html += '<td style="font-weight:600;">' + qAStr + '</td>';
					html += '<td style="font-weight:600;">' + qBStr + '</td>';
					html += '<td style="color:' + qDiffColor + ';font-weight:600;">' + ( qDiff || '\u2014' ) + '</td>';
					html += '</tr>';
				}

				html += '</tbody></table>';
			} else {
				// PSI metrics comparison (works for PSI vs PSI or mixed).
				var metricsA = a.metrics || {};
				var metricsB = b.metrics || {};
				var metricDefs = [
					{ key: 'fcp', label: 'FCP' },
					{ key: 'lcp', label: 'LCP' },
					{ key: 'tbt', label: 'TBT' },
					{ key: 'cls', label: 'CLS' },
					{ key: 'si',  label: 'SI' },
					{ key: 'ttfb', label: 'TTFB' }
				];

				html += '<h4 style="margin:20px 0 8px;font-size:13px;color:var(--up-gray-700);">Core Web Vitals</h4>';
				html += '<table class="up-speed-compare__table">';
				html += '<thead><tr><th>Metric</th><th>' + self.escHtml( labelA ) + '</th><th>' + self.escHtml( labelB ) + '</th></tr></thead>';
				html += '<tbody>';

				for ( var mi = 0; mi < metricDefs.length; mi++ ) {
					var md = metricDefs[ mi ];
					var mA = metricsA[ md.key ] || {};
					var mB = metricsB[ md.key ] || {};
					var mAColor = mA.score !== null && mA.score !== undefined ? self.scoreColor( mA.score, true ) : '#6B7280';
					var mBColor = mB.score !== null && mB.score !== undefined ? self.scoreColor( mB.score, true ) : '#6B7280';

					html += '<tr>';
					html += '<td>' + md.label + '</td>';
					html += '<td style="color:' + mAColor + ';font-weight:600;">' + ( mA.value || '\u2014' ) + '</td>';
					html += '<td style="color:' + mBColor + ';font-weight:600;">' + ( mB.value || '\u2014' ) + '</td>';
					html += '</tr>';
				}

				html += '</tbody></table>';
			}
			html += '</div>';

			$container.html( html );
		},

		/**
		 * Bind bulk WebP conversion button.
		 */
		bindBulkWebP: function() {
			var self = this;

			$( document ).on( 'click', '#up-bulk-webp', function() {
				var $btn      = $( this );
				var $status   = $( '#up-bulk-webp-status' );
				var $progress = $( '#up-bulk-webp-progress' );
				var $bar      = $( '#up-bulk-webp-bar' );
				var label     = $btn.text();

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span> ' + upAdmin.i18n.converting_webp );
				$progress.show();
				$bar.css( 'width', '0%' );

				var totalImages = 0;

				function processBatch() {
					$.ajax({
						url: upAdmin.ajax_url,
						type: 'POST',
						data: {
							action: 'up_bulk_webp_convert',
							nonce: upAdmin.nonce,
							offset: 0
						},
						success: function( response ) {
							if ( response.success ) {
								var data = response.data;
								if ( totalImages === 0 && data.total > 0 ) {
									totalImages = data.total + data.converted;
								}

								if ( totalImages > 0 ) {
									var done = totalImages - data.remaining;
									var pct  = Math.round( ( done / totalImages ) * 100 );
									$bar.css( 'width', pct + '%' );
								}

								$status.text( data.message );

								if ( ! data.done ) {
									processBatch();
								} else {
									$btn.prop( 'disabled', false ).text( label );
									$bar.css( 'width', '100%' );
									self.showToast( data.message, 'success' );
								}
							} else {
								$btn.prop( 'disabled', false ).text( label );
								$progress.hide();
								self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
							}
						},
						error: function() {
							$btn.prop( 'disabled', false ).text( label );
							$progress.hide();
							self.showToast( upAdmin.i18n.network_error, 'error' );
						}
					});
				}

				processBatch();
			});
		},

		/**
		 * Bind bulk image compression button.
		 */
		bindBulkCompress: function() {
			var self = this;

			$( document ).on( 'click', '#up-bulk-compress', function() {
				var $btn      = $( this );
				var $status   = $( '#up-bulk-compress-status' );
				var $progress = $( '#up-bulk-compress-progress' );
				var $bar      = $( '#up-bulk-compress-bar' );
				var label     = $btn.text();

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span> ' + upAdmin.i18n.compressing );
				$progress.show();
				$bar.css( 'width', '0%' );

				var totalImages = 0;

				function processBatch() {
					$.ajax({
						url: upAdmin.ajax_url,
						type: 'POST',
						data: {
							action: 'up_bulk_compress',
							nonce: upAdmin.nonce
						},
						success: function( response ) {
							if ( response.success ) {
								var data = response.data;
								if ( totalImages === 0 && data.total > 0 ) {
									totalImages = data.total + data.compressed;
								}

								if ( totalImages > 0 ) {
									var done = totalImages - data.remaining;
									var pct  = Math.round( ( done / totalImages ) * 100 );
									$bar.css( 'width', pct + '%' );
								}

								$status.text( data.message );

								if ( ! data.done ) {
									processBatch();
								} else {
									$btn.prop( 'disabled', false ).text( label );
									$bar.css( 'width', '100%' );
									self.showToast( data.message, 'success' );
								}
							} else {
								$btn.prop( 'disabled', false ).text( label );
								$progress.hide();
								self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
							}
						},
						error: function() {
							$btn.prop( 'disabled', false ).text( label );
							$progress.hide();
							self.showToast( upAdmin.i18n.network_error, 'error' );
						}
					});
				}

				processBatch();
			});
		},

		/**
		 * Bind the Re-detect tools button on Image Optimization settings.
		 *
		 * @since 1.1.0
		 */
		bindRefreshTools: function() {
			var self = this;

			$( document ).on( 'click', '#up-refresh-tools', function() {
				var $btn  = $( this );
				var label = $btn.html();

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span> ' + upAdmin.i18n.detecting_tools );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_detect_image_tools',
						nonce: upAdmin.nonce
					},
					success: function( response ) {
						if ( response.success ) {
							var tools = response.data.tools;
							var $grid = $( '#up-tools-grid' );
							var html  = '';

							$.each( tools, function( slug, tool ) {
								var isAvailable = tool.available;
								var itemClass   = isAvailable ? 'up-tool-item--available' : 'up-tool-item--missing';
								var iconClass   = isAvailable ? 'dashicons-yes-alt up-tool-item__icon--ok' : 'dashicons-dismiss up-tool-item__icon--no';

								html += '<div class="up-tool-item ' + itemClass + '">';
								html += '<div class="up-tool-item__status"><span class="dashicons ' + iconClass + '"></span></div>';
								html += '<div class="up-tool-item__info">';
								html += '<strong class="up-tool-item__name">' + self.escHtml( tool.label ) + '</strong>';
								html += '<span class="up-tool-item__desc">' + self.escHtml( tool.desc ) + '</span>';

								if ( isAvailable && tool.version ) {
									html += '<span class="up-tool-item__version">v' + self.escHtml( tool.version ) + '</span>';
								} else if ( ! isAvailable && slug !== 'gd' ) {
									html += '<span class="up-tool-item__hint">' + upAdmin.i18n.not_installed + '</span>';
								}

								html += '</div></div>';
							});

							$grid.html( html );
							self.showToast( upAdmin.i18n.tools_detected, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).html( label );
					}
				});
			});
		},

		/**
		 * Bind CDN provider selection, panel toggling, and purge buttons.
		 */
		bindCDNProviders: function() {
			var self = this;

			// CDN URL placeholders per provider.
			var placeholders = {
				cloudflare: '',
				bunnycdn:   'https://your-zone.b-cdn.net',
				keycdn:     'https://your-zone-xxxx.kxcdn.com',
				cloudfront: 'https://d1234567890.cloudfront.net',
				stackpath:  'https://your-zone.stackpathdns.com',
				custom:     'https://cdn.example.com'
			};

			// Toggle panels and update placeholder when provider changes.
			$( document ).on( 'change', 'input[name="cdn_provider"]', function() {
				var selected = $( this ).val();

				// Show/hide provider-specific panels.
				$( '.up-cdn-panel' ).hide();
				$( '.up-cdn-panel[data-cdn-provider="' + selected + '"]' ).show();

				// Show/hide CDN URL config (Cloudflare doesn't need it).
				if ( selected === 'cloudflare' ) {
					$( '.up-cdn-url-config' ).hide();
				} else {
					$( '.up-cdn-url-config' ).show();
				}

				// Update CDN URL placeholder.
				var ph = placeholders[ selected ] || placeholders.custom;
				$( '#cdn_url' ).attr( 'placeholder', ph );
			});

			// Cloudflare Test Connection.
			$( document ).on( 'click', '#up-cf-test', function() {
				var $btn  = $( this );
				var label = $btn.text();

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span> ' + upAdmin.i18n.testing_connection );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_cdn_cloudflare_test',
						nonce: upAdmin.nonce,
						email: $( '#cloudflare_email' ).val(),
						api_key: $( '#cloudflare_api_key' ).val(),
						zone_id: $( '#cloudflare_zone_id' ).val()
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( response.data.message, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});

			// Cloudflare Purge Cache.
			$( document ).on( 'click', '#up-cf-purge', function() {
				var $btn  = $( this );
				var label = $btn.text();

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + upAdmin.i18n.purging );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_cdn_cloudflare_purge',
						nonce: upAdmin.nonce
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( response.data.message, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});

			// BunnyCDN Purge Cache.
			$( document ).on( 'click', '#up-bunny-purge', function() {
				var $btn  = $( this );
				var label = $btn.text();

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + upAdmin.i18n.purging );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_cdn_bunnycdn_purge',
						nonce: upAdmin.nonce
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( response.data.message, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});

			// Toggle offload provider endpoint field visibility.
			$( document ).on( 'change', 'input[name="offload_provider"]', function() {
				var selected = $( this ).val();
				if ( selected === 'r2' ) {
					$( '#up-offload-endpoint-field' ).show();
				} else {
					$( '#up-offload-endpoint-field' ).hide();
				}
			});

			// Offload Test Connection.
			$( document ).on( 'click', '#up-offload-test', function() {
				var $btn  = $( this );
				var label = $btn.text();

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span> ' + upAdmin.i18n.testing_connection );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_offload_test_connection',
						nonce: upAdmin.nonce,
						provider: $( 'input[name="offload_provider"]:checked' ).val(),
						access_key: $( '#offload_access_key' ).val(),
						secret_key: $( '#offload_secret_key' ).val(),
						bucket: $( '#offload_bucket' ).val(),
						region: $( '#offload_region' ).val(),
						endpoint: $( '#offload_endpoint' ).val()
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( response.data.message, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});

			// Configure Bucket (public access + CORS).
			$( document ).on( 'click', '#up-configure-bucket', function() {
				var $btn  = $( this );
				var label = $btn.text();

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span> ' + upAdmin.i18n.configuring );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_offload_configure_bucket',
						nonce: upAdmin.nonce,
						provider: $( 'input[name="offload_provider"]:checked' ).val(),
						access_key: $( '#offload_access_key' ).val(),
						secret_key: $( '#offload_secret_key' ).val(),
						bucket: $( '#offload_bucket' ).val(),
						region: $( '#offload_region' ).val(),
						endpoint: $( '#offload_endpoint' ).val()
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( response.data.message, 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});

			// Bulk Offload.
			$( document ).on( 'click', '#up-bulk-offload', function() {
				var $btn      = $( this );
				var $status   = $( '#up-bulk-offload-status' );
				var $progress = $( '#up-bulk-offload-progress' );
				var $bar      = $( '#up-bulk-offload-bar' );
				var label     = $btn.text();

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span> ' + upAdmin.i18n.offloading );
				$progress.show();
				$bar.css( 'width', '0%' );

				var totalImages = 0;

				function processBatch() {
					$.ajax({
						url: upAdmin.ajax_url,
						type: 'POST',
						data: {
							action: 'up_offload_bulk',
							nonce: upAdmin.nonce
						},
						timeout: 120000,
						success: function( response ) {
							if ( response.success ) {
								var data = response.data;
								if ( totalImages === 0 && data.total > 0 ) {
									totalImages = data.total + data.offloaded;
								}

								if ( totalImages > 0 ) {
									var done = totalImages - data.remaining;
									var pct  = Math.round( ( done / totalImages ) * 100 );
									$bar.css( 'width', pct + '%' );
								}

								$status.text( data.message );

								if ( ! data.done ) {
									processBatch();
								} else {
									$btn.prop( 'disabled', false ).text( label );
									$bar.css( 'width', '100%' );
									self.showToast( data.message, 'success' );
								}
							} else {
								$btn.prop( 'disabled', false ).text( label );
								$progress.hide();
								self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
							}
						},
						error: function() {
							$btn.prop( 'disabled', false ).text( label );
							$progress.hide();
							self.showToast( upAdmin.i18n.network_error, 'error' );
						}
					});
				}

				processBatch();
			});
		},

		loadDatabaseCounts: function() {
			if ( ! $( '#up-db-tools' ).length ) {
				return;
			}

			$.ajax({
				url: upAdmin.ajax_url,
				type: 'POST',
				data: {
					action: 'up_db_get_counts',
					nonce: upAdmin.nonce
				},
				success: function( response ) {
					if ( response.success && response.data.counts ) {
						$.each( response.data.counts, function( type, count ) {
							var $el = $( '[data-count="' + type + '"]' );
							$el.text( count );
							if ( parseInt( count, 10 ) > 0 ) {
								$el.addClass( 'has-items' );
							}
						});
					}
				}
			});
		},

		/**
		 * Bind preset application buttons.
		 */
		bindPresets: function() {
			var self = this;

			$( document ).on( 'click', '.up-apply-preset', function() {
				var $btn       = $( this );
				var preset     = $btn.data( 'preset' );
				var presetName = $btn.data( 'preset-name' );
				var label      = $btn.text();

				if ( ! confirm(
					upAdmin.i18n.confirm_preset.replace( '%s', presetName )
				) ) {
					return;
				}

				$btn.prop( 'disabled', true ).html(
					'<span class="up-spinner up-spinner--white"></span> ' + upAdmin.i18n.applying_preset
				);

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_apply_preset',
						nonce: upAdmin.nonce,
						preset: preset
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( response.data.message, 'success' );
							self.updateActivePreset( preset );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
							$btn.prop( 'disabled', false ).text( label );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});
		},

		/**
		 * Update the UI to reflect the newly active preset.
		 *
		 * @param {string} preset The preset slug that was just applied.
		 */
		updateActivePreset: function( preset ) {
			var activeLabel = upAdmin.i18n.currently_active || 'Currently Active';
			var applyLabel  = upAdmin.i18n.apply_preset || 'Apply Preset';

			// Remove active state from all cards.
			$( '.up-preset-card' ).each( function() {
				var $card = $( this );
				var slug  = $card.data( 'preset' );
				var isRec = $card.hasClass( 'up-preset-card--recommended' );

				$card.removeClass( 'up-preset-card--active' );
				$card.find( '.up-preset-card__active-badge' ).remove();

				// Restore the "Recommended" badge if needed.
				if ( isRec && slug !== preset ) {
					$card.prepend(
						'<div class="up-preset-card__badge">' +
						( upAdmin.i18n.recommended || 'Recommended' ) +
						'</div>'
					);
				}

				// Restore button if it was showing "Currently Active" label.
				var $footer = $card.find( '.up-preset-card__footer' );
				if ( $footer.find( '.up-preset-card__active-label' ).length ) {
					var btnClass = isRec ? 'up-btn--primary' : 'up-btn--secondary';
					$footer.html(
						'<button type="button" class="up-btn ' + btnClass + ' up-apply-preset" ' +
						'data-preset="' + slug + '" data-preset-name="' + $card.find( '.up-preset-card__title' ).text() + '">' +
						applyLabel +
						'</button>'
					);
				}
			});

			// Set active state on the new card.
			var $activeCard = $( '.up-preset-card[data-preset="' + preset + '"]' );
			$activeCard.addClass( 'up-preset-card--active' );

			// Remove the "Recommended" badge (replaced by Active badge).
			$activeCard.find( '.up-preset-card__badge' ).remove();

			// Add the active badge.
			$activeCard.prepend(
				'<div class="up-preset-card__active-badge">' +
				'<span class="dashicons dashicons-yes-alt"></span> ' +
				( upAdmin.i18n.active || 'Active' ) +
				'</div>'
			);

			// Replace button with "Currently Active" label.
			$activeCard.find( '.up-preset-card__footer' ).html(
				'<span class="up-preset-card__active-label">' +
				'<span class="dashicons dashicons-yes-alt"></span> ' +
				activeLabel +
				'</span>'
			);
		},

		/**
		 * Bind fix suggestion "Apply Fix" buttons on the dashboard.
		 *
		 * @since 1.3.0
		 */
		bindFixSuggestions: function() {
			var self = this;

			$( document ).on( 'click', '.up-apply-fix', function() {
				var $btn    = $( this );
				var auditId = $btn.data( 'audit-id' );
				var label   = $btn.text();
				var $item   = $btn.closest( '.up-fix-item' );

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span>' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_apply_fix',
						nonce: upAdmin.nonce,
						audit_id: auditId
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( response.data.message, 'success' );

							// Update local fix status so subsequent renders reflect the change.
							if ( upAdmin.fix_status ) {
								upAdmin.fix_status[ auditId ] = true;
							}

							$btn.replaceWith(
								'<span class="up-badge up-badge--success">' +
								'<span class="dashicons dashicons-yes-alt" style="font-size:14px;width:14px;height:14px;margin-right:2px;"></span>' +
								( upAdmin.i18n.applied || 'Applied' ) +
								'</span>'
							);

							$item.addClass( 'up-fix-item--applied' );
							$item.find( '.up-fix-item__dot' ).css( 'background', '#059669' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
							$btn.prop( 'disabled', false ).text( label );
						}
					},
					error: function() {
						self.showToast( upAdmin.i18n.network_error, 'error' );
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});
		},

		/**
		 * Bind Static Site Generator controls.
		 *
		 * @since 1.2.0
		 */
		bindStaticSite: function() {
			var self = this;

			// --- Stepper +/- buttons ---
			$( document ).on( 'click', '.up-stepper__btn', function() {
				var targetId = $( this ).data( 'target' );
				var step     = parseInt( $( this ).data( 'step' ), 10 ) || 0;
				var $input   = $( '#' + targetId );

				if ( ! $input.length ) return;

				var current = parseInt( $input.val(), 10 ) || 0;
				var min     = parseInt( $input.attr( 'min' ), 10 ) || 0;
				var max     = parseInt( $input.attr( 'max' ), 10 ) || Infinity;
				var newVal  = current + step;

				if ( newVal >= min && newVal <= max ) {
					$input.val( newVal );
				}
			});

			// --- Tab switching ---
			$( document ).on( 'click', '.up-static-tabs__btn', function() {
				var tab = $( this ).data( 'tab' );
				$( '.up-static-tabs__btn' ).removeClass( 'up-static-tabs__btn--active' );
				$( this ).addClass( 'up-static-tabs__btn--active' );
				$( '.up-static-panel' ).removeClass( 'up-static-panel--active' );
				$( '.up-static-panel[data-panel="' + tab + '"]' ).addClass( 'up-static-panel--active' );
			});

			// --- Conditional field visibility ---
			$( document ).on( 'change', 'input[name="delivery_method"]', function() {
				$( '#up-field-output-dir' ).toggle( $( this ).val() === 'local_dir' );
			});

			$( document ).on( 'change', 'input[name="url_style"]', function() {
				$( '#up-field-base-url' ).toggle( $( this ).val() === 'absolute' );
			});

			// --- Sync include_types checkboxes to hidden field ---
			$( document ).on( 'change', '.up-include-type', function() {
				var types = [];
				$( '.up-include-type:checked' ).each( function() {
					types.push( $( this ).val() );
				});
				$( '#up-include-types' ).val( types.join( ',' ) );
			});

			// --- Shared helpers ---
			var $log = $( '#up-static-log' );

			function addLog( message, type ) {
				var time = new Date().toLocaleTimeString();
				var cls  = 'up-log-entry';
				if ( type === 'error' ) cls += ' up-log--error';
				if ( type === 'success' ) cls += ' up-log--success';
				$log.append( '<div class="' + cls + '">[' + time + '] ' + self.escHtml( message ) + '</div>' );
				$log.scrollTop( $log[0].scrollHeight );
			}

			function updatePipeline( $pipeline, phase ) {
				$pipeline.find( '.up-pipeline__step' )
					.removeClass( 'up-pipeline__step--active up-pipeline__step--done' );

				var phases = [];
				$pipeline.find( '.up-pipeline__step' ).each( function() {
					phases.push( $( this ).data( 'phase' ) );
				});

				var idx = phases.indexOf( phase );
				for ( var i = 0; i < idx; i++ ) {
					$pipeline.find( '.up-pipeline__step[data-phase="' + phases[i] + '"]' )
						.addClass( 'up-pipeline__step--done' );
				}
				if ( idx >= 0 ) {
					$pipeline.find( '.up-pipeline__step[data-phase="' + phase + '"]' )
						.addClass( 'up-pipeline__step--active' );
				}
				if ( phase === 'complete' ) {
					$pipeline.find( '.up-pipeline__step' ).addClass( 'up-pipeline__step--done' );
				}
			}

			// ==========================================
			// FULL SITE GENERATION
			// ==========================================
			var fullCancelled = false;

			$( document ).on( 'click', '#up-static-generate', function() {
				if ( ! confirm( upAdmin.i18n.confirm_generate || 'Generate a static copy of your site?' ) ) {
					return;
				}

				fullCancelled = false;
				var $btn     = $( this );
				var $cancel  = $( '#up-static-cancel' );
				var $pipeline = $( '#up-pipeline-full' );
				var $progress = $( '#up-static-progress' );
				var $bar      = $( '#up-static-bar' );
				var $status   = $( '#up-static-status' );

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span> ' + ( upAdmin.i18n.generating || 'Generating...' ) );
				$cancel.show();
				$pipeline.show();
				$progress.show();
				$bar.css( 'width', '0%' );
				$log.html( '' );
				addLog( 'Starting full site generation...' );

				function runPhase( phase ) {
					if ( fullCancelled ) return;
					updatePipeline( $pipeline, phase );

					$.ajax({
						url: upAdmin.ajax_url,
						type: 'POST',
						data: {
							action: 'up_static_generate',
							nonce: upAdmin.nonce,
							phase: phase
						},
						success: function( response ) {
							if ( ! response.success ) {
								addLog( response.data.message || upAdmin.i18n.error, 'error' );
								resetFullUI();
								return;
							}

							var data = response.data;
							addLog( data.message );

							if ( data.total > 0 && typeof data.remaining !== 'undefined' ) {
								var pct = Math.round( ( ( data.total - data.remaining ) / data.total ) * 100 );
								$bar.css( 'width', pct + '%' );
							}

							$status.text( data.message );

							if ( ! data.done ) {
								runPhase( phase );
							} else if ( data.next_phase ) {
								$bar.css( 'width', '0%' );
								runPhase( data.next_phase );
							} else {
								updatePipeline( $pipeline, 'complete' );
								$bar.css( 'width', '100%' );
								addLog( data.message, 'success' );
								if ( data.download_url ) {
									$status.html( '<a href="' + data.download_url + '" class="up-btn up-btn--primary">' +
										'<span class="dashicons dashicons-download"></span> Download ZIP</a>' );
								}
								resetFullUI();
								self.showToast( upAdmin.i18n.static_complete || 'Static site generated!', 'success' );
							}
						},
						error: function() {
							addLog( upAdmin.i18n.network_error, 'error' );
							resetFullUI();
						}
					});
				}

				function resetFullUI() {
					$btn.prop( 'disabled', false ).html(
						'<span class="dashicons dashicons-download"></span> ' +
						( upAdmin.i18n.generate_static || 'Generate Static Site' )
					);
					$cancel.hide();
				}

				runPhase( 'setup' );
			});

			$( document ).on( 'click', '#up-static-cancel', function() {
				fullCancelled = true;
				$.post( upAdmin.ajax_url, {
					action: 'up_static_cancel',
					nonce: upAdmin.nonce
				}, function( response ) {
					if ( response.success ) {
						addLog( response.data.message, 'success' );
						self.showToast( upAdmin.i18n.static_cancelled || 'Cancelled.', 'success' );
					}
				});
				$( '#up-static-generate' ).prop( 'disabled', false ).html(
					'<span class="dashicons dashicons-download"></span> ' +
					( upAdmin.i18n.generate_static || 'Generate Static Site' )
				);
				$( this ).hide();
			});

			// ==========================================
			// INDIVIDUAL PAGES
			// ==========================================
			var selectedPages = [];
			var searchTimer;
			var pagesCancelled = false;

			// Search with debounce.
			$( document ).on( 'input', '#up-static-search', function() {
				var q = $( this ).val();
				clearTimeout( searchTimer );

				if ( q.length < 2 ) {
					$( '#up-static-search-results' ).hide();
					return;
				}

				searchTimer = setTimeout( function() {
					$.post( upAdmin.ajax_url, {
						action: 'up_static_search_pages',
						nonce: upAdmin.nonce,
						search: q
					}, function( response ) {
						if ( ! response.success ) return;

						var $results = $( '#up-static-search-results' );
						$results.empty();

						if ( response.data.results.length === 0 ) {
							$results.html( '<div class="up-static-search__empty">' +
								( upAdmin.i18n.no_pages_found || 'No pages found.' ) + '</div>' );
						} else {
							$.each( response.data.results, function( i, page ) {
								// Skip already selected.
								var alreadySelected = false;
								$.each( selectedPages, function( j, sp ) {
									if ( sp.url === page.url ) alreadySelected = true;
								});
								if ( alreadySelected ) return;

								$results.append(
									'<div class="up-static-search__item" data-page=\'' + JSON.stringify( page ) + '\'>' +
										'<div class="up-static-search__title">' + self.escHtml( page.title ) +
											'<span class="up-static-search__badge">' + self.escHtml( page.post_type_label ) + '</span>' +
										'</div>' +
										'<div class="up-static-search__url">' + self.escHtml( page.url ) + '</div>' +
									'</div>'
								);
							});
						}

						$results.show();
					});
				}, 300 );
			});

			// Close search results when clicking outside.
			$( document ).on( 'click', function( e ) {
				if ( ! $( e.target ).closest( '.up-static-search' ).length ) {
					$( '#up-static-search-results' ).hide();
				}
			});

			// Select a page from results.
			$( document ).on( 'click', '.up-static-search__item', function() {
				var page = JSON.parse( $( this ).attr( 'data-page' ) );
				selectedPages.push( page );
				renderSelectedPages();
				$( '#up-static-search' ).val( '' );
				$( '#up-static-search-results' ).hide();
			});

			// Remove a selected page.
			$( document ).on( 'click', '.up-static-selected__remove', function() {
				var idx = $( this ).data( 'index' );
				selectedPages.splice( idx, 1 );
				renderSelectedPages();
			});

			function renderSelectedPages() {
				var $table = $( '#up-static-selected-table' );
				var $body  = $( '#up-static-selected-body' );
				var $hint  = $( '#up-static-selected-hint' );
				var $btn   = $( '#up-static-generate-pages' );

				if ( selectedPages.length === 0 ) {
					$table.hide();
					$hint.show();
					$btn.prop( 'disabled', true );
					return;
				}

				$hint.hide();
				$table.show();
				$btn.prop( 'disabled', false );
				$body.empty();

				$.each( selectedPages, function( i, page ) {
					$body.append(
						'<tr>' +
							'<td>' + self.escHtml( page.title ) + '</td>' +
							'<td style="font-size:11px;color:#94a3b8;word-break:break-all;">' + self.escHtml( page.url ) + '</td>' +
							'<td><span class="up-static-search__badge">' + self.escHtml( page.post_type_label ) + '</span></td>' +
							'<td><button type="button" class="up-static-selected__remove" data-index="' + i + '">&times;</button></td>' +
						'</tr>'
					);
				});
			}

			// Generate selected pages.
			$( document ).on( 'click', '#up-static-generate-pages', function() {
				if ( selectedPages.length === 0 ) return;

				pagesCancelled = false;
				var $btn      = $( this );
				var $cancel   = $( '#up-static-cancel-pages' );
				var $pipeline = $( '#up-pipeline-individual' );
				var $progress = $( '#up-static-pages-progress' );
				var $bar      = $( '#up-static-pages-bar' );
				var $status   = $( '#up-static-pages-status' );

				var urls = $.map( selectedPages, function( p ) { return p.url; } );

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span> ' + ( upAdmin.i18n.generating || 'Generating...' ) );
				$cancel.show();
				$pipeline.show();
				$progress.show();
				$bar.css( 'width', '0%' );
				$log.html( '' );
				addLog( 'Starting generation for ' + selectedPages.length + ' selected page(s)...' );

				function runPhase( phase ) {
					if ( pagesCancelled ) return;
					updatePipeline( $pipeline, phase );

					var postData = {
						action: 'up_static_generate_pages',
						nonce: upAdmin.nonce,
						phase: phase
					};

					// Include URLs only in setup phase.
					if ( phase === 'setup' ) {
						postData.urls = urls;
					}

					$.ajax({
						url: upAdmin.ajax_url,
						type: 'POST',
						data: postData,
						success: function( response ) {
							if ( ! response.success ) {
								addLog( response.data.message || upAdmin.i18n.error, 'error' );
								resetPagesUI();
								return;
							}

							var data = response.data;
							addLog( data.message );

							if ( data.total > 0 && typeof data.remaining !== 'undefined' ) {
								var pct = Math.round( ( ( data.total - data.remaining ) / data.total ) * 100 );
								$bar.css( 'width', pct + '%' );
							}

							$status.text( data.message );

							if ( ! data.done ) {
								runPhase( phase );
							} else if ( data.next_phase ) {
								$bar.css( 'width', '0%' );
								runPhase( data.next_phase );
							} else {
								updatePipeline( $pipeline, 'complete' );
								$bar.css( 'width', '100%' );
								addLog( data.message, 'success' );
								if ( data.download_url ) {
									$status.html( '<a href="' + data.download_url + '" class="up-btn up-btn--primary">' +
										'<span class="dashicons dashicons-download"></span> Download ZIP</a>' );
								}
								resetPagesUI();
								self.showToast( upAdmin.i18n.static_complete || 'Static site generated!', 'success' );
							}
						},
						error: function() {
							addLog( upAdmin.i18n.network_error, 'error' );
							resetPagesUI();
						}
					});
				}

				function resetPagesUI() {
					$btn.prop( 'disabled', selectedPages.length === 0 ).html(
						'<span class="dashicons dashicons-download"></span> ' +
						( upAdmin.i18n.generate_selected || 'Generate Selected Pages' )
					);
					$cancel.hide();
				}

				runPhase( 'setup' );
			});

			$( document ).on( 'click', '#up-static-cancel-pages', function() {
				pagesCancelled = true;
				$.post( upAdmin.ajax_url, {
					action: 'up_static_cancel',
					nonce: upAdmin.nonce
				}, function( response ) {
					if ( response.success ) {
						addLog( response.data.message, 'success' );
						self.showToast( upAdmin.i18n.static_cancelled || 'Cancelled.', 'success' );
					}
				});
				$( '#up-static-generate-pages' ).prop( 'disabled', selectedPages.length === 0 ).html(
					'<span class="dashicons dashicons-download"></span> ' +
					( upAdmin.i18n.generate_selected || 'Generate Selected Pages' )
				);
				$( this ).hide();
			});

			// ==========================================
			// STATIC SERVING
			// ==========================================

			// Toggle sub-options visibility based on enable checkbox.
			$( '#up-serve-enabled' ).on( 'change', function() {
				$( '#up-serve-options' ).toggle( this.checked );
				updateServeStatus();
			});

			// Load serve status on page load.
			function updateServeStatus() {
				$.post( upAdmin.ajax_url, {
					action: 'up_static_status',
					nonce: upAdmin.nonce
				}, function( response ) {
					if ( response.success ) {
						var $status   = $( '#up-serve-status' );
						var count     = response.data.serve_count || 0;
						var isEnabled = $( '#up-serve-enabled' ).is( ':checked' );

						if ( count > 0 && isEnabled ) {
							$status.removeClass( 'up-serve-status--inactive' )
								.addClass( 'up-serve-status--active' )
								.text( ( upAdmin.i18n.serving_pages || 'Serving %d static page(s)' ).replace( '%d', count ) );
						} else if ( count > 0 ) {
							$status.removeClass( 'up-serve-status--active' )
								.addClass( 'up-serve-status--inactive' )
								.text( ( upAdmin.i18n.pages_ready || '%d page(s) ready to serve' ).replace( '%d', count ) );
						} else {
							$status.removeClass( 'up-serve-status--active' )
								.addClass( 'up-serve-status--inactive' )
								.text( upAdmin.i18n.no_pages_serving || 'No pages available for serving. Generate pages first.' );
						}
					}
				});
			}

			if ( $( '#up-serve-status' ).length ) {
				updateServeStatus();
			}

			// Save serve settings.
			$( document ).on( 'click', '#up-save-serve-settings', function() {
				var $btn = $( this );
				$btn.prop( 'disabled', true );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_save_settings',
						nonce: upAdmin.nonce,
						module: 'static_site',
						settings: {
							serve_enabled: $( '#up-serve-enabled' ).is( ':checked' ) ? '1' : '',
							serve_logged_in: $( '#up-serve-logged-in' ).is( ':checked' ) ? '1' : '',
							serve_exclude_urls: $( '#up-serve-exclude' ).val() || ''
						}
					},
					success: function( response ) {
						$btn.prop( 'disabled', false );
						if ( response.success ) {
							self.showToast( upAdmin.i18n.serve_saved || 'Serve settings saved.', 'success' );
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						$btn.prop( 'disabled', false );
						self.showToast( upAdmin.i18n.network_error, 'error' );
					}
				});
			});

			// Purge served files.
			$( document ).on( 'click', '#up-purge-serve', function() {
				if ( ! confirm( upAdmin.i18n.confirm_purge_serve || 'This will delete all served static files. Continue?' ) ) {
					return;
				}

				var $btn = $( this );
				$btn.prop( 'disabled', true );

				$.post( upAdmin.ajax_url, {
					action: 'up_static_purge_serve',
					nonce: upAdmin.nonce
				}, function( response ) {
					$btn.prop( 'disabled', false );
					if ( response.success ) {
						self.showToast( upAdmin.i18n.serve_purged || 'Served files purged.', 'success' );
						updateServeStatus();
					} else {
						self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
					}
				}).fail( function() {
					$btn.prop( 'disabled', false );
					self.showToast( upAdmin.i18n.network_error, 'error' );
				});
			});
		},

		/**
		 * Bind API key mask Change / Remove buttons.
		 */
		/**
		 * Bind AI Assistant page controls.
		 *
		 * @since 1.4.0
		 */
		bindAiAssistant: function() {
			var self = this;

			// --- Test Connection ---
			$( document ).on( 'click', '.up-ai-test-connection', function() {
				var $btn     = $( this );
				var provider = $btn.data( 'provider' );
				var label    = $btn.text();
				var $status  = $( '.up-ai-connection-status[data-provider="' + provider + '"]' );

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner"></span> ' + ( upAdmin.i18n.testing_connection || 'Testing...' ) );
				$status.text( '' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_ai_test_connection',
						nonce: upAdmin.nonce,
						provider: provider
					},
					timeout: 30000,
					success: function( response ) {
						if ( response.success ) {
							$status.html( '<span style="color: var(--up-success);">&#10003; ' + self.escHtml( response.data.message ) + '</span>' );
							self.showToast( response.data.message, 'success' );
						} else {
							$status.html( '<span style="color: var(--up-danger);">&#10007; ' + self.escHtml( response.data.message ) + '</span>' );
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					},
					error: function() {
						$status.html( '<span style="color: var(--up-danger);">&#10007; ' + upAdmin.i18n.network_error + '</span>' );
						self.showToast( upAdmin.i18n.network_error, 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});

			// --- Load speed test reports into selector ---
			if ( $( '#up-ai-report-select' ).length ) {
				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_load_speed_reports',
						nonce: upAdmin.nonce
					},
					success: function( response ) {
						if ( response.success && response.data.reports ) {
							var $select = $( '#up-ai-report-select' );
							$.each( response.data.reports, function( i, report ) {
								if ( report.strategy === 'quick' ) return;
								var lbl = '#' + report.id + ' - ' + report.url + ' (' + report.strategy + ') - Score: ' + ( report.performance_score || 'N/A' ) + ' - ' + report.created_at;
								$select.append( '<option value="' + report.id + '">' + self.escHtml( lbl ) + '</option>' );
							});
						}
					}
				});

				$( '#up-ai-report-select' ).on( 'change', function() {
					$( '#up-ai-analyze-report' ).prop( 'disabled', ! $( this ).val() );
				});
			}

			// --- Analyze Speed Test with AI ---
			$( document ).on( 'click', '#up-ai-analyze-report', function() {
				var $btn      = $( this );
				var reportId  = $( '#up-ai-report-select' ).val();
				var label     = $btn.text();
				var $results  = $( '#up-ai-speed-analysis' );

				if ( ! reportId ) {
					self.showToast( upAdmin.i18n.ai_select_report || 'Please select a report.', 'error' );
					return;
				}

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + ( upAdmin.i18n.ai_analyzing || 'Analyzing...' ) );
				$results.html( '<p style="color: var(--up-gray-500); text-align: center; padding: 20px;">' + ( upAdmin.i18n.ai_analyzing || 'Analyzing...' ) + '</p>' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_ai_analyze_speed_test',
						nonce: upAdmin.nonce,
						report_id: reportId
					},
					timeout: 120000,
					success: function( response ) {
						if ( response.success ) {
							$results.html( self.renderAiReport( response.data ) );
						} else {
							$results.html( '<p style="color: var(--up-danger); padding: 12px;">' + self.escHtml( response.data.message || upAdmin.i18n.error ) + '</p>' );
						}
					},
					error: function() {
						$results.html( '<p style="color: var(--up-danger); padding: 12px;">' + upAdmin.i18n.network_error + '</p>' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( label );
					}
				});
			});

			// --- Scan Website ---
			$( document ).on( 'click', '#up-ai-scan-website', function() {
				var $btn     = $( this );
				var url      = $( '#up-ai-scan-url' ).val();
				var label    = $btn.html();
				var $results = $( '#up-ai-scan-results' );

				if ( ! url ) {
					self.showToast( upAdmin.i18n.enter_url, 'error' );
					return;
				}

				$btn.prop( 'disabled', true ).html( '<span class="up-spinner up-spinner--white"></span> ' + ( upAdmin.i18n.ai_scanning || 'Scanning...' ) );
				$results.html( '<p style="color: var(--up-gray-500); text-align: center; padding: 20px;">' + ( upAdmin.i18n.ai_scan_hint || 'Fetching page data and analyzing with AI. This may take up to 60 seconds...' ) + '</p>' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_ai_scan_website',
						nonce: upAdmin.nonce,
						url: url
					},
					timeout: 120000,
					success: function( response ) {
						if ( response.success ) {
							$results.html( self.renderAiReport( response.data, true ) );
							self.loadAiReports();
						} else {
							$results.html( '<p style="color: var(--up-danger); padding: 12px;">' + self.escHtml( response.data.message || upAdmin.i18n.error ) + '</p>' );
						}
					},
					error: function() {
						$results.html( '<p style="color: var(--up-danger); padding: 12px;">' + upAdmin.i18n.network_error + '</p>' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).html( label );
					}
				});
			});

			// --- Load saved AI reports ---
			if ( $( '#up-ai-saved-reports' ).length ) {
				self.loadAiReports();
			}

			// --- Delete AI report ---
			$( document ).on( 'click', '.up-ai-delete-report', function( e ) {
				e.stopPropagation();
				var $btn     = $( this );
				var reportId = $btn.data( 'report-id' );

				if ( ! confirm( upAdmin.i18n.ai_confirm_delete || 'Are you sure you want to delete this report?' ) ) {
					return;
				}

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_ai_delete_report',
						nonce: upAdmin.nonce,
						report_id: reportId
					},
					success: function( response ) {
						if ( response.success ) {
							self.showToast( upAdmin.i18n.ai_report_deleted || 'Report deleted.', 'success' );
							self.loadAiReports();
						} else {
							self.showToast( response.data.message || upAdmin.i18n.error, 'error' );
						}
					}
				});
			});

			// --- Searchable Model Selects ---
			self.initModelSelects();

			// --- Refresh/Fetch Models ---
			$( document ).on( 'click', '.up-ai-refresh-models', function() {
				var $btn     = $( this );
				var provider = $btn.data( 'provider' );
				var $icon    = $btn.find( '.dashicons' );

				$btn.prop( 'disabled', true );
				$icon.addClass( 'up-spin' );

				self.fetchProviderModels( provider, true, function() {
					$btn.prop( 'disabled', false );
					$icon.removeClass( 'up-spin' );
				});
			});
		},

		/**
		 * Render an AI analysis report.
		 *
		 * @since  1.4.0
		 * @param  {Object}  data       AI response data.
		 * @param  {boolean} showScanData Whether to show raw scan data summary.
		 * @return {string}  HTML string.
		 */
		renderAiReport: function( data, showScanData ) {
			var self = this;
			var html = '<div class="up-ai-report">';

			// Summary banner.
			var scoreClass = 'up-ai-report__summary--warning';
			if ( data.score_label === 'good' ) scoreClass = 'up-ai-report__summary--success';
			if ( data.score_label === 'poor' ) scoreClass = 'up-ai-report__summary--danger';

			html += '<div class="up-ai-report__summary ' + scoreClass + '">';
			html += '<span class="dashicons dashicons-lightbulb" style="margin-right: 8px; line-height: 1.4;"></span>';
			html += '<span>' + self.escHtml( data.summary || 'Analysis complete.' ) + '</span>';
			html += '</div>';

			// Scan data summary (for website scans).
			if ( showScanData && data.scan_data ) {
				var sd = data.scan_data;
				html += '<div class="up-ai-scan-summary" style="padding: 12px; background: var(--up-gray-50, #f8fafc); border-radius: 6px; margin: 12px 0; font-size: 13px;">';
				html += '<strong>Scan Summary:</strong> ';
				html += 'HTML size: ' + Math.round( ( sd.html_size || 0 ) / 1024 ) + ' KB';
				html += ' &middot; Compression: ' + self.escHtml( sd.compression || 'none' );
				if ( sd.html_analysis ) {
					html += ' &middot; Scripts: ' + ( sd.html_analysis.total_scripts || 0 );
					html += ' &middot; Images: ' + ( sd.html_analysis.total_images || 0 );
				}
				if ( sd.static_asset_headers && sd.static_asset_headers['cache-control'] ) {
					html += ' &middot; Static cache: ' + self.escHtml( sd.static_asset_headers['cache-control'] );
				}
				if ( data.has_psi ) {
					html += ' &middot; <span style="color: var(--up-success, #10b981);">PSI data included</span>';
				}
				html += '</div>';
			}

			// If raw response (AI didn't return JSON), display as text with debug info.
			if ( data.raw ) {
				html += '<div style="padding: 16px;">';
				html += '<p style="color: var(--up-danger, #ef4444); font-size: 13px; margin: 0 0 8px;">JSON parsing failed — the AI response could not be parsed into structured format.</p>';
				if ( data._parse_error ) {
					html += '<p style="color: var(--up-gray-500, #6b7280); font-size: 12px; margin: 0 0 8px;">Parse error: ' + self.escHtml( data._parse_error ) + '</p>';
				}
				html += '<p style="color: var(--up-gray-500, #6b7280); font-size: 12px; margin: 0 0 12px;">Please try scanning again. If this persists, try switching to a different AI model.</p>';
				if ( data.summary ) {
					html += '<details style="margin-top: 8px;"><summary style="cursor: pointer; font-size: 12px; color: var(--up-gray-400);">Raw AI Response</summary>';
					html += '<pre style="font-size: 11px; max-height: 300px; overflow: auto; background: var(--up-gray-50, #f8fafc); padding: 8px; border-radius: 4px; margin-top: 6px; white-space: pre-wrap; word-break: break-all;">' + self.escHtml( data.summary ) + '</pre>';
					html += '</details>';
				}
				html += '</div>';
				html += '</div>';
				return html;
			}

			// Categorized recommendations.
			var categories = data.categories || [];

			if ( categories.length === 0 ) {
				html += '<div style="padding: 16px; text-align: center;">';
				html += '<p style="color: var(--up-warning, #f59e0b); font-size: 13px; margin: 0 0 8px;">No specific recommendations were generated.</p>';
				html += '<p style="color: var(--up-gray-500, #6b7280); font-size: 12px; margin: 0;">The AI returned a valid response but with no categorized issues. Try running the scan again.</p>';
				if ( data._debug_raw ) {
					html += '<details style="margin-top: 12px; text-align: left;"><summary style="cursor: pointer; font-size: 12px; color: var(--up-gray-400);">Debug: Raw AI Response</summary>';
					html += '<pre style="font-size: 11px; max-height: 200px; overflow: auto; background: var(--up-gray-50); padding: 8px; border-radius: 4px; margin-top: 6px; white-space: pre-wrap; word-break: break-all;">' + self.escHtml( data._debug_raw ) + '</pre>';
					html += '</details>';
				}
				html += '</div>';
			}

			for ( var i = 0; i < categories.length; i++ ) {
				var cat = categories[i];
				html += '<div class="up-ai-category" style="margin: 16px 0;">';
				html += '<h4 style="font-size: 14px; font-weight: 600; margin: 0 0 8px; display: flex; align-items: center; gap: 6px;">';
				html += '<span class="dashicons ' + self.escHtml( cat.icon || 'dashicons-admin-generic' ) + '" style="font-size: 16px; width: 16px; height: 16px; color: var(--up-primary, #6366f1);"></span>';
				html += self.escHtml( cat.name );
				html += '</h4>';

				var items = cat.items || [];
				for ( var j = 0; j < items.length; j++ ) {
					var item = items[j];
					var impactColor = item.impact === 'high' ? 'var(--up-danger, #ef4444)' : ( item.impact === 'medium' ? 'var(--up-warning, #f59e0b)' : 'var(--up-gray-300, #d1d5db)' );

					html += '<div class="up-ai-item" style="padding: 8px 12px; border-left: 3px solid ' + impactColor + '; background: var(--up-gray-50, #f8fafc); border-radius: 0 4px 4px 0; margin-bottom: 6px;">';
					html += '<div style="font-size: 13px; font-weight: 500;">' + self.escHtml( item.issue ) + '</div>';
					html += '<div style="font-size: 12px; color: var(--up-gray-500, #6b7280); margin-top: 2px;">' + self.escHtml( item.fix ) + '</div>';

					if ( item.code ) {
						html += '<pre class="up-ai-code" style="background: var(--up-gray-800, #1f2937); color: #e5e7eb; padding: 8px 12px; border-radius: 4px; font-size: 12px; margin-top: 6px; overflow-x: auto; white-space: pre-wrap; word-break: break-all; font-family: \'SF Mono\', Monaco, Consolas, monospace;">' + self.escHtml( item.code ) + '</pre>';
					}

					if ( item.module ) {
						html += '<span class="up-badge" style="font-size: 11px; margin-top: 4px; display: inline-block;">' + self.escHtml( item.module.replace( /_/g, ' ' ) ) + '</span>';
					}

					html += '</div>';
				}

				html += '</div>';
			}

			html += '</div>';
			return html;
		},

		/**
		 * Initialize searchable model select dropdowns.
		 *
		 * @since 1.4.0
		 */
		initModelSelects: function() {
			var self = this;

			$( '.up-model-select' ).each( function() {
				var $wrap    = $( this );
				var provider = $wrap.data( 'provider' );
				var $search  = $wrap.find( '.up-model-select__search' );
				var $dropdown = $wrap.find( '.up-model-select__dropdown' );
				var $hidden  = $wrap.find( 'input[type="hidden"]' );

				// Build initial options from static models.
				var staticModels = ( upAdmin.ai_models && upAdmin.ai_models[ provider ] ) ? upAdmin.ai_models[ provider ] : {};
				var models = [];
				$.each( staticModels, function( id, label ) {
					models.push({ id: id, name: label });
				});

				$wrap.data( 'models', models );
				self._renderModelDropdown( $wrap );

				// Show dropdown on focus/click.
				$search.on( 'focus click', function( e ) {
					e.stopPropagation();
					$( '.up-model-select__dropdown' ).not( $dropdown ).hide();
					self._filterModelDropdown( $wrap );
					$dropdown.show();
				});

				// Filter on typing, also update hidden input for free-text.
				$search.on( 'input', function() {
					$hidden.val( $search.val() );
					self._filterModelDropdown( $wrap );
					$dropdown.show();
				});

				// Select option.
				$dropdown.on( 'click', '.up-model-select__option', function() {
					var id   = $( this ).data( 'id' );
					var name = $( this ).data( 'name' );
					$search.val( id );
					$hidden.val( id );
					$dropdown.hide();
				});

				// Keyboard navigation.
				$search.on( 'keydown', function( e ) {
					if ( e.key === 'Escape' ) {
						$dropdown.hide();
						$search.blur();
					} else if ( e.key === 'ArrowDown' || e.key === 'ArrowUp' ) {
						e.preventDefault();
						var $visible = $dropdown.find( '.up-model-select__option:visible' );
						var $active  = $dropdown.find( '.up-model-select__option--highlight' );
						var idx      = $visible.index( $active );

						$visible.removeClass( 'up-model-select__option--highlight' );
						if ( e.key === 'ArrowDown' ) {
							idx = ( idx + 1 ) % $visible.length;
						} else {
							idx = idx <= 0 ? $visible.length - 1 : idx - 1;
						}
						var $next = $visible.eq( idx ).addClass( 'up-model-select__option--highlight' );
						// Scroll into view.
						if ( $next.length ) {
							$next[0].scrollIntoView({ block: 'nearest' });
						}
					} else if ( e.key === 'Enter' ) {
						e.preventDefault();
						var $highlighted = $dropdown.find( '.up-model-select__option--highlight:visible' );
						if ( $highlighted.length ) {
							$highlighted.trigger( 'click' );
						}
					}
				});

				// Auto-fetch if API key is present.
				var keyField = provider + '_api_key';
				var $keyInput = $wrap.closest( '.up-ai-provider-card' ).find( 'input[name="' + keyField + '"]' );
				if ( $keyInput.length && $keyInput.val() ) {
					self.fetchProviderModels( provider, false );
				}
			});

			// Close dropdowns on outside click.
			$( document ).on( 'click', function( e ) {
				if ( ! $( e.target ).closest( '.up-model-select' ).length ) {
					$( '.up-model-select__dropdown' ).hide();
				}
			});
		},

		/**
		 * Render model dropdown options.
		 *
		 * @since 1.4.0
		 * @param {jQuery} $wrap The .up-model-select wrapper.
		 */
		_renderModelDropdown: function( $wrap ) {
			var models   = $wrap.data( 'models' ) || [];
			var $dropdown = $wrap.find( '.up-model-select__dropdown' );
			var current  = $wrap.find( 'input[type="hidden"]' ).val();
			var html     = '';

			if ( ! models.length ) {
				html = '<div class="up-model-select__empty">No models available. Click refresh to fetch.</div>';
			} else {
				for ( var i = 0; i < models.length; i++ ) {
					var m = models[i];
					var activeClass = ( m.id === current ) ? ' up-model-select__option--active' : '';
					html += '<div class="up-model-select__option' + activeClass + '" data-id="' + this.escHtml( m.id ) + '" data-name="' + this.escHtml( m.name ) + '">';
					html += '<span style="font-weight:500;">' + this.escHtml( m.id ) + '</span>';
					if ( m.name && m.name !== m.id ) {
						html += '<span style="color:var(--up-gray-400,#9ca3af);margin-left:6px;font-size:12px;">' + this.escHtml( m.name ) + '</span>';
					}
					html += '</div>';
				}
			}

			$dropdown.html( html );
		},

		/**
		 * Filter model dropdown based on search input.
		 *
		 * @since 1.4.0
		 * @param {jQuery} $wrap The .up-model-select wrapper.
		 */
		_filterModelDropdown: function( $wrap ) {
			var query = $wrap.find( '.up-model-select__search' ).val().toLowerCase();
			var $options = $wrap.find( '.up-model-select__option' );
			var visible = 0;

			$options.each( function() {
				var id   = ( $( this ).data( 'id' ) || '' ).toString().toLowerCase();
				var name = ( $( this ).data( 'name' ) || '' ).toString().toLowerCase();
				var match = ! query || id.indexOf( query ) !== -1 || name.indexOf( query ) !== -1;
				$( this ).toggle( match );
				if ( match ) visible++;
			});

			var $empty = $wrap.find( '.up-model-select__empty' );
			if ( visible === 0 && ! $empty.length ) {
				$wrap.find( '.up-model-select__dropdown' ).append(
					'<div class="up-model-select__empty">No models matching "' + this.escHtml( query ) + '"</div>'
				);
			} else if ( visible > 0 ) {
				$empty.remove();
			}
		},

		/**
		 * Fetch models from a provider API via AJAX.
		 *
		 * @since 1.4.0
		 * @param {string}   provider Provider key.
		 * @param {boolean}  force    Force refresh (bypass cache).
		 * @param {Function} callback Optional callback on complete.
		 */
		fetchProviderModels: function( provider, force, callback ) {
			var self = this;
			var $wrap = $( '.up-model-select[data-provider="' + provider + '"]' );

			$.ajax({
				url: upAdmin.ajax_url,
				type: 'POST',
				data: {
					action: 'up_ai_fetch_models',
					nonce: upAdmin.nonce,
					provider: provider,
					force: force ? 1 : 0
				},
				timeout: 30000,
				success: function( response ) {
					if ( response.success && response.data.models ) {
						var models = response.data.models;
						$wrap.data( 'models', models );
						self._renderModelDropdown( $wrap );
						self._filterModelDropdown( $wrap );

						if ( force ) {
							self.showToast(
								models.length + ' models loaded for ' + provider.charAt(0).toUpperCase() + provider.slice(1) + '.',
								'success'
							);
						}
					} else if ( response.data && response.data.message ) {
						if ( force ) {
							self.showToast( response.data.message, 'error' );
						}
					}
				},
				error: function() {
					if ( force ) {
						self.showToast( upAdmin.i18n.network_error, 'error' );
					}
				},
				complete: function() {
					if ( typeof callback === 'function' ) {
						callback();
					}
				}
			});
		},

		bindApiKeyMask: function() {
			// Generic Change button for any masked key field.
			$( document ).on( 'click', '.up-key-change', function() {
				var $wrapper    = $( this ).closest( '.up-api-key-masked' );
				var $hidden     = $wrapper.find( 'input[type="hidden"]' );
				var name        = $hidden.attr( 'name' );
				var id          = $hidden.attr( 'id' );
				var placeholder = $( this ).data( 'placeholder' ) || '';

				$wrapper.replaceWith(
					'<input type="text" name="' + name + '" id="' + id + '" class="up-input" value="" placeholder="' + placeholder + '">'
				);
				$( '#' + id ).focus();
			});

			// Generic Remove button for any masked key field.
			$( document ).on( 'click', '.up-key-remove', function() {
				var $wrapper    = $( this ).closest( '.up-api-key-masked' );
				var $hidden     = $wrapper.find( 'input[type="hidden"]' );
				var name        = $hidden.attr( 'name' );
				var id          = $hidden.attr( 'id' );
				var placeholder = $( this ).data( 'placeholder' ) || '';

				$wrapper.replaceWith(
					'<input type="text" name="' + name + '" id="' + id + '" class="up-input" value="" placeholder="' + placeholder + '">'
				);
				// Auto-submit the form to save the empty key.
				$( '#' + id ).closest( 'form' ).trigger( 'submit' );
			});
		},
		/**
		 * UCSS status panel and purge button.
		 */
		bindUCSS: function() {
			var $status = $( '#up-ucss-status' );
			var $purgeBtn = $( '#up-ucss-purge-btn' );

			if ( ! $status.length ) {
				return;
			}

			// Load UCSS status on page load.
			$.ajax({
				url: upAdmin.ajax_url,
				type: 'POST',
				data: {
					action: 'up_ucss_status',
					nonce: upAdmin.nonce
				},
				success: function( response ) {
					if ( response.success ) {
						var d = response.data;
						$status.html(
							'<strong>' + d.total_pages + '</strong> pages cached &mdash; ' +
							'<strong>' + d.savings_percent + '%</strong> CSS reduced ' +
							'(' + d.total_original + ' &rarr; ' + d.total_ucss + ')'
						);
					} else {
						$status.text( 'Unable to load UCSS status.' );
					}
				},
				error: function() {
					$status.text( 'Unable to load UCSS status.' );
				}
			});

			// Purge UCSS cache.
			$purgeBtn.on( 'click', function( e ) {
				e.preventDefault();
				var $btn = $( this );
				$btn.prop( 'disabled', true ).text( 'Purging...' );

				$.ajax({
					url: upAdmin.ajax_url,
					type: 'POST',
					data: {
						action: 'up_ucss_purge',
						nonce: upAdmin.nonce
					},
					success: function( response ) {
						if ( response.success ) {
							UP.showToast( response.data.message, 'success' );
							$status.html( '<strong>0</strong> pages cached &mdash; <strong>0%</strong> CSS reduced' );
						} else {
							UP.showToast( response.data.message || 'Purge failed.', 'error' );
						}
					},
					error: function() {
						UP.showToast( 'UCSS purge request failed.', 'error' );
					},
					complete: function() {
						$btn.prop( 'disabled', false ).text( 'Purge UCSS Cache' );
					}
				});
			});
		}
	};

	$( document ).ready( function() {
		UP.init();
	});

})( jQuery );
