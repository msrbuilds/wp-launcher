<?php
/**
 * Plugin Name:       Ultimate Performance
 * Plugin URI:        https://developer.wordpress.org/plugins/ultimate-performance/
 * Description:       A comprehensive WordPress performance optimization toolkit.
 * Version:           1.0.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Ultimate Performance Team
 * Author URI:        https://developer.wordpress.org/plugins/ultimate-performance/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ultimate-performance
 * Domain Path:       /languages
 *
 * @package Ultimate_Performance
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Plugin constants.
define( 'UP_VERSION', '1.0.1' );
define( 'UP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'UP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'UP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

if ( ! function_exists( 'ultimate_performance_fs' ) ) {
    // Create a helper function for easy SDK access.
    function ultimate_performance_fs() {
        global $ultimate_performance_fs;

        if ( ! isset( $ultimate_performance_fs ) ) {
            // Include Freemius SDK.
            require_once dirname( __FILE__ ) . '/vendor/freemius/start.php';

            $ultimate_performance_fs = fs_dynamic_init( array(
                'id'                  => '25104',
                'slug'                => 'ultimate-performance',
                'premium_slug'        => 'ultimate-performance',
                'type'                => 'plugin',
                'public_key'          => 'pk_97764fe81056ca2d444fd51ba8588',
                'is_premium'          => true,
                'is_premium_only'     => true,
                'has_addons'          => false,
                'has_paid_plans'      => true,
                'is_org_compliant'    => false,
                'trial'               => array(
                    'days'               => 3,
                    'is_require_payment' => true,
                ),
                'menu'                => array(
                    'slug'           => 'ultimate-performance',
                    'contact'        => false,
                    'support'        => false,
                ),
            ) );
        }

        return $ultimate_performance_fs;
    }

    // Init Freemius.
    ultimate_performance_fs();
    // Signal that SDK was initiated.
    do_action( 'ultimate_performance_fs_loaded' );

    // Hook uninstall cleanup to Freemius after_uninstall action.
    ultimate_performance_fs()->add_action( 'after_uninstall', 'ultimate_performance_fs_uninstall_cleanup' );
}
/**
 * Clean up all plugin data on uninstall.
 *
 * Hooked to the Freemius after_uninstall action so that
 * Freemius can track the uninstall event before cleanup runs.
 *
 * @since 1.0.0
 */
function ultimate_performance_fs_uninstall_cleanup() {
	global $wpdb;

	// Delete plugin options.
	delete_option( 'up_settings' );
	delete_option( 'up_version' );
	delete_option( 'up_db_version' );
	delete_option( 'up_ai_reports' );

	// Delete all transients with up_ prefix.
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Cleanup during uninstall; caching not applicable.
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_up_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_up_' ) . '%'
		)
	);
	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

	// Drop custom tables.
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange -- Required for clean uninstall.
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}up_speed_tests" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}up_image_optimization" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}up_static_pages" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}up_ucss_cache" );
	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange

	// Clean up post meta.
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Cleanup during uninstall; caching not applicable.
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
			$wpdb->esc_like( '_up_' ) . '%'
		)
	);
	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

	// Initialize WP_Filesystem for clean file removal.
	require_once ABSPATH . 'wp-admin/includes/file.php';
	WP_Filesystem();
	global $wp_filesystem;

	if ( $wp_filesystem ) {
		// Delete cache directory.
		$cache_dir = WP_CONTENT_DIR . '/cache/ultimate-performance';
		if ( $wp_filesystem->is_dir( $cache_dir ) ) {
			$wp_filesystem->delete( $cache_dir, true );
		}

		// Delete fonts directory.
		$fonts_dir = WP_CONTENT_DIR . '/fonts/ultimate-performance';
		if ( $wp_filesystem->is_dir( $fonts_dir ) ) {
			$wp_filesystem->delete( $fonts_dir, true );
		}

		// Delete static site output directory.
		$upload_dir = wp_upload_dir();
		$static_dir = $upload_dir['basedir'] . '/ultimate-performance/static-site';
		if ( $wp_filesystem->is_dir( $static_dir ) ) {
			$wp_filesystem->delete( $static_dir, true );
		}

		// Delete static serve directory.
		$serve_dir = $upload_dir['basedir'] . '/ultimate-performance/static-serve';
		if ( $wp_filesystem->is_dir( $serve_dir ) ) {
			$wp_filesystem->delete( $serve_dir, true );
		}

		// Delete any static site ZIP files.
		$plugin_upload_dir = $upload_dir['basedir'] . '/ultimate-performance';
		if ( $wp_filesystem->is_dir( $plugin_upload_dir ) ) {
			$zips = glob( $plugin_upload_dir . '/static-site-*.zip' );
			if ( $zips ) {
				foreach ( $zips as $zip ) {
					wp_delete_file( $zip );
				}
			}
		}
	}
}

// Include core classes.
require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-activator.php';
require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-deactivator.php';
require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance.php';

// Activation and deactivation.
register_activation_hook( __FILE__, array( 'Ultimate_Performance_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Ultimate_Performance_Deactivator', 'deactivate' ) );

/**
 * Begin plugin execution.
 *
 * @since 1.0.0
 */
function ultimate_performance_run() {
	$plugin = new Ultimate_Performance();
	$plugin->run();
}
ultimate_performance_run();
