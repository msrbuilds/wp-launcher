<?php
/**
 * Internationalization functionality.
 *
 * Since WordPress 4.6, translations for plugins hosted on WordPress.org
 * are loaded automatically. This class is kept as a stub for backward
 * compatibility with the plugin loader.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_I18n
 *
 * @since 1.0.0
 */
class Ultimate_Performance_I18n {

	/**
	 * No-op. Translations are loaded automatically by WordPress 4.6+.
	 *
	 * @since 1.0.0
	 */
	public function load_plugin_textdomain() {
		// Intentionally empty — WordPress.org handles translations automatically since WP 4.6.
	}
}
