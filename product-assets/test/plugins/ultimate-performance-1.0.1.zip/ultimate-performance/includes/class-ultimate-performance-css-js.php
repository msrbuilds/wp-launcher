<?php
/**
 * Handles CSS/JS optimization: minification, defer, delay, query string removal.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_CSS_JS
 *
 * Minifies CSS/JS/HTML, defers and delays JavaScript loading,
 * and removes query strings from static assets.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_CSS_JS {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Handles to exclude from defer.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $exclude_defer = array();

	/**
	 * Handles to exclude from delay.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $exclude_delay = array();

	/**
	 * Handles to exclude from async CSS loading.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $exclude_async_css = array();

	/**
	 * Handles to exclude from CSS minification.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $exclude_minify_css = array();

	/**
	 * Handles to exclude from JS minification.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $exclude_minify_js = array();

	/**
	 * Pre-computed set of handles that must not be deferred.
	 *
	 * Built lazily on first call to get_non_deferrable_handles().
	 *
	 * @since 1.1.0
	 * @var   array|null
	 */
	private $non_deferrable = null;

	/**
	 * Default script handles that should never be deferred or delayed.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $default_exclude_handles = array(
		'jquery',
		'jquery-core',
		'jquery-migrate',
		'jquery-ui-*',
		'wp-*',
		'moment',
		'lodash',
		'react',
		'react-dom',
		'underscore',
		'backbone',
		'elementor-*',
		'eicons',
	);

	/**
	 * Initialize the CSS/JS optimization module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'css_js' );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		$this->parse_exclusions();
		$this->setup_minify_css();
		$this->setup_minify_js();
		$this->setup_minify_html();
		$this->setup_async_css();
		$this->setup_defer_js();
		$this->setup_delay_js();
		$this->setup_move_jquery_to_footer();
		$this->setup_remove_query_strings();
	}

	/**
	 * Parse exclusion textareas into arrays.
	 *
	 * @since 1.0.0
	 */
	private function parse_exclusions() {
		$this->exclude_defer      = $this->parse_textarea_lines( $this->settings['exclude_defer_js'] );
		$this->exclude_delay      = $this->parse_textarea_lines( $this->settings['exclude_delay_js'] );
		$this->exclude_async_css  = $this->parse_textarea_lines( $this->settings['exclude_async_css'] );
		$this->exclude_minify_css = $this->parse_textarea_lines( $this->settings['exclude_minify_css'] );
		$this->exclude_minify_js  = $this->parse_textarea_lines( $this->settings['exclude_minify_js'] );

		// Always exclude our own scripts and core essentials.
		$always_exclude = array_merge( $this->default_exclude_handles, array( 'up-instant-page', 'up-delay-js' ) );
		$this->exclude_defer = array_merge( $this->exclude_defer, $always_exclude );
		$this->exclude_delay = array_merge( $this->exclude_delay, $always_exclude );
	}

	/**
	 * Setup CSS minification.
	 *
	 * @since 1.0.0
	 */
	private function setup_minify_css() {
		if ( empty( $this->settings['minify_css'] ) ) {
			return;
		}

		add_filter( 'style_loader_tag', array( $this, 'minify_css_tag' ), 10, 4 );
	}

	/**
	 * Minify a CSS file via the style_loader_tag filter.
	 *
	 * @since  1.0.0
	 * @param  string $tag    The link tag HTML.
	 * @param  string $handle The stylesheet handle.
	 * @param  string $href   The stylesheet URL.
	 * @param  string $media  The stylesheet media attribute.
	 * @return string Modified tag.
	 */
	public function minify_css_tag( $tag, $handle, $href, $media ) {
		if ( is_admin() ) {
			return $tag;
		}

		// Skip excluded handles.
		if ( $this->is_excluded_handle( $handle, $this->exclude_minify_css ) ) {
			return $tag;
		}

		$local_path = $this->url_to_local_path( $href );
		if ( ! $local_path || ! file_exists( $local_path ) ) {
			return $tag;
		}

		$cache_key = md5( $local_path . filemtime( $local_path ) );

		// Serve from cache if already minified.
		if ( $this->cached_file_exists( $cache_key, 'css' ) ) {
			$cached_url = Ultimate_Performance_Minifier::get_cache_url() . $cache_key . '.css';
			return str_replace( $href, $cached_url, $tag );
		}

		// Read, minify, and cache.
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$css = file_get_contents( $local_path );
		if ( false === $css || empty( $css ) ) {
			return $tag;
		}

		// Rewrite relative URLs to absolute before moving to cache directory.
		$css = $this->resolve_css_urls( $css, $local_path );

		$minified   = Ultimate_Performance_Minifier::minify_css( $css );
		$cached_url = Ultimate_Performance_Minifier::get_cached_file( $minified, 'css', $cache_key );

		if ( ! $cached_url ) {
			return $tag;
		}

		return str_replace( $href, $cached_url, $tag );
	}

	/**
	 * Setup JS minification.
	 *
	 * @since 1.0.0
	 */
	private function setup_minify_js() {
		if ( empty( $this->settings['minify_js'] ) ) {
			return;
		}

		add_filter( 'script_loader_tag', array( $this, 'minify_js_tag' ), 10, 3 );
	}

	/**
	 * Minify a JS file via the script_loader_tag filter.
	 *
	 * @since  1.0.0
	 * @param  string $tag    The script tag HTML.
	 * @param  string $handle The script handle.
	 * @param  string $src    The script URL.
	 * @return string Modified tag.
	 */
	public function minify_js_tag( $tag, $handle, $src ) {
		if ( is_admin() ) {
			return $tag;
		}

		// Skip our own scripts.
		if ( 0 === strpos( $handle, 'up-' ) ) {
			return $tag;
		}

		// Skip excluded handles.
		if ( $this->is_excluded_handle( $handle, $this->exclude_minify_js ) ) {
			return $tag;
		}

		$local_path = $this->url_to_local_path( $src );
		if ( ! $local_path || ! file_exists( $local_path ) ) {
			return $tag;
		}

		// Skip already minified files.
		if ( preg_match( '/\.min\.js$/i', $local_path ) ) {
			return $tag;
		}

		$cache_key = md5( $local_path . filemtime( $local_path ) );

		if ( ! $this->cached_file_exists( $cache_key, 'js' ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$js = file_get_contents( $local_path );
			if ( false === $js || empty( $js ) ) {
				return $tag;
			}

			$minified   = Ultimate_Performance_Minifier::minify_js( $js );
			$cached_url = Ultimate_Performance_Minifier::get_cached_file( $minified, 'js', $cache_key );

			if ( ! $cached_url ) {
				return $tag;
			}
		} else {
			$cached_url = Ultimate_Performance_Minifier::get_cache_url() . $cache_key . '.js';
		}

		// Strip query string from original src for replacement.
		$src_no_qs = strtok( $src, '?' );
		$tag = str_replace( $src_no_qs, $cached_url, $tag );

		return $tag;
	}

	/**
	 * Setup HTML minification via output buffering.
	 *
	 * @since 1.0.0
	 */
	private function setup_minify_html() {
		if ( empty( $this->settings['minify_html'] ) ) {
			return;
		}

		add_action( 'template_redirect', array( $this, 'start_html_buffer' ), 999 );
	}

	/**
	 * Start output buffering for HTML minification.
	 *
	 * @since 1.0.0
	 */
	public function start_html_buffer() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}

		ob_start( array( $this, 'minify_html_output' ) );
	}

	/**
	 * Minify HTML output buffer callback.
	 *
	 * @since  1.0.0
	 * @param  string $html Raw HTML output.
	 * @return string Minified HTML.
	 */
	public function minify_html_output( $html ) {
		if ( empty( $html ) ) {
			return $html;
		}

		// Only minify HTML content type.
		$content_type = '';
		foreach ( headers_list() as $header ) {
			if ( stripos( $header, 'content-type:' ) === 0 ) {
				$content_type = $header;
				break;
			}
		}

		if ( $content_type && stripos( $content_type, 'text/html' ) === false ) {
			return $html;
		}

		return Ultimate_Performance_Minifier::minify_html( $html );
	}

	/**
	 * Setup asynchronous CSS loading.
	 *
	 * Uses the media="print" onload pattern to make stylesheets non-render-blocking.
	 * This eliminates the "Render blocking requests" PageSpeed warning for CSS files.
	 *
	 * @since 1.0.0
	 */
	private function setup_async_css() {
		if ( empty( $this->settings['async_css'] ) ) {
			return;
		}

		add_filter( 'style_loader_tag', array( $this, 'load_css_async' ), 30, 4 );
		add_action( 'wp_head', array( $this, 'output_async_css_fallback' ), 0 );
	}

	/**
	 * Convert stylesheet link tags to load asynchronously.
	 *
	 * Switches media to "print" and adds an onload handler to flip it to the
	 * original media value once loaded. Includes a noscript fallback.
	 *
	 * @since  1.0.0
	 * @param  string $tag    The link tag HTML.
	 * @param  string $handle The stylesheet handle.
	 * @param  string $href   The stylesheet URL.
	 * @param  string $media  The stylesheet media attribute.
	 * @return string Modified tag.
	 */
	public function load_css_async( $tag, $handle, $href, $media ) {
		if ( is_admin() ) {
			return $tag;
		}

		// Skip excluded handles.
		if ( $this->is_excluded_handle( $handle, $this->exclude_async_css ) ) {
			return $tag;
		}

		// Skip if already async or preloaded.
		if ( false !== strpos( $tag, 'onload=' ) || false !== strpos( $tag, 'rel="preload"' ) ) {
			return $tag;
		}

		// Only process stylesheet link tags.
		if ( false === strpos( $tag, 'rel=' ) || false === strpos( $tag, 'stylesheet' ) ) {
			return $tag;
		}

		$original_media = ! empty( $media ) ? $media : 'all';

		// Replace media with "print" and add onload to switch back.
		$async_tag = str_replace(
			"media='{$media}'",
			"media='print' onload=\"this.media='{$original_media}'\"",
			$tag
		);

		// Also handle double-quoted media attribute.
		if ( $async_tag === $tag ) {
			$async_tag = str_replace(
				"media=\"{$media}\"",
				"media=\"print\" onload=\"this.media='{$original_media}'\"",
				$tag
			);
		}

		// If no media attribute was found, inject before closing >.
		if ( $async_tag === $tag ) {
			$async_tag = str_replace(
				'/>',
				"media='print' onload=\"this.media='{$original_media}'\" />",
				$tag
			);
		}

		// Add noscript fallback so CSS still loads without JS.
		$noscript = '<noscript>' . $tag . '</noscript>';

		return $async_tag . $noscript;
	}

	/**
	 * Output a tiny inline script that ensures async CSS works even if onload fails.
	 *
	 * @since 1.0.0
	 */
	public function output_async_css_fallback() {
		if ( is_admin() ) {
			return;
		}
		// Fallback: after window load, flip any remaining print stylesheets.
		echo '<script>addEventListener("load",function(){var s=document.querySelectorAll("link[media=\'print\'][onload]");for(var i=0;i<s.length;i++)s[i].media=s[i].onload?s[i].media:s[i].getAttribute("data-media")||"all"});</script>' . "\n";
	}

	/**
	 * Setup JavaScript defer.
	 *
	 * @since 1.0.0
	 */
	private function setup_defer_js() {
		if ( empty( $this->settings['defer_js'] ) ) {
			return;
		}

		add_filter( 'script_loader_tag', array( $this, 'add_defer_attribute' ), 20, 3 );
	}

	/**
	 * Add defer attribute to script tags.
	 *
	 * @since  1.0.0
	 * @param  string $tag    The script tag HTML.
	 * @param  string $handle The script handle.
	 * @param  string $src    The script URL.
	 * @return string Modified tag.
	 */
	public function add_defer_attribute( $tag, $handle, $src ) {
		if ( is_admin() ) {
			return $tag;
		}

		// Skip if already has defer or async.
		if ( preg_match( '/\b(defer|async)\b/', $tag ) ) {
			return $tag;
		}

		// Skip inline scripts (no src).
		if ( empty( $src ) ) {
			return $tag;
		}

		// Check pre-computed non-deferrable set (exclusion list + inline data + full dep tree).
		$non_deferrable = $this->get_non_deferrable_handles();
		if ( isset( $non_deferrable[ $handle ] ) ) {
			return $tag;
		}

		return str_replace( ' src=', ' defer src=', $tag );
	}

	/**
	 * Setup moving jQuery and its dependencies to the footer.
	 *
	 * Moves jquery-core and jquery-migrate to the footer group so they
	 * no longer appear in <head> as render-blocking scripts. WordPress
	 * will automatically move any script that depends on jQuery to the
	 * footer as well, preserving correct execution order.
	 *
	 * @since 1.2.0
	 */
	private function setup_move_jquery_to_footer() {
		if ( empty( $this->settings['move_jquery_to_footer'] ) ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'move_jquery_to_footer' ), 9999 );
	}

	/**
	 * Move jQuery and all its dependents to the footer.
	 *
	 * WordPress's dependency system pulls scripts into the lowest group
	 * of their dependents. If ANY head-group script depends on jQuery,
	 * WordPress pulls jQuery back to the head — defeating our move.
	 *
	 * To prevent this, we walk the full dependency graph and move every
	 * script that directly or transitively depends on jQuery to the
	 * footer (group 1) as well.
	 *
	 * @since 1.2.0
	 */
	public function move_jquery_to_footer() {
		if ( is_admin() ) {
			return;
		}

		$wp_scripts = wp_scripts();

		if ( empty( $wp_scripts->registered ) ) {
			return;
		}

		// Core jQuery handles that must move to footer.
		$jquery_set = array( 'jquery' => true, 'jquery-core' => true, 'jquery-migrate' => true );

		// Find all scripts that directly or transitively depend on jQuery.
		$to_move = $jquery_set;
		$changed = true;

		while ( $changed ) {
			$changed = false;
			foreach ( $wp_scripts->registered as $handle => $script ) {
				if ( isset( $to_move[ $handle ] ) ) {
					continue;
				}
				foreach ( $script->deps as $dep ) {
					if ( isset( $to_move[ $dep ] ) ) {
						$to_move[ $handle ] = true;
						$changed            = true;
						break;
					}
				}
			}
		}

		// Move all identified handles to the footer group.
		foreach ( $to_move as $handle => $_ ) {
			if ( isset( $wp_scripts->registered[ $handle ] ) ) {
				$wp_scripts->add_data( $handle, 'group', 1 );
			}
		}
	}

	/**
	 * Setup JavaScript delay (load on user interaction).
	 *
	 * @since 1.0.0
	 */
	private function setup_delay_js() {
		if ( empty( $this->settings['delay_js'] ) ) {
			return;
		}

		add_filter( 'script_loader_tag', array( $this, 'delay_script_tag' ), 25, 3 );
		add_action( 'wp_footer', array( $this, 'output_delay_restore_script' ), 999 );
	}

	/**
	 * Replace script type to delay loading.
	 *
	 * @since  1.0.0
	 * @param  string $tag    The script tag HTML.
	 * @param  string $handle The script handle.
	 * @param  string $src    The script URL.
	 * @return string Modified tag.
	 */
	public function delay_script_tag( $tag, $handle, $src ) {
		if ( is_admin() ) {
			return $tag;
		}

		// Skip inline scripts.
		if ( empty( $src ) ) {
			return $tag;
		}

		// Use the same non-deferrable set for delay (same dependency risks).
		$non_deferrable = $this->get_non_deferrable_handles();
		if ( isset( $non_deferrable[ $handle ] ) ) {
			return $tag;
		}

		// Also check delay-specific exclusions from user settings.
		if ( $this->is_excluded_handle( $handle, $this->exclude_delay ) ) {
			return $tag;
		}

		// Change type to prevent execution and store original src.
		$tag = preg_replace( '/type=["\'][^"\']*["\']/', '', $tag );
		// phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Modifying existing enqueued script tag via script_loader_tag filter.
		$tag = str_replace( '<script ', '<script type="up-delay-js" data-up-src="' . esc_attr( $src ) . '" ', $tag );

		return $tag;
	}

	/**
	 * Output the script that restores delayed scripts on first interaction.
	 *
	 * @since 1.0.0
	 */
	public function output_delay_restore_script() {
		if ( is_admin() ) {
			return;
		}
		// phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Inline delay-restore script must be output directly.
		?>
		<script id="up-delay-js-restore">
		(function(){
			var events = ['mousemove','scroll','keydown','click','touchstart'];
			var loaded = false;

			function loadDelayed() {
				if (loaded) return;
				loaded = true;

				events.forEach(function(e) {
					document.removeEventListener(e, loadDelayed, {passive:true,capture:true});
				});

				var scripts = document.querySelectorAll('script[type="up-delay-js"]');
				scripts.forEach(function(old) {
					var s = document.createElement('script');
					var src = old.getAttribute('data-up-src');
					if (src) s.src = src;
					if (old.id) s.id = old.id;
					s.type = 'text/javascript';
					old.parentNode.replaceChild(s, old);
				});
			}

			events.forEach(function(e) {
				document.addEventListener(e, loadDelayed, {passive:true,capture:true});
			});
		})();
		</script>
		<?php
	}

	/**
	 * Setup query string removal from static assets.
	 *
	 * @since 1.0.0
	 */
	private function setup_remove_query_strings() {
		if ( empty( $this->settings['remove_query_strings'] ) ) {
			return;
		}

		add_filter( 'style_loader_src', array( $this, 'remove_query_string' ), 9999 );
		add_filter( 'script_loader_src', array( $this, 'remove_query_string' ), 9999 );
	}

	/**
	 * Remove version query strings from asset URLs.
	 *
	 * @since  1.0.0
	 * @param  string $src Asset URL.
	 * @return string URL without query string.
	 */
	public function remove_query_string( $src ) {
		if ( is_admin() ) {
			return $src;
		}

		if ( strpos( $src, '?ver=' ) !== false || strpos( $src, '&ver=' ) !== false ) {
			$src = remove_query_arg( 'ver', $src );
		}

		return $src;
	}

	/**
	 * Build the full set of handles that must not be deferred/delayed.
	 *
	 * Collects handles from:
	 * 1. The explicit exclusion list (including wildcard patterns).
	 * 2. Handles with inline before/after data (wp_add_inline_script).
	 * 3. All dependencies of the above (recursively).
	 *
	 * This ensures that if a non-deferrable script depends on script X,
	 * then X is also non-deferrable — preventing execution order issues.
	 *
	 * @since  1.1.0
	 * @return array Associative array of handle => true.
	 */
	private function get_non_deferrable_handles() {
		if ( null !== $this->non_deferrable ) {
			return $this->non_deferrable;
		}

		$wp_scripts = wp_scripts();
		$non_defer  = array();

		if ( empty( $wp_scripts->registered ) ) {
			$this->non_deferrable = $non_defer;
			return $non_defer;
		}

		// 1. Explicitly excluded handles.
		foreach ( $wp_scripts->registered as $handle => $script ) {
			if ( $this->is_excluded_handle( $handle, $this->exclude_defer ) ) {
				$non_defer[ $handle ] = true;
			}
		}

		// 2. Handles with inline before/after data.
		foreach ( $wp_scripts->registered as $handle => $script ) {
			$after  = $wp_scripts->get_data( $handle, 'after' );
			$before = $wp_scripts->get_data( $handle, 'before' );
			if ( ! empty( $after ) || ! empty( $before ) ) {
				$non_defer[ $handle ] = true;
			}
		}

		// 3. Recursively add all dependencies of non-deferrable handles.
		$changed = true;
		while ( $changed ) {
			$changed = false;
			foreach ( $non_defer as $handle => $_ ) {
				if ( ! isset( $wp_scripts->registered[ $handle ] ) ) {
					continue;
				}
				foreach ( $wp_scripts->registered[ $handle ]->deps as $dep ) {
					if ( ! isset( $non_defer[ $dep ] ) ) {
						$non_defer[ $dep ] = true;
						$changed           = true;
					}
				}
			}
		}

		$this->non_deferrable = $non_defer;
		return $non_defer;
	}

	/**
	 * Check if a script handle is in the exclusion list.
	 *
	 * @since  1.0.0
	 * @param  string $handle     Script handle.
	 * @param  array  $exclusions Exclusion list.
	 * @return bool
	 */
	private function is_excluded_handle( $handle, $exclusions ) {
		foreach ( $exclusions as $pattern ) {
			if ( $handle === $pattern ) {
				return true;
			}
			// Support partial matching (e.g., "wc-" matches "wc-cart").
			if ( substr( $pattern, -1 ) === '*' && 0 === strpos( $handle, rtrim( $pattern, '*' ) ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Parse a textarea value into an array of non-empty trimmed lines.
	 *
	 * @since  1.0.0
	 * @param  string $text Textarea value.
	 * @return array  Non-empty lines.
	 */
	private function parse_textarea_lines( $text ) {
		if ( empty( $text ) ) {
			return array();
		}

		$lines = preg_split( '/\r\n|\r|\n/', $text );
		$lines = array_map( 'trim', $lines );
		$lines = array_filter( $lines, 'strlen' );

		return array_values( $lines );
	}

	/**
	 * Resolve relative URLs in CSS to absolute paths.
	 *
	 * When CSS is moved to the cache directory, relative url() references
	 * (e.g., ../images/bg.png) would break. This converts them to absolute URLs.
	 *
	 * @since  1.0.0
	 * @param  string $css        CSS content.
	 * @param  string $local_path Absolute path to the original CSS file.
	 * @return string CSS with resolved URLs.
	 */
	public function resolve_css_urls( $css, $local_path ) {
		$css_dir  = dirname( $local_path );
		$abspath  = wp_normalize_path( ABSPATH );
		$css_dir  = wp_normalize_path( $css_dir );
		$site_url = site_url();

		return preg_replace_callback(
			'/url\(\s*[\'"]?\s*(?!data:|https?:|\/\/|#)([^\'"\)\s]+)[\'"]?\s*\)/i',
			function ( $matches ) use ( $css_dir, $abspath, $site_url ) {
				$relative = $matches[1];

				// Already absolute path.
				if ( 0 === strpos( $relative, '/' ) ) {
					return $matches[0];
				}

				// Strip query string / fragment for filesystem lookup.
				$clean    = preg_replace( '/[?#].*$/', '', $relative );
				$absolute = realpath( $css_dir . '/' . $clean );

				if ( ! $absolute ) {
					return $matches[0];
				}

				$absolute = wp_normalize_path( $absolute );

				if ( 0 !== strpos( $absolute, $abspath ) ) {
					return $matches[0];
				}

				$web_path = str_replace( $abspath, '/', $absolute );
				// Re-append query string / fragment if present.
				$suffix = substr( $relative, strlen( $clean ) );
				return 'url(' . $site_url . $web_path . $suffix . ')';
			},
			$css
		) ?? $css;
	}

	/**
	 * Convert a URL to a local file path.
	 *
	 * @since  1.0.0
	 * @param  string $url Asset URL.
	 * @return string|false Local file path or false if not local.
	 */
	public function url_to_local_path( $url ) {
		$site_url    = site_url();
		$content_url = content_url();

		// Strip query string.
		$url = strtok( $url, '?' );

		// Handle protocol-relative URLs.
		if ( 0 === strpos( $url, '//' ) ) {
			$url = 'https:' . $url;
		}

		// Check if URL is local.
		if ( 0 === strpos( $url, $site_url ) ) {
			$relative = str_replace( $site_url, '', $url );
			return ABSPATH . ltrim( $relative, '/' );
		}

		if ( 0 === strpos( $url, $content_url ) ) {
			$relative = str_replace( $content_url, '', $url );
			return WP_CONTENT_DIR . '/' . ltrim( $relative, '/' );
		}

		// Handle root-relative URLs.
		if ( 0 === strpos( $url, '/' ) ) {
			return ABSPATH . ltrim( $url, '/' );
		}

		return false;
	}

	/**
	 * Check if a cached file exists.
	 *
	 * @since  1.0.0
	 * @param  string $cache_key Cache key.
	 * @param  string $ext       File extension.
	 * @return bool
	 */
	private function cached_file_exists( $cache_key, $ext ) {
		return file_exists( Ultimate_Performance_Minifier::get_cache_dir() . $cache_key . '.' . $ext );
	}
}
