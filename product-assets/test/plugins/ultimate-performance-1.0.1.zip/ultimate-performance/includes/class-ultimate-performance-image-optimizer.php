<?php
/**
 * Image optimizer utility with CLI binary detection and fallback to GD.
 *
 * Detects available server-side image optimization tools (jpegoptim, pngquant,
 * optipng, cwebp, gifsicle) and routes compression through the best available
 * tool per format. Falls back to PHP GD when no CLI tools are found.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Image_Optimizer
 *
 * Static utility class — no init() needed.
 *
 * @since 1.1.0
 */
class Ultimate_Performance_Image_Optimizer {

	/**
	 * Cached tool detection results.
	 *
	 * @since 1.1.0
	 * @var   array|null
	 */
	private static $tools_cache = null;

	/**
	 * Tool definitions: binary name, version flag, and supported MIME types.
	 *
	 * @since 1.1.0
	 * @var   array
	 */
	private static $tool_definitions = array(
		'jpegoptim' => array(
			'label'   => 'jpegoptim',
			'binary'  => 'jpegoptim',
			'version' => '--version',
			'formats' => array( 'image/jpeg' ),
			'desc'    => 'Lossy/lossless JPEG optimizer',
		),
		'pngquant' => array(
			'label'   => 'pngquant',
			'binary'  => 'pngquant',
			'version' => '--version',
			'formats' => array( 'image/png' ),
			'desc'    => 'Lossy PNG compressor (quantization)',
		),
		'optipng' => array(
			'label'   => 'optipng',
			'binary'  => 'optipng',
			'version' => '--version',
			'formats' => array( 'image/png' ),
			'desc'    => 'Lossless PNG optimizer',
		),
		'cwebp' => array(
			'label'   => 'cwebp',
			'binary'  => 'cwebp',
			'version' => '-version',
			'formats' => array( 'image/jpeg', 'image/png' ),
			'desc'    => 'WebP encoder from Google',
		),
		'gifsicle' => array(
			'label'   => 'gifsicle',
			'binary'  => 'gifsicle',
			'version' => '--version',
			'formats' => array( 'image/gif' ),
			'desc'    => 'GIF optimizer and animator',
		),
	);

	/**
	 * Check whether PHP exec() is available and not disabled.
	 *
	 * @since  1.1.0
	 * @return bool
	 */
	public static function is_exec_available() {
		if ( ! function_exists( 'exec' ) ) {
			return false;
		}

		$disabled = ini_get( 'disable_functions' );
		if ( ! empty( $disabled ) ) {
			$disabled_list = array_map( 'trim', explode( ',', strtolower( $disabled ) ) );
			if ( in_array( 'exec', $disabled_list, true ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Detect available optimization tools on the server.
	 *
	 * Results are cached in a transient (1 hour) and in a static property
	 * for the duration of the request.
	 *
	 * @since  1.1.0
	 * @param  bool $force_refresh Bypass cache and re-detect.
	 * @return array Associative array of tool slug => detection result.
	 */
	public static function detect_tools( $force_refresh = false ) {
		if ( null !== self::$tools_cache && ! $force_refresh ) {
			return self::$tools_cache;
		}

		if ( ! $force_refresh ) {
			$cached = get_transient( 'up_image_tools' );
			if ( false !== $cached ) {
				self::$tools_cache = $cached;
				return $cached;
			}
		}

		$exec_available = self::is_exec_available();
		$tools          = array();

		foreach ( self::$tool_definitions as $slug => $def ) {
			$tools[ $slug ] = array(
				'label'     => $def['label'],
				'desc'      => $def['desc'],
				'formats'   => $def['formats'],
				'available' => false,
				'version'   => '',
				'path'      => '',
			);

			if ( ! $exec_available ) {
				continue;
			}

			// Try to find the binary path.
			$path = self::find_binary( $def['binary'] );
			if ( empty( $path ) ) {
				continue;
			}

			// Get version string.
			$version = self::get_binary_version( $path, $def['version'] );

			$tools[ $slug ]['available'] = true;
			$tools[ $slug ]['version']   = $version;
			$tools[ $slug ]['path']      = $path;
		}

		// Always check GD as a fallback.
		$tools['gd'] = array(
			'label'     => 'GD Library',
			'desc'      => 'PHP built-in image library (fallback)',
			'formats'   => array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ),
			'available' => extension_loaded( 'gd' ),
			'version'   => extension_loaded( 'gd' ) ? self::get_gd_version() : '',
			'path'      => 'PHP extension',
		);

		self::$tools_cache = $tools;
		set_transient( 'up_image_tools', $tools, HOUR_IN_SECONDS );

		return $tools;
	}

	/**
	 * Find the full path of a binary using `which` (Unix) or `where` (Windows).
	 *
	 * @since  1.1.0
	 * @param  string $binary Binary name.
	 * @return string Full path or empty string.
	 */
	private static function find_binary( $binary ) {
		$command = ( 'WIN' === strtoupper( substr( PHP_OS, 0, 3 ) ) )
			? 'where ' . escapeshellarg( $binary ) . ' 2>NUL'
			: 'which ' . escapeshellarg( $binary ) . ' 2>/dev/null';

		$output = array();
		$code   = 0;
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec -- CLI image optimization tools require exec(); all arguments use escapeshellarg().
		exec( $command, $output, $code );

		if ( 0 === $code && ! empty( $output[0] ) ) {
			return trim( $output[0] );
		}

		return '';
	}

	/**
	 * Get the version string from a binary.
	 *
	 * @since  1.1.0
	 * @param  string $path    Binary path.
	 * @param  string $flag    Version flag (e.g. --version).
	 * @return string Version string.
	 */
	private static function get_binary_version( $path, $flag ) {
		$output = array();
		$code   = 0;
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec -- CLI image optimization tools require exec(); all arguments use escapeshellarg().
		exec( escapeshellarg( $path ) . ' ' . $flag . ' 2>&1', $output, $code );

		if ( ! empty( $output[0] ) ) {
			// Extract version number from first line.
			$line = trim( $output[0] );
			if ( preg_match( '/(\d+[\.\d]+)/', $line, $m ) ) {
				return $m[1];
			}
			return $line;
		}

		return '';
	}

	/**
	 * Get the GD library version string.
	 *
	 * @since  1.1.0
	 * @return string
	 */
	private static function get_gd_version() {
		if ( function_exists( 'gd_info' ) ) {
			$info = gd_info();
			return isset( $info['GD Version'] ) ? $info['GD Version'] : '';
		}
		return '';
	}

	/**
	 * Compress an image file using the best available tool.
	 *
	 * @since  1.1.0
	 * @param  string $file_path Absolute path to the image file.
	 * @param  string $mime      MIME type of the image.
	 * @param  int    $quality   Quality level (1–100).
	 * @return array  Result with 'success', 'tool', 'original_size', 'new_size'.
	 */
	public static function compress( $file_path, $mime, $quality = 82 ) {
		if ( ! file_exists( $file_path ) ) {
			return array(
				'success'       => false,
				'tool'          => 'none',
				'original_size' => 0,
				'new_size'      => 0,
			);
		}

		$original_size = filesize( $file_path );
		$tools         = self::detect_tools();
		$quality       = max( 1, min( 100, (int) $quality ) );

		$result = array(
			'success'       => false,
			'tool'          => 'none',
			'original_size' => $original_size,
			'new_size'      => $original_size,
		);

		if ( 'image/jpeg' === $mime ) {
			$result = self::compress_jpeg( $file_path, $quality, $tools );
		} elseif ( 'image/png' === $mime ) {
			$result = self::compress_png( $file_path, $quality, $tools );
		} elseif ( 'image/gif' === $mime ) {
			$result = self::compress_gif( $file_path, $tools );
		}

		$result['original_size'] = $original_size;

		return $result;
	}

	/**
	 * Compress a JPEG file.
	 *
	 * Priority: jpegoptim > GD.
	 *
	 * @since  1.1.0
	 * @param  string $file_path File path.
	 * @param  int    $quality   Quality (1–100).
	 * @param  array  $tools     Detected tools.
	 * @return array  Result array.
	 */
	private static function compress_jpeg( $file_path, $quality, $tools ) {
		// Try jpegoptim first.
		if ( ! empty( $tools['jpegoptim']['available'] ) ) {
			$success = self::run_jpegoptim( $tools['jpegoptim']['path'], $file_path, $quality );
			if ( $success ) {
				clearstatcache( true, $file_path );
				return array(
					'success'  => true,
					'tool'     => 'jpegoptim',
					'new_size' => filesize( $file_path ),
				);
			}
		}

		// Fallback to GD.
		if ( ! empty( $tools['gd']['available'] ) && function_exists( 'imagecreatefromjpeg' ) ) {
			$image = @imagecreatefromjpeg( $file_path );
			if ( $image ) {
				imagejpeg( $image, $file_path, $quality );
				imagedestroy( $image );
				clearstatcache( true, $file_path );
				return array(
					'success'  => true,
					'tool'     => 'gd',
					'new_size' => filesize( $file_path ),
				);
			}
		}

		return array(
			'success'  => false,
			'tool'     => 'none',
			'new_size' => filesize( $file_path ),
		);
	}

	/**
	 * Compress a PNG file.
	 *
	 * Priority: pngquant (lossy) > optipng (lossless) > GD.
	 *
	 * @since  1.1.0
	 * @param  string $file_path File path.
	 * @param  int    $quality   Quality (1–100).
	 * @param  array  $tools     Detected tools.
	 * @return array  Result array.
	 */
	private static function compress_png( $file_path, $quality, $tools ) {
		$tool_used = 'none';
		$success   = false;

		// Try pngquant for lossy compression.
		if ( ! empty( $tools['pngquant']['available'] ) ) {
			$success = self::run_pngquant( $tools['pngquant']['path'], $file_path, $quality );
			if ( $success ) {
				$tool_used = 'pngquant';
			}
		}

		// Then optipng for additional lossless optimization.
		if ( ! empty( $tools['optipng']['available'] ) ) {
			$optipng_success = self::run_optipng( $tools['optipng']['path'], $file_path );
			if ( $optipng_success ) {
				$tool_used = $success ? 'pngquant+optipng' : 'optipng';
				$success   = true;
			}
		}

		if ( $success ) {
			clearstatcache( true, $file_path );
			return array(
				'success'  => true,
				'tool'     => $tool_used,
				'new_size' => filesize( $file_path ),
			);
		}

		// Fallback to GD.
		if ( ! empty( $tools['gd']['available'] ) && function_exists( 'imagecreatefrompng' ) ) {
			$image = @imagecreatefrompng( $file_path );
			if ( $image ) {
				$png_quality = (int) round( ( 100 - $quality ) * 9 / 100 );
				imagesavealpha( $image, true );
				imagepng( $image, $file_path, $png_quality );
				imagedestroy( $image );
				clearstatcache( true, $file_path );
				return array(
					'success'  => true,
					'tool'     => 'gd',
					'new_size' => filesize( $file_path ),
				);
			}
		}

		return array(
			'success'  => false,
			'tool'     => 'none',
			'new_size' => filesize( $file_path ),
		);
	}

	/**
	 * Optimize a GIF file.
	 *
	 * Uses gifsicle only — no GD fallback for GIF optimization.
	 *
	 * @since  1.1.0
	 * @param  string $file_path File path.
	 * @param  array  $tools     Detected tools.
	 * @return array  Result array.
	 */
	private static function compress_gif( $file_path, $tools ) {
		if ( ! empty( $tools['gifsicle']['available'] ) ) {
			$success = self::run_gifsicle( $tools['gifsicle']['path'], $file_path );
			if ( $success ) {
				clearstatcache( true, $file_path );
				return array(
					'success'  => true,
					'tool'     => 'gifsicle',
					'new_size' => filesize( $file_path ),
				);
			}
		}

		return array(
			'success'  => false,
			'tool'     => 'none',
			'new_size' => filesize( $file_path ),
		);
	}

	/**
	 * Create a WebP copy of an image using the best available tool.
	 *
	 * Priority: cwebp > GD.
	 *
	 * @since  1.1.0
	 * @param  string $source_path Source image path.
	 * @param  string $mime        Source MIME type.
	 * @param  int    $quality     WebP quality (1–100).
	 * @return string|false WebP file path or false on failure.
	 */
	public static function create_webp( $source_path, $mime, $quality = 80 ) {
		if ( ! file_exists( $source_path ) ) {
			return false;
		}

		$webp_path = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $source_path );
		$quality   = max( 1, min( 100, (int) $quality ) );
		$tools     = self::detect_tools();

		// Try cwebp first.
		if ( ! empty( $tools['cwebp']['available'] ) ) {
			$success = self::run_cwebp( $tools['cwebp']['path'], $source_path, $webp_path, $quality );
			if ( $success && file_exists( $webp_path ) ) {
				return $webp_path;
			}
		}

		// Fallback to GD.
		if ( ! empty( $tools['gd']['available'] ) && function_exists( 'imagewebp' ) ) {
			$image = false;

			if ( 'image/jpeg' === $mime ) {
				$image = @imagecreatefromjpeg( $source_path );
			} elseif ( 'image/png' === $mime ) {
				$image = @imagecreatefrompng( $source_path );
				if ( $image ) {
					imagepalettetotruecolor( $image );
					imagealphablending( $image, true );
					imagesavealpha( $image, true );
				}
			}

			if ( $image ) {
				$result = imagewebp( $image, $webp_path, $quality );
				imagedestroy( $image );
				if ( $result && file_exists( $webp_path ) ) {
					return $webp_path;
				}
			}
		}

		return false;
	}

	/**
	 * Get the name of the best available tool for a given MIME type.
	 *
	 * @since  1.1.0
	 * @param  string $mime MIME type.
	 * @param  string $task Either 'compress' or 'webp'.
	 * @return string Tool name or 'gd' or 'none'.
	 */
	public static function get_best_tool( $mime, $task = 'compress' ) {
		$tools = self::detect_tools();

		if ( 'webp' === $task ) {
			if ( ! empty( $tools['cwebp']['available'] ) ) {
				return 'cwebp';
			}
			if ( ! empty( $tools['gd']['available'] ) && function_exists( 'imagewebp' ) ) {
				return 'gd';
			}
			return 'none';
		}

		if ( 'image/jpeg' === $mime ) {
			if ( ! empty( $tools['jpegoptim']['available'] ) ) {
				return 'jpegoptim';
			}
			if ( ! empty( $tools['gd']['available'] ) && function_exists( 'imagecreatefromjpeg' ) ) {
				return 'gd';
			}
		} elseif ( 'image/png' === $mime ) {
			if ( ! empty( $tools['pngquant']['available'] ) ) {
				return 'pngquant';
			}
			if ( ! empty( $tools['optipng']['available'] ) ) {
				return 'optipng';
			}
			if ( ! empty( $tools['gd']['available'] ) && function_exists( 'imagecreatefrompng' ) ) {
				return 'gd';
			}
		} elseif ( 'image/gif' === $mime ) {
			if ( ! empty( $tools['gifsicle']['available'] ) ) {
				return 'gifsicle';
			}
		}

		return 'none';
	}

	// ------------------------------------------------------------------
	// CLI tool execution methods
	// ------------------------------------------------------------------

	/**
	 * Run jpegoptim on a JPEG file.
	 *
	 * @since  1.1.0
	 * @param  string $bin     Binary path.
	 * @param  string $file    File path.
	 * @param  int    $quality Max quality (1–100).
	 * @return bool
	 */
	private static function run_jpegoptim( $bin, $file, $quality ) {
		$cmd = sprintf(
			'%s --max=%d --strip-all --all-progressive --overwrite %s 2>&1',
			escapeshellarg( $bin ),
			$quality,
			escapeshellarg( $file )
		);

		$output = array();
		$code   = 0;
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec -- CLI image optimization tools require exec(); all arguments use escapeshellarg().
		exec( $cmd, $output, $code );

		return 0 === $code;
	}

	/**
	 * Run pngquant on a PNG file.
	 *
	 * @since  1.1.0
	 * @param  string $bin     Binary path.
	 * @param  string $file    File path.
	 * @param  int    $quality Quality range max (1–100).
	 * @return bool
	 */
	private static function run_pngquant( $bin, $file, $quality ) {
		$min = max( 0, $quality - 20 );

		$cmd = sprintf(
			'%s --quality=%d-%d --speed 1 --force --output %s -- %s 2>&1',
			escapeshellarg( $bin ),
			$min,
			$quality,
			escapeshellarg( $file ),
			escapeshellarg( $file )
		);

		$output = array();
		$code   = 0;
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec -- CLI image optimization tools require exec(); all arguments use escapeshellarg().
		exec( $cmd, $output, $code );

		// pngquant returns 99 if the result is larger than the original (skip).
		return 0 === $code || 99 === $code;
	}

	/**
	 * Run optipng on a PNG file.
	 *
	 * @since  1.1.0
	 * @param  string $bin  Binary path.
	 * @param  string $file File path.
	 * @return bool
	 */
	private static function run_optipng( $bin, $file ) {
		$cmd = sprintf(
			'%s -o2 -strip all -quiet %s 2>&1',
			escapeshellarg( $bin ),
			escapeshellarg( $file )
		);

		$output = array();
		$code   = 0;
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec -- CLI image optimization tools require exec(); all arguments use escapeshellarg().
		exec( $cmd, $output, $code );

		return 0 === $code;
	}

	/**
	 * Run cwebp to create a WebP copy.
	 *
	 * @since  1.1.0
	 * @param  string $bin     Binary path.
	 * @param  string $source  Source image path.
	 * @param  string $dest    Destination WebP path.
	 * @param  int    $quality Quality (1–100).
	 * @return bool
	 */
	private static function run_cwebp( $bin, $source, $dest, $quality ) {
		$cmd = sprintf(
			'%s -q %d -mt -quiet %s -o %s 2>&1',
			escapeshellarg( $bin ),
			$quality,
			escapeshellarg( $source ),
			escapeshellarg( $dest )
		);

		$output = array();
		$code   = 0;
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec -- CLI image optimization tools require exec(); all arguments use escapeshellarg().
		exec( $cmd, $output, $code );

		return 0 === $code;
	}

	/**
	 * Run gifsicle on a GIF file.
	 *
	 * @since  1.1.0
	 * @param  string $bin  Binary path.
	 * @param  string $file File path.
	 * @return bool
	 */
	private static function run_gifsicle( $bin, $file ) {
		$cmd = sprintf(
			'%s -O3 --batch %s 2>&1',
			escapeshellarg( $bin ),
			escapeshellarg( $file )
		);

		$output = array();
		$code   = 0;
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec -- CLI image optimization tools require exec(); all arguments use escapeshellarg().
		exec( $cmd, $output, $code );

		return 0 === $code;
	}
}
