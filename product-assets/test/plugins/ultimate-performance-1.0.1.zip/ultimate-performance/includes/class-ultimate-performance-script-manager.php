<?php
/**
 * Handles per-page and global script/style management.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Script_Manager
 *
 * Provides a metabox on post/page edit screens to disable specific
 * scripts and styles per page, plus global disable via settings.
 * Scans actual frontend assets by fetching the page URL.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Script_Manager {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Initialize the module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'script_manager' );

		// Always register AJAX handler and frontend scan endpoint.
		add_action( 'wp_ajax_up_scan_assets', array( $this, 'ajax_scan_assets' ) );

		if ( ! is_admin() ) {
			add_action( 'template_redirect', array( $this, 'maybe_handle_frontend_scan' ), 0 );
		}

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		// Admin: metabox + save.
		if ( is_admin() ) {
			add_action( 'add_meta_boxes', array( $this, 'register_metabox' ) );
			add_action( 'save_post', array( $this, 'save_metabox' ) );
		}

		// Frontend: dequeue disabled assets.
		if ( ! is_admin() ) {
			add_action( 'wp_print_scripts', array( $this, 'dequeue_disabled_scripts' ), 999 );
			add_action( 'wp_print_styles', array( $this, 'dequeue_disabled_styles' ), 999 );
		}
	}

	/**
	 * Register the Script Manager metabox on post types.
	 *
	 * @since 1.0.0
	 */
	public function register_metabox() {
		$post_types = get_post_types( array( 'public' => true ), 'names' );

		foreach ( $post_types as $post_type ) {
			add_meta_box(
				'up_script_manager',
				__( 'Script Manager', 'ultimate-performance' ),
				array( $this, 'render_metabox' ),
				$post_type,
				'normal',
				'low'
			);
		}
	}

	/**
	 * Render the metabox content.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post The current post object.
	 */
	public function render_metabox( $post ) {
		wp_nonce_field( 'up_script_manager', 'up_script_manager_nonce' );
		include UP_PLUGIN_DIR . 'admin/partials/script-manager-metabox.php';
	}

	/**
	 * Save per-page disabled assets from the metabox.
	 *
	 * @since 1.0.0
	 * @param int $post_id The post ID.
	 */
	public function save_metabox( $post_id ) {
		// Verify nonce.
		if ( ! isset( $_POST['up_script_manager_nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['up_script_manager_nonce'] ) ), 'up_script_manager' ) ) {
			return;
		}

		// Check autosave.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Check permissions.
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Save disabled scripts.
		if ( isset( $_POST['up_disabled_scripts'] ) && is_array( $_POST['up_disabled_scripts'] ) ) {
			$scripts = array_map( 'sanitize_text_field', wp_unslash( $_POST['up_disabled_scripts'] ) );
			update_post_meta( $post_id, '_up_disabled_scripts', $scripts );
		} else {
			delete_post_meta( $post_id, '_up_disabled_scripts' );
		}

		// Save disabled styles.
		if ( isset( $_POST['up_disabled_styles'] ) && is_array( $_POST['up_disabled_styles'] ) ) {
			$styles = array_map( 'sanitize_text_field', wp_unslash( $_POST['up_disabled_styles'] ) );
			update_post_meta( $post_id, '_up_disabled_styles', $styles );
		} else {
			delete_post_meta( $post_id, '_up_disabled_styles' );
		}
	}

	/**
	 * AJAX: Scan frontend assets for a specific post.
	 *
	 * Fetches the post's frontend URL with a scan token, which triggers
	 * the frontend scan endpoint to collect enqueued assets and return JSON.
	 *
	 * @since 1.0.0
	 */
	public function ajax_scan_assets() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		if ( ! $post_id ) {
			wp_send_json_error( array( 'message' => __( 'No post ID provided.', 'ultimate-performance' ) ) );
		}

		// Get the post's frontend URL.
		$url = get_permalink( $post_id );
		if ( ! $url ) {
			$url = get_preview_post_link( $post_id );
		}
		if ( ! $url ) {
			wp_send_json_error( array( 'message' => __( 'Could not determine the page URL. Make sure the post is published or has a preview link.', 'ultimate-performance' ) ) );
		}

		// Generate a one-time scan token stored as a transient.
		$token = wp_generate_password( 32, false );
		set_transient( 'up_scan_token', $token, 60 );

		$scan_url = add_query_arg( 'up_scan_assets', $token, $url );

		// Forward auth cookies so draft/private posts are accessible.
		$cookies = array();
		foreach ( $_COOKIE as $name => $value ) {
			if ( is_string( $value ) ) {
				$cookies[] = new WP_Http_Cookie( array(
					'name'  => $name,
					'value' => $value,
				) );
			}
		}

		$response = wp_remote_get( $scan_url, array(
			'timeout'   => 30,
			'sslverify' => ! defined( 'UP_DISABLE_SSL_VERIFY' ),
			'cookies'   => $cookies,
		) );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array(
				/* translators: %s: error message */
				'message' => sprintf( __( 'Failed to fetch page: %s', 'ultimate-performance' ), $response->get_error_message() ),
			) );
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( ! is_array( $data ) || empty( $data['success'] ) ) {
			wp_send_json_error( array(
				'message' => __( 'Failed to scan frontend assets. Make sure the post is published and publicly accessible.', 'ultimate-performance' ),
			) );
		}

		// Merge per-page disabled status from post meta.
		$disabled_scripts = get_post_meta( $post_id, '_up_disabled_scripts', true );
		$disabled_styles  = get_post_meta( $post_id, '_up_disabled_styles', true );
		if ( ! is_array( $disabled_scripts ) ) {
			$disabled_scripts = array();
		}
		if ( ! is_array( $disabled_styles ) ) {
			$disabled_styles = array();
		}

		if ( ! empty( $data['scripts'] ) ) {
			foreach ( $data['scripts'] as &$script ) {
				$script['disabled'] = in_array( $script['handle'], $disabled_scripts, true );
			}
			unset( $script );
		}

		if ( ! empty( $data['styles'] ) ) {
			foreach ( $data['styles'] as &$style ) {
				$style['disabled'] = in_array( $style['handle'], $disabled_styles, true );
			}
			unset( $style );
		}

		wp_send_json_success( array(
			'scripts' => ! empty( $data['scripts'] ) ? $data['scripts'] : array(),
			'styles'  => ! empty( $data['styles'] ) ? $data['styles'] : array(),
		) );
	}

	/**
	 * Handle frontend scan request (triggered by a special query param).
	 *
	 * When the AJAX scanner fetches the frontend URL with ?up_scan_assets={token},
	 * this method starts output buffering and hooks into shutdown to collect
	 * all enqueued assets after the page has fully rendered.
	 *
	 * @since 1.0.0
	 */
	public function maybe_handle_frontend_scan() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Token-based verification via transient; nonce not applicable for this cross-request flow.
		if ( empty( $_GET['up_scan_assets'] ) ) {
			return;
		}

		$token    = sanitize_text_field( wp_unslash( $_GET['up_scan_assets'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$expected = get_transient( 'up_scan_token' );

		if ( empty( $expected ) || ! hash_equals( $expected, $token ) ) {
			return;
		}

		// Consume the token so it can't be reused.
		delete_transient( 'up_scan_token' );

		// Buffer all normal page output — we'll discard it at shutdown.
		ob_start();

		// Collect assets at shutdown (after all enqueue hooks have fired).
		add_action( 'shutdown', array( $this, 'output_scanned_frontend_assets' ), 0 );
	}

	/**
	 * Output scanned frontend assets as JSON and exit.
	 *
	 * Runs at shutdown after the full page has been rendered (in the buffer).
	 * Discards the HTML and returns a JSON payload with all enqueued assets.
	 *
	 * @since 1.0.0
	 */
	public function output_scanned_frontend_assets() {
		// Discard all buffered HTML output.
		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		$scripts = $this->collect_enqueued_assets( 'scripts' );
		$styles  = $this->collect_enqueued_assets( 'styles' );

		header( 'Content-Type: application/json; charset=utf-8' );
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON output.
		echo wp_json_encode( array(
			'success' => true,
			'scripts' => $scripts,
			'styles'  => $styles,
		) );
		exit;
	}

	/**
	 * Collect enqueued (actually loaded) assets from the frontend page.
	 *
	 * Uses the queue and done arrays to get only assets that were
	 * actually enqueued for this specific page, not all registered assets.
	 *
	 * @since  1.0.0
	 * @param  string $type 'scripts' or 'styles'.
	 * @return array  Asset list with handle, src, and source.
	 */
	private function collect_enqueued_assets( $type ) {
		global $wp_scripts, $wp_styles;

		$registry = ( 'scripts' === $type ) ? $wp_scripts : $wp_styles;
		$assets   = array();

		if ( ! $registry || ! isset( $registry->registered ) ) {
			return $assets;
		}

		// Combine queued + done to catch everything (head + footer assets).
		$queued  = isset( $registry->queue ) ? $registry->queue : array();
		$done    = isset( $registry->done ) ? $registry->done : array();
		$handles = array_unique( array_merge( $queued, $done ) );

		foreach ( $handles as $handle ) {
			if ( ! isset( $registry->registered[ $handle ] ) ) {
				continue;
			}

			$dep = $registry->registered[ $handle ];
			$src = isset( $dep->src ) ? $dep->src : '';

			// Skip empty/false src (virtual/alias handles).
			if ( empty( $src ) || false === $src ) {
				continue;
			}

			$assets[] = array(
				'handle' => $handle,
				'src'    => $src,
				'source' => $this->get_asset_source( $src ),
			);
		}

		// Sort by source, then handle.
		usort( $assets, function( $a, $b ) {
			$cmp = strcmp( $a['source'], $b['source'] );
			return 0 !== $cmp ? $cmp : strcmp( $a['handle'], $b['handle'] );
		} );

		return $assets;
	}

	/**
	 * Identify the source (plugin, theme, or core) of an asset by its URL.
	 *
	 * @since  1.0.0
	 * @param  string $src The asset URL.
	 * @return string Human-readable source name.
	 */
	private function get_asset_source( $src ) {
		if ( empty( $src ) ) {
			return __( 'Unknown', 'ultimate-performance' );
		}

		// Normalize URL for comparison.
		$src = set_url_scheme( $src );

		$plugins_url   = plugins_url();
		$theme_root    = get_theme_root_uri();
		$includes_url  = includes_url();
		$admin_url     = admin_url();

		// Check plugins.
		if ( 0 === strpos( $src, $plugins_url ) ) {
			$relative = substr( $src, strlen( $plugins_url ) + 1 );
			$parts    = explode( '/', $relative );
			if ( ! empty( $parts[0] ) ) {
				$plugin_slug = $parts[0];
				$name = $this->get_plugin_name( $plugin_slug );
				return $name ? $name : ucwords( str_replace( '-', ' ', $plugin_slug ) );
			}
		}

		// Check themes.
		if ( 0 === strpos( $src, $theme_root ) ) {
			$relative = substr( $src, strlen( $theme_root ) + 1 );
			$parts    = explode( '/', $relative );
			if ( ! empty( $parts[0] ) ) {
				$theme = wp_get_theme( $parts[0] );
				return $theme->exists() ? $theme->get( 'Name' ) : ucwords( str_replace( '-', ' ', $parts[0] ) );
			}
		}

		// Check WordPress core.
		if ( 0 === strpos( $src, $includes_url ) || 0 === strpos( $src, $admin_url ) ) {
			return __( 'WordPress Core', 'ultimate-performance' );
		}

		return __( 'External', 'ultimate-performance' );
	}

	/**
	 * Get a plugin's display name from its slug.
	 *
	 * @since  1.0.0
	 * @param  string $slug Plugin directory slug.
	 * @return string|false Plugin name or false.
	 */
	private function get_plugin_name( $slug ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_plugins();
		foreach ( $plugins as $file => $data ) {
			if ( 0 === strpos( $file, $slug . '/' ) ) {
				return $data['Name'];
			}
		}

		return false;
	}

	/**
	 * Dequeue globally and per-page disabled scripts.
	 *
	 * Cascades to also disable any scripts that depend on the disabled handles,
	 * preventing WordPress notices about missing dependencies.
	 *
	 * @since 1.0.0
	 */
	public function dequeue_disabled_scripts() {
		global $wp_scripts;

		$disabled = $this->get_merged_disabled( 'scripts' );
		$disabled = $this->resolve_dependents( $disabled, $wp_scripts );

		foreach ( $disabled as $handle ) {
			wp_dequeue_script( $handle );
			wp_deregister_script( $handle );
		}
	}

	/**
	 * Dequeue globally and per-page disabled styles.
	 *
	 * Cascades to also disable any styles that depend on the disabled handles,
	 * preventing WordPress notices about missing dependencies.
	 *
	 * @since 1.0.0
	 */
	public function dequeue_disabled_styles() {
		global $wp_styles;

		$disabled = $this->get_merged_disabled( 'styles' );
		$disabled = $this->resolve_dependents( $disabled, $wp_styles );

		foreach ( $disabled as $handle ) {
			wp_dequeue_style( $handle );
			wp_deregister_style( $handle );
		}
	}

	/**
	 * Resolve all dependents of the disabled handles.
	 *
	 * Walks through all registered assets and finds any that list a disabled
	 * handle as a dependency. Those dependents are added to the disabled list
	 * recursively so the entire dependency tree is cleaned up.
	 *
	 * @since  1.0.0
	 * @param  array               $disabled Initial list of disabled handles.
	 * @param  WP_Dependencies|null $registry The scripts or styles registry.
	 * @return array Expanded list including all dependent handles.
	 */
	private function resolve_dependents( $disabled, $registry ) {
		if ( ! $registry || empty( $registry->registered ) || empty( $disabled ) ) {
			return $disabled;
		}

		$disabled_set = array_flip( $disabled );
		$changed      = true;

		// Keep iterating until no new dependents are found.
		while ( $changed ) {
			$changed = false;

			foreach ( $registry->registered as $handle => $dep ) {
				if ( isset( $disabled_set[ $handle ] ) ) {
					continue;
				}

				if ( empty( $dep->deps ) || ! is_array( $dep->deps ) ) {
					continue;
				}

				// If any of this asset's dependencies are disabled, disable it too.
				foreach ( $dep->deps as $dep_handle ) {
					if ( isset( $disabled_set[ $dep_handle ] ) ) {
						$disabled_set[ $handle ] = true;
						$changed = true;
						break;
					}
				}
			}
		}

		return array_keys( $disabled_set );
	}

	/**
	 * Get merged list of disabled handles (global + per-page).
	 *
	 * @since  1.0.0
	 * @param  string $type 'scripts' or 'styles'.
	 * @return array  Array of handle names.
	 */
	private function get_merged_disabled( $type ) {
		$disabled = array();

		// Global disabled from settings.
		$settings_key = 'scripts' === $type ? 'global_disabled_scripts' : 'global_disabled_styles';
		$global       = $this->settings[ $settings_key ];
		if ( ! empty( $global ) ) {
			$lines = preg_split( '/\r\n|\r|\n/', $global );
			foreach ( $lines as $line ) {
				$line = trim( $line );
				if ( '' !== $line ) {
					$disabled[] = $line;
				}
			}
		}

		// Per-page disabled from post meta.
		$post_id = get_the_ID();
		if ( $post_id ) {
			$meta_key   = 'scripts' === $type ? '_up_disabled_scripts' : '_up_disabled_styles';
			$per_page   = get_post_meta( $post_id, $meta_key, true );
			if ( is_array( $per_page ) ) {
				$disabled = array_merge( $disabled, $per_page );
			}
		}

		return array_unique( $disabled );
	}
}
