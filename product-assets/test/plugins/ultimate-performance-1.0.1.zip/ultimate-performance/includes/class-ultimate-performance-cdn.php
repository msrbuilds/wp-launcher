<?php
/**
 * Handles CDN URL rewriting for static assets.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_CDN
 *
 * Rewrites static asset URLs to serve from a CDN. Supports
 * extension-based inclusion, exclusion patterns, and covers
 * enqueued styles/scripts, attachment URLs, and post content.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_CDN {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Site URL without protocol.
	 *
	 * @since 1.0.0
	 * @var   string
	 */
	private $site_url;

	/**
	 * CDN URL without protocol.
	 *
	 * @since 1.0.0
	 * @var   string
	 */
	private $cdn_url;

	/**
	 * Parsed array of included file extensions.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $extensions = array();

	/**
	 * Parsed array of exclusion patterns.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $exclusions = array();

	/**
	 * Initialize the module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'cdn' );

		// Always register AJAX handlers for CDN integrations.
		add_action( 'wp_ajax_up_cdn_cloudflare_test', array( $this, 'ajax_cloudflare_test' ) );
		add_action( 'wp_ajax_up_cdn_cloudflare_purge', array( $this, 'ajax_cloudflare_purge' ) );
		add_action( 'wp_ajax_up_cdn_bunnycdn_purge', array( $this, 'ajax_bunnycdn_purge' ) );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		if ( is_admin() ) {
			return;
		}

		$cdn_url = trim( $this->settings['cdn_url'] );
		if ( empty( $cdn_url ) ) {
			return;
		}

		// Strip protocol for comparison.
		$this->site_url = $this->strip_protocol( site_url() );
		$this->cdn_url  = $this->strip_protocol( $cdn_url );

		// Don't rewrite if CDN URL matches site URL.
		if ( $this->site_url === $this->cdn_url ) {
			return;
		}

		$this->parse_extensions();
		$this->parse_exclusions();
		$this->setup_hooks();
	}

	/**
	 * Parse included extensions from settings.
	 *
	 * @since 1.0.0
	 */
	private function parse_extensions() {
		$raw = $this->settings['included_extensions'];
		if ( empty( $raw ) ) {
			return;
		}

		$parts = array_map( 'trim', explode( ',', $raw ) );
		foreach ( $parts as $ext ) {
			$ext = ltrim( $ext, '.' );
			if ( '' !== $ext ) {
				$this->extensions[] = '.' . strtolower( $ext );
			}
		}
	}

	/**
	 * Parse exclusion patterns from settings.
	 *
	 * @since 1.0.0
	 */
	private function parse_exclusions() {
		$raw = $this->settings['exclusion_patterns'];
		if ( empty( $raw ) ) {
			return;
		}

		$lines = preg_split( '/\r\n|\r|\n/', $raw );
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' !== $line ) {
				$this->exclusions[] = $line;
			}
		}
	}

	/**
	 * Register WordPress hooks for URL rewriting.
	 *
	 * @since 1.0.0
	 */
	private function setup_hooks() {
		add_filter( 'style_loader_src', array( $this, 'rewrite_url' ), 10 );
		add_filter( 'script_loader_src', array( $this, 'rewrite_url' ), 10 );
		add_filter( 'wp_get_attachment_url', array( $this, 'rewrite_url' ), 10 );
		add_filter( 'the_content', array( $this, 'rewrite_content_urls' ), 999 );
	}

	/**
	 * Rewrite a single URL to use the CDN domain.
	 *
	 * @since  1.0.0
	 * @param  string $url The original URL.
	 * @return string The rewritten URL or original if not eligible.
	 */
	public function rewrite_url( $url ) {
		if ( empty( $url ) || ! is_string( $url ) ) {
			return $url;
		}

		$url_no_protocol = $this->strip_protocol( $url );

		// Only rewrite URLs belonging to this site.
		if ( 0 !== strpos( $url_no_protocol, $this->site_url ) ) {
			return $url;
		}

		// Check file extension.
		if ( ! $this->has_allowed_extension( $url ) ) {
			return $url;
		}

		// Check exclusions.
		if ( $this->is_excluded( $url ) ) {
			return $url;
		}

		// Replace site URL with CDN URL.
		return str_replace( $this->site_url, $this->cdn_url, $url_no_protocol );
	}

	/**
	 * Rewrite URLs within post content (inline images, etc.).
	 *
	 * @since  1.0.0
	 * @param  string $content Post content HTML.
	 * @return string Modified content.
	 */
	public function rewrite_content_urls( $content ) {
		if ( empty( $content ) ) {
			return $content;
		}

		$site_url = preg_quote( $this->site_url, '/' );

		// Match URLs in src, href, srcset, data-src attributes.
		return preg_replace_callback(
			'/((?:src|href|srcset|data-src)\s*=\s*["\'])(?:https?:)?\/\/' . $site_url . '([^"\']+)(["\'])/i',
			array( $this, 'rewrite_content_match' ),
			$content
		);
	}

	/**
	 * Callback for content URL regex replacement.
	 *
	 * @since  1.0.0
	 * @param  array $matches Regex matches.
	 * @return string Replacement string.
	 */
	public function rewrite_content_match( $matches ) {
		$prefix = $matches[1];
		$path   = $matches[2];
		$quote  = $matches[3];

		$full_url = '//' . $this->site_url . $path;

		if ( ! $this->has_allowed_extension( $path ) ) {
			return $matches[0];
		}

		if ( $this->is_excluded( $full_url ) ) {
			return $matches[0];
		}

		return $prefix . '//' . $this->cdn_url . $path . $quote;
	}

	/**
	 * Check if a URL has an allowed file extension.
	 *
	 * @since  1.0.0
	 * @param  string $url The URL to check.
	 * @return bool True if extension is allowed.
	 */
	private function has_allowed_extension( $url ) {
		if ( empty( $this->extensions ) ) {
			return true; // No filter = allow all.
		}

		$ext = $this->get_file_extension( $url );
		if ( empty( $ext ) ) {
			return false;
		}

		return in_array( $ext, $this->extensions, true );
	}

	/**
	 * Check if a URL matches any exclusion pattern.
	 *
	 * @since  1.0.0
	 * @param  string $url The URL to check.
	 * @return bool True if excluded.
	 */
	private function is_excluded( $url ) {
		foreach ( $this->exclusions as $pattern ) {
			if ( false !== strpos( $url, $pattern ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Extract file extension from a URL.
	 *
	 * @since  1.0.0
	 * @param  string $url The URL.
	 * @return string Lowercase extension with dot (e.g. '.css') or empty.
	 */
	private function get_file_extension( $url ) {
		// Remove query string and fragment.
		$path = strtok( $url, '?#' );
		$ext  = pathinfo( $path, PATHINFO_EXTENSION );

		if ( empty( $ext ) ) {
			return '';
		}

		return '.' . strtolower( $ext );
	}

	/**
	 * Strip protocol from a URL.
	 *
	 * @since  1.0.0
	 * @param  string $url The URL.
	 * @return string URL without protocol prefix.
	 */
	private function strip_protocol( $url ) {
		return preg_replace( '/^https?:\/\//', '//', rtrim( $url, '/' ) );
	}

	/**
	 * AJAX: Test Cloudflare API connection.
	 *
	 * @since 1.0.0
	 */
	public function ajax_cloudflare_test() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$email   = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
		$api_key = sanitize_text_field( wp_unslash( $_POST['api_key'] ?? '' ) );
		$zone_id = sanitize_text_field( wp_unslash( $_POST['zone_id'] ?? '' ) );

		if ( empty( $email ) || empty( $api_key ) || empty( $zone_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Please fill in all Cloudflare fields.', 'ultimate-performance' ) ) );
		}

		// Validate zone ID format (32-char hex string).
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $zone_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid Cloudflare Zone ID format.', 'ultimate-performance' ) ) );
		}

		$response = wp_remote_get(
			'https://api.cloudflare.com/client/v4/zones/' . $zone_id,
			array(
				'timeout' => 15,
				'headers' => array(
					'X-Auth-Email' => $email,
					'X-Auth-Key'   => $api_key,
					'Content-Type' => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array( 'message' => $response->get_error_message() ) );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! empty( $body['success'] ) ) {
			$zone_name = $body['result']['name'] ?? '';
			wp_send_json_success( array(
				/* translators: %s: Cloudflare zone name (domain) */
				'message' => sprintf( __( 'Connected successfully to zone: %s', 'ultimate-performance' ), $zone_name ),
			) );
		}

		$error_msg = __( 'Cloudflare API error.', 'ultimate-performance' );
		if ( ! empty( $body['errors'][0]['message'] ) ) {
			$error_msg = $body['errors'][0]['message'];
		}
		wp_send_json_error( array( 'message' => $error_msg ) );
	}

	/**
	 * AJAX: Purge entire Cloudflare cache.
	 *
	 * @since 1.0.0
	 */
	public function ajax_cloudflare_purge() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$settings = Ultimate_Performance_Settings::get_module_settings( 'cdn' );
		$email    = $settings['cloudflare_email'];
		$api_key  = $settings['cloudflare_api_key'];
		$zone_id  = $settings['cloudflare_zone_id'];

		if ( empty( $email ) || empty( $api_key ) || empty( $zone_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Cloudflare credentials not configured. Please save your settings first.', 'ultimate-performance' ) ) );
		}

		// Validate zone ID format (32-char hex string).
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $zone_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid Cloudflare Zone ID.', 'ultimate-performance' ) ) );
		}

		$response = wp_remote_request(
			'https://api.cloudflare.com/client/v4/zones/' . $zone_id . '/purge_cache',
			array(
				'method'  => 'POST',
				'timeout' => 30,
				'headers' => array(
					'X-Auth-Email' => $email,
					'X-Auth-Key'   => $api_key,
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode( array( 'purge_everything' => true ) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array( 'message' => $response->get_error_message() ) );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! empty( $body['success'] ) ) {
			wp_send_json_success( array( 'message' => __( 'Cloudflare cache purged successfully.', 'ultimate-performance' ) ) );
		}

		$error_msg = __( 'Failed to purge Cloudflare cache.', 'ultimate-performance' );
		if ( ! empty( $body['errors'][0]['message'] ) ) {
			$error_msg = $body['errors'][0]['message'];
		}
		wp_send_json_error( array( 'message' => $error_msg ) );
	}

	/**
	 * AJAX: Purge BunnyCDN pull zone cache.
	 *
	 * @since 1.0.0
	 */
	public function ajax_bunnycdn_purge() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$settings    = Ultimate_Performance_Settings::get_module_settings( 'cdn' );
		$api_key     = $settings['bunnycdn_api_key'];
		$pullzone_id = $settings['bunnycdn_pullzone_id'];

		if ( empty( $api_key ) || empty( $pullzone_id ) ) {
			wp_send_json_error( array( 'message' => __( 'BunnyCDN credentials not configured. Please save your settings first.', 'ultimate-performance' ) ) );
		}

		// Validate pullzone ID is numeric.
		if ( ! ctype_digit( (string) $pullzone_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid BunnyCDN Pull Zone ID.', 'ultimate-performance' ) ) );
		}

		$response = wp_remote_request(
			'https://api.bunny.net/pullzone/' . $pullzone_id . '/purgeCache',
			array(
				'method'  => 'POST',
				'timeout' => 30,
				'headers' => array(
					'AccessKey'    => $api_key,
					'Content-Type' => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array( 'message' => $response->get_error_message() ) );
		}

		$code = wp_remote_retrieve_response_code( $response );

		if ( 204 === $code || 200 === $code ) {
			wp_send_json_success( array( 'message' => __( 'BunnyCDN cache purged successfully.', 'ultimate-performance' ) ) );
		}

		$body      = json_decode( wp_remote_retrieve_body( $response ), true );
		$error_msg = $body['Message'] ?? __( 'Failed to purge BunnyCDN cache.', 'ultimate-performance' );
		wp_send_json_error( array( 'message' => $error_msg ) );
	}
}
