<?php
/**
 * Handles preloading and resource hints functionality.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Preloading
 *
 * Outputs DNS prefetch, preconnect, and preload resource hints.
 * Optionally enables hover-based page prefetching (Instant Page)
 * and the Speculation Rules API for speculative prerendering.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Preloading {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Initialize the preloading module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'preloading' );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		$this->setup_dns_prefetch();
		$this->setup_preconnect();
		$this->setup_preload();
		$this->setup_instant_page();
		$this->setup_speculation_rules();
	}

	/**
	 * Output DNS prefetch hints.
	 *
	 * @since 1.0.0
	 */
	private function setup_dns_prefetch() {
		$domains = $this->parse_textarea_lines( $this->settings['dns_prefetch'] );

		if ( empty( $domains ) ) {
			return;
		}

		add_action( 'wp_head', function () use ( $domains ) {
			foreach ( $domains as $domain ) {
				$domain = $this->normalize_domain( $domain );
				if ( $domain ) {
					printf( '<link rel="dns-prefetch" href="%s">' . "\n", esc_url( $domain ) );
				}
			}
		}, 1 );
	}

	/**
	 * Output preconnect hints.
	 *
	 * @since 1.0.0
	 */
	private function setup_preconnect() {
		$origins = $this->parse_textarea_lines( $this->settings['preconnect'] );

		if ( empty( $origins ) ) {
			return;
		}

		add_action( 'wp_head', function () use ( $origins ) {
			foreach ( $origins as $origin ) {
				$origin = $this->normalize_domain( $origin );
				if ( $origin ) {
					printf( '<link rel="preconnect" href="%s" crossorigin>' . "\n", esc_url( $origin ) );
				}
			}
		}, 1 );
	}

	/**
	 * Output preload hints.
	 *
	 * @since 1.0.0
	 */
	private function setup_preload() {
		$urls = $this->parse_textarea_lines( $this->settings['preload_urls'] );

		if ( empty( $urls ) ) {
			return;
		}

		add_action( 'wp_head', function () use ( $urls ) {
			foreach ( $urls as $url ) {
				$as = $this->detect_resource_type( $url );
				printf(
					'<link rel="preload" href="%s" as="%s"%s>' . "\n",
					esc_url( $url ),
					esc_attr( $as ),
					( 'font' === $as ) ? ' crossorigin' : ''
				);
			}
		}, 1 );
	}

	/**
	 * Enqueue Instant Page hover prefetch script.
	 *
	 * @since 1.0.0
	 */
	private function setup_instant_page() {
		if ( empty( $this->settings['instant_page'] ) ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', function () {
			if ( is_admin() ) {
				return;
			}

			wp_enqueue_script(
				'up-instant-page',
				UP_PLUGIN_URL . 'public/js/ultimate-performance-instant-page.js',
				array(),
				UP_VERSION,
				array( 'strategy' => 'defer', 'in_footer' => true )
			);
		} );
	}

	/**
	 * Output Speculation Rules JSON for speculative prerendering.
	 *
	 * @since 1.0.0
	 */
	private function setup_speculation_rules() {
		if ( empty( $this->settings['speculation_rules'] ) ) {
			return;
		}

		$eagerness = $this->settings['speculation_eagerness'] ?? 'moderate';
		$allowed   = array( 'conservative', 'moderate', 'eager' );
		if ( ! in_array( $eagerness, $allowed, true ) ) {
			$eagerness = 'moderate';
		}

		add_action( 'wp_head', function () use ( $eagerness ) {
			$rules = array(
				'prerender' => array(
					array(
						'where' => array(
							'and' => array(
								array( 'href_matches' => '/*' ),
								array(
									'not' => array(
										'href_matches' => array(
											'/wp-admin/*',
											'/wp-login.php',
											'/cart/*',
											'/checkout/*',
											'/my-account/*',
										),
									),
								),
							),
						),
						'eagerness' => $eagerness,
					),
				),
			);
			printf(
				'<script type="speculationrules">%s</script>' . "\n",
				wp_json_encode( $rules )
			);
		}, 99 );
	}

	/**
	 * Parse a textarea value into an array of non-empty trimmed lines.
	 *
	 * @since  1.0.0
	 * @param  string $text Textarea value.
	 * @return array  Non-empty lines.
	 */
	private function parse_textarea_lines( $text ) {
		if ( empty( $text ) ) {
			return array();
		}

		$lines = preg_split( '/\r\n|\r|\n/', $text );
		$lines = array_map( 'trim', $lines );
		$lines = array_filter( $lines, 'strlen' );

		return array_values( $lines );
	}

	/**
	 * Normalize a domain string to ensure it has a scheme prefix.
	 *
	 * @since  1.0.0
	 * @param  string $domain Raw domain input.
	 * @return string|false Normalized domain or false on failure.
	 */
	private function normalize_domain( $domain ) {
		$domain = trim( $domain );

		if ( empty( $domain ) ) {
			return false;
		}

		// If only a bare domain (e.g. "fonts.googleapis.com"), prepend //.
		if ( 0 !== strpos( $domain, '//' ) && 0 !== strpos( $domain, 'http' ) ) {
			$domain = '//' . $domain;
		}

		return $domain;
	}

	/**
	 * Detect the resource type from a URL extension for the preload `as` attribute.
	 *
	 * @since  1.0.0
	 * @param  string $url Resource URL.
	 * @return string Resource type.
	 */
	private function detect_resource_type( $url ) {
		$path = wp_parse_url( $url, PHP_URL_PATH );
		$ext  = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

		$map = array(
			'css'   => 'style',
			'js'    => 'script',
			'woff'  => 'font',
			'woff2' => 'font',
			'ttf'   => 'font',
			'otf'   => 'font',
			'eot'   => 'font',
			'jpg'   => 'image',
			'jpeg'  => 'image',
			'png'   => 'image',
			'gif'   => 'image',
			'svg'   => 'image',
			'webp'  => 'image',
			'avif'  => 'image',
			'mp4'   => 'video',
			'webm'  => 'video',
		);

		return isset( $map[ $ext ] ) ? $map[ $ext ] : 'fetch';
	}
}
