<?php
/**
 * Fired during plugin activation.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Activator
 *
 * Runs code on plugin activation, such as creating
 * default options or database tables.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Activator {

	/**
	 * Run activation tasks.
	 *
	 * @since 1.0.0
	 */
	public static function activate() {
		// Set default options with all module defaults.
		if ( false === get_option( 'up_settings' ) ) {
			require_once plugin_dir_path( __FILE__ ) . 'class-ultimate-performance-settings.php';
			add_option( 'up_settings', Ultimate_Performance_Settings::get_defaults() );
		}

		// Store the plugin version for future upgrade routines.
		update_option( 'up_version', UP_VERSION );

		// Create custom database tables.
		self::create_tables();
	}

	/**
	 * Create custom database tables.
	 *
	 * @since 1.0.0
	 */
	public static function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$sql_speed_tests = "CREATE TABLE {$wpdb->prefix}up_speed_tests (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url varchar(2083) NOT NULL,
			strategy varchar(10) NOT NULL DEFAULT 'mobile',
			performance_score tinyint(3) unsigned DEFAULT NULL,
			lcp_ms int(10) unsigned DEFAULT NULL,
			inp_ms int(10) unsigned DEFAULT NULL,
			cls_score decimal(5,4) DEFAULT NULL,
			label varchar(255) DEFAULT '',
			raw_response longtext,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY url_strategy (url(191), strategy),
			KEY created_at (created_at)
		) {$charset_collate};";

		$sql_image_optimization = "CREATE TABLE {$wpdb->prefix}up_image_optimization (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			attachment_id bigint(20) unsigned NOT NULL,
			original_size bigint(20) unsigned NOT NULL DEFAULT 0,
			optimized_size bigint(20) unsigned NOT NULL DEFAULT 0,
			webp_size bigint(20) unsigned DEFAULT NULL,
			avif_size bigint(20) unsigned DEFAULT NULL,
			compression_type varchar(20) NOT NULL DEFAULT 'lossy',
			status varchar(20) NOT NULL DEFAULT 'pending',
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY attachment_id (attachment_id),
			KEY status (status)
		) {$charset_collate};";

		$sql_static_pages = "CREATE TABLE {$wpdb->prefix}up_static_pages (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url varchar(2083) NOT NULL,
			file_path varchar(2083) DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			http_status_code smallint(5) unsigned DEFAULT NULL,
			content_type varchar(100) DEFAULT NULL,
			content_hash char(32) DEFAULT NULL,
			error_message text DEFAULT NULL,
			found_on varchar(2083) DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY url (url(191)),
			KEY status (status)
		) {$charset_collate};";

		$sql_ucss_cache = "CREATE TABLE {$wpdb->prefix}up_ucss_cache (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url varchar(2083) NOT NULL,
			url_hash char(32) NOT NULL,
			post_id bigint(20) unsigned DEFAULT 0,
			ucss_path varchar(512) DEFAULT '',
			critical_path varchar(512) DEFAULT '',
			original_size bigint(20) unsigned DEFAULT 0,
			ucss_size bigint(20) unsigned DEFAULT 0,
			status varchar(20) NOT NULL DEFAULT 'pending',
			generated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			expires_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY url_hash (url_hash),
			KEY post_id (post_id),
			KEY status (status),
			KEY expires_at (expires_at)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql_speed_tests );
		dbDelta( $sql_image_optimization );
		dbDelta( $sql_static_pages );
		dbDelta( $sql_ucss_cache );

		update_option( 'up_db_version', '1.2.0' );
	}
}
