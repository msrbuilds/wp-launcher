<?php
/**
 * Handles HTTP security header output.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Security_Headers
 *
 * Outputs HTTP security headers on frontend responses based on
 * user configuration. Includes X-Content-Type-Options,
 * X-Frame-Options, Referrer-Policy, Permissions-Policy,
 * Strict-Transport-Security, and X-XSS-Protection.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Security_Headers {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Initialize the module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'security_headers' );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		// Only send headers on frontend requests.
		if ( is_admin() ) {
			return;
		}

		add_action( 'send_headers', array( $this, 'send_security_headers' ) );
	}

	/**
	 * Output all enabled HTTP security headers.
	 *
	 * @since 1.0.0
	 */
	public function send_security_headers() {
		// X-Content-Type-Options.
		if ( ! empty( $this->settings['x_content_type_options'] ) ) {
			header( 'X-Content-Type-Options: nosniff' );
		}

		// X-XSS-Protection.
		if ( ! empty( $this->settings['x_xss_protection'] ) ) {
			header( 'X-XSS-Protection: 1; mode=block' );
		}

		// X-Frame-Options — validate against allowlist.
		$x_frame        = strtoupper( $this->settings['x_frame_options'] );
		$allowed_xframe = array( 'DENY', 'SAMEORIGIN' );
		if ( ! empty( $x_frame ) && 'DISABLED' !== $x_frame && in_array( $x_frame, $allowed_xframe, true ) ) {
			header( 'X-Frame-Options: ' . $x_frame );
		}

		// Referrer-Policy — validate against allowlist.
		$referrer         = $this->settings['referrer_policy'];
		$allowed_referrer = array(
			'no-referrer', 'no-referrer-when-downgrade', 'origin', 'origin-when-cross-origin',
			'same-origin', 'strict-origin', 'strict-origin-when-cross-origin', 'unsafe-url',
		);
		if ( ! empty( $referrer ) && 'disabled' !== $referrer && in_array( $referrer, $allowed_referrer, true ) ) {
			header( 'Referrer-Policy: ' . $referrer );
		}

		// Permissions-Policy — strip newlines to prevent header injection.
		$permissions = str_replace( array( "\r", "\n" ), '', trim( $this->settings['permissions_policy'] ) );
		if ( ! empty( $permissions ) ) {
			header( 'Permissions-Policy: ' . $permissions );
		}

		// Strict-Transport-Security (HSTS).
		if ( ! empty( $this->settings['hsts_enabled'] ) ) {
			$max_age = absint( $this->settings['hsts_max_age'] );
			if ( $max_age < 1 ) {
				$max_age = 31536000;
			}
			$hsts = 'max-age=' . $max_age;
			if ( ! empty( $this->settings['hsts_include_subdomains'] ) ) {
				$hsts .= '; includeSubDomains';
			}
			header( 'Strict-Transport-Security: ' . $hsts );
		}
	}
}
