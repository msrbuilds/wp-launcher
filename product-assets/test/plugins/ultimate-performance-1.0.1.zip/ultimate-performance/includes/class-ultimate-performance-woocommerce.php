<?php
/**
 * Handles WooCommerce-specific performance optimizations.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_WooCommerce
 *
 * Conditionally dequeues WooCommerce scripts, styles, and cart
 * fragments on pages that do not need them to reduce page weight.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_WooCommerce {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Initialize the module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		// Bail early if WooCommerce is not active.
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'woocommerce' );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		// Only optimize frontend.
		if ( is_admin() ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'optimize_scripts' ), 99 );
	}

	/**
	 * Conditionally dequeue WooCommerce assets on non-WC pages.
	 *
	 * @since 1.0.0
	 */
	public function optimize_scripts() {
		// Disable cart fragments on non-cart/checkout pages.
		if ( ! empty( $this->settings['disable_cart_fragments'] ) ) {
			if ( ! $this->is_wc_page() ) {
				wp_dequeue_script( 'wc-cart-fragments' );
			}
		}

		// Dequeue WC scripts and styles on non-WC pages.
		if ( ! empty( $this->settings['dequeue_wc_scripts'] ) ) {
			if ( ! $this->is_wc_page() ) {
				// Scripts.
				wp_dequeue_script( 'woocommerce' );
				wp_dequeue_script( 'wc-add-to-cart' );
				wp_dequeue_script( 'wc-cart-fragments' );
				wp_dequeue_script( 'wc-add-to-cart-variation' );
				wp_dequeue_script( 'wc-single-product' );

				// Styles.
				wp_dequeue_style( 'woocommerce-general' );
				wp_dequeue_style( 'woocommerce-layout' );
				wp_dequeue_style( 'woocommerce-smallscreen' );
				wp_dequeue_style( 'wc-blocks-style' );
			}
		}

		// Disable password strength meter on non-account pages.
		if ( ! empty( $this->settings['disable_password_strength'] ) ) {
			if ( ! $this->is_account_page() ) {
				wp_dequeue_script( 'zxcvbn-async' );
				wp_dequeue_script( 'password-strength-meter' );
				wp_dequeue_script( 'wc-password-strength-meter' );
			}
		}

		// Disable WC widgets/smallscreen CSS.
		if ( ! empty( $this->settings['disable_wc_widgets_css'] ) ) {
			wp_dequeue_style( 'woocommerce-smallscreen' );
		}
	}

	/**
	 * Check if the current page is a WooCommerce page.
	 *
	 * @since  1.0.0
	 * @return bool
	 */
	private function is_wc_page() {
		if ( ! function_exists( 'is_woocommerce' ) ) {
			return false;
		}

		return is_woocommerce() || is_cart() || is_checkout() || is_account_page();
	}

	/**
	 * Check if the current page is a My Account page.
	 *
	 * @since  1.0.0
	 * @return bool
	 */
	private function is_account_page() {
		if ( ! function_exists( 'is_account_page' ) ) {
			return false;
		}

		return is_account_page();
	}
}
