<?php
/**
 * Fired during plugin deactivation.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Deactivator
 *
 * Runs code on plugin deactivation, such as clearing
 * scheduled events or transients.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Deactivator {

	/**
	 * Run deactivation tasks.
	 *
	 * @since 1.0.0
	 */
	public static function deactivate() {
		// Clear all scheduled cron events.
		wp_clear_scheduled_hook( 'up_scheduled_cleanup' );
		wp_clear_scheduled_hook( 'up_scheduled_db_cleanup' );
		wp_clear_scheduled_hook( 'up_cache_preload' );
		wp_clear_scheduled_hook( 'up_speed_test_scheduled' );
		wp_clear_scheduled_hook( 'up_refresh_local_scripts' );
		wp_clear_scheduled_hook( 'up_image_optimization_batch' );
	}
}
