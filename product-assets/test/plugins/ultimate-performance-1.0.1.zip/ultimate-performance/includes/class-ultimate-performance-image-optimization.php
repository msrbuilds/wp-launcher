<?php
/**
 * Handles image optimization: lazy loading, missing dimensions, WebP conversion, compression.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Image_Optimization
 *
 * Adds lazy loading to images and iframes, detects and adds missing
 * image dimensions, generates WebP copies on upload, and compresses
 * uploaded images using CLI tools (jpegoptim, pngquant, optipng, cwebp,
 * gifsicle) with automatic GD fallback via Ultimate_Performance_Image_Optimizer.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Image_Optimization {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Counter for above-the-fold image exclusion.
	 *
	 * @since 1.0.0
	 * @var   int
	 */
	private $image_counter = 0;

	/**
	 * Parsed lazy load exclusion patterns.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $exclusion_patterns = array();

	/**
	 * Initialize the image optimization module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'image_optimization' );

		// AJAX handlers registered regardless of enabled state.
		add_action( 'wp_ajax_up_bulk_webp_convert', array( $this, 'ajax_bulk_webp_convert' ) );
		add_action( 'wp_ajax_up_bulk_compress', array( $this, 'ajax_bulk_compress' ) );
		add_action( 'wp_ajax_up_detect_image_tools', array( $this, 'ajax_detect_image_tools' ) );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		$this->exclusion_patterns = $this->parse_textarea_lines( $this->settings['lazy_load_exclusions'] );

		$this->setup_output_buffer();
		$this->setup_compression();
		$this->setup_webp_conversion();
		$this->setup_webp_cleanup();
		$this->setup_disable_native_lazy();
		$this->setup_media_library_column();
	}

	/**
	 * Setup a single output buffer for all image HTML processing.
	 *
	 * @since 1.0.0
	 */
	private function setup_output_buffer() {
		$needs_buffer = ! empty( $this->settings['lazy_load_images'] )
			|| ! empty( $this->settings['lazy_load_iframes'] )
			|| ! empty( $this->settings['add_missing_dimensions'] )
			|| ! empty( $this->settings['webp_conversion'] );

		if ( ! $needs_buffer ) {
			return;
		}

		add_action( 'template_redirect', array( $this, 'start_image_buffer' ), 2 );
	}

	/**
	 * Start the output buffer for image processing.
	 *
	 * @since 1.0.0
	 */
	public function start_image_buffer() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || is_feed() ) {
			return;
		}

		$this->image_counter = 0;
		ob_start( array( $this, 'process_image_buffer' ) );
	}

	/**
	 * Process the output buffer: dimensions, WebP rewrite, lazy loading.
	 *
	 * @since  1.0.0
	 * @param  string $html Page HTML output.
	 * @return string Modified HTML.
	 */
	public function process_image_buffer( $html ) {
		if ( empty( $html ) ) {
			return $html;
		}

		// 1. Add missing dimensions first (before lazy load changes tags).
		if ( ! empty( $this->settings['add_missing_dimensions'] ) ) {
			$html = $this->add_missing_dimensions( $html );
		}

		// 2. WebP rewrite (wraps img in picture).
		if ( ! empty( $this->settings['webp_conversion'] ) ) {
			$html = $this->rewrite_images_to_webp( $html );
		}

		// 3. Lazy loading last (adds attributes to final tags).
		if ( ! empty( $this->settings['lazy_load_images'] ) || ! empty( $this->settings['lazy_load_iframes'] ) ) {
			$html = $this->apply_lazy_loading( $html );
		}

		return $html;
	}

	/**
	 * Add missing width/height attributes to images.
	 *
	 * @since  1.0.0
	 * @param  string $html Page HTML.
	 * @return string Modified HTML.
	 */
	private function add_missing_dimensions( $html ) {
		return preg_replace_callback(
			'/<img\s[^>]*>/i',
			array( $this, 'add_dimensions_to_img' ),
			$html
		);
	}

	/**
	 * Callback to add dimensions to a single img tag.
	 *
	 * @since  1.0.0
	 * @param  array $matches Regex matches.
	 * @return string Modified img tag.
	 */
	public function add_dimensions_to_img( $matches ) {
		$tag = $matches[0];

		// Skip if both width and height already present.
		if ( preg_match( '/\bwidth\s*=/i', $tag ) && preg_match( '/\bheight\s*=/i', $tag ) ) {
			return $tag;
		}

		// Extract src.
		if ( ! preg_match( '/\bsrc\s*=\s*["\']([^"\']+)["\']/i', $tag, $src_match ) ) {
			return $tag;
		}

		$src        = $src_match[1];
		$local_path = $this->url_to_local_path( $src );

		if ( ! $local_path || ! file_exists( $local_path ) ) {
			return $tag;
		}

		$size = wp_getimagesize( $local_path );
		if ( ! $size || empty( $size[0] ) || empty( $size[1] ) ) {
			return $tag;
		}

		$width  = $size[0];
		$height = $size[1];

		// Add missing attributes.
		if ( ! preg_match( '/\bwidth\s*=/i', $tag ) ) {
			$tag = str_replace( '<img ', '<img width="' . (int) $width . '" ', $tag );
		}

		if ( ! preg_match( '/\bheight\s*=/i', $tag ) ) {
			$tag = str_replace( '<img ', '<img height="' . (int) $height . '" ', $tag );
		}

		return $tag;
	}

	/**
	 * Rewrite images with WebP sources using picture element.
	 *
	 * @since  1.0.0
	 * @param  string $html Page HTML.
	 * @return string Modified HTML.
	 */
	private function rewrite_images_to_webp( $html ) {
		return preg_replace_callback(
			'/<img\s[^>]*src\s*=\s*["\']([^"\']+\.(?:jpe?g|png))["\'][^>]*>/i',
			array( $this, 'wrap_img_with_picture' ),
			$html
		);
	}

	/**
	 * Callback to wrap an img tag with a picture element for WebP.
	 *
	 * @since  1.0.0
	 * @param  array $matches Regex matches.
	 * @return string Picture element or original img tag.
	 */
	public function wrap_img_with_picture( $matches ) {
		$img_tag = $matches[0];
		$src     = $matches[1];

		// Skip if already inside a <picture> element.
		// This is a simple heuristic; we just avoid double-wrapping.

		$local_path = $this->url_to_local_path( $src );
		if ( ! $local_path ) {
			return $img_tag;
		}

		$webp_path = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $local_path );
		if ( ! file_exists( $webp_path ) ) {
			return $img_tag;
		}

		$webp_url = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $src );

		return sprintf(
			'<picture><source type="image/webp" srcset="%s">%s</picture>',
			esc_url( $webp_url ),
			$img_tag
		);
	}

	/**
	 * Apply lazy loading to images and iframes.
	 *
	 * @since  1.0.0
	 * @param  string $html Page HTML.
	 * @return string Modified HTML.
	 */
	private function apply_lazy_loading( $html ) {
		// Lazy load images.
		if ( ! empty( $this->settings['lazy_load_images'] ) ) {
			$html = preg_replace_callback(
				'/<img\s[^>]*>/i',
				array( $this, 'maybe_lazy_load_img' ),
				$html
			);
		}

		// Lazy load iframes.
		if ( ! empty( $this->settings['lazy_load_iframes'] ) ) {
			$html = preg_replace_callback(
				'/<iframe\s[^>]*>/i',
				array( $this, 'maybe_lazy_load_iframe' ),
				$html
			);
		}

		return $html;
	}

	/**
	 * Callback to maybe add lazy loading to an img tag.
	 *
	 * @since  1.0.0
	 * @param  array $matches Regex matches.
	 * @return string Modified img tag.
	 */
	public function maybe_lazy_load_img( $matches ) {
		$tag = $matches[0];

		// Skip if already has loading attribute.
		if ( preg_match( '/\bloading\s*=/i', $tag ) ) {
			return $tag;
		}

		// Skip if has data-no-lazy attribute.
		if ( false !== strpos( $tag, 'data-no-lazy' ) ) {
			return $tag;
		}

		// Skip if matches exclusion patterns.
		if ( $this->is_excluded_from_lazy( $tag ) ) {
			return $tag;
		}

		// Skip first N images (above the fold).
		$this->image_counter++;
		$exclude_first = absint( $this->settings['lazy_load_exclude_first'] );
		if ( $this->image_counter <= $exclude_first ) {
			return $tag;
		}

		// Add loading="lazy" and decoding="async".
		$tag = str_replace( '<img ', '<img loading="lazy" decoding="async" ', $tag );

		return $tag;
	}

	/**
	 * Callback to maybe add lazy loading to an iframe tag.
	 *
	 * @since  1.0.0
	 * @param  array $matches Regex matches.
	 * @return string Modified iframe tag.
	 */
	public function maybe_lazy_load_iframe( $matches ) {
		$tag = $matches[0];

		// Skip if already has loading attribute.
		if ( preg_match( '/\bloading\s*=/i', $tag ) ) {
			return $tag;
		}

		// Skip if has data-no-lazy attribute.
		if ( false !== strpos( $tag, 'data-no-lazy' ) ) {
			return $tag;
		}

		$tag = str_replace( '<iframe ', '<iframe loading="lazy" ', $tag );

		return $tag;
	}

	/**
	 * Check if a tag matches any lazy loading exclusion pattern.
	 *
	 * @since  1.0.0
	 * @param  string $tag HTML tag.
	 * @return bool
	 */
	private function is_excluded_from_lazy( $tag ) {
		foreach ( $this->exclusion_patterns as $pattern ) {
			if ( false !== strpos( $tag, $pattern ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Disable WordPress native lazy loading so we handle it ourselves.
	 *
	 * @since 1.0.0
	 */
	private function setup_disable_native_lazy() {
		if ( empty( $this->settings['lazy_load_images'] ) ) {
			return;
		}

		add_filter( 'wp_lazy_loading_enabled', '__return_false' );
	}

	/**
	 * Setup image compression on upload.
	 *
	 * @since 1.0.0
	 */
	private function setup_compression() {
		if ( empty( $this->settings['compression_enabled'] ) ) {
			return;
		}

		// At least one compression tool (CLI or GD) must be available.
		$best_jpeg = Ultimate_Performance_Image_Optimizer::get_best_tool( 'image/jpeg', 'compress' );
		$best_png  = Ultimate_Performance_Image_Optimizer::get_best_tool( 'image/png', 'compress' );

		if ( 'none' === $best_jpeg && 'none' === $best_png ) {
			return;
		}

		add_filter( 'wp_generate_attachment_metadata', array( $this, 'compress_uploaded_images' ), 5, 2 );
	}

	/**
	 * Compress uploaded images.
	 *
	 * @since  1.0.0
	 * @param  array $metadata      Attachment metadata.
	 * @param  int   $attachment_id Attachment ID.
	 * @return array Unmodified metadata.
	 */
	public function compress_uploaded_images( $metadata, $attachment_id ) {
		$file = get_attached_file( $attachment_id );
		if ( ! $file || ! file_exists( $file ) ) {
			return $metadata;
		}

		$mime = get_post_mime_type( $attachment_id );
		if ( ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/gif' ), true ) ) {
			return $metadata;
		}

		$original_size = filesize( $file );

		// Compress main file using the best available tool.
		$result = $this->compress_image_file( $file, $mime );

		// Compress thumbnails.
		if ( ! empty( $metadata['sizes'] ) ) {
			$upload_dir = dirname( $file );
			foreach ( $metadata['sizes'] as $size ) {
				$thumb_path = $upload_dir . '/' . $size['file'];
				if ( file_exists( $thumb_path ) ) {
					$this->compress_image_file( $thumb_path, $mime );
				}
			}
		}

		// Track compression with original size for savings calculation.
		clearstatcache( true, $file );
		update_post_meta( $attachment_id, '_up_compressed', true );
		update_post_meta( $attachment_id, '_up_original_size', $original_size );

		if ( ! empty( $result['tool'] ) && 'none' !== $result['tool'] ) {
			update_post_meta( $attachment_id, '_up_compression_tool', $result['tool'] );
		}

		return $metadata;
	}

	/**
	 * Compress a single image file using the best available tool.
	 *
	 * Routes through Ultimate_Performance_Image_Optimizer which tries
	 * CLI binaries first, then falls back to GD.
	 *
	 * @since  1.0.0
	 * @param  string $file_path File path.
	 * @param  string $mime      MIME type.
	 * @return array  Compression result from optimizer.
	 */
	private function compress_image_file( $file_path, $mime ) {
		$quality = absint( $this->settings['compression_quality'] );
		return Ultimate_Performance_Image_Optimizer::compress( $file_path, $mime, $quality );
	}

	/**
	 * Setup WebP conversion on upload.
	 *
	 * @since 1.0.0
	 */
	private function setup_webp_conversion() {
		if ( empty( $this->settings['webp_conversion'] ) ) {
			return;
		}

		// At least one WebP tool (cwebp or GD) must be available.
		$best = Ultimate_Performance_Image_Optimizer::get_best_tool( 'image/jpeg', 'webp' );
		if ( 'none' === $best ) {
			return;
		}

		add_filter( 'wp_generate_attachment_metadata', array( $this, 'generate_webp_copies' ), 10, 2 );
	}

	/**
	 * Generate WebP copies of uploaded images.
	 *
	 * @since  1.0.0
	 * @param  array $metadata      Attachment metadata.
	 * @param  int   $attachment_id Attachment ID.
	 * @return array Unmodified metadata.
	 */
	public function generate_webp_copies( $metadata, $attachment_id ) {
		$file = get_attached_file( $attachment_id );
		if ( ! $file || ! file_exists( $file ) ) {
			return $metadata;
		}

		$mime = get_post_mime_type( $attachment_id );
		if ( ! in_array( $mime, array( 'image/jpeg', 'image/png' ), true ) ) {
			return $metadata;
		}

		// Convert main file.
		$this->create_webp_file( $file, $mime );

		// Convert thumbnails.
		if ( ! empty( $metadata['sizes'] ) ) {
			$upload_dir = dirname( $file );
			foreach ( $metadata['sizes'] as $size ) {
				$thumb_path = $upload_dir . '/' . $size['file'];
				if ( file_exists( $thumb_path ) ) {
					$thumb_mime = isset( $size['mime-type'] ) ? $size['mime-type'] : $mime;
					$this->create_webp_file( $thumb_path, $thumb_mime );
				}
			}
		}

		// Mark attachment as having WebP versions.
		update_post_meta( $attachment_id, '_up_has_webp', true );

		return $metadata;
	}

	/**
	 * Create a WebP copy of an image file.
	 *
	 * Routes through Ultimate_Performance_Image_Optimizer which tries
	 * cwebp first, then falls back to GD.
	 *
	 * @since  1.0.0
	 * @param  string $source_path Source image path.
	 * @param  string $mime        MIME type.
	 * @return string|false        WebP file path or false on failure.
	 */
	private function create_webp_file( $source_path, $mime ) {
		$quality = absint( $this->settings['webp_quality'] );
		return Ultimate_Performance_Image_Optimizer::create_webp( $source_path, $mime, $quality );
	}

	/**
	 * Setup cleanup of WebP files when attachment is deleted.
	 *
	 * @since 1.0.0
	 */
	private function setup_webp_cleanup() {
		if ( empty( $this->settings['webp_conversion'] ) ) {
			return;
		}

		add_action( 'delete_attachment', array( $this, 'cleanup_webp_files' ) );
	}

	/**
	 * Delete WebP files when an attachment is deleted.
	 *
	 * @since 1.0.0
	 * @param int $attachment_id Attachment ID.
	 */
	public function cleanup_webp_files( $attachment_id ) {
		$file = get_attached_file( $attachment_id );
		if ( ! $file ) {
			return;
		}

		// Delete main WebP file.
		$webp = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file );
		if ( file_exists( $webp ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			unlink( $webp );
		}

		// Delete thumbnail WebP files.
		$metadata = wp_get_attachment_metadata( $attachment_id );
		if ( ! empty( $metadata['sizes'] ) ) {
			$upload_dir = dirname( $file );
			foreach ( $metadata['sizes'] as $size ) {
				$webp_thumb = $upload_dir . '/' . preg_replace( '/\.(jpe?g|png)$/i', '.webp', $size['file'] );
				if ( file_exists( $webp_thumb ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
					unlink( $webp_thumb );
				}
			}
		}

		delete_post_meta( $attachment_id, '_up_has_webp' );
	}

	/**
	 * Setup the Media Library status columns and attachment details.
	 *
	 * @since 1.0.0
	 */
	private function setup_media_library_column() {
		$has_webp       = ! empty( $this->settings['webp_conversion'] );
		$has_compress   = ! empty( $this->settings['compression_enabled'] );

		if ( ! $has_webp && ! $has_compress ) {
			return;
		}

		add_filter( 'manage_media_columns', array( $this, 'add_image_columns' ) );
		add_action( 'manage_media_custom_column', array( $this, 'render_webp_column' ), 10, 2 );
		add_action( 'manage_media_custom_column', array( $this, 'render_compressed_column' ), 10, 2 );

		if ( $has_webp ) {
			add_filter( 'attachment_fields_to_edit', array( $this, 'add_webp_attachment_field' ), 10, 2 );
		}
	}

	/**
	 * Add image optimization columns to Media Library list view.
	 *
	 * @since  1.0.0
	 * @param  array $columns Existing columns.
	 * @return array Modified columns.
	 */
	public function add_image_columns( $columns ) {
		if ( ! empty( $this->settings['compression_enabled'] ) ) {
			$columns['up_compressed'] = __( 'Compressed', 'ultimate-performance' );
		}
		if ( ! empty( $this->settings['webp_conversion'] ) ) {
			$columns['up_webp'] = __( 'WebP', 'ultimate-performance' );
		}
		return $columns;
	}

	/**
	 * Render the WebP status column content.
	 *
	 * @since 1.0.0
	 * @param string $column_name Column identifier.
	 * @param int    $post_id     Attachment ID.
	 */
	public function render_webp_column( $column_name, $post_id ) {
		if ( 'up_webp' !== $column_name ) {
			return;
		}

		$mime = get_post_mime_type( $post_id );
		if ( ! in_array( $mime, array( 'image/jpeg', 'image/png' ), true ) ) {
			echo '<span style="color:#9ca3af;">—</span>';
			return;
		}

		$file = get_attached_file( $post_id );
		if ( ! $file || ! file_exists( $file ) ) {
			echo '<span style="color:#9ca3af;">—</span>';
			return;
		}

		$webp_path = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file );

		if ( file_exists( $webp_path ) ) {
			$original_size = filesize( $file );
			$webp_size     = filesize( $webp_path );

			if ( $original_size > 0 ) {
				$savings = round( ( 1 - $webp_size / $original_size ) * 100 );
				printf(
					'<span style="color:#059669;" title="%s">%s</span><br><small style="color:#6b7280;">%s</small>',
					esc_attr( size_format( $webp_size ) ),
					esc_html__( 'Converted', 'ultimate-performance' ),
					/* translators: %s: percentage savings */
					esc_html( sprintf( __( '%s%% smaller', 'ultimate-performance' ), $savings ) )
				);
			} else {
				printf( '<span style="color:#059669;">%s</span>', esc_html__( 'Converted', 'ultimate-performance' ) );
			}
		} else {
			printf( '<span style="color:#d97706;">%s</span>', esc_html__( 'Not converted', 'ultimate-performance' ) );
		}
	}

	/**
	 * Render the Compressed status column content.
	 *
	 * @since 1.0.0
	 * @param string $column_name Column identifier.
	 * @param int    $post_id     Attachment ID.
	 */
	public function render_compressed_column( $column_name, $post_id ) {
		if ( 'up_compressed' !== $column_name ) {
			return;
		}

		$mime = get_post_mime_type( $post_id );
		if ( ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/gif' ), true ) ) {
			echo '<span style="color:#9ca3af;">—</span>';
			return;
		}

		$is_compressed = get_post_meta( $post_id, '_up_compressed', true );

		if ( $is_compressed ) {
			$original_size = get_post_meta( $post_id, '_up_original_size', true );
			$file          = get_attached_file( $post_id );
			$current_size  = $file && file_exists( $file ) ? filesize( $file ) : 0;
			$tool_used     = get_post_meta( $post_id, '_up_compression_tool', true );
			$tool_label    = $tool_used ? ' (' . esc_html( $tool_used ) . ')' : '';

			if ( $original_size && $current_size > 0 ) {
				$savings = round( ( 1 - $current_size / $original_size ) * 100 );
				printf(
					'<span style="color:#059669;" title="%s → %s">%s</span><br><small style="color:#6b7280;">%s%s</small>',
					esc_attr( size_format( $original_size ) ),
					esc_attr( size_format( $current_size ) ),
					esc_html__( 'Compressed', 'ultimate-performance' ),
					/* translators: %s: percentage savings */
					esc_html( sprintf( __( '%s%% smaller', 'ultimate-performance' ), $savings ) ),
					wp_kses_post( $tool_label )
				);
			} else {
				printf( '<span style="color:#059669;">%s</span>', esc_html__( 'Compressed', 'ultimate-performance' ) );
			}
		} else {
			printf( '<span style="color:#d97706;">%s</span>', esc_html__( 'Not compressed', 'ultimate-performance' ) );
		}
	}

	/**
	 * Add WebP status field to the attachment edit/detail modal.
	 *
	 * @since  1.0.0
	 * @param  array   $form_fields Existing fields.
	 * @param  WP_Post $post        Attachment post object.
	 * @return array   Modified fields.
	 */
	public function add_webp_attachment_field( $form_fields, $post ) {
		$mime = get_post_mime_type( $post->ID );
		if ( ! in_array( $mime, array( 'image/jpeg', 'image/png' ), true ) ) {
			return $form_fields;
		}

		$file = get_attached_file( $post->ID );
		if ( ! $file || ! file_exists( $file ) ) {
			return $form_fields;
		}

		$webp_path = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file );

		if ( file_exists( $webp_path ) ) {
			$original_size = filesize( $file );
			$webp_size     = filesize( $webp_path );
			$savings       = $original_size > 0 ? round( ( 1 - $webp_size / $original_size ) * 100 ) : 0;

			$html = sprintf(
				'<span style="color:#059669; font-weight: 600;">%s</span> &mdash; %s → %s (%s%% %s)',
				esc_html__( 'Converted', 'ultimate-performance' ),
				esc_html( size_format( $original_size ) ),
				esc_html( size_format( $webp_size ) ),
				esc_html( $savings ),
				esc_html__( 'smaller', 'ultimate-performance' )
			);
		} else {
			$html = sprintf(
				'<span style="color:#d97706;">%s</span>',
				esc_html__( 'Not converted. Re-upload or run bulk conversion.', 'ultimate-performance' )
			);
		}

		$form_fields['up_webp_status'] = array(
			'label' => __( 'WebP Status', 'ultimate-performance' ),
			'input' => 'html',
			'html'  => $html,
		);

		return $form_fields;
	}

	/**
	 * AJAX handler: Bulk convert existing images to WebP.
	 *
	 * Processes a batch of images per request.
	 *
	 * @since 1.0.0
	 */
	public function ajax_bulk_webp_convert() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$best_webp = Ultimate_Performance_Image_Optimizer::get_best_tool( 'image/jpeg', 'webp' );
		if ( 'none' === $best_webp ) {
			wp_send_json_error( array( 'message' => __( 'No WebP conversion tool available (no cwebp binary or GD WebP support found).', 'ultimate-performance' ) ) );
		}

		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'image_optimization' );

		$offset     = isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;
		$batch_size = 5;

		// Query images that don't have WebP copies yet.
		$args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => array( 'image/jpeg', 'image/png' ),
			'post_status'    => 'inherit',
			'posts_per_page' => $batch_size,
			'offset'         => $offset,
			'fields'         => 'ids',
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Required to find unprocessed attachments.
				array(
					'key'     => '_up_has_webp',
					'compare' => 'NOT EXISTS',
				),
			),
		);

		$query      = new WP_Query( $args );
		$ids        = $query->posts;
		$total      = $query->found_posts;
		$converted  = 0;

		foreach ( $ids as $attachment_id ) {
			$file = get_attached_file( $attachment_id );
			if ( ! $file || ! file_exists( $file ) ) {
				continue;
			}

			$mime     = get_post_mime_type( $attachment_id );
			$metadata = wp_get_attachment_metadata( $attachment_id );

			// Convert main file.
			$result = $this->create_webp_file( $file, $mime );

			// Convert thumbnails.
			if ( ! empty( $metadata['sizes'] ) ) {
				$upload_dir = dirname( $file );
				foreach ( $metadata['sizes'] as $size ) {
					$thumb_path = $upload_dir . '/' . $size['file'];
					if ( file_exists( $thumb_path ) ) {
						$thumb_mime = isset( $size['mime-type'] ) ? $size['mime-type'] : $mime;
						$this->create_webp_file( $thumb_path, $thumb_mime );
					}
				}
			}

			if ( $result ) {
				update_post_meta( $attachment_id, '_up_has_webp', true );
				$converted++;
			}
		}

		$remaining = max( 0, $total - $converted );

		wp_send_json_success( array(
			'converted' => $converted,
			'remaining' => $remaining,
			'total'     => $total,
			'done'      => empty( $ids ),
			'message'   => $remaining > 0
				/* translators: %d: number of remaining images */
				? sprintf( __( '%d images remaining...', 'ultimate-performance' ), $remaining )
				: __( 'All images have been converted to WebP!', 'ultimate-performance' ),
		) );
	}

	/**
	 * AJAX handler: Bulk compress existing images.
	 *
	 * Processes a batch of images per request.
	 *
	 * @since 1.0.0
	 */
	public function ajax_bulk_compress() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$best_jpeg = Ultimate_Performance_Image_Optimizer::get_best_tool( 'image/jpeg', 'compress' );
		$best_png  = Ultimate_Performance_Image_Optimizer::get_best_tool( 'image/png', 'compress' );

		if ( 'none' === $best_jpeg && 'none' === $best_png ) {
			wp_send_json_error( array( 'message' => __( 'No image compression tools are available (no CLI tools or GD library found).', 'ultimate-performance' ) ) );
		}

		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'image_optimization' );

		$batch_size = 5;

		// Query images that haven't been compressed yet.
		$mime_types = array( 'image/jpeg', 'image/png' );

		// Include GIF if gifsicle is available.
		$best_gif = Ultimate_Performance_Image_Optimizer::get_best_tool( 'image/gif', 'compress' );
		if ( 'none' !== $best_gif ) {
			$mime_types[] = 'image/gif';
		}

		$args = array(
			'post_type'      => 'attachment',
			'post_mime_type' => $mime_types,
			'post_status'    => 'inherit',
			'posts_per_page' => $batch_size,
			'fields'         => 'ids',
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Required to find unprocessed attachments.
				array(
					'key'     => '_up_compressed',
					'compare' => 'NOT EXISTS',
				),
			),
		);

		$query      = new WP_Query( $args );
		$ids        = $query->posts;
		$total      = $query->found_posts;
		$compressed = 0;

		foreach ( $ids as $attachment_id ) {
			$file = get_attached_file( $attachment_id );
			if ( ! $file || ! file_exists( $file ) ) {
				// Mark as processed even if file missing to avoid reprocessing.
				update_post_meta( $attachment_id, '_up_compressed', true );
				continue;
			}

			$mime          = get_post_mime_type( $attachment_id );
			$metadata      = wp_get_attachment_metadata( $attachment_id );
			$original_size = filesize( $file );

			// Compress main file via optimizer.
			$result = $this->compress_image_file( $file, $mime );

			// Compress thumbnails.
			if ( ! empty( $metadata['sizes'] ) ) {
				$upload_dir = dirname( $file );
				foreach ( $metadata['sizes'] as $size ) {
					$thumb_path = $upload_dir . '/' . $size['file'];
					if ( file_exists( $thumb_path ) ) {
						$this->compress_image_file( $thumb_path, $mime );
					}
				}
			}

			clearstatcache( true, $file );
			update_post_meta( $attachment_id, '_up_compressed', true );
			update_post_meta( $attachment_id, '_up_original_size', $original_size );

			if ( ! empty( $result['tool'] ) && 'none' !== $result['tool'] ) {
				update_post_meta( $attachment_id, '_up_compression_tool', $result['tool'] );
			}

			$compressed++;
		}

		$remaining = max( 0, $total - $compressed );

		wp_send_json_success( array(
			'compressed' => $compressed,
			'remaining'  => $remaining,
			'total'      => $total,
			'done'       => empty( $ids ),
			'message'    => $remaining > 0
				/* translators: %d: number of remaining images */
				? sprintf( __( '%d images remaining...', 'ultimate-performance' ), $remaining )
				: __( 'All images have been compressed!', 'ultimate-performance' ),
		) );
	}

	/**
	 * AJAX handler: Re-detect available image optimization tools.
	 *
	 * @since 1.1.0
	 */
	public function ajax_detect_image_tools() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		// Force-refresh detection (clears transient cache).
		$tools   = Ultimate_Performance_Image_Optimizer::detect_tools( true );
		$exec_ok = Ultimate_Performance_Image_Optimizer::is_exec_available();

		wp_send_json_success( array(
			'tools'   => $tools,
			'exec_ok' => $exec_ok,
		) );
	}

	/**
	 * Convert a URL to a local file path.
	 *
	 * @since  1.0.0
	 * @param  string $url Asset URL.
	 * @return string|false Local file path or false if not local.
	 */
	private function url_to_local_path( $url ) {
		$site_url    = site_url();
		$content_url = content_url();

		// Strip query string.
		$url = strtok( $url, '?' );

		// Handle protocol-relative URLs.
		if ( 0 === strpos( $url, '//' ) ) {
			$url = 'https:' . $url;
		}

		if ( 0 === strpos( $url, $site_url ) ) {
			$relative = str_replace( $site_url, '', $url );
			return ABSPATH . ltrim( $relative, '/' );
		}

		if ( 0 === strpos( $url, $content_url ) ) {
			$relative = str_replace( $content_url, '', $url );
			return WP_CONTENT_DIR . '/' . ltrim( $relative, '/' );
		}

		if ( 0 === strpos( $url, '/' ) ) {
			return ABSPATH . ltrim( $url, '/' );
		}

		return false;
	}

	/**
	 * Parse a textarea value into an array of non-empty trimmed lines.
	 *
	 * @since  1.0.0
	 * @param  string $text Textarea value.
	 * @return array  Non-empty lines.
	 */
	private function parse_textarea_lines( $text ) {
		if ( empty( $text ) ) {
			return array();
		}

		$lines = preg_split( '/\r\n|\r|\n/', $text );
		$lines = array_map( 'trim', $lines );
		$lines = array_filter( $lines, 'strlen' );

		return array_values( $lines );
	}
}
