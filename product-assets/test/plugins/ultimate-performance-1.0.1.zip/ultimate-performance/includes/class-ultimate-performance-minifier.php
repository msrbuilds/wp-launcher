<?php
/**
 * Static minification utility for CSS, JS, and HTML.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Minifier
 *
 * Provides static methods for minifying CSS, JS, and HTML content.
 * Handles cache file storage in wp-content/cache/ultimate-performance/min/.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Minifier {

	/**
	 * Minify CSS content.
	 *
	 * Strips comments, collapses whitespace, removes unnecessary semicolons.
	 *
	 * @since  1.0.0
	 * @param  string $css Raw CSS content.
	 * @return string Minified CSS.
	 */
	public static function minify_css( $css ) {
		if ( empty( $css ) ) {
			return $css;
		}

		// Remove comments.
		$css = preg_replace( '!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css );

		// Remove whitespace around selectors, braces, colons, semicolons.
		$css = preg_replace( '/\s*([{}:;,>~+])\s*/', '$1', $css );

		// Collapse remaining whitespace.
		$css = preg_replace( '/\s+/', ' ', $css );

		// Remove trailing semicolons before closing braces.
		$css = str_replace( ';}', '}', $css );

		return trim( $css );
	}

	/**
	 * Minify JavaScript content (conservative).
	 *
	 * Strips single-line and multi-line comments while preserving strings,
	 * then collapses whitespace.
	 *
	 * @since  1.0.0
	 * @param  string $js Raw JS content.
	 * @return string Minified JS.
	 */
	public static function minify_js( $js ) {
		if ( empty( $js ) ) {
			return $js;
		}

		// Token-aware comment removal: walk the source character by character,
		// skipping over string literals, template literals, and regex literals
		// so that comment delimiters inside them are never touched.
		$len    = strlen( $js );
		$out    = '';
		$i      = 0;

		while ( $i < $len ) {
			$ch = $js[ $i ];

			// Single-quoted string.
			if ( "'" === $ch ) {
				$end = self::skip_js_string( $js, $i, $len, "'" );
				$out .= substr( $js, $i, $end - $i );
				$i    = $end;
				continue;
			}

			// Double-quoted string.
			if ( '"' === $ch ) {
				$end = self::skip_js_string( $js, $i, $len, '"' );
				$out .= substr( $js, $i, $end - $i );
				$i    = $end;
				continue;
			}

			// Template literal.
			if ( '`' === $ch ) {
				$end = self::skip_js_string( $js, $i, $len, '`' );
				$out .= substr( $js, $i, $end - $i );
				$i    = $end;
				continue;
			}

			// Forward slash — could be comment, regex, or division.
			if ( '/' === $ch && $i + 1 < $len ) {
				$next = $js[ $i + 1 ];

				// Multi-line comment.
				if ( '*' === $next ) {
					$close = strpos( $js, '*/', $i + 2 );
					$i     = false === $close ? $len : $close + 2;
					$out  .= ' ';
					continue;
				}

				// Single-line comment.
				if ( '/' === $next ) {
					$eol = strpos( $js, "\n", $i + 2 );
					$i   = false === $eol ? $len : $eol;
					continue;
				}

				// Regex literal: a / after certain tokens is a regex, not division.
				if ( self::is_js_regex_context( $out ) ) {
					$end  = self::skip_js_regex( $js, $i, $len );
					$out .= substr( $js, $i, $end - $i );
					$i    = $end;
					continue;
				}
			}

			$out .= $ch;
			$i++;
		}

		$js = $out;

		// Collapse multiple whitespace/newlines.
		$js = preg_replace( '/[ \t]+/', ' ', $js );
		$js = preg_replace( '/\n\s*\n/', "\n", $js );

		return trim( $js );
	}

	/**
	 * Skip past a JS string literal (single, double, or backtick).
	 *
	 * @since  1.1.0
	 * @param  string $js    Source code.
	 * @param  int    $start Position of the opening quote.
	 * @param  int    $len   Source length.
	 * @param  string $quote Quote character.
	 * @return int    Position after the closing quote.
	 */
	private static function skip_js_string( $js, $start, $len, $quote ) {
		$i = $start + 1;
		while ( $i < $len ) {
			if ( '\\' === $js[ $i ] ) {
				$i += 2;
				continue;
			}
			if ( $js[ $i ] === $quote ) {
				return $i + 1;
			}
			$i++;
		}
		return $len;
	}

	/**
	 * Skip past a JS regex literal including flags.
	 *
	 * @since  1.1.0
	 * @param  string $js    Source code.
	 * @param  int    $start Position of the opening /.
	 * @param  int    $len   Source length.
	 * @return int    Position after the regex (including flags).
	 */
	private static function skip_js_regex( $js, $start, $len ) {
		$i = $start + 1;
		while ( $i < $len ) {
			$ch = $js[ $i ];
			if ( '\\' === $ch ) {
				$i += 2;
				continue;
			}
			if ( '[' === $ch ) {
				// Inside character class — skip to ].
				$i++;
				while ( $i < $len && ']' !== $js[ $i ] ) {
					if ( '\\' === $js[ $i ] ) {
						$i++;
					}
					$i++;
				}
				$i++;
				continue;
			}
			if ( '/' === $ch ) {
				$i++;
				// Consume flags (gimsuvy).
				while ( $i < $len && ctype_alpha( $js[ $i ] ) ) {
					$i++;
				}
				return $i;
			}
			if ( "\n" === $ch ) {
				// Unterminated regex — bail.
				return $start + 1;
			}
			$i++;
		}
		return $len;
	}

	/**
	 * Determine whether the current position in output is a regex context.
	 *
	 * A / is a regex literal (not division) when preceded by an operator,
	 * keyword, opening bracket/paren, comma, semicolon, or line start.
	 *
	 * @since  1.1.0
	 * @param  string $preceding Accumulated output so far.
	 * @return bool
	 */
	private static function is_js_regex_context( $preceding ) {
		$trimmed = rtrim( $preceding );
		if ( '' === $trimmed ) {
			return true;
		}
		$last = substr( $trimmed, -1 );

		// After these characters, / starts a regex.
		if ( false !== strpos( '=({[;,!&|?:~^%*+-><', $last ) ) {
			return true;
		}

		// After `return`, `typeof`, `instanceof`, `in`, `throw`, `new`, `delete`, `void`, `case`.
		$keywords = array( 'return', 'typeof', 'instanceof', 'in', 'throw', 'new', 'delete', 'void', 'case' );
		foreach ( $keywords as $kw ) {
			$kwlen = strlen( $kw );
			if ( strlen( $trimmed ) >= $kwlen && substr( $trimmed, -$kwlen ) === $kw ) {
				$before = strlen( $trimmed ) > $kwlen ? substr( $trimmed, -$kwlen - 1, 1 ) : '';
				if ( '' === $before || ! ctype_alnum( $before ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Minify HTML content.
	 *
	 * Strips HTML comments (not IE conditionals), collapses inter-tag whitespace,
	 * preserves content in pre, code, textarea, script, and style tags.
	 *
	 * @since  1.0.0
	 * @param  string $html Raw HTML content.
	 * @return string Minified HTML.
	 */
	public static function minify_html( $html ) {
		if ( empty( $html ) ) {
			return $html;
		}

		// Preserve content inside special tags.
		$preserved = array();
		$html = preg_replace_callback(
			'/<(pre|code|textarea|script|style)\b[^>]*>.*?<\/\1>/is',
			function ( $matches ) use ( &$preserved ) {
				$key = '<!--UP_PRESERVE_' . count( $preserved ) . '-->';
				$preserved[ $key ] = $matches[0];
				return $key;
			},
			$html
		);

		// Remove HTML comments (except IE conditionals).
		$html = preg_replace( '/<!--(?!\[if)(?!UP_PRESERVE).*?-->/s', '', $html );

		// Collapse whitespace between tags.
		$html = preg_replace( '/>\s+</', '> <', $html );

		// Collapse multiple spaces.
		$html = preg_replace( '/\s+/', ' ', $html );

		// Restore preserved blocks.
		$html = str_replace( array_keys( $preserved ), array_values( $preserved ), $html );

		return trim( $html );
	}

	/**
	 * Get the cache directory path.
	 *
	 * @since  1.0.0
	 * @return string Cache directory path with trailing slash.
	 */
	public static function get_cache_dir() {
		return WP_CONTENT_DIR . '/cache/ultimate-performance/min/';
	}

	/**
	 * Get the cache directory URL.
	 *
	 * @since  1.0.0
	 * @return string Cache directory URL with trailing slash.
	 */
	public static function get_cache_url() {
		return content_url( '/cache/ultimate-performance/min/' );
	}

	/**
	 * Get or create a cached minified file.
	 *
	 * @since  1.0.0
	 * @param  string $content   Minified content.
	 * @param  string $ext       File extension (css or js).
	 * @param  string $cache_key Unique cache key (e.g., md5 of path + filemtime).
	 * @return string|false      Cached file URL, or false on failure.
	 */
	public static function get_cached_file( $content, $ext, $cache_key ) {
		$dir  = self::get_cache_dir();
		$file = $cache_key . '.' . $ext;
		$path = $dir . $file;

		if ( file_exists( $path ) ) {
			return self::get_cache_url() . $file;
		}

		if ( ! wp_mkdir_p( $dir ) ) {
			return false;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false === file_put_contents( $path, $content ) ) {
			return false;
		}

		return self::get_cache_url() . $file;
	}

	/**
	 * Clear all minification cache files.
	 *
	 * @since 1.0.0
	 */
	public static function clear_cache() {
		$dir = self::get_cache_dir();

		if ( ! is_dir( $dir ) ) {
			return;
		}

		$files = glob( $dir . '*' );
		if ( $files ) {
			foreach ( $files as $file ) {
				if ( is_file( $file ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
					unlink( $file );
				}
			}
		}
	}
}
