<?php
/**
 * Handles web fonts optimization: local Google Fonts hosting, font-display, preloading.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Webfonts
 *
 * Detects Google Fonts in enqueued stylesheets, downloads and locally hosts
 * them for GDPR compliance and performance. Injects font-display: swap and
 * preload hints for locally hosted font files.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Webfonts {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Local fonts directory path.
	 *
	 * @since 1.0.0
	 * @var   string
	 */
	private $fonts_dir;

	/**
	 * Local fonts directory URL.
	 *
	 * @since 1.0.0
	 * @var   string
	 */
	private $fonts_url;

	/**
	 * Initialize the web fonts module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings  = Ultimate_Performance_Settings::get_module_settings( 'webfonts' );
		$this->fonts_dir = WP_CONTENT_DIR . '/fonts/ultimate-performance/';
		$this->fonts_url = content_url( '/fonts/ultimate-performance/' );

		// Always register AJAX handler.
		add_action( 'wp_ajax_up_clear_local_fonts', array( $this, 'ajax_clear_local_fonts' ) );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		$this->setup_local_google_fonts();
		$this->setup_font_display_swap();
		$this->setup_preload_fonts();
	}

	/**
	 * Setup local Google Fonts hosting.
	 *
	 * @since 1.0.0
	 */
	private function setup_local_google_fonts() {
		if ( empty( $this->settings['local_google_fonts'] ) ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'intercept_google_fonts' ), 9999 );
	}

	/**
	 * Intercept Google Fonts stylesheets and replace with local copies.
	 *
	 * @since 1.0.0
	 */
	public function intercept_google_fonts() {
		if ( is_admin() ) {
			return;
		}

		global $wp_styles;

		if ( empty( $wp_styles->registered ) ) {
			return;
		}

		$font_map = get_transient( 'up_local_fonts_map' );
		if ( ! is_array( $font_map ) ) {
			$font_map = array();
		}

		$map_changed = false;

		foreach ( $wp_styles->registered as $handle => $style ) {
			if ( empty( $style->src ) ) {
				continue;
			}

			if ( false === strpos( $style->src, 'fonts.googleapis.com' ) ) {
				continue;
			}

			$url_hash = md5( preg_replace( '/^https?:/', '', $style->src ) );

			// Check if already locally cached.
			if ( isset( $font_map[ $url_hash ] ) && file_exists( $font_map[ $url_hash ] ) ) {
				$local_url = $this->fonts_url . $url_hash . '.css';
			} else {
				// Download and cache locally.
				$local_path = $this->download_google_fonts_css( $style->src, $url_hash );
				if ( ! $local_path ) {
					continue;
				}
				$font_map[ $url_hash ] = $local_path;
				$map_changed = true;
				$local_url = $this->fonts_url . $url_hash . '.css';
			}

			// Replace the stylesheet source.
			$deps = $style->deps;
			$ver  = $style->ver;
			wp_deregister_style( $handle );
			wp_register_style( $handle, $local_url, $deps, $ver );
			wp_enqueue_style( $handle );
		}

		if ( $map_changed ) {
			set_transient( 'up_local_fonts_map', $font_map, 0 );
		}
	}

	/**
	 * Download Google Fonts CSS and font files to local storage.
	 *
	 * @since  1.0.0
	 * @param  string $url      Google Fonts CSS URL.
	 * @param  string $url_hash MD5 hash of the URL.
	 * @return string|false     Local CSS file path or false on failure.
	 */
	private function download_google_fonts_css( $url, $url_hash ) {
		// Use Chrome user-agent to get woff2 format.
		$response = wp_remote_get( $url, array(
			'timeout'    => 30,
			'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
		) );

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$css = wp_remote_retrieve_body( $response );
		if ( empty( $css ) ) {
			return false;
		}

		// Create font directory.
		$font_subdir = $this->fonts_dir . $url_hash . '/';
		if ( ! wp_mkdir_p( $font_subdir ) ) {
			return false;
		}

		$this->ensure_fonts_dir();

		// Extract and download font file URLs.
		$css = preg_replace_callback(
			'/url\s*\(\s*([\'"]?)([^\'"\)]+)\1\s*\)/',
			function ( $matches ) use ( $font_subdir, $url_hash ) {
				$font_url = $matches[2];

				// Only process external URLs.
				if ( 0 !== strpos( $font_url, 'http' ) ) {
					return $matches[0];
				}

				$font_filename = basename( wp_parse_url( $font_url, PHP_URL_PATH ) );
				$local_path    = $font_subdir . $font_filename;

				if ( ! file_exists( $local_path ) ) {
					$font_response = wp_remote_get( $font_url, array( 'timeout' => 30 ) );
					if ( ! is_wp_error( $font_response ) && 200 === wp_remote_retrieve_response_code( $font_response ) ) {
						// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
						file_put_contents( $local_path, wp_remote_retrieve_body( $font_response ) );
					}
				}

				$local_url = content_url( '/fonts/ultimate-performance/' . $url_hash . '/' . $font_filename );
				return 'url(' . $matches[1] . $local_url . $matches[1] . ')';
			},
			$css
		);

		// Inject font-display: swap into @font-face blocks.
		$css = preg_replace(
			'/@font-face\s*\{/',
			'@font-face{font-display:swap;',
			$css
		);

		// Save rewritten CSS.
		$css_path = $this->fonts_dir . $url_hash . '.css';
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false === file_put_contents( $css_path, $css ) ) {
			return false;
		}

		return $css_path;
	}

	/**
	 * Setup font-display: swap for all font sources.
	 *
	 * Rewrites stylesheets that contain @font-face blocks missing font-display
	 * and appends display=swap to remote Google Fonts URLs.
	 *
	 * @since 1.0.0
	 */
	private function setup_font_display_swap() {
		if ( empty( $this->settings['font_display_swap'] ) ) {
			return;
		}

		// Rewrite local CSS files that contain @font-face without font-display.
		add_filter( 'style_loader_tag', array( $this, 'rewrite_font_display_in_css' ), 5, 4 );
		// Append display=swap to remote Google Fonts URLs.
		add_filter( 'style_loader_tag', array( $this, 'maybe_add_font_display' ), 10, 4 );
		// Catch inline @font-face in the HTML output.
		add_action( 'template_redirect', array( $this, 'start_font_display_buffer' ), 1 );
	}

	/**
	 * Rewrite a local stylesheet to inject font-display: swap into @font-face blocks.
	 *
	 * Reads the CSS file, injects font-display: swap into any @font-face block
	 * that doesn't already have it, caches the result, and swaps the URL.
	 *
	 * @since  1.1.0
	 * @param  string $tag    The link tag HTML.
	 * @param  string $handle The stylesheet handle.
	 * @param  string $href   The stylesheet URL.
	 * @param  string $media  The stylesheet media attribute.
	 * @return string Modified tag.
	 */
	public function rewrite_font_display_in_css( $tag, $handle, $href, $media ) {
		if ( is_admin() ) {
			return $tag;
		}

		// Skip remote URLs (Google Fonts handled by maybe_add_font_display).
		if ( false !== strpos( $href, 'fonts.googleapis.com' ) ) {
			return $tag;
		}

		$local_path = $this->url_to_local_path( $href );
		if ( ! $local_path || ! file_exists( $local_path ) ) {
			return $tag;
		}

		// Quick check: only process files that actually contain @font-face.
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$css = file_get_contents( $local_path );
		if ( false === $css || false === stripos( $css, '@font-face' ) ) {
			return $tag;
		}

		// Skip if all @font-face blocks already use font-display: swap.
		// We still need to process files where font-display is missing OR
		// set to a non-swap value (e.g., Font Awesome uses "block").
		$needs_rewrite = false;
		if ( preg_match_all( '/@font-face\s*\{([^}]+)\}/is', $css, $ff_blocks ) ) {
			foreach ( $ff_blocks[1] as $block ) {
				if ( false === stripos( $block, 'font-display' ) ) {
					$needs_rewrite = true;
					break;
				}
				if ( ! preg_match( '/font-display\s*:\s*swap/i', $block ) ) {
					$needs_rewrite = true;
					break;
				}
			}
		}
		if ( ! $needs_rewrite ) {
			return $tag;
		}

		// Check cache.
		$cache_key  = 'up_fd_' . md5( $local_path . filemtime( $local_path ) );
		$cache_dir  = WP_CONTENT_DIR . '/cache/ultimate-performance/fonts/';
		$cache_file = $cache_dir . $cache_key . '.css';

		if ( file_exists( $cache_file ) ) {
			$cached_url = content_url( '/cache/ultimate-performance/fonts/' . $cache_key . '.css' );
			return str_replace( strtok( $href, '?' ), $cached_url, $tag );
		}

		// Inject or replace font-display in @font-face blocks.
		$rewritten = preg_replace_callback(
			'/@font-face\s*\{([^}]+)\}/is',
			function ( $matches ) {
				$block = $matches[1];

				if ( false !== stripos( $block, 'font-display' ) ) {
					// Replace existing font-display value with swap.
					$block = preg_replace( '/font-display\s*:\s*[^;}\s]+/i', 'font-display:swap', $block );
					return '@font-face{' . $block . '}';
				}

				// Inject font-display: swap when missing.
				return '@font-face{font-display:swap;' . $block . '}';
			},
			$css
		);

		if ( null === $rewritten ) {
			return $tag;
		}

		// Resolve relative URLs since the file will be served from cache dir.
		$rewritten = $this->resolve_font_css_urls( $rewritten, $local_path );

		// Cache the rewritten CSS.
		if ( ! wp_mkdir_p( $cache_dir ) ) {
			return $tag;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false === file_put_contents( $cache_file, $rewritten ) ) {
			return $tag;
		}

		$cached_url = content_url( '/cache/ultimate-performance/fonts/' . $cache_key . '.css' );
		return str_replace( strtok( $href, '?' ), $cached_url, $tag );
	}

	/**
	 * Resolve relative URLs in CSS for font-display rewriting.
	 *
	 * @since  1.1.0
	 * @param  string $css        CSS content.
	 * @param  string $local_path Original CSS file path.
	 * @return string CSS with resolved URLs.
	 */
	private function resolve_font_css_urls( $css, $local_path ) {
		$css_dir  = wp_normalize_path( dirname( $local_path ) );
		$abspath  = wp_normalize_path( ABSPATH );
		$site_url = site_url();

		return preg_replace_callback(
			'/url\(\s*[\'"]?\s*(?!data:|https?:|\/\/|#)([^\'"\)\s]+)[\'"]?\s*\)/i',
			function ( $matches ) use ( $css_dir, $abspath, $site_url ) {
				$relative = $matches[1];

				if ( 0 === strpos( $relative, '/' ) ) {
					return $matches[0];
				}

				$clean    = preg_replace( '/[?#].*$/', '', $relative );
				$absolute = realpath( $css_dir . '/' . $clean );

				if ( ! $absolute ) {
					return $matches[0];
				}

				$absolute = wp_normalize_path( $absolute );

				if ( 0 !== strpos( $absolute, $abspath ) ) {
					return $matches[0];
				}

				$web_path = str_replace( $abspath, '/', $absolute );
				$suffix   = substr( $relative, strlen( $clean ) );
				return 'url(' . $site_url . $web_path . $suffix . ')';
			},
			$css
		) ?? $css;
	}

	/**
	 * Convert a URL to a local file path.
	 *
	 * @since  1.1.0
	 * @param  string $url Asset URL.
	 * @return string|false Local file path or false if not local.
	 */
	private function url_to_local_path( $url ) {
		$url = strtok( $url, '?' );

		if ( 0 === strpos( $url, '//' ) ) {
			$url = 'https:' . $url;
		}

		$site_url    = site_url();
		$content_url = content_url();

		if ( 0 === strpos( $url, $site_url ) ) {
			return ABSPATH . ltrim( str_replace( $site_url, '', $url ), '/' );
		}

		if ( 0 === strpos( $url, $content_url ) ) {
			return WP_CONTENT_DIR . '/' . ltrim( str_replace( $content_url, '', $url ), '/' );
		}

		if ( 0 === strpos( $url, '/' ) ) {
			return ABSPATH . ltrim( $url, '/' );
		}

		return false;
	}

	/**
	 * Append display=swap to remaining remote Google Font URLs.
	 *
	 * @since  1.0.0
	 * @param  string $tag    The link tag HTML.
	 * @param  string $handle The stylesheet handle.
	 * @param  string $href   The stylesheet URL.
	 * @param  string $media  The stylesheet media attribute.
	 * @return string Modified tag.
	 */
	public function maybe_add_font_display( $tag, $handle, $href, $media ) {
		if ( false === strpos( $href, 'fonts.googleapis.com' ) ) {
			return $tag;
		}

		// Add display=swap if not already present.
		if ( false === strpos( $href, 'display=' ) ) {
			$new_href = add_query_arg( 'display', 'swap', $href );
			$tag = str_replace( $href, $new_href, $tag );
		}

		return $tag;
	}

	/**
	 * Start output buffering to inject font-display into inline @font-face.
	 *
	 * @since 1.1.0
	 */
	public function start_font_display_buffer() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}

		ob_start( array( $this, 'inject_font_display_in_html' ) );
	}

	/**
	 * Inject font-display: swap into inline style @font-face blocks in HTML.
	 *
	 * @since  1.1.0
	 * @param  string $html HTML output.
	 * @return string Modified HTML.
	 */
	public function inject_font_display_in_html( $html ) {
		if ( empty( $html ) || false === stripos( $html, '@font-face' ) ) {
			return $html;
		}

		// Find inline <style> blocks containing @font-face and ensure font-display: swap.
		return preg_replace_callback(
			'/<style\b[^>]*>(.*?)<\/style>/is',
			function ( $matches ) {
				$style = $matches[1];
				if ( false === stripos( $style, '@font-face' ) ) {
					return $matches[0];
				}

				$fixed = preg_replace_callback(
					'/@font-face\s*\{([^}]+)\}/is',
					function ( $ff ) {
						$block = $ff[1];
						if ( false !== stripos( $block, 'font-display' ) ) {
							// Replace existing non-swap value with swap.
							if ( preg_match( '/font-display\s*:\s*swap/i', $block ) ) {
								return $ff[0];
							}
							$block = preg_replace( '/font-display\s*:\s*[^;}\s]+/i', 'font-display:swap', $block );
							return '@font-face{' . $block . '}';
						}
						return '@font-face{font-display:swap;' . $ff[1] . '}';
					},
					$style
				);

				return str_replace( $style, $fixed, $matches[0] );
			},
			$html
		) ?? $html;
	}

	/**
	 * Setup font file preloading.
	 *
	 * @since 1.0.0
	 */
	private function setup_preload_fonts() {
		if ( empty( $this->settings['preload_fonts'] ) || empty( $this->settings['local_google_fonts'] ) ) {
			return;
		}

		add_action( 'wp_head', array( $this, 'output_font_preload_links' ), 2 );
	}

	/**
	 * Output preload link tags for locally hosted font files.
	 *
	 * Only preloads font files for the latin unicode-range subset to avoid
	 * excessive preload tags (Google Fonts serves many subsets per family).
	 *
	 * @since 1.0.0
	 */
	public function output_font_preload_links() {
		if ( is_admin() || ! is_dir( $this->fonts_dir ) ) {
			return;
		}

		$font_map = get_transient( 'up_local_fonts_map' );
		if ( ! is_array( $font_map ) || empty( $font_map ) ) {
			return;
		}

		foreach ( $font_map as $url_hash => $css_path ) {
			if ( ! is_string( $css_path ) || ! file_exists( $css_path ) ) {
				continue;
			}

			$latin_fonts = $this->get_latin_font_urls( $css_path, $url_hash );

			foreach ( $latin_fonts as $font_url ) {
				printf(
					'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
					esc_url( $font_url )
				);
			}
		}
	}

	/**
	 * Parse a cached Google Fonts CSS file and return URLs for latin subset only.
	 *
	 * Google Fonts CSS contains comments like "/* latin *​/" before each @font-face
	 * block, and each block has a unicode-range. This method extracts font URLs
	 * from blocks matching the latin subset (U+0000-00FF).
	 *
	 * @since  1.0.0
	 * @param  string $css_path Path to the cached CSS file.
	 * @param  string $url_hash Hash identifier for the font set.
	 * @return array  Array of font URLs to preload.
	 */
	private function get_latin_font_urls( $css_path, $url_hash ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
		$css = file_get_contents( $css_path );
		if ( empty( $css ) ) {
			return array();
		}

		$urls = array();

		// Split CSS into @font-face blocks and check each for latin subset.
		if ( ! preg_match_all( '/@font-face\s*\{[^}]+\}/s', $css, $blocks ) ) {
			return array();
		}

		foreach ( $blocks[0] as $block ) {
			// Check if this block is for the latin subset (U+0000-00FF range).
			if ( false === stripos( $block, 'U+0000-00FF' ) &&
				 false === stripos( $block, 'U+0000-00ff' ) ) {
				continue;
			}

			// Extract the font file URL from this block.
			if ( preg_match( '/url\s*\(\s*[\'"]?([^\'")\s]+\.woff2)[\'"]?\s*\)/', $block, $url_match ) ) {
				$urls[] = $url_match[1];
			}
		}

		return $urls;
	}

	/**
	 * AJAX handler to clear all locally hosted font files.
	 *
	 * @since 1.0.0
	 */
	public function ajax_clear_local_fonts() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$this->delete_directory( $this->fonts_dir );
		delete_transient( 'up_local_fonts_map' );

		wp_send_json_success( array( 'message' => __( 'Local font files cleared successfully.', 'ultimate-performance' ) ) );
	}

	/**
	 * Ensure the fonts directory exists with a security index.php.
	 *
	 * @since 1.0.0
	 */
	private function ensure_fonts_dir() {
		if ( ! is_dir( $this->fonts_dir ) ) {
			wp_mkdir_p( $this->fonts_dir );
		}

		$index = $this->fonts_dir . 'index.php';
		if ( ! file_exists( $index ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( $index, '<?php // Silence is golden.' );
		}
	}

	/**
	 * Recursively delete a directory and its contents.
	 *
	 * @since 1.0.0
	 * @param string $dir Directory path.
	 */
	private function delete_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$items = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator( $dir, \RecursiveDirectoryIterator::SKIP_DOTS ),
			\RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $items as $item ) {
			if ( $item->isDir() ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
				rmdir( $item->getRealPath() );
			} else {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
				unlink( $item->getRealPath() );
			}
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
		rmdir( $dir );
	}
}
