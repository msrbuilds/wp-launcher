<?php
/**
 * Handles page caching, browser cache, and GZIP compression.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Cache
 *
 * Implements page caching via output buffering, browser cache
 * and GZIP compression via .htaccess rules, and smart cache
 * purging on content updates.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Cache {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Cache directory base path.
	 *
	 * @since 1.0.0
	 * @var   string
	 */
	private $cache_dir;

	/**
	 * .htaccess marker for our rules.
	 *
	 * @since 1.0.0
	 * @var   string
	 */
	const HTACCESS_MARKER = 'Ultimate Performance';

	/**
	 * Initialize the caching module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings  = Ultimate_Performance_Settings::get_module_settings( 'caching' );
		$this->cache_dir = WP_CONTENT_DIR . '/cache/ultimate-performance/page/';

		// Always register AJAX handlers.
		add_action( 'wp_ajax_up_purge_cache', array( $this, 'ajax_purge_cache' ) );
		add_action( 'wp_ajax_up_verify_cache_headers', array( $this, 'ajax_verify_cache_headers' ) );
		add_action( 'wp_ajax_up_rewrite_htaccess_rules', array( $this, 'ajax_rewrite_htaccess_rules' ) );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		$this->setup_page_cache();
		$this->setup_smart_purge();
		$this->setup_htaccess_rules();
	}

	/**
	 * Setup page caching via output buffering.
	 *
	 * @since 1.0.0
	 */
	private function setup_page_cache() {
		if ( empty( $this->settings['page_cache'] ) ) {
			return;
		}

		add_action( 'template_redirect', array( $this, 'serve_or_start_cache' ), 0 );
	}

	/**
	 * Serve a cached page or start output buffering to create one.
	 *
	 * @since 1.0.0
	 */
	public function serve_or_start_cache() {
		if ( $this->should_skip_cache() ) {
			return;
		}

		$cache_file = $this->get_cache_file_path();

		// Serve cached version if it exists.
		if ( file_exists( $cache_file ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$cached = file_get_contents( $cache_file );
			if ( false !== $cached ) {
				echo $cached; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo "\n<!-- Served from Ultimate Performance cache -->";
				exit;
			}
		}

		// Start output buffering to capture the page.
		ob_start( array( $this, 'save_cache_output' ) );
	}

	/**
	 * Save the output buffer to a cache file.
	 *
	 * @since  1.0.0
	 * @param  string $html Page HTML output.
	 * @return string Unmodified HTML.
	 */
	public function save_cache_output( $html ) {
		if ( empty( $html ) || http_response_code() !== 200 ) {
			return $html;
		}

		// Only cache HTML responses to avoid corrupting plain-text or XML content.
		$content_type = '';
		foreach ( headers_list() as $header ) {
			if ( stripos( $header, 'content-type:' ) === 0 ) {
				$content_type = $header;
				break;
			}
		}
		if ( $content_type && false === stripos( $content_type, 'text/html' ) ) {
			return $html;
		}

		$cache_file = $this->get_cache_file_path();
		$cache_dir  = dirname( $cache_file );

		if ( wp_mkdir_p( $cache_dir ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( $cache_file, $html . "\n<!-- Cached by Ultimate Performance on " . gmdate( 'Y-m-d H:i:s' ) . ' -->' );
		}

		return $html;
	}

	/**
	 * Check if the current request should skip caching.
	 *
	 * @since  1.0.0
	 * @return bool True to skip caching.
	 */
	private function should_skip_cache() {
		// Skip non-GET requests.
		if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'GET' !== $_SERVER['REQUEST_METHOD'] ) {
			return true;
		}

		// Skip logged-in users.
		if ( is_user_logged_in() ) {
			return true;
		}

		// Skip admin, AJAX, cron, REST API.
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return true;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}

		// Skip requests with query strings.
		if ( ! empty( $_SERVER['QUERY_STRING'] ) ) {
			return true;
		}

		// Skip 404, search, and non-HTML responses.
		if ( is_404() || is_search() ) {
			return true;
		}

		// Skip robots.txt, feeds, and sitemaps (non-HTML content).
		if ( is_robots() || is_feed() ) {
			return true;
		}
		if ( function_exists( 'is_sitemap' ) && is_sitemap() ) {
			return true;
		}

		// Skip excluded URLs.
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		if ( $this->is_url_excluded( $request_uri ) ) {
			return true;
		}

		// Skip excluded cookies.
		if ( $this->has_excluded_cookie() ) {
			return true;
		}

		// Skip WooCommerce dynamic pages.
		if ( $this->is_woocommerce_dynamic_page() ) {
			return true;
		}

		return false;
	}

	/**
	 * Check if a URL matches an excluded pattern.
	 *
	 * @since  1.0.0
	 * @param  string $url Request URI.
	 * @return bool
	 */
	private function is_url_excluded( $url ) {
		$excluded = $this->parse_textarea_lines( $this->settings['exclude_urls'] );

		foreach ( $excluded as $pattern ) {
			if ( false !== strpos( $url, $pattern ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if an excluded cookie is present.
	 *
	 * @since  1.0.0
	 * @return bool
	 */
	private function has_excluded_cookie() {
		$excluded = $this->parse_textarea_lines( $this->settings['exclude_cookies'] );

		foreach ( $excluded as $cookie_name ) {
			if ( isset( $_COOKIE[ $cookie_name ] ) ) {
				return true;
			}
		}

		// Always skip if WordPress login/comment cookies exist.
		foreach ( array_keys( $_COOKIE ) as $name ) {
			if ( 0 === strpos( $name, 'wordpress_logged_in_' ) ||
				 0 === strpos( $name, 'comment_author_' ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if current page is a WooCommerce dynamic page.
	 *
	 * @since  1.0.0
	 * @return bool
	 */
	private function is_woocommerce_dynamic_page() {
		if ( ! function_exists( 'is_cart' ) ) {
			return false;
		}

		return is_cart() || is_checkout() || is_account_page();
	}

	/**
	 * Get the cache file path for the current request.
	 *
	 * @since  1.0.0
	 * @return string Cache file path.
	 */
	private function get_cache_file_path() {
		$host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_file_name( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : 'localhost';
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';

		// Normalize the URI for file path.
		$path = trim( $uri, '/' );
		if ( empty( $path ) ) {
			$path = '_index';
		}

		// Sanitize path for filesystem.
		$path = preg_replace( '/[^a-zA-Z0-9\/_-]/', '', $path );

		return $this->cache_dir . $host . '/' . $path . '/index.html';
	}

	/**
	 * Setup smart cache purging on content updates.
	 *
	 * @since 1.0.0
	 */
	private function setup_smart_purge() {
		if ( empty( $this->settings['purge_on_post_update'] ) ) {
			return;
		}

		add_action( 'save_post', array( $this, 'purge_post_cache' ), 10, 2 );
		add_action( 'comment_post', array( $this, 'purge_comment_post_cache' ), 10, 3 );
		add_action( 'switch_theme', array( $this, 'purge_all_cache' ) );
		add_action( 'activated_plugin', array( $this, 'purge_all_cache' ) );
		add_action( 'deactivated_plugin', array( $this, 'purge_all_cache' ) );
		add_action( 'wp_update_nav_menu', array( $this, 'purge_all_cache' ) );
	}

	/**
	 * Purge cache for a specific post and related pages.
	 *
	 * @since 1.0.0
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 */
	public function purge_post_cache( $post_id, $post ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( 'publish' !== $post->post_status ) {
			return;
		}

		// Purge the post URL.
		$permalink = get_permalink( $post_id );
		if ( $permalink ) {
			$this->purge_url( $permalink );
		}

		// Purge the homepage.
		$this->purge_url( home_url( '/' ) );

		// Purge category and tag archives.
		$taxonomies = get_object_taxonomies( $post->post_type );
		foreach ( $taxonomies as $taxonomy ) {
			$terms = get_the_terms( $post_id, $taxonomy );
			if ( $terms && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$term_link = get_term_link( $term );
					if ( ! is_wp_error( $term_link ) ) {
						$this->purge_url( $term_link );
					}
				}
			}
		}
	}

	/**
	 * Purge cache for a post when a new comment is posted.
	 *
	 * @since 1.0.0
	 * @param int        $comment_id       Comment ID.
	 * @param int|string $comment_approved  Approval status.
	 * @param array      $commentdata      Comment data.
	 */
	public function purge_comment_post_cache( $comment_id, $comment_approved, $commentdata ) {
		if ( ! empty( $commentdata['comment_post_ID'] ) ) {
			$permalink = get_permalink( $commentdata['comment_post_ID'] );
			if ( $permalink ) {
				$this->purge_url( $permalink );
			}
		}
	}

	/**
	 * Purge a specific URL from cache.
	 *
	 * @since 1.0.0
	 * @param string $url Full URL to purge.
	 */
	public function purge_url( $url ) {
		$parsed = wp_parse_url( $url );
		$host   = isset( $parsed['host'] ) ? sanitize_file_name( $parsed['host'] ) : 'localhost';
		$path   = isset( $parsed['path'] ) ? trim( $parsed['path'], '/' ) : '';

		if ( empty( $path ) ) {
			$path = '_index';
		}

		$path = preg_replace( '/[^a-zA-Z0-9\/_-]/', '', $path );
		$file = $this->cache_dir . $host . '/' . $path . '/index.html';

		if ( file_exists( $file ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			unlink( $file );
		}
	}

	/**
	 * Purge all cached pages.
	 *
	 * @since 1.0.0
	 */
	public function purge_all_cache() {
		$this->delete_directory( $this->cache_dir );

		// Also clear minification cache.
		if ( class_exists( 'Ultimate_Performance_Minifier' ) ) {
			Ultimate_Performance_Minifier::clear_cache();
		}

		// Clear font-display rewrite cache.
		$fonts_cache = WP_CONTENT_DIR . '/cache/ultimate-performance/fonts/';
		if ( is_dir( $fonts_cache ) ) {
			$this->delete_directory( $fonts_cache );
		}

		// Clear UCSS cache.
		$ucss_cache = WP_CONTENT_DIR . '/cache/ultimate-performance/ucss/';
		if ( is_dir( $ucss_cache ) ) {
			$this->delete_directory( $ucss_cache );
		}

		/**
		 * Fires after all caches have been purged.
		 *
		 * @since 1.5.0
		 */
		do_action( 'ultimate_performance_purge_all_cache' );
	}

	/**
	 * AJAX handler for cache purge.
	 *
	 * @since 1.0.0
	 */
	public function ajax_purge_cache() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$this->purge_all_cache();

		wp_send_json_success( array( 'message' => __( 'Cache purged successfully.', 'ultimate-performance' ) ) );
	}

	/**
	 * Setup .htaccess rules for browser cache and GZIP.
	 *
	 * @since 1.0.0
	 */
	private function setup_htaccess_rules() {
		// Write/remove rules when settings are saved.
		add_action( 'update_option_' . Ultimate_Performance_Settings::OPTION_NAME, array( $this, 'update_htaccess_rules' ), 10, 2 );
	}

	/**
	 * Update .htaccess rules when settings change.
	 *
	 * @since 1.0.0
	 * @param mixed $old_value Old option value.
	 * @param mixed $new_value New option value.
	 */
	public function update_htaccess_rules( $old_value, $new_value ) {
		$caching = isset( $new_value['caching'] ) ? $new_value['caching'] : array();

		// Refresh settings so write_htaccess_rules uses the new values.
		$this->settings = wp_parse_args( $caching, $this->settings );

		$browser_cache = ! empty( $caching['browser_cache'] );
		$gzip          = ! empty( $caching['gzip_compression'] );

		if ( $browser_cache || $gzip ) {
			$this->write_htaccess_rules( $browser_cache, $gzip );
		} else {
			$this->remove_htaccess_rules();
		}
	}

	/**
	 * Map of cache lifespan setting values to expires directive and max-age seconds.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private static $lifespan_map = array(
		'1 month'  => array( 'expires' => '1 month', 'max_age' => 2592000 ),
		'3 months' => array( 'expires' => '3 months', 'max_age' => 7776000 ),
		'6 months' => array( 'expires' => '6 months', 'max_age' => 15552000 ),
		'1 year'   => array( 'expires' => '1 year', 'max_age' => 31536000 ),
	);

	/**
	 * Write browser cache and/or GZIP rules to .htaccess.
	 *
	 * @since 1.0.0
	 * @param bool $browser_cache Whether to add browser cache rules.
	 * @param bool $gzip          Whether to add GZIP rules.
	 */
	private function write_htaccess_rules( $browser_cache, $gzip ) {
		$htaccess = ABSPATH . '.htaccess';

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- Checking .htaccess writability before modification.
		if ( ! is_writable( $htaccess ) && ! is_writable( ABSPATH ) ) {
			return;
		}

		// Remove existing rules first.
		$this->remove_htaccess_rules();

		$rules = array();

		if ( $browser_cache ) {
			$lifespan = isset( $this->settings['cache_lifespan'] ) ? $this->settings['cache_lifespan'] : '1 year';
			if ( ! isset( self::$lifespan_map[ $lifespan ] ) ) {
				$lifespan = '1 year';
			}
			$expires_val = self::$lifespan_map[ $lifespan ]['expires'];
			$max_age     = self::$lifespan_map[ $lifespan ]['max_age'];

			// Expires headers (mod_expires).
			$rules[] = '<IfModule mod_expires.c>';
			$rules[] = '  ExpiresActive On';
			$rules[] = '  ExpiresByType text/css "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType text/javascript "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType application/javascript "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType application/x-javascript "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType image/jpeg "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType image/png "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType image/gif "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType image/svg+xml "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType image/webp "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType image/avif "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType image/x-icon "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType application/font-woff "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType application/font-woff2 "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType font/woff2 "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType application/vnd.ms-fontobject "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType font/ttf "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType font/otf "access plus ' . $expires_val . '"';
			$rules[] = '  ExpiresByType application/pdf "access plus 1 month"';
			$rules[] = '  ExpiresByType text/html "access plus 0 seconds"';
			$rules[] = '</IfModule>';
			$rules[] = '';

			// Cache-Control headers (mod_headers).
			// Uses "always set" to ensure headers survive internal redirects and
			// are not overridden by LiteSpeed or other server-level cache layers.
			$rules[] = '<IfModule mod_headers.c>';
			$rules[] = '  <FilesMatch "\.(css|js)$">';
			$rules[] = '    Header always set Cache-Control "public, max-age=' . $max_age . ', immutable"';
			$rules[] = '  </FilesMatch>';
			$rules[] = '  <FilesMatch "\.(jpg|jpeg|png|gif|webp|avif|svg|ico)$">';
			$rules[] = '    Header always set Cache-Control "public, max-age=' . $max_age . ', immutable"';
			$rules[] = '  </FilesMatch>';
			$rules[] = '  <FilesMatch "\.(woff|woff2|ttf|otf|eot)$">';
			$rules[] = '    Header always set Cache-Control "public, max-age=' . $max_age . ', immutable"';
			$rules[] = '  </FilesMatch>';
			$rules[] = '  <FilesMatch "\.(pdf)$">';
			$rules[] = '    Header always set Cache-Control "public, max-age=2592000"';
			$rules[] = '  </FilesMatch>';
			$rules[] = '  <FilesMatch "\.(html|htm)$">';
			$rules[] = '    Header always set Cache-Control "no-cache, no-store, must-revalidate"';
			$rules[] = '  </FilesMatch>';
			$rules[] = '</IfModule>';
			$rules[] = '';

			// LiteSpeed-specific: ensure LSCache does not override our headers.
			$rules[] = '<IfModule LiteSpeed>';
			$rules[] = '  CacheLookup on';
			$rules[] = '</IfModule>';
			$rules[] = '';

			// ETag removal — prevents redundant validation when Expires/Cache-Control are set.
			$rules[] = '<IfModule mod_headers.c>';
			$rules[] = '  Header always unset ETag';
			$rules[] = '</IfModule>';
			$rules[] = 'FileETag None';
			$rules[] = '';
		}

		if ( $gzip ) {
			$rules[] = '<IfModule mod_deflate.c>';
			$rules[] = '  AddOutputFilterByType DEFLATE text/html';
			$rules[] = '  AddOutputFilterByType DEFLATE text/css';
			$rules[] = '  AddOutputFilterByType DEFLATE text/javascript';
			$rules[] = '  AddOutputFilterByType DEFLATE application/javascript';
			$rules[] = '  AddOutputFilterByType DEFLATE application/x-javascript';
			$rules[] = '  AddOutputFilterByType DEFLATE text/xml';
			$rules[] = '  AddOutputFilterByType DEFLATE application/xml';
			$rules[] = '  AddOutputFilterByType DEFLATE application/json';
			$rules[] = '  AddOutputFilterByType DEFLATE image/svg+xml';
			$rules[] = '  AddOutputFilterByType DEFLATE application/font-woff';
			$rules[] = '  AddOutputFilterByType DEFLATE font/woff2';
			$rules[] = '</IfModule>';
		}

		if ( empty( $rules ) ) {
			return;
		}

		$marker_start = '# BEGIN ' . self::HTACCESS_MARKER;
		$marker_end   = '# END ' . self::HTACCESS_MARKER;

		$insertion  = $marker_start . "\n";
		$insertion .= implode( "\n", $rules ) . "\n";
		$insertion .= $marker_end . "\n";

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$existing = file_exists( $htaccess ) ? file_get_contents( $htaccess ) : '';

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( $htaccess, $insertion . "\n" . $existing, LOCK_EX );
	}

	/**
	 * Remove our rules from .htaccess.
	 *
	 * @since 1.0.0
	 */
	private function remove_htaccess_rules() {
		$htaccess = ABSPATH . '.htaccess';

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- Checking .htaccess writability.
		if ( ! file_exists( $htaccess ) || ! is_writable( $htaccess ) ) {
			return;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$contents = file_get_contents( $htaccess );

		$marker_start = '# BEGIN ' . self::HTACCESS_MARKER;
		$marker_end   = '# END ' . self::HTACCESS_MARKER;

		$pattern  = '/' . preg_quote( $marker_start, '/' ) . '.*?' . preg_quote( $marker_end, '/' ) . '\n?/s';
		$contents = preg_replace( $pattern, '', $contents );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( $htaccess, $contents );
	}

	/**
	 * Recursively delete a directory and its contents.
	 *
	 * @since 1.0.0
	 * @param string $dir Directory path.
	 */
	private function delete_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$items = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator( $dir, \RecursiveDirectoryIterator::SKIP_DOTS ),
			\RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $items as $item ) {
			if ( $item->isDir() ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
				rmdir( $item->getRealPath() );
			} else {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
				unlink( $item->getRealPath() );
			}
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
		rmdir( $dir );
	}

	/**
	 * Parse a textarea value into an array of non-empty trimmed lines.
	 *
	 * @since  1.0.0
	 * @param  string $text Textarea value.
	 * @return array  Non-empty lines.
	 */
	private function parse_textarea_lines( $text ) {
		if ( empty( $text ) ) {
			return array();
		}

		$lines = preg_split( '/\r\n|\r|\n/', $text );
		$lines = array_map( 'trim', $lines );
		$lines = array_filter( $lines, 'strlen' );

		return array_values( $lines );
	}

	/**
	 * AJAX handler to verify browser cache headers on a live static asset.
	 *
	 * Fetches a real CSS/JS file from the site and reports its actual cache
	 * headers, so the user can confirm their caching rules are working.
	 *
	 * @since 1.4.0
	 */
	public function ajax_verify_cache_headers() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$results = array();

		// Detect web server.
		$server_software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '';
		$results['server'] = $server_software;

		if ( stripos( $server_software, 'nginx' ) !== false ) {
			$results['server_type'] = 'nginx';
		} elseif ( stripos( $server_software, 'litespeed' ) !== false ) {
			$results['server_type'] = 'litespeed';
		} elseif ( stripos( $server_software, 'apache' ) !== false ) {
			$results['server_type'] = 'apache';
		} else {
			$results['server_type'] = 'unknown';
		}

		// Check .htaccess for our rules.
		$htaccess = ABSPATH . '.htaccess';
		$results['htaccess_exists']  = file_exists( $htaccess );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- Diagnostic check for .htaccess writability.
	$results['htaccess_writable'] = is_writable( $htaccess ) || is_writable( ABSPATH );
		$results['rules_present']    = false;

		if ( $results['htaccess_exists'] ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$contents = file_get_contents( $htaccess );
			$results['rules_present'] = ( false !== strpos( $contents, '# BEGIN ' . self::HTACCESS_MARKER ) );
		}

		// Find a local static asset to test.
		$home_response = wp_remote_get( home_url( '/' ), array(
			'timeout'    => 15,
			'sslverify'  => false,
			'user-agent' => 'Ultimate-Performance-CacheCheck/1.0',
		) );

		$results['assets'] = array();

		if ( ! is_wp_error( $home_response ) && 200 === wp_remote_retrieve_response_code( $home_response ) ) {
			$html      = wp_remote_retrieve_body( $home_response );
			$home_host = wp_parse_url( home_url(), PHP_URL_HOST );

			// Collect up to 3 local asset URLs (CSS + JS).
			$asset_urls = array();

			if ( preg_match_all( '/<link[^>]+href=["\']([^"\']+\.css[^"\']*)["\'][^>]*>/i', $html, $css_matches ) ) {
				foreach ( $css_matches[1] as $href ) {
					$parsed = wp_parse_url( $href );
					if ( empty( $parsed['host'] ) || $parsed['host'] === $home_host ) {
						$asset_urls[] = $href;
						if ( count( $asset_urls ) >= 2 ) {
							break;
						}
					}
				}
			}

			if ( count( $asset_urls ) < 3 && preg_match_all( '/<script[^>]+src=["\']([^"\']+\.js[^"\']*)["\'][^>]*>/i', $html, $js_matches ) ) {
				foreach ( $js_matches[1] as $src ) {
					$parsed = wp_parse_url( $src );
					if ( empty( $parsed['host'] ) || $parsed['host'] === $home_host ) {
						$asset_urls[] = $src;
						if ( count( $asset_urls ) >= 3 ) {
							break;
						}
					}
				}
			}

			// Fetch headers from each asset.
			foreach ( $asset_urls as $asset_url ) {
				if ( 0 !== strpos( $asset_url, 'http' ) ) {
					$asset_url = home_url( $asset_url );
				}

				$asset_response = wp_remote_head( $asset_url, array(
					'timeout'    => 10,
					'sslverify'  => false,
					'user-agent' => 'Ultimate-Performance-CacheCheck/1.0',
				) );

				if ( is_wp_error( $asset_response ) ) {
					continue;
				}

				$asset_headers = wp_remote_retrieve_headers( $asset_response );
				$h_array       = is_object( $asset_headers ) ? $asset_headers->getAll() : (array) $asset_headers;

				$asset_info = array(
					'url'           => $asset_url,
					'cache_control' => isset( $h_array['cache-control'] ) ? ( is_array( $h_array['cache-control'] ) ? implode( ', ', $h_array['cache-control'] ) : $h_array['cache-control'] ) : 'not set',
					'expires'       => isset( $h_array['expires'] ) ? ( is_array( $h_array['expires'] ) ? implode( ', ', $h_array['expires'] ) : $h_array['expires'] ) : 'not set',
				);

				// Parse max-age from Cache-Control.
				$asset_info['max_age'] = null;
				if ( preg_match( '/max-age=(\d+)/i', $asset_info['cache_control'], $ma ) ) {
					$asset_info['max_age'] = (int) $ma[1];
				}

				$results['assets'][] = $asset_info;
			}
		}

		// Determine overall status.
		$settings  = Ultimate_Performance_Settings::get_module_settings( 'caching' );
		$lifespan  = isset( $settings['cache_lifespan'] ) ? $settings['cache_lifespan'] : '1 year';
		$expected  = isset( self::$lifespan_map[ $lifespan ] ) ? self::$lifespan_map[ $lifespan ]['max_age'] : 31536000;

		$results['expected_max_age'] = $expected;
		$results['browser_cache_enabled'] = ! empty( $settings['browser_cache'] );

		$all_ok = true;
		foreach ( $results['assets'] as $asset ) {
			if ( null === $asset['max_age'] || $asset['max_age'] < $expected ) {
				$all_ok = false;
				break;
			}
		}

		$results['status'] = $all_ok && ! empty( $results['assets'] ) ? 'ok' : 'issue';

		// Check if rules need updating (e.g. missing "always" keyword).
		$results['rules_need_update'] = false;
		if ( $results['rules_present'] && $results['htaccess_exists'] ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$ht_contents = file_get_contents( ABSPATH . '.htaccess' );
			if ( false !== strpos( $ht_contents, 'Header set Cache-Control' ) && false === strpos( $ht_contents, 'Header always set Cache-Control' ) ) {
				$results['rules_need_update'] = true;
			}
			if ( false === strpos( $ht_contents, '<IfModule LiteSpeed>' ) && 'litespeed' === $results['server_type'] ) {
				$results['rules_need_update'] = true;
			}
		}

		// Build diagnosis message.
		if ( ! $results['browser_cache_enabled'] ) {
			$results['diagnosis'] = __( 'Browser cache is disabled in settings. Enable it to add cache headers.', 'ultimate-performance' );
		} elseif ( 'nginx' === $results['server_type'] ) {
			$results['diagnosis'] = __( 'Your server runs Nginx which ignores .htaccess rules. Add cache headers in your Nginx server config (see snippet below).', 'ultimate-performance' );
			$results['nginx_snippet'] = self::get_nginx_cache_snippet( $expected );
		} elseif ( ! $results['htaccess_exists'] ) {
			$results['diagnosis'] = __( 'No .htaccess file found. Flush permalinks (Settings → Permalinks → Save) to create one, then re-save caching settings.', 'ultimate-performance' );
		} elseif ( ! $results['htaccess_writable'] ) {
			$results['diagnosis'] = __( 'The .htaccess file is not writable. Check file permissions (644) and try re-saving caching settings.', 'ultimate-performance' );
		} elseif ( ! $results['rules_present'] ) {
			$results['diagnosis'] = __( 'Cache rules are not in .htaccess. Re-save caching settings to write them.', 'ultimate-performance' );
		} elseif ( $results['rules_need_update'] ) {
			$results['diagnosis'] = __( 'Cache rules exist but need updating for your server. Click "Re-write Rules" below to apply the fix, then verify again.', 'ultimate-performance' );
		} elseif ( ! $all_ok && 'litespeed' === $results['server_type'] ) {
			$results['diagnosis'] = __( 'LiteSpeed\'s built-in cache may be overriding your .htaccess headers. See LiteSpeed-specific steps below.', 'ultimate-performance' );
			$results['litespeed_guidance'] = self::get_litespeed_guidance();
		} elseif ( ! $all_ok ) {
			$results['diagnosis'] = __( 'Rules are in .htaccess but headers differ. A CDN, hosting panel, or server-level config may be overriding them.', 'ultimate-performance' );
		} else {
			$results['diagnosis'] = __( 'Browser cache headers are working correctly.', 'ultimate-performance' );
		}

		wp_send_json_success( $results );
	}

	/**
	 * AJAX handler to re-write .htaccess rules with the latest format.
	 *
	 * Useful when rules exist but use an outdated format (e.g. missing
	 * "always" keyword or LiteSpeed directives).
	 *
	 * @since 1.4.0
	 */
	public function ajax_rewrite_htaccess_rules() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'caching' );
		$browser_cache  = ! empty( $this->settings['browser_cache'] );
		$gzip           = ! empty( $this->settings['gzip_compression'] );

		if ( ! $browser_cache && ! $gzip ) {
			wp_send_json_error( array( 'message' => __( 'Browser cache and GZIP are both disabled. Enable at least one first.', 'ultimate-performance' ) ) );
		}

		$this->write_htaccess_rules( $browser_cache, $gzip );

		wp_send_json_success( array( 'message' => __( 'Cache rules re-written successfully. Verify headers again to confirm.', 'ultimate-performance' ) ) );
	}

	/**
	 * Generate an Nginx config snippet for browser caching.
	 *
	 * @since  1.4.0
	 * @param  int $max_age Max-age in seconds.
	 * @return string Nginx config snippet.
	 */
	public static function get_nginx_cache_snippet( $max_age = 31536000 ) {
		return 'location ~* \.(css|js|jpg|jpeg|png|gif|webp|avif|svg|ico|woff|woff2|ttf|otf|eot)$ {' . "\n"
			. '    expires ' . $max_age . 's;' . "\n"
			. '    add_header Cache-Control "public, max-age=' . $max_age . ', immutable";' . "\n"
			. '    add_header X-Cache-Status "static";' . "\n"
			. '    access_log off;' . "\n"
			. '}';
	}

	/**
	 * Generate LiteSpeed-specific troubleshooting guidance.
	 *
	 * @since  1.4.0
	 * @return array Guidance steps.
	 */
	public static function get_litespeed_guidance() {
		return array(
			__( 'LiteSpeed Web Server has a built-in cache (LSCache) that can override .htaccess Cache-Control headers.', 'ultimate-performance' ),
			__( 'Check your hosting panel (cPanel, CyberPanel, DirectAdmin) for a "Cache" or "LiteSpeed Cache" section and ensure its TTL settings match your desired cache lifespan.', 'ultimate-performance' ),
			__( 'If the LiteSpeed Cache WordPress plugin is active, its "Browser Cache" setting may override your headers. Go to LiteSpeed Cache → Cache → Browser and set it to match (or disable it to let .htaccess rules control caching).', 'ultimate-performance' ),
			__( 'If your host uses OLS (OpenLiteSpeed), static file caching is controlled at the server level. Contact your host to increase the static file cache TTL.', 'ultimate-performance' ),
			__( 'After making changes, purge LiteSpeed cache from your hosting panel, then verify headers again.', 'ultimate-performance' ),
		);
	}
}
