<?php
/**
 * The core plugin class.
 *
 * Orchestrates all plugin components by loading dependencies,
 * setting the locale, and registering admin and public hooks.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance
 *
 * @since 1.0.0
 */
class Ultimate_Performance {

	/**
	 * The loader that registers all hooks for the plugin.
	 *
	 * @since  1.0.0
	 * @var    Ultimate_Performance_Loader
	 */
	protected $loader;

	/**
	 * Initialize the plugin.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->load_modules();
	}

	/**
	 * Load required dependencies.
	 *
	 * @since 1.0.0
	 */
	private function load_dependencies() {
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-loader.php';
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-i18n.php';
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-settings.php';
		require_once UP_PLUGIN_DIR . 'admin/class-ultimate-performance-admin.php';
		require_once UP_PLUGIN_DIR . 'public/class-ultimate-performance-public.php';

		$this->loader = new Ultimate_Performance_Loader();
	}

	/**
	 * Set the plugin locale for internationalization.
	 *
	 * @since 1.0.0
	 */
	private function set_locale() {
		$i18n = new Ultimate_Performance_I18n();
		$this->loader->add_action( 'init', $i18n, 'load_plugin_textdomain' );
	}

	/**
	 * Register all admin-related hooks.
	 *
	 * @since 1.0.0
	 */
	private function define_admin_hooks() {
		$admin    = new Ultimate_Performance_Admin();
		$settings = new Ultimate_Performance_Settings();

		$this->loader->add_action( 'admin_enqueue_scripts', $admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $admin, 'enqueue_scripts' );

		// Admin bar and other direct hooks.
		$admin->init();

		// Settings hooks are registered via init() which uses add_action directly.
		$settings->init();
	}

	/**
	 * Register all public-facing hooks.
	 *
	 * @since 1.0.0
	 */
	private function define_public_hooks() {
		$public = new Ultimate_Performance_Public();
		$this->loader->add_action( 'wp_enqueue_scripts', $public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $public, 'enqueue_scripts' );
	}

	/**
	 * Load and initialize feature modules based on settings.
	 *
	 * @since 1.0.0
	 */
	private function load_modules() {
		// Bloat Removal — init checks enabled flag internally.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-bloat-removal.php';
		$bloat_removal = new Ultimate_Performance_Bloat_Removal();
		$bloat_removal->init();

		// Database — always loaded for AJAX handlers (tools page works regardless of enabled flag).
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-database.php';
		$database = new Ultimate_Performance_Database();
		$database->init();

		// Preloading & Resource Hints.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-preloading.php';
		$preloading = new Ultimate_Performance_Preloading();
		$preloading->init();

		// Minifier utility (static, no init needed).
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-minifier.php';

		// CSS/JS Optimization.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-css-js.php';
		$css_js = new Ultimate_Performance_CSS_JS();
		$css_js->init();

		// Used CSS (UCSS) and Critical CSS.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-ucss.php';
		$ucss = new Ultimate_Performance_UCSS();
		$ucss->init();

		// Caching — always loaded for AJAX purge handler.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-cache.php';
		$cache = new Ultimate_Performance_Cache();
		$cache->init();

		// Web Fonts Optimization.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-webfonts.php';
		$webfonts = new Ultimate_Performance_Webfonts();
		$webfonts->init();

		// Image Optimizer utility (static, no init needed — must load before Image Optimization).
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-image-optimizer.php';

		// Image Optimization.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-image-optimization.php';
		$image_optimization = new Ultimate_Performance_Image_Optimization();
		$image_optimization->init();

		// CDN Integration.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-cdn.php';
		$cdn = new Ultimate_Performance_CDN();
		$cdn->init();

		// Media Offloading (S3-compatible storage).
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-media-offload.php';
		$media_offload = new Ultimate_Performance_Media_Offload();
		$media_offload->init();

		// Third-Party Scripts.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-third-party.php';
		$third_party = new Ultimate_Performance_Third_Party();
		$third_party->init();

		// Script Manager — always loaded for metabox + AJAX.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-script-manager.php';
		$script_manager = new Ultimate_Performance_Script_Manager();
		$script_manager->init();

		// Security Headers.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-security-headers.php';
		$security_headers = new Ultimate_Performance_Security_Headers();
		$security_headers->init();

		// WooCommerce Optimization.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-woocommerce.php';
		$woocommerce = new Ultimate_Performance_WooCommerce();
		$woocommerce->init();

		// Speed Test — always loaded for AJAX handler.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-speed-test.php';
		$speed_test = new Ultimate_Performance_Speed_Test();
		$speed_test->init();

		// Basic SEO.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-seo.php';
		$seo = new Ultimate_Performance_Seo();
		$seo->init();

		// AI Assistant — always loaded for AJAX handlers and page rendering.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-ai.php';
		$ai = new Ultimate_Performance_Ai();
		$ai->init();

		// Static Site Generator — always loaded for AJAX handlers.
		require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-static-site.php';
		$static_site = new Ultimate_Performance_Static_Site();
		$static_site->init();
	}

	/**
	 * Run the loader to execute all registered hooks.
	 *
	 * @since 1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * Get the loader instance.
	 *
	 * @since  1.0.0
	 * @return Ultimate_Performance_Loader
	 */
	public function get_loader() {
		return $this->loader;
	}
}
