<?php
/**
 * Handles WordPress bloat removal functionality.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Bloat_Removal
 *
 * Removes unnecessary WordPress default scripts, styles,
 * meta tags, and features based on user toggle settings.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Bloat_Removal {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Initialize the bloat removal module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'bloat_removal' );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		$this->disable_emojis();
		$this->disable_embeds();
		$this->cleanup_head();
		$this->cleanup_scripts();
		$this->cleanup_features();
		$this->control_heartbeat();
	}

	/**
	 * Disable WordPress emoji scripts and styles.
	 *
	 * @since 1.0.0
	 */
	private function disable_emojis() {
		if ( empty( $this->settings['disable_emojis'] ) ) {
			return;
		}

		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );

		add_filter( 'tiny_mce_plugins', array( $this, 'remove_tinymce_emoji' ) );
		add_filter( 'wp_resource_hints', array( $this, 'remove_emoji_dns_prefetch' ), 10, 2 );
	}

	/**
	 * Remove TinyMCE emoji plugin.
	 *
	 * @since  1.0.0
	 * @param  array $plugins TinyMCE plugins.
	 * @return array Filtered plugins.
	 */
	public function remove_tinymce_emoji( $plugins ) {
		if ( is_array( $plugins ) ) {
			return array_diff( $plugins, array( 'wpemoji' ) );
		}
		return $plugins;
	}

	/**
	 * Remove emoji DNS prefetch.
	 *
	 * @since  1.0.0
	 * @param  array  $urls          Resource hint URLs.
	 * @param  string $relation_type Hint type.
	 * @return array  Filtered URLs.
	 */
	public function remove_emoji_dns_prefetch( $urls, $relation_type ) {
		if ( 'dns-prefetch' === $relation_type ) {
			$urls = array_filter( $urls, function ( $url ) {
				$url_string = is_array( $url ) ? ( $url['href'] ?? '' ) : $url;
				return false === strpos( $url_string, 'https://s.w.org/images/core/emoji/' );
			});
		}
		return $urls;
	}

	/**
	 * Disable oEmbed/embeds.
	 *
	 * @since 1.0.0
	 */
	private function disable_embeds() {
		if ( empty( $this->settings['disable_embeds'] ) ) {
			return;
		}

		remove_action( 'rest_api_init', 'wp_oembed_register_route' );
		remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		remove_action( 'wp_head', 'wp_oembed_add_host_js' );

		add_filter( 'embed_oembed_discover', '__return_false' );
		add_filter( 'tiny_mce_plugins', array( $this, 'remove_tinymce_embeds' ) );

		add_action( 'wp_footer', array( $this, 'deregister_embed_script' ) );
	}

	/**
	 * Remove TinyMCE embed plugin.
	 *
	 * @since  1.0.0
	 * @param  array $plugins TinyMCE plugins.
	 * @return array Filtered plugins.
	 */
	public function remove_tinymce_embeds( $plugins ) {
		if ( is_array( $plugins ) ) {
			return array_diff( $plugins, array( 'wpembed' ) );
		}
		return $plugins;
	}

	/**
	 * Deregister wp-embed script on frontend.
	 *
	 * @since 1.0.0
	 */
	public function deregister_embed_script() {
		if ( ! is_admin() ) {
			wp_deregister_script( 'wp-embed' );
		}
	}

	/**
	 * Clean up wp_head meta tags and links.
	 *
	 * @since 1.0.0
	 */
	private function cleanup_head() {
		if ( ! empty( $this->settings['remove_wlw_manifest'] ) ) {
			remove_action( 'wp_head', 'wlwmanifest_link' );
		}

		if ( ! empty( $this->settings['remove_rsd_link'] ) ) {
			remove_action( 'wp_head', 'rsd_link' );
		}

		if ( ! empty( $this->settings['remove_shortlinks'] ) ) {
			remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );
			remove_action( 'template_redirect', 'wp_shortlink_header', 11 );
		}

		if ( ! empty( $this->settings['remove_wp_version'] ) ) {
			remove_action( 'wp_head', 'wp_generator' );
			add_filter( 'the_generator', '__return_empty_string' );
		}

		if ( ! empty( $this->settings['disable_rest_api_links'] ) ) {
			remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
			remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
			remove_action( 'template_redirect', 'rest_output_link_header', 11 );
		}

		if ( ! empty( $this->settings['disable_rss_feeds'] ) ) {
			remove_action( 'wp_head', 'feed_links', 2 );
			remove_action( 'wp_head', 'feed_links_extra', 3 );
		}
	}

	/**
	 * Clean up frontend scripts and styles.
	 *
	 * @since 1.0.0
	 */
	private function cleanup_scripts() {
		if ( ! empty( $this->settings['remove_dashicons'] ) ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'remove_dashicons' ) );
		}

		if ( ! empty( $this->settings['remove_jquery_migrate'] ) ) {
			add_action( 'wp_default_scripts', array( $this, 'remove_jquery_migrate' ) );
		}

		if ( ! empty( $this->settings['disable_global_styles'] ) ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'remove_global_styles' ), 100 );
		}

		if ( ! empty( $this->settings['remove_comment_reply_js'] ) ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'conditional_comment_reply_js' ) );
		}
	}

	/**
	 * Remove dashicons from frontend for non-logged-in users.
	 *
	 * @since 1.0.0
	 */
	public function remove_dashicons() {
		if ( ! is_user_logged_in() ) {
			wp_deregister_style( 'dashicons' );
		}
	}

	/**
	 * Remove jQuery Migrate from frontend.
	 *
	 * @since 1.0.0
	 * @param \WP_Scripts $scripts WP_Scripts instance.
	 */
	public function remove_jquery_migrate( $scripts ) {
		if ( ! is_admin() && isset( $scripts->registered['jquery'] ) ) {
			$scripts->registered['jquery']->deps = array_diff(
				$scripts->registered['jquery']->deps,
				array( 'jquery-migrate' )
			);
		}
	}

	/**
	 * Remove global styles and classic theme styles.
	 *
	 * @since 1.0.0
	 */
	public function remove_global_styles() {
		wp_dequeue_style( 'global-styles' );
		wp_dequeue_style( 'classic-theme-styles' );
	}

	/**
	 * Only load comment-reply.js when needed.
	 *
	 * @since 1.0.0
	 */
	public function conditional_comment_reply_js() {
		if ( ! is_singular() || ! comments_open() || 0 === (int) get_comments_number() ) {
			wp_dequeue_script( 'comment-reply' );
		}
	}

	/**
	 * Handle WordPress feature toggles.
	 *
	 * @since 1.0.0
	 */
	private function cleanup_features() {
		if ( ! empty( $this->settings['disable_xmlrpc'] ) ) {
			add_filter( 'xmlrpc_enabled', '__return_false' );
			add_filter( 'wp_headers', array( $this, 'remove_x_pingback_header' ) );
		}

		if ( ! empty( $this->settings['disable_self_pingbacks'] ) ) {
			add_action( 'pre_ping', array( $this, 'disable_self_pingbacks' ) );
		}

		if ( ! empty( $this->settings['disable_login_language'] ) ) {
			add_filter( 'login_display_language_dropdown', '__return_false' );
		}
	}

	/**
	 * Remove X-Pingback HTTP header.
	 *
	 * @since  1.0.0
	 * @param  array $headers HTTP headers.
	 * @return array Filtered headers.
	 */
	public function remove_x_pingback_header( $headers ) {
		unset( $headers['X-Pingback'] );
		return $headers;
	}

	/**
	 * Disable self-pingbacks.
	 *
	 * @since 1.0.0
	 * @param array $links Pingback link URLs.
	 */
	public function disable_self_pingbacks( &$links ) {
		$home = get_option( 'home' );
		foreach ( $links as $key => $link ) {
			if ( 0 === strpos( $link, $home ) ) {
				unset( $links[ $key ] );
			}
		}
	}

	/**
	 * Control WordPress Heartbeat API.
	 *
	 * @since 1.0.0
	 */
	private function control_heartbeat() {
		$frontend = $this->settings['heartbeat_frontend'] ?? 'default';
		$admin    = $this->settings['heartbeat_admin'] ?? 'default';
		$editor   = $this->settings['heartbeat_editor'] ?? 'default';

		if ( 'default' === $frontend && 'default' === $admin && 'default' === $editor ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'heartbeat_frontend' ), 99 );
		add_action( 'admin_enqueue_scripts', array( $this, 'heartbeat_admin' ), 99 );

		if ( 'default' !== $frontend || 'default' !== $admin || 'default' !== $editor ) {
			add_filter( 'heartbeat_settings', array( $this, 'heartbeat_settings' ) );
		}
	}

	/**
	 * Control heartbeat on frontend.
	 *
	 * @since 1.0.0
	 */
	public function heartbeat_frontend() {
		$setting = $this->settings['heartbeat_frontend'] ?? 'default';
		if ( 'disable' === $setting ) {
			wp_deregister_script( 'heartbeat' );
		}
	}

	/**
	 * Control heartbeat on admin pages.
	 *
	 * @since 1.0.0
	 * @param string $hook Admin page hook.
	 */
	public function heartbeat_admin( $hook ) {
		$is_editor = in_array( $hook, array( 'post.php', 'post-new.php' ), true );

		if ( $is_editor ) {
			$setting = $this->settings['heartbeat_editor'] ?? 'default';
		} else {
			$setting = $this->settings['heartbeat_admin'] ?? 'default';
		}

		if ( 'disable' === $setting ) {
			wp_deregister_script( 'heartbeat' );
		}
	}

	/**
	 * Modify heartbeat interval settings.
	 *
	 * @since  1.0.0
	 * @param  array $settings Heartbeat settings.
	 * @return array Modified settings.
	 */
	public function heartbeat_settings( $settings ) {
		if ( ! is_admin() ) {
			$interval = $this->settings['heartbeat_frontend'] ?? 'default';
		} elseif ( $this->is_post_editor() ) {
			$interval = $this->settings['heartbeat_editor'] ?? 'default';
		} else {
			$interval = $this->settings['heartbeat_admin'] ?? 'default';
		}

		if ( 'default' !== $interval && 'disable' !== $interval ) {
			$settings['interval'] = absint( $interval );
		}

		return $settings;
	}

	/**
	 * Check if current screen is the post editor.
	 *
	 * @since  1.0.0
	 * @return bool
	 */
	private function is_post_editor() {
		global $pagenow;
		return in_array( $pagenow, array( 'post.php', 'post-new.php' ), true );
	}
}
