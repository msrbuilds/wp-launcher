<?php
/**
 * Static Site Generator module.
 *
 * Generates a complete static HTML copy of the WordPress site via
 * a phased AJAX pipeline: Setup → Discover → Fetch → Rewrite → Package.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Static_Site
 *
 * @since 1.2.0
 */
class Ultimate_Performance_Static_Site {

	/**
	 * The site URL used for domain matching and URL rewriting.
	 *
	 * @since 1.2.0
	 * @var   string
	 */
	private $site_url;

	/**
	 * Parsed host from site URL for domain comparison.
	 *
	 * @since 1.2.0
	 * @var   string
	 */
	private $site_host;

	/**
	 * Whether the database table has been verified to exist this request.
	 *
	 * @since 1.2.0
	 * @var   bool
	 */
	private $table_verified = false;

	/**
	 * Registry of assigned asset filenames to detect collisions across batches.
	 *
	 * Keyed by 'category/filename' => original URL.
	 *
	 * @since 1.4.0
	 * @var   array
	 */
	private $asset_filename_registry = array();

	/**
	 * Initialize hooks.
	 *
	 * @since 1.2.0
	 */
	public function init() {
		$this->site_url  = untrailingslashit( get_site_url() );
		$this->site_host = wp_parse_url( $this->site_url, PHP_URL_HOST );

		// Full site generation.
		add_action( 'wp_ajax_up_static_generate', array( $this, 'ajax_generate' ) );

		// Individual page generation.
		add_action( 'wp_ajax_up_static_generate_pages', array( $this, 'ajax_generate_pages' ) );
		add_action( 'wp_ajax_up_static_search_pages', array( $this, 'ajax_search_pages' ) );

		// Shared actions.
		add_action( 'wp_ajax_up_static_cancel', array( $this, 'ajax_cancel' ) );
		add_action( 'wp_ajax_up_static_status', array( $this, 'ajax_status' ) );
		add_action( 'wp_ajax_up_static_download', array( $this, 'ajax_download' ) );
		add_action( 'wp_ajax_up_static_purge_serve', array( $this, 'ajax_purge_serve' ) );

		// Frontend static serving.
		$settings = $this->get_settings();
		if ( ! empty( $settings['serve_enabled'] ) ) {
			add_action( 'template_redirect', array( $this, 'maybe_serve_static' ), -1 );
			$this->setup_serve_purge();
		}
	}

	/**
	 * Get the module settings.
	 *
	 * @since  1.2.0
	 * @return array
	 */
	private function get_settings() {
		return Ultimate_Performance_Settings::get_module_settings( 'static_site' );
	}

	/**
	 * Get the batch size from settings.
	 *
	 * @since  1.2.0
	 * @return int
	 */
	private function get_batch_size() {
		$settings = $this->get_settings();
		return max( 10, min( 200, absint( $settings['batch_size'] ) ) );
	}

	// ------------------------------------------------------------------
	// Output directory helpers
	// ------------------------------------------------------------------

	/**
	 * Get the resolved output directory path.
	 *
	 * @since  1.2.0
	 * @return string Absolute directory path.
	 */
	private function get_output_dir() {
		$settings = $this->get_settings();

		if ( ! empty( $settings['output_dir'] ) ) {
			$dir = trailingslashit( $settings['output_dir'] );
		} else {
			$upload_dir = wp_upload_dir();
			$dir        = trailingslashit( $upload_dir['basedir'] ) . 'ultimate-performance/static-site/';
		}

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		return $dir;
	}

	/**
	 * Get the serve directory for pre-rewrite HTML files.
	 *
	 * Files here retain absolute WordPress URLs and are used for
	 * frontend static serving (bypassing WordPress rendering).
	 *
	 * @since  1.3.0
	 * @return string Absolute directory path.
	 */
	private function get_serve_dir() {
		$upload_dir = wp_upload_dir();
		$dir        = trailingslashit( $upload_dir['basedir'] ) . 'ultimate-performance/static-serve/';

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		return $dir;
	}

	/**
	 * Get the directory for storing ZIP files.
	 *
	 * @since  1.2.0
	 * @return string
	 */
	private function get_zip_dir() {
		$upload_dir = wp_upload_dir();
		$dir        = trailingslashit( $upload_dir['basedir'] ) . 'ultimate-performance/';

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		return $dir;
	}

	// ------------------------------------------------------------------
	// Table management
	// ------------------------------------------------------------------

	/**
	 * Ensure the static pages table exists, creating it if necessary.
	 *
	 * The table is normally created on activation, but if the plugin was already
	 * active when this module was added, the table won't exist yet.
	 *
	 * @since 1.2.0
	 */
	private function ensure_table() {
		global $wpdb;

		$table = $wpdb->prefix . 'up_static_pages';

		// Quick check: if we've already verified this request, skip.
		if ( ! empty( $this->table_verified ) ) {
			return;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table query; not suitable for object cache.
		$exists = $wpdb->get_var(
			$wpdb->prepare( 'SHOW TABLES LIKE %s', $table )
		);

		if ( $exists ) {
			$this->table_verified = true;
			return;
		}

		// Create the table via dbDelta.
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url varchar(2083) NOT NULL,
			file_path varchar(2083) DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			http_status_code smallint(5) unsigned DEFAULT NULL,
			content_type varchar(100) DEFAULT NULL,
			content_hash char(32) DEFAULT NULL,
			error_message text DEFAULT NULL,
			found_on varchar(2083) DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY url (url(191)),
			KEY status (status)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		$this->table_verified = true;
	}

	// ------------------------------------------------------------------
	// Cleanup
	// ------------------------------------------------------------------

	/**
	 * Reset the static pages table and output directory.
	 *
	 * @since 1.2.0
	 */
	private function cleanup() {
		global $wpdb;

		$this->ensure_table();

		$table = $wpdb->prefix . 'up_static_pages';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Write operation; caching not applicable.
		$wpdb->query( "TRUNCATE TABLE {$table}" );

		// Delete output directory contents.
		$dir = $this->get_output_dir();
		if ( is_dir( $dir ) ) {
			$this->delete_directory_contents( $dir );
		}

		// Delete serve directory contents.
		$serve_dir = $this->get_serve_dir();
		if ( is_dir( $serve_dir ) ) {
			$this->delete_directory_contents( $serve_dir );
		}

		// Delete old ZIP files.
		$zip_dir = $this->get_zip_dir();
		$zips    = glob( $zip_dir . 'static-site-*.zip' );
		if ( $zips ) {
			foreach ( $zips as $zip ) {
				wp_delete_file( $zip );
			}
		}

		delete_transient( 'up_static_generating' );
		delete_option( 'up_static_last_run' );
	}

	/**
	 * Recursively delete directory contents without removing the directory itself.
	 *
	 * @since 1.2.0
	 * @param string $dir Directory path.
	 */
	private function delete_directory_contents( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		global $wp_filesystem;
		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		if ( ! $wp_filesystem ) {
			return;
		}

		$files = $wp_filesystem->dirlist( $dir );
		if ( is_array( $files ) ) {
			foreach ( $files as $name => $info ) {
				$wp_filesystem->delete( trailingslashit( $dir ) . $name, true );
			}
		}
	}

	// ------------------------------------------------------------------
	// URL Discovery (Full Site)
	// ------------------------------------------------------------------

	/**
	 * Discover all site URLs and insert them into the static pages table.
	 *
	 * @since  1.2.0
	 * @return int Number of URLs discovered.
	 */
	private function discover_urls() {
		$settings      = $this->get_settings();
		$include_types = array_map( 'trim', explode( ',', $settings['include_types'] ) );
		$exclude_urls  = $this->parse_url_list( $settings['exclude_urls'] );
		$urls          = array();

		if ( in_array( 'posts', $include_types, true ) || in_array( 'pages', $include_types, true ) ) {
			$urls = array_merge( $urls, $this->get_post_urls( $include_types ) );
		}

		if ( in_array( 'categories', $include_types, true ) || in_array( 'tags', $include_types, true ) ) {
			$urls = array_merge( $urls, $this->get_taxonomy_urls( $include_types ) );
		}

		if ( in_array( 'archives', $include_types, true ) ) {
			$urls = array_merge( $urls, $this->get_archive_urls() );
		}

		if ( in_array( 'author_pages', $include_types, true ) ) {
			$urls = array_merge( $urls, $this->get_author_urls() );
		}

		if ( in_array( 'custom_post_types', $include_types, true ) ) {
			$urls = array_merge( $urls, $this->get_cpt_urls() );
		}

		// Always include homepage and blog page.
		$urls[] = trailingslashit( $this->site_url );
		$blog_page_id = get_option( 'page_for_posts' );
		if ( $blog_page_id ) {
			$urls[] = get_permalink( $blog_page_id );
		}

		// Sitemap.
		$urls[] = $this->site_url . '/wp-sitemap.xml';

		// Additional user-supplied URLs.
		$additional = $this->parse_url_list( $settings['additional_urls'] );
		$urls       = array_merge( $urls, $additional );

		// De-duplicate and filter.
		$urls = array_unique( array_filter( $urls ) );

		// Insert into database, skipping excluded URLs.
		$inserted = 0;
		foreach ( $urls as $url ) {
			$url = $this->normalize_url( $url );

			if ( ! $this->is_same_domain( $url ) ) {
				continue;
			}

			if ( $this->is_excluded( $url, $exclude_urls ) ) {
				continue;
			}

			if ( $this->insert_url( $url, 'discovery' ) ) {
				$inserted++;
			}
		}

		return $inserted;
	}

	/**
	 * Get URLs for published posts and pages.
	 *
	 * @since  1.2.0
	 * @param  array $include_types Active content type slugs.
	 * @return array
	 */
	private function get_post_urls( $include_types ) {
		$post_types = array();
		if ( in_array( 'posts', $include_types, true ) ) {
			$post_types[] = 'post';
		}
		if ( in_array( 'pages', $include_types, true ) ) {
			$post_types[] = 'page';
		}

		if ( empty( $post_types ) ) {
			return array();
		}

		$posts = get_posts( array(
			'post_type'      => $post_types,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		) );

		$urls = array();
		foreach ( $posts as $post_id ) {
			$urls[] = get_permalink( $post_id );
		}

		return $urls;
	}

	/**
	 * Get taxonomy term archive URLs.
	 *
	 * @since  1.2.0
	 * @param  array $include_types Active content type slugs.
	 * @return array
	 */
	private function get_taxonomy_urls( $include_types ) {
		$taxonomies = array();
		if ( in_array( 'categories', $include_types, true ) ) {
			$taxonomies[] = 'category';
		}
		if ( in_array( 'tags', $include_types, true ) ) {
			$taxonomies[] = 'post_tag';
		}

		if ( empty( $taxonomies ) ) {
			return array();
		}

		$urls  = array();
		$terms = get_terms( array(
			'taxonomy'   => $taxonomies,
			'hide_empty' => true,
			'fields'     => 'all',
		) );

		if ( is_wp_error( $terms ) ) {
			return array();
		}

		foreach ( $terms as $term ) {
			$link = get_term_link( $term );
			if ( ! is_wp_error( $link ) ) {
				$urls[] = $link;
			}
		}

		return $urls;
	}

	/**
	 * Get date-based and post type archive URLs.
	 *
	 * @since  1.2.0
	 * @return array
	 */
	private function get_archive_urls() {
		global $wpdb;

		$urls = array();

		// Yearly and monthly archives.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table query; not suitable for object cache.
		$months = $wpdb->get_results(
			"SELECT DISTINCT YEAR(post_date) AS year, MONTH(post_date) AS month
			 FROM {$wpdb->posts}
			 WHERE post_status = 'publish' AND post_type = 'post'
			 ORDER BY post_date DESC"
		);

		$years_added = array();
		foreach ( $months as $row ) {
			$urls[] = get_month_link( $row->year, $row->month );
			if ( ! in_array( $row->year, $years_added, true ) ) {
				$urls[]        = get_year_link( $row->year );
				$years_added[] = $row->year;
			}
		}

		return $urls;
	}

	/**
	 * Get author archive URLs.
	 *
	 * @since  1.2.0
	 * @return array
	 */
	private function get_author_urls() {
		$urls  = array();
		$users = get_users( array(
			'has_published_posts' => true,
			'fields'             => 'ID',
		) );

		foreach ( $users as $user_id ) {
			$urls[] = get_author_posts_url( $user_id );
		}

		return $urls;
	}

	/**
	 * Get custom post type URLs.
	 *
	 * @since  1.2.0
	 * @return array
	 */
	private function get_cpt_urls() {
		$urls       = array();
		$post_types = get_post_types( array(
			'public'   => true,
			'_builtin' => false,
		), 'names' );

		foreach ( $post_types as $pt ) {
			// Post type archive URL.
			$archive_url = get_post_type_archive_link( $pt );
			if ( $archive_url ) {
				$urls[] = $archive_url;
			}

			// Individual CPT posts.
			$posts = get_posts( array(
				'post_type'      => $pt,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			) );

			foreach ( $posts as $post_id ) {
				$urls[] = get_permalink( $post_id );
			}
		}

		return $urls;
	}

	// ------------------------------------------------------------------
	// URL Helpers
	// ------------------------------------------------------------------

	/**
	 * Parse a newline-separated URL list from settings.
	 *
	 * @since  1.2.0
	 * @param  string $text Raw textarea value.
	 * @return array
	 */
	private function parse_url_list( $text ) {
		if ( empty( $text ) ) {
			return array();
		}

		$lines = preg_split( '/\r\n|\r|\n/', $text );
		return array_filter( array_map( 'trim', $lines ) );
	}

	/**
	 * Normalize a URL for consistent comparison.
	 *
	 * @since  1.2.0
	 * @param  string $url URL to normalize.
	 * @return string
	 */
	private function normalize_url( $url ) {
		// Handle protocol-relative URLs (//example.com/path).
		if ( 0 === strpos( $url, '//' ) ) {
			$url = 'https:' . $url;
		} elseif ( 0 === strpos( $url, '/' ) ) {
			// Root-relative URL — prepend site URL.
			$url = $this->site_url . $url;
		}

		// Remove fragment.
		$url = preg_replace( '/#.*$/', '', $url );

		// Remove trailing query string if empty.
		$url = rtrim( $url, '?' );

		return $url;
	}

	/**
	 * Check if a URL belongs to this site's domain.
	 *
	 * @since  1.2.0
	 * @param  string $url URL to check.
	 * @return bool
	 */
	private function is_same_domain( $url ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );
		return $host === $this->site_host;
	}

	/**
	 * Check if a URL matches the exclusion list.
	 *
	 * Supports exact match and wildcard patterns with *.
	 *
	 * @since  1.2.0
	 * @param  string $url      URL to check.
	 * @param  array  $patterns Exclusion patterns.
	 * @return bool
	 */
	private function is_excluded( $url, $patterns ) {
		foreach ( $patterns as $pattern ) {
			// Make relative patterns absolute for comparison.
			if ( 0 === strpos( $pattern, '/' ) ) {
				$pattern = $this->site_url . $pattern;
			}

			if ( false !== strpos( $pattern, '*' ) ) {
				// Wildcard match.
				$regex = '#^' . str_replace( '\*', '.*', preg_quote( $pattern, '#' ) ) . '$#i';
				if ( preg_match( $regex, $url ) ) {
					return true;
				}
			} elseif ( $url === $pattern || untrailingslashit( $url ) === untrailingslashit( $pattern ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Insert a URL into the static pages table.
	 *
	 * @since  1.2.0
	 * @param  string $url      URL to insert.
	 * @param  string $found_on Where the URL was discovered.
	 * @return bool   True if inserted, false if already exists.
	 */
	private function insert_url( $url, $found_on = '' ) {
		global $wpdb;

		$table = $wpdb->prefix . 'up_static_pages';

		// Use INSERT IGNORE to skip duplicates.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Write operation on custom table; name from $wpdb->prefix is safe.
		$result = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$table} (url, found_on, status, created_at, updated_at) VALUES (%s, %s, 'pending', NOW(), NOW())",
				$url,
				$found_on
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

		return $result > 0;
	}

	// ------------------------------------------------------------------
	// Fetch & Save
	// ------------------------------------------------------------------

	/**
	 * Fetch a batch of pending URLs and save their content to disk.
	 *
	 * @since  1.2.0
	 * @param  bool $assets_only When true, only discover asset URLs (CSS/JS/images) from fetched HTML, not page links.
	 * @return array Batch status with { done, total, remaining, message, errors }.
	 */
	private function fetch_batch( $assets_only = false ) {
		global $wpdb;

		$table      = $wpdb->prefix . 'up_static_pages';
		$batch_size = $this->get_batch_size();
		$output_dir = $this->get_output_dir();
		$settings   = $this->get_settings();

		// Rebuild asset filename registry for consistent deduplication across batches.
		$this->rebuild_asset_registry();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
		$pending = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, url FROM {$table} WHERE status = 'pending' LIMIT %d",
				$batch_size
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

		$cache_group = 'ultimate_performance_static';

		$total = wp_cache_get( 'total_count', $cache_group );
		if ( false === $total ) {
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
			wp_cache_set( 'total_count', $total, $cache_group );
		}

		$remaining = wp_cache_get( 'pending_count', $cache_group );
		if ( false === $remaining ) {
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
			$remaining = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} WHERE status = %s",
					'pending'
				)
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
			wp_cache_set( 'pending_count', $remaining, $cache_group );
		}

		if ( empty( $pending ) ) {
			return array(
				'done'      => true,
				'total'     => $total,
				'remaining' => 0,
				'message'   => sprintf(
					/* translators: %d: total number of pages */
					__( 'Fetched all %d pages.', 'ultimate-performance' ),
					$total
				),
				'errors'    => 0,
			);
		}

		$errors = 0;

		foreach ( $pending as $row ) {
			$response = wp_remote_get( $row->url, array(
				'timeout'     => 30,
				'redirection' => 5,
				'sslverify'   => false,
			) );

			if ( is_wp_error( $response ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
				$wpdb->update(
					$table,
					array(
						'status'        => 'error',
						'error_message' => $response->get_error_message(),
						'updated_at'    => current_time( 'mysql' ),
					),
					array( 'id' => $row->id ),
					array( '%s', '%s', '%s' ),
					array( '%d' )
				);
				$errors++;
				continue;
			}

			$http_code    = wp_remote_retrieve_response_code( $response );
			$content_type = wp_remote_retrieve_header( $response, 'content-type' );
			$body         = wp_remote_retrieve_body( $response );

			// Determine file path from URL (assets routed to assets/{category}/).
			$file_path = $this->url_to_asset_path( $row->url );
			$full_path = $output_dir . $file_path;

			// Create directory structure.
			$dir = dirname( $full_path );
			if ( ! is_dir( $dir ) ) {
				wp_mkdir_p( $dir );
			}

			// Save file.
			$saved = file_put_contents( $full_path, $body ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

			if ( false === $saved ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
				$wpdb->update(
					$table,
					array(
						'status'           => 'error',
						'http_status_code' => $http_code,
						'content_type'     => $content_type,
						'error_message'    => __( 'Failed to write file to disk.', 'ultimate-performance' ),
						'updated_at'       => current_time( 'mysql' ),
					),
					array( 'id' => $row->id ),
					array( '%s', '%d', '%s', '%s', '%s' ),
					array( '%d' )
				);
				$errors++;
				continue;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
			$wpdb->update(
				$table,
				array(
					'status'           => 'fetched',
					'file_path'        => $file_path,
					'http_status_code' => $http_code,
					'content_type'     => $content_type,
					'content_hash'     => md5( $body ),
					'updated_at'       => current_time( 'mysql' ),
				),
				array( 'id' => $row->id ),
				array( '%s', '%s', '%d', '%s', '%s', '%s' ),
				array( '%d' )
			);

			// Save serve-ready copy of HTML (pre-rewrite with absolute URLs).
			if ( false !== strpos( $content_type, 'text/html' ) ) {
				$serve_path     = $this->get_serve_dir() . $file_path;
				$serve_dir_path = dirname( $serve_path );
				if ( ! is_dir( $serve_dir_path ) ) {
					wp_mkdir_p( $serve_dir_path );
				}
				file_put_contents( $serve_path, $body ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			}

			// Discover linked assets (and pages in full-site mode) from HTML content.
			if ( false !== strpos( $content_type, 'text/html' ) ) {
				$this->extract_urls_from_html( $body, $row->url, $assets_only );
			}

			// Discover assets referenced inside external CSS files (fonts, images).
			if ( false !== strpos( $content_type, 'text/css' ) ) {
				$this->extract_urls_from_css( $body, $row->url );
			}
		}

		// Invalidate counts cached earlier — statuses changed during the batch loop.
		wp_cache_delete( 'total_count', $cache_group );
		wp_cache_delete( 'pending_count', $cache_group );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
		$remaining = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE status = %s",
				'pending'
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
		wp_cache_set( 'pending_count', $remaining, $cache_group );

		return array(
			'done'      => 0 === $remaining,
			'total'     => $total,
			'remaining' => $remaining,
			'message'   => sprintf(
				/* translators: 1: remaining count, 2: total count */
				__( 'Fetching pages: %1$d remaining of %2$d total.', 'ultimate-performance' ),
				$remaining,
				$total
			),
			'errors'    => $errors,
		);
	}

	/**
	 * Convert a URL to a relative file path for the static output.
	 *
	 * @since  1.2.0
	 * @param  string $url Full URL.
	 * @return string Relative file path.
	 */
	private function url_to_file_path( $url ) {
		$path = wp_parse_url( $url, PHP_URL_PATH );

		if ( empty( $path ) || '/' === $path ) {
			return 'index.html';
		}

		// Remove leading slash.
		$path = ltrim( $path, '/' );

		// Check if the path has a file extension.
		$extension = pathinfo( $path, PATHINFO_EXTENSION );

		if ( empty( $extension ) ) {
			// Directory-style URL: /about/ → about/index.html
			$path = trailingslashit( $path ) . 'index.html';
		}

		return $path;
	}

	/**
	 * Classify a URL into an asset type category based on file extension.
	 *
	 * @since  1.4.0
	 * @param  string $url Full or relative URL.
	 * @return string|false One of 'css', 'js', 'images', 'fonts', or false for HTML pages.
	 */
	private function classify_asset_type( $url ) {
		$path = wp_parse_url( $url, PHP_URL_PATH );

		if ( empty( $path ) ) {
			return false;
		}

		$extension = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

		$map = array(
			'css'   => array( 'css' ),
			'js'    => array( 'js' ),
			'images' => array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'ico', 'bmp', 'tiff', 'tif' ),
			'fonts' => array( 'woff', 'woff2', 'ttf', 'eot', 'otf' ),
		);

		foreach ( $map as $category => $extensions ) {
			if ( in_array( $extension, $extensions, true ) ) {
				return $category;
			}
		}

		return false;
	}

	/**
	 * Generate a deduplicated filename for an asset within its category folder.
	 *
	 * If 'style.css' already exists from one source, a second 'style.css' from
	 * a different source becomes 'plugin-name-style.css'.
	 *
	 * @since  1.4.0
	 * @param  string $category Asset category ('css', 'js', 'images', 'fonts').
	 * @param  string $url      Original full URL of the asset.
	 * @return string Deduplicated filename (not a path, just filename).
	 */
	private function deduplicate_filename( $category, $url ) {
		$path         = wp_parse_url( $url, PHP_URL_PATH );
		$filename     = basename( $path );
		$registry_key = $category . '/' . $filename;

		// Check if this exact URL already has an assigned filename.
		foreach ( $this->asset_filename_registry as $key => $registered_url ) {
			if ( $registered_url === $url ) {
				return substr( $key, strlen( $category ) + 1 );
			}
		}

		// If filename is not taken, register it.
		if ( ! isset( $this->asset_filename_registry[ $registry_key ] ) ) {
			$this->asset_filename_registry[ $registry_key ] = $url;
			return $filename;
		}

		// Collision: derive a prefix from the URL path for disambiguation.
		$path_parts = explode( '/', trim( $path, '/' ) );
		$prefix     = '';

		// Look for theme/plugin name in typical WP paths.
		foreach ( $path_parts as $i => $part ) {
			if ( in_array( $part, array( 'themes', 'plugins' ), true ) && isset( $path_parts[ $i + 1 ] ) ) {
				$prefix = sanitize_file_name( $path_parts[ $i + 1 ] );
				break;
			}
		}

		// Fallback: use parent directory name.
		if ( empty( $prefix ) && count( $path_parts ) >= 2 ) {
			$prefix = sanitize_file_name( $path_parts[ count( $path_parts ) - 2 ] );
		}

		$name_no_ext = pathinfo( $filename, PATHINFO_FILENAME );
		$ext         = pathinfo( $filename, PATHINFO_EXTENSION );
		$new_name    = $prefix . '-' . $name_no_ext . '.' . $ext;

		// If still collides, append numeric suffix.
		$candidate_key = $category . '/' . $new_name;
		$counter       = 2;
		while ( isset( $this->asset_filename_registry[ $candidate_key ] ) ) {
			$new_name      = $prefix . '-' . $name_no_ext . '-' . $counter . '.' . $ext;
			$candidate_key = $category . '/' . $new_name;
			$counter++;
		}

		$this->asset_filename_registry[ $candidate_key ] = $url;
		return $new_name;
	}

	/**
	 * Convert a URL to a clean asset path under the assets/ directory.
	 *
	 * For HTML pages, delegates to url_to_file_path(). For CSS/JS/images/fonts,
	 * returns assets/{category}/{deduplicated-name}.
	 *
	 * @since  1.4.0
	 * @param  string $url Full URL.
	 * @return string Relative file path for the output directory.
	 */
	private function url_to_asset_path( $url ) {
		$category = $this->classify_asset_type( $url );

		if ( false === $category ) {
			return $this->url_to_file_path( $url );
		}

		$filename = $this->deduplicate_filename( $category, $url );
		return 'assets/' . $category . '/' . $filename;
	}

	/**
	 * Rebuild the asset filename registry from already-processed database rows.
	 *
	 * Called at the start of each fetch/rewrite batch to ensure consistent
	 * filename assignment across multiple AJAX requests.
	 *
	 * @since 1.4.0
	 */
	private function rebuild_asset_registry() {
		global $wpdb;

		$table = $wpdb->prefix . 'up_static_pages';
		$this->asset_filename_registry = array();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
		$rows = $wpdb->get_results(
			"SELECT url, file_path FROM {$table} WHERE file_path IS NOT NULL AND file_path != '' AND status IN ('fetched', 'saved')"
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

		foreach ( $rows as $row ) {
			$category = $this->classify_asset_type( $row->url );
			if ( false !== $category && ! empty( $row->file_path ) ) {
				$filename     = basename( $row->file_path );
				$registry_key = $category . '/' . $filename;
				$this->asset_filename_registry[ $registry_key ] = $row->url;
			}
		}
	}

	/**
	 * Extract internal URLs from HTML content and insert new ones into the database.
	 *
	 * @since  1.2.0
	 * @param  string $html        HTML content.
	 * @param  string $source_url  URL where the content was fetched from.
	 * @param  bool   $assets_only When true, only extract asset URLs (CSS/JS/images), skip <a> page links.
	 * @return array  Discovered URLs.
	 */
	private function extract_urls_from_html( $html, $source_url, $assets_only = false ) {
		$settings     = $this->get_settings();
		$exclude_urls = $this->parse_url_list( $settings['exclude_urls'] );
		$discovered   = array();

		// Suppress DOMDocument warnings for malformed HTML.
		$prev = libxml_use_internal_errors( true );

		$dom = new DOMDocument();
		$dom->loadHTML( '<?xml encoding="UTF-8">' . $html, LIBXML_NOWARNING | LIBXML_NOERROR );

		libxml_clear_errors();
		libxml_use_internal_errors( $prev );

		// Extract href from <a> (page links — full site mode only) and <link> (CSS/assets — always).
		if ( ! $assets_only ) {
			$anchors = $dom->getElementsByTagName( 'a' );
			foreach ( $anchors as $el ) {
				$url = $el->getAttribute( 'href' );
				if ( ! empty( $url ) ) {
					$discovered[] = $url;
				}
			}
		}

		// Always extract <link> hrefs (stylesheets, icons, preloads).
		$links = $dom->getElementsByTagName( 'link' );
		foreach ( $links as $el ) {
			$url = $el->getAttribute( 'href' );
			if ( ! empty( $url ) ) {
				$discovered[] = $url;
			}
		}

		// Extract src from <script>, <img>.
		$src_tags = array( 'script', 'img' );
		foreach ( $src_tags as $tag ) {
			$elements = $dom->getElementsByTagName( $tag );
			foreach ( $elements as $el ) {
				$src = $el->getAttribute( 'src' );
				if ( ! empty( $src ) ) {
					$discovered[] = $src;
				}

				// Also check srcset for <img>.
				if ( 'img' === $tag ) {
					$srcset = $el->getAttribute( 'srcset' );
					if ( ! empty( $srcset ) ) {
						$parts = explode( ',', $srcset );
						foreach ( $parts as $part ) {
							$pieces = preg_split( '/\s+/', trim( $part ) );
							if ( ! empty( $pieces[0] ) ) {
								$discovered[] = $pieces[0];
							}
						}
					}
				}
			}
		}

		// Extract srcset/src from <source> elements (WebP inside <picture> tags).
		$sources = $dom->getElementsByTagName( 'source' );
		foreach ( $sources as $el ) {
			$srcset = $el->getAttribute( 'srcset' );
			if ( ! empty( $srcset ) ) {
				$parts = explode( ',', $srcset );
				foreach ( $parts as $part ) {
					$pieces = preg_split( '/\s+/', trim( $part ) );
					if ( ! empty( $pieces[0] ) ) {
						$discovered[] = $pieces[0];
					}
				}
			}
			$src = $el->getAttribute( 'src' );
			if ( ! empty( $src ) ) {
				$discovered[] = $src;
			}
		}

		// Extract CSS url() references from <style> tags.
		$styles = $dom->getElementsByTagName( 'style' );
		foreach ( $styles as $style ) {
			preg_match_all( '/url\(\s*[\'"]?([^\'")\s]+)[\'"]?\s*\)/i', $style->textContent, $matches );
			if ( ! empty( $matches[1] ) ) {
				$discovered = array_merge( $discovered, $matches[1] );
			}
		}

		// Extract URLs from inline <script> content (dynamically loaded assets).
		$site_url_escaped = preg_quote( $this->site_url, '#' );
		$scripts_all      = $dom->getElementsByTagName( 'script' );
		foreach ( $scripts_all as $script ) {
			// Skip external scripts (those with src attribute).
			if ( $script->getAttribute( 'src' ) ) {
				continue;
			}
			$js_content = $script->textContent;
			if ( empty( $js_content ) ) {
				continue;
			}
			// Find all URLs matching the site domain within JS strings.
			preg_match_all(
				'#["\'](' . $site_url_escaped . '/[^\s"\'<>]+\.(?:js|css|woff2?|ttf|eot|otf|png|jpe?g|gif|webp|avif|svg|ico))["\']#i',
				$js_content,
				$js_matches
			);
			if ( ! empty( $js_matches[1] ) ) {
				$discovered = array_merge( $discovered, $js_matches[1] );
			}
		}

		// Filter and insert.
		$inserted = array();
		foreach ( $discovered as $url ) {
			$url = $this->normalize_url( $url );

			if ( ! $this->is_same_domain( $url ) ) {
				continue;
			}

			if ( $this->is_excluded( $url, $exclude_urls ) ) {
				continue;
			}

			if ( $this->insert_url( $url, $source_url ) ) {
				$inserted[] = $url;
			}
		}

		return $inserted;
	}

	/**
	 * Extract asset URLs from external CSS content and insert new ones into the database.
	 *
	 * Parses url() and @import references to discover fonts, background images,
	 * and other assets that need to be fetched.
	 *
	 * @since  1.4.0
	 * @param  string $css        CSS content.
	 * @param  string $source_url URL where the CSS was fetched from.
	 * @return array  Discovered URLs that were inserted.
	 */
	private function extract_urls_from_css( $css, $source_url ) {
		$settings     = $this->get_settings();
		$exclude_urls = $this->parse_url_list( $settings['exclude_urls'] );
		$discovered   = array();
		$css_dir      = dirname( $source_url );

		// Extract url() values.
		preg_match_all( '/url\(\s*[\'"]?([^\'")\s]+)[\'"]?\s*\)/i', $css, $matches );
		if ( ! empty( $matches[1] ) ) {
			foreach ( $matches[1] as $url ) {
				// Skip data: URIs.
				if ( 0 === strpos( $url, 'data:' ) ) {
					continue;
				}
				// Resolve relative URLs against the CSS file's directory.
				if ( 0 !== strpos( $url, 'http' ) && 0 !== strpos( $url, '//' ) ) {
					$url = $css_dir . '/' . $url;
				}
				$discovered[] = $url;
			}
		}

		// Extract @import URLs.
		preg_match_all( '/@import\s+[\'"]([^\'"]+)[\'"]/i', $css, $import_matches );
		if ( ! empty( $import_matches[1] ) ) {
			foreach ( $import_matches[1] as $url ) {
				if ( 0 !== strpos( $url, 'http' ) && 0 !== strpos( $url, '//' ) ) {
					$url = $css_dir . '/' . $url;
				}
				$discovered[] = $url;
			}
		}

		// Filter and insert.
		$inserted = array();
		foreach ( $discovered as $url ) {
			$url = $this->normalize_url( $url );

			if ( ! $this->is_same_domain( $url ) ) {
				continue;
			}

			if ( $this->is_excluded( $url, $exclude_urls ) ) {
				continue;
			}

			if ( $this->insert_url( $url, $source_url ) ) {
				$inserted[] = $url;
			}
		}

		return $inserted;
	}

	// ------------------------------------------------------------------
	// URL Rewriting
	// ------------------------------------------------------------------

	/**
	 * Rewrite URLs in a batch of fetched files.
	 *
	 * @since  1.2.0
	 * @return array Batch status with { done, total, remaining, message }.
	 */
	private function rewrite_batch() {
		global $wpdb;

		// Rebuild asset filename registry for consistent path resolution.
		$this->rebuild_asset_registry();

		$table      = $wpdb->prefix . 'up_static_pages';
		$batch_size = $this->get_batch_size();
		$output_dir = $this->get_output_dir();
		$settings   = $this->get_settings();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
		$fetched = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, url, file_path, content_type FROM {$table} WHERE status = 'fetched' LIMIT %d",
				$batch_size
			)
		);

		$total     = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$table} WHERE status IN ('fetched','saved')"
		);
		$remaining = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE status = %s",
				'fetched'
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

		if ( empty( $fetched ) ) {
			return array(
				'done'      => true,
				'total'     => $total,
				'remaining' => 0,
				'message'   => __( 'URL rewriting complete.', 'ultimate-performance' ),
			);
		}

		foreach ( $fetched as $row ) {
			$full_path = $output_dir . $row->file_path;

			if ( ! file_exists( $full_path ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
				$wpdb->update(
					$table,
					array( 'status' => 'saved', 'updated_at' => current_time( 'mysql' ) ),
					array( 'id' => $row->id ),
					array( '%s', '%s' ),
					array( '%d' )
				);
				continue;
			}

			$content = file_get_contents( $full_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents

			if ( false !== strpos( $row->content_type, 'text/html' ) ) {
				$content = $this->rewrite_html_urls( $content, $row->file_path, $settings['url_style'], $settings['base_url'] );
			} elseif ( false !== strpos( $row->content_type, 'text/css' ) ) {
				$content = $this->rewrite_css_urls( $content, $row->file_path, $settings['url_style'], $settings['base_url'] );
			}

			file_put_contents( $full_path, $content ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
			$wpdb->update(
				$table,
				array( 'status' => 'saved', 'updated_at' => current_time( 'mysql' ) ),
				array( 'id' => $row->id ),
				array( '%s', '%s' ),
				array( '%d' )
			);
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
		$remaining = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE status = %s",
				'fetched'
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

		return array(
			'done'      => 0 === $remaining,
			'total'     => $total,
			'remaining' => $remaining,
			'message'   => sprintf(
				/* translators: %d: remaining count */
				__( 'Rewriting URLs: %d files remaining.', 'ultimate-performance' ),
				$remaining
			),
		);
	}

	/**
	 * Rewrite URLs in HTML content.
	 *
	 * @since  1.2.0
	 * @param  string $html      HTML content.
	 * @param  string $file_path Current file's relative path.
	 * @param  string $url_style 'relative', 'offline', or 'absolute'.
	 * @param  string $base_url  Base URL for absolute mode.
	 * @return string Rewritten HTML.
	 */
	private function rewrite_html_urls( $html, $file_path, $url_style, $base_url ) {
		$site_url = preg_quote( $this->site_url, '#' );

		// Replace the site URL in all attributes.
		$html = preg_replace_callback(
			'#(href|src|action|srcset)=(["\'])(' . $site_url . ')(/[^"\']*?)(["\'])#i',
			function ( $matches ) use ( $file_path, $url_style, $base_url ) {
				$attr     = $matches[1];
				$quote    = $matches[2];
				$path     = $matches[4];
				$new_url  = $this->rewrite_url( $path, $file_path, $url_style, $base_url );
				return $attr . '=' . $quote . $new_url . $quote;
			},
			$html
		);

		// Also rewrite protocol-relative URLs and root-relative URLs.
		$host = preg_quote( $this->site_host, '#' );
		$html = preg_replace_callback(
			'#(href|src|action)=(["\'])(//?' . $host . ')(/[^"\']*?)(["\'])#i',
			function ( $matches ) use ( $file_path, $url_style, $base_url ) {
				$attr    = $matches[1];
				$quote   = $matches[2];
				$path    = $matches[4];
				$new_url = $this->rewrite_url( $path, $file_path, $url_style, $base_url );
				return $attr . '=' . $quote . $new_url . $quote;
			},
			$html
		);

		// Rewrite site URLs inside inline JavaScript strings (dynamically loaded assets).
		$html = preg_replace_callback(
			'#(["\'])(' . $site_url . ')(/[^\s"\'<>]+?\.(?:js|css|woff2?|ttf|eot|otf|png|jpe?g|gif|webp|avif|svg|ico))(["\'])#i',
			function ( $matches ) use ( $file_path, $url_style, $base_url ) {
				$open_quote  = $matches[1];
				$path        = $matches[3];
				$close_quote = $matches[4];
				$new_url     = $this->rewrite_url( $path, $file_path, $url_style, $base_url );
				return $open_quote . $new_url . $close_quote;
			},
			$html
		);

		return $html;
	}

	/**
	 * Rewrite URLs in CSS content.
	 *
	 * @since  1.2.0
	 * @param  string $css       CSS content.
	 * @param  string $file_path Current file's relative path.
	 * @param  string $url_style URL rewriting style.
	 * @param  string $base_url  Base URL for absolute mode.
	 * @return string Rewritten CSS.
	 */
	private function rewrite_css_urls( $css, $file_path, $url_style, $base_url ) {
		$site_url = preg_quote( $this->site_url, '#' );

		// Rewrite url() values.
		$css = preg_replace_callback(
			'#url\(\s*[\'"]?(' . $site_url . ')(/[^\'")\s]+)[\'"]?\s*\)#i',
			function ( $matches ) use ( $file_path, $url_style, $base_url ) {
				$path    = $matches[2];
				$new_url = $this->rewrite_url( $path, $file_path, $url_style, $base_url );
				return 'url(' . $new_url . ')';
			},
			$css
		);

		// Rewrite @import urls.
		$css = preg_replace_callback(
			'#@import\s+[\'"](' . $site_url . ')(/[^\'"]+)[\'"]#i',
			function ( $matches ) use ( $file_path, $url_style, $base_url ) {
				$path    = $matches[2];
				$new_url = $this->rewrite_url( $path, $file_path, $url_style, $base_url );
				return '@import \'' . $new_url . '\'';
			},
			$css
		);

		return $css;
	}

	/**
	 * Convert an absolute path to the appropriate URL format.
	 *
	 * @since  1.2.0
	 * @param  string $path      URL path (e.g., /about/).
	 * @param  string $file_path Current file's relative path for relative mode.
	 * @param  string $url_style 'relative', 'offline', or 'absolute'.
	 * @param  string $base_url  Base URL for absolute mode.
	 * @return string Rewritten URL.
	 */
	private function rewrite_url( $path, $file_path, $url_style, $base_url ) {
		$target_path = $this->url_to_asset_path( $this->site_url . $path );

		switch ( $url_style ) {
			case 'absolute':
				return trailingslashit( untrailingslashit( $base_url ) ) . $target_path;

			case 'offline':
				return './' . $target_path;

			case 'relative':
			default:
				// Calculate relative path from current file to target.
				$from_dir = dirname( $file_path );
				if ( '.' === $from_dir || empty( $from_dir ) ) {
					return $target_path;
				}

				$from_parts   = explode( '/', $from_dir );
				$target_parts = explode( '/', $target_path );

				// Find common prefix length.
				$common = 0;
				$max    = min( count( $from_parts ), count( $target_parts ) );
				for ( $i = 0; $i < $max; $i++ ) {
					if ( $from_parts[ $i ] === $target_parts[ $i ] ) {
						$common++;
					} else {
						break;
					}
				}

				$up   = count( $from_parts ) - $common;
				$down = array_slice( $target_parts, $common );

				$relative = str_repeat( '../', $up ) . implode( '/', $down );

				return $relative ?: './';
		}
	}

	// ------------------------------------------------------------------
	// Packaging
	// ------------------------------------------------------------------

	/**
	 * Package the output directory into a ZIP file.
	 *
	 * @since  1.2.0
	 * @return array { success, file_path, download_url, total_size, total_files }
	 */
	private function create_zip() {
		$output_dir = $this->get_output_dir();
		$zip_dir    = $this->get_zip_dir();
		$zip_name   = 'static-site-' . gmdate( 'Y-m-d-His' ) . '.zip';
		$zip_path   = $zip_dir . $zip_name;

		if ( ! class_exists( 'ZipArchive' ) ) {
			return array(
				'success' => false,
				'message' => __( 'ZipArchive PHP extension is not available.', 'ultimate-performance' ),
			);
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return array(
				'success' => false,
				'message' => __( 'Failed to create ZIP file.', 'ultimate-performance' ),
			);
		}

		$total_files = 0;
		$total_size  = 0;

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $output_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::LEAVES_ONLY
		);

		foreach ( $iterator as $file ) {
			if ( ! $file->isDir() ) {
				$real_path     = $file->getRealPath();
				$relative_path = substr( $real_path, strlen( realpath( $output_dir ) ) + 1 );

				// Normalize path separators for ZIP.
				$relative_path = str_replace( '\\', '/', $relative_path );

				$zip->addFile( $real_path, $relative_path );
				$total_files++;
				$total_size += $file->getSize();
			}
		}

		$zip->close();

		// Build download URL.
		$upload_dir   = wp_upload_dir();
		$download_url = $upload_dir['baseurl'] . '/ultimate-performance/' . $zip_name;

		return array(
			'success'      => true,
			'file_path'    => $zip_path,
			'download_url' => $download_url,
			'total_files'  => $total_files,
			'total_size'   => size_format( $total_size ),
		);
	}

	// ------------------------------------------------------------------
	// AJAX Handlers — Full Site
	// ------------------------------------------------------------------

	/**
	 * AJAX handler for full site static generation.
	 *
	 * @since 1.2.0
	 */
	public function ajax_generate() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$this->ensure_table();

		$phase = isset( $_POST['phase'] ) ? sanitize_key( wp_unslash( $_POST['phase'] ) ) : 'setup';

		switch ( $phase ) {
			case 'setup':
				$this->cleanup();
				set_transient( 'up_static_generating', true, HOUR_IN_SECONDS );

				wp_send_json_success( array(
					'done'       => true,
					'phase'      => 'setup',
					'next_phase' => 'discover',
					'total'      => 0,
					'remaining'  => 0,
					'message'    => __( 'Setup complete. Starting URL discovery...', 'ultimate-performance' ),
				) );
				break;

			case 'discover':
				$count = $this->discover_urls();

				wp_send_json_success( array(
					'done'       => true,
					'phase'      => 'discover',
					'next_phase' => 'fetch',
					'total'      => $count,
					'remaining'  => $count,
					'message'    => sprintf(
						/* translators: %d: number of URLs discovered */
						__( 'Discovered %d URLs. Starting fetch...', 'ultimate-performance' ),
						$count
					),
				) );
				break;

			case 'fetch':
				$result = $this->fetch_batch();

				$response = array(
					'done'       => $result['done'],
					'phase'      => 'fetch',
					'total'      => $result['total'],
					'remaining'  => $result['remaining'],
					'message'    => $result['message'],
				);

				if ( $result['done'] ) {
					$response['next_phase'] = 'rewrite';
				}

				wp_send_json_success( $response );
				break;

			case 'rewrite':
				$result = $this->rewrite_batch();

				$response = array(
					'done'       => $result['done'],
					'phase'      => 'rewrite',
					'total'      => $result['total'],
					'remaining'  => $result['remaining'],
					'message'    => $result['message'],
				);

				if ( $result['done'] ) {
					$response['next_phase'] = 'package';
				}

				wp_send_json_success( $response );
				break;

			case 'package':
				$settings = $this->get_settings();

				if ( 'zip' === $settings['delivery_method'] ) {
					$result = $this->create_zip();

					if ( ! $result['success'] ) {
						wp_send_json_error( array( 'message' => $result['message'] ) );
					}

					$this->save_last_run( $result );

					wp_send_json_success( array(
						'done'         => true,
						'phase'        => 'package',
						'total'        => $result['total_files'],
						'remaining'    => 0,
						'message'      => sprintf(
							/* translators: 1: file count, 2: total size */
							__( 'Static site packaged: %1$d files (%2$s). Ready for download!', 'ultimate-performance' ),
							$result['total_files'],
							$result['total_size']
						),
						'download_url' => $result['download_url'],
					) );
				} else {
					// Local directory mode — just save stats.
					$output_dir = $this->get_output_dir();
					$this->save_last_run( array(
						'total_files' => $this->count_files_in_dir( $output_dir ),
						'total_size'  => size_format( $this->dir_size( $output_dir ) ),
					) );

					wp_send_json_success( array(
						'done'      => true,
						'phase'     => 'package',
						'total'     => 0,
						'remaining' => 0,
						'message'   => sprintf(
							/* translators: %s: output directory path */
							__( 'Static site saved to: %s', 'ultimate-performance' ),
							$output_dir
						),
					) );
				}

				delete_transient( 'up_static_generating' );
				break;

			default:
				wp_send_json_error( array( 'message' => __( 'Unknown phase.', 'ultimate-performance' ) ) );
				break;
		}
	}

	// ------------------------------------------------------------------
	// AJAX Handlers — Individual Pages
	// ------------------------------------------------------------------

	/**
	 * AJAX handler for searching pages by title or URL.
	 *
	 * @since 1.2.0
	 */
	public function ajax_search_pages() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$search = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';

		if ( strlen( $search ) < 2 ) {
			wp_send_json_success( array( 'results' => array() ) );
		}

		$post_types = get_post_types( array( 'public' => true ), 'objects' );
		$type_names = array_keys( $post_types );

		$query = new WP_Query( array(
			's'              => $search,
			'post_type'      => $type_names,
			'post_status'    => 'publish',
			'posts_per_page' => 20,
			'fields'         => 'ids',
		) );

		$results = array();
		foreach ( $query->posts as $post_id ) {
			$post       = get_post( $post_id );
			$type_obj   = isset( $post_types[ $post->post_type ] ) ? $post_types[ $post->post_type ] : null;

			$results[] = array(
				'id'              => $post_id,
				'title'           => get_the_title( $post_id ),
				'url'             => get_permalink( $post_id ),
				'post_type'       => $post->post_type,
				'post_type_label' => $type_obj ? $type_obj->labels->singular_name : $post->post_type,
			);
		}

		wp_send_json_success( array( 'results' => $results ) );
	}

	/**
	 * AJAX handler for generating individual selected pages.
	 *
	 * @since 1.2.0
	 */
	public function ajax_generate_pages() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$this->ensure_table();

		$phase = isset( $_POST['phase'] ) ? sanitize_key( wp_unslash( $_POST['phase'] ) ) : 'setup';

		switch ( $phase ) {
			case 'setup':
				$this->cleanup();
				set_transient( 'up_static_generating', true, HOUR_IN_SECONDS );

				$urls = isset( $_POST['urls'] ) ? array_map( 'esc_url_raw', wp_unslash( $_POST['urls'] ) ) : array();

				if ( empty( $urls ) ) {
					wp_send_json_error( array( 'message' => __( 'No pages selected.', 'ultimate-performance' ) ) );
				}

				// Insert selected URLs.
				$inserted = 0;
				foreach ( $urls as $url ) {
					$url = $this->normalize_url( $url );
					if ( $this->is_same_domain( $url ) && $this->insert_url( $url, 'manual_selection' ) ) {
						$inserted++;
					}
				}

				wp_send_json_success( array(
					'done'       => true,
					'phase'      => 'setup',
					'next_phase' => 'fetch',
					'total'      => $inserted,
					'remaining'  => $inserted,
					'message'    => sprintf(
						/* translators: %d: number of pages */
						__( 'Starting generation for %d selected page(s)...', 'ultimate-performance' ),
						$inserted
					),
				) );
				break;

			case 'fetch':
				// Assets only — don't crawl <a> page links in individual mode.
				$result = $this->fetch_batch( true );

				$response = array(
					'done'       => $result['done'],
					'phase'      => 'fetch',
					'total'      => $result['total'],
					'remaining'  => $result['remaining'],
					'message'    => $result['message'],
				);

				if ( $result['done'] ) {
					$response['next_phase'] = 'rewrite';
				}

				wp_send_json_success( $response );
				break;

			case 'rewrite':
				$result = $this->rewrite_batch();

				$response = array(
					'done'       => $result['done'],
					'phase'      => 'rewrite',
					'total'      => $result['total'],
					'remaining'  => $result['remaining'],
					'message'    => $result['message'],
				);

				if ( $result['done'] ) {
					$response['next_phase'] = 'package';
				}

				wp_send_json_success( $response );
				break;

			case 'package':
				$settings = $this->get_settings();

				if ( 'zip' === $settings['delivery_method'] ) {
					$result = $this->create_zip();

					if ( ! $result['success'] ) {
						wp_send_json_error( array( 'message' => $result['message'] ) );
					}

					$this->save_last_run( $result );

					wp_send_json_success( array(
						'done'         => true,
						'phase'        => 'package',
						'total'        => $result['total_files'],
						'remaining'    => 0,
						'message'      => sprintf(
							/* translators: 1: file count, 2: total size */
							__( 'Selected pages packaged: %1$d files (%2$s). Ready for download!', 'ultimate-performance' ),
							$result['total_files'],
							$result['total_size']
						),
						'download_url' => $result['download_url'],
					) );
				} else {
					$output_dir = $this->get_output_dir();
					$this->save_last_run( array(
						'total_files' => $this->count_files_in_dir( $output_dir ),
						'total_size'  => size_format( $this->dir_size( $output_dir ) ),
					) );

					wp_send_json_success( array(
						'done'      => true,
						'phase'     => 'package',
						'total'     => 0,
						'remaining' => 0,
						'message'   => sprintf(
							/* translators: %s: output directory path */
							__( 'Selected pages saved to: %s', 'ultimate-performance' ),
							$output_dir
						),
					) );
				}

				delete_transient( 'up_static_generating' );
				break;

			default:
				wp_send_json_error( array( 'message' => __( 'Unknown phase.', 'ultimate-performance' ) ) );
				break;
		}
	}

	// ------------------------------------------------------------------
	// AJAX Handlers — Shared
	// ------------------------------------------------------------------

	/**
	 * AJAX handler to cancel an in-progress generation.
	 *
	 * @since 1.2.0
	 */
	public function ajax_cancel() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$this->cleanup();

		wp_send_json_success( array(
			'message' => __( 'Generation cancelled and cleaned up.', 'ultimate-performance' ),
		) );
	}

	/**
	 * AJAX handler to get the current generation status.
	 *
	 * @since 1.2.0
	 */
	public function ajax_status() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		global $wpdb;

		$table = $wpdb->prefix . 'up_static_pages';

		// Check if table exists.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table query; not suitable for object cache.
		$table_exists = $wpdb->get_var(
			$wpdb->prepare( 'SHOW TABLES LIKE %s', $table )
		);

		if ( ! $table_exists ) {
			wp_send_json_success( array(
				'generating'  => false,
				'total'       => 0,
				'pending'     => 0,
				'fetched'     => 0,
				'saved'       => 0,
				'errors'      => 0,
				'last_run'    => get_option( 'up_static_last_run', null ),
				'serve_count' => $this->get_serve_count(),
			) );
		}

		$cache_group = 'ultimate_performance_static';

		$status_total = wp_cache_get( 'status_total', $cache_group );
		if ( false === $status_total ) {
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
			$status_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
			wp_cache_set( 'status_total', $status_total, $cache_group );
		}

		$statuses = array( 'pending', 'fetched', 'saved', 'error' );
		$counts   = array();
		foreach ( $statuses as $status ) {
			$cache_key = 'status_' . $status;
			$count     = wp_cache_get( $cache_key, $cache_group );
			if ( false === $count ) {
				// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
				$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", $status ) );
				// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
				wp_cache_set( $cache_key, $count, $cache_group );
			}
			$counts[ $status ] = $count;
		}

		wp_send_json_success( array(
			'generating'  => (bool) get_transient( 'up_static_generating' ),
			'total'       => $status_total,
			'pending'     => $counts['pending'],
			'fetched'     => $counts['fetched'],
			'saved'       => $counts['saved'],
			'errors'      => $counts['error'],
			'last_run'    => get_option( 'up_static_last_run', null ),
			'serve_count' => $this->get_serve_count(),
		) );
	}

	/**
	 * AJAX handler to serve the ZIP file for download.
	 *
	 * @since 1.2.0
	 */
	public function ajax_download() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'ultimate-performance' ), 403 );
		}

		$last_run = get_option( 'up_static_last_run' );

		if ( empty( $last_run['file_path'] ) || ! file_exists( $last_run['file_path'] ) ) {
			wp_die( esc_html__( 'ZIP file not found.', 'ultimate-performance' ), 404 );
		}

		$file = $last_run['file_path'];

		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . basename( $file ) . '"' );
		header( 'Content-Length: ' . filesize( $file ) );

		readfile( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		exit;
	}

	// ------------------------------------------------------------------
	// Utility
	// ------------------------------------------------------------------

	/**
	 * Save last run statistics to options.
	 *
	 * @since 1.2.0
	 * @param array $result Generation result data.
	 */
	private function save_last_run( $result ) {
		update_option( 'up_static_last_run', array(
			'date'        => current_time( 'mysql' ),
			'total_files' => isset( $result['total_files'] ) ? $result['total_files'] : 0,
			'total_size'  => isset( $result['total_size'] ) ? $result['total_size'] : '0 B',
			'file_path'   => isset( $result['file_path'] ) ? $result['file_path'] : '',
			'download_url' => isset( $result['download_url'] ) ? $result['download_url'] : '',
		) );
	}

	/**
	 * Count files in a directory recursively.
	 *
	 * @since  1.2.0
	 * @param  string $dir Directory path.
	 * @return int
	 */
	private function count_files_in_dir( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return 0;
		}

		$count    = 0;
		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS )
		);

		foreach ( $iterator as $file ) {
			if ( ! $file->isDir() ) {
				$count++;
			}
		}

		return $count;
	}

	/**
	 * Calculate total size of a directory recursively.
	 *
	 * @since  1.2.0
	 * @param  string $dir Directory path.
	 * @return int Size in bytes.
	 */
	private function dir_size( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return 0;
		}

		$size     = 0;
		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS )
		);

		foreach ( $iterator as $file ) {
			if ( ! $file->isDir() ) {
				$size += $file->getSize();
			}
		}

		return $size;
	}

	// ------------------------------------------------------------------
	// Frontend Static Serving
	// ------------------------------------------------------------------

	/**
	 * Serve a pre-generated static HTML file if available.
	 *
	 * Hooked to `template_redirect` at priority -1 (before page cache).
	 * Only serves HTML pages from the serve directory — CSS, JS, and
	 * images are already served directly by the web server.
	 *
	 * @since 1.3.0
	 */
	public function maybe_serve_static() {
		// 1. Skip non-GET requests.
		if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'GET' !== $_SERVER['REQUEST_METHOD'] ) {
			return;
		}

		// 2. Skip logged-in users (unless setting allows).
		$settings = $this->get_settings();
		if ( is_user_logged_in() && empty( $settings['serve_logged_in'] ) ) {
			return;
		}

		// 3. Skip admin, AJAX, cron, REST API.
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}

		// 4. Skip requests with query strings.
		if ( ! empty( $_SERVER['QUERY_STRING'] ) ) {
			return;
		}

		// 5. Skip 404 and search pages.
		if ( is_404() || is_search() ) {
			return;
		}

		// 6. Check URL exclusions.
		$request_uri = isset( $_SERVER['REQUEST_URI'] )
			? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) )
			: '';
		if ( $this->is_serve_url_excluded( $request_uri, $settings ) ) {
			return;
		}

		// 7. Convert URL to file path and check serve directory.
		$file_path  = $this->url_to_file_path( home_url( $request_uri ) );
		$serve_file = $this->get_serve_dir() . $file_path;

		if ( file_exists( $serve_file ) ) {
			$content = file_get_contents( $serve_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
			if ( false !== $content ) {
				header( 'Content-Type: text/html; charset=UTF-8' );
				header( 'X-Static-Generator: Ultimate Performance' );
				echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Pre-generated HTML page.
				echo "\n<!-- Served statically by Ultimate Performance -->";
				exit;
			}
		}

		// File doesn't exist — fall through to normal WordPress.
	}

	/**
	 * Check if a request URI is excluded from static serving.
	 *
	 * @since  1.3.0
	 * @param  string $uri      The request URI.
	 * @param  array  $settings Module settings.
	 * @return bool
	 */
	private function is_serve_url_excluded( $uri, $settings ) {
		if ( empty( $settings['serve_exclude_urls'] ) ) {
			return false;
		}

		$patterns = $this->parse_url_list( $settings['serve_exclude_urls'] );

		foreach ( $patterns as $pattern ) {
			$pattern = trim( $pattern );
			if ( empty( $pattern ) ) {
				continue;
			}

			// Exact match.
			if ( $pattern === $uri || trailingslashit( $pattern ) === trailingslashit( $uri ) ) {
				return true;
			}

			// Wildcard match (e.g., /cart/*).
			if ( false !== strpos( $pattern, '*' ) ) {
				$regex = '/^' . str_replace( '\*', '.*', preg_quote( $pattern, '/' ) ) . '$/';
				if ( preg_match( $regex, $uri ) ) {
					return true;
				}
			}
		}

		return false;
	}

	// ------------------------------------------------------------------
	// Smart Serve Purge (Auto-Invalidation)
	// ------------------------------------------------------------------

	/**
	 * Register hooks to auto-delete stale serve files when content changes.
	 *
	 * @since 1.3.0
	 */
	private function setup_serve_purge() {
		// Content updates.
		add_action( 'save_post', array( $this, 'purge_serve_post' ), 10, 2 );

		// Site-wide changes.
		add_action( 'switch_theme', array( $this, 'purge_all_serve' ) );
		add_action( 'activated_plugin', array( $this, 'purge_all_serve' ) );
		add_action( 'deactivated_plugin', array( $this, 'purge_all_serve' ) );
		add_action( 'wp_update_nav_menu', array( $this, 'purge_all_serve' ) );
	}

	/**
	 * Purge serve files for a post and related pages when saved.
	 *
	 * @since 1.3.0
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 */
	public function purge_serve_post( $post_id, $post ) {
		// Skip revisions and autosaves.
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		// Only process published posts.
		if ( 'publish' !== $post->post_status ) {
			return;
		}

		// Purge the post's own URL.
		$permalink = get_permalink( $post_id );
		if ( $permalink ) {
			$this->purge_serve_url( $permalink );
		}

		// Purge homepage (it may list this post).
		$this->purge_serve_url( home_url( '/' ) );

		// Purge taxonomy archive pages for this post's terms.
		$taxonomies = get_object_taxonomies( $post->post_type );
		foreach ( $taxonomies as $taxonomy ) {
			$terms = get_the_terms( $post_id, $taxonomy );
			if ( $terms && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$term_link = get_term_link( $term );
					if ( ! is_wp_error( $term_link ) ) {
						$this->purge_serve_url( $term_link );
					}
				}
			}
		}
	}

	/**
	 * Delete the serve file for a specific URL.
	 *
	 * @since 1.3.0
	 * @param string $url Full URL to purge.
	 */
	public function purge_serve_url( $url ) {
		$file_path  = $this->url_to_file_path( $url );
		$serve_file = $this->get_serve_dir() . $file_path;

		if ( file_exists( $serve_file ) ) {
			wp_delete_file( $serve_file );
		}
	}

	/**
	 * Delete all served static files.
	 *
	 * @since 1.3.0
	 */
	public function purge_all_serve() {
		$serve_dir = $this->get_serve_dir();
		if ( is_dir( $serve_dir ) ) {
			$this->delete_directory_contents( $serve_dir );
		}
	}

	/**
	 * AJAX handler to purge all served static files.
	 *
	 * @since 1.3.0
	 */
	public function ajax_purge_serve() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$this->purge_all_serve();

		wp_send_json_success( array( 'message' => __( 'Served files purged successfully.', 'ultimate-performance' ) ) );
	}

	/**
	 * Count the number of HTML files in the serve directory.
	 *
	 * @since  1.3.0
	 * @return int
	 */
	private function get_serve_count() {
		$serve_dir = $this->get_serve_dir();
		$count     = 0;

		if ( ! is_dir( $serve_dir ) ) {
			return 0;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $serve_dir, RecursiveDirectoryIterator::SKIP_DOTS )
		);

		foreach ( $iterator as $file ) {
			if ( $file->isFile() && 'html' === pathinfo( $file->getFilename(), PATHINFO_EXTENSION ) ) {
				$count++;
			}
		}

		return $count;
	}
}
