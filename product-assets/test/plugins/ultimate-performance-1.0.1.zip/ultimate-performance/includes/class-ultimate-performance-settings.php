<?php
/**
 * Handles plugin settings, admin menu, and settings registration.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Settings
 *
 * Registers the admin menu, settings pages, and manages
 * all plugin settings with defaults and sanitization.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Settings {

	/**
	 * Option name in wp_options.
	 *
	 * @var string
	 */
	const OPTION_NAME = 'up_settings';

	/**
	 * Admin page hook suffixes for conditional asset loading.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $page_hooks = array();

	/**
	 * Initialize settings hooks.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_filter( 'plugin_action_links_' . UP_PLUGIN_BASENAME, array( $this, 'add_action_links' ) );
		add_action( 'wp_ajax_up_save_settings', array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_up_apply_preset', array( $this, 'ajax_apply_preset' ) );
	}

	/**
	 * Register the admin menu and submenu pages.
	 *
	 * @since 1.0.0
	 */
	public function register_menu() {
		$this->page_hooks[] = add_menu_page(
			__( 'Ultimate Performance', 'ultimate-performance' ),
			__( 'Ultimate Perf', 'ultimate-performance' ),
			'manage_options',
			'ultimate-performance',
			array( $this, 'render_dashboard_page' ),
			'dashicons-performance',
			80
		);

		$this->page_hooks[] = add_submenu_page(
			'ultimate-performance',
			__( 'Dashboard', 'ultimate-performance' ),
			__( 'Dashboard', 'ultimate-performance' ),
			'manage_options',
			'ultimate-performance',
			array( $this, 'render_dashboard_page' )
		);

		$this->page_hooks[] = add_submenu_page(
			'ultimate-performance',
			__( 'Presets', 'ultimate-performance' ),
			__( 'Presets', 'ultimate-performance' ),
			'manage_options',
			'ultimate-performance-presets',
			array( $this, 'render_presets_page' )
		);

		$this->page_hooks[] = add_submenu_page(
			'ultimate-performance',
			__( 'Optimize', 'ultimate-performance' ),
			__( 'Optimize', 'ultimate-performance' ),
			'manage_options',
			'ultimate-performance-settings',
			array( $this, 'render_settings_page' )
		);

		$this->page_hooks[] = add_submenu_page(
			'ultimate-performance',
			__( 'Speed Test', 'ultimate-performance' ),
			__( 'Speed Test', 'ultimate-performance' ),
			'manage_options',
			'ultimate-performance-speed-test',
			array( $this, 'render_speed_test_page' )
		);

		$this->page_hooks[] = add_submenu_page(
			'ultimate-performance',
			__( 'SEO', 'ultimate-performance' ),
			__( 'SEO', 'ultimate-performance' ),
			'manage_options',
			'ultimate-performance-seo',
			array( $this, 'render_seo_page' )
		);

		$this->page_hooks[] = add_submenu_page(
			'ultimate-performance',
			__( 'AI Assistant', 'ultimate-performance' ),
			__( 'AI Assistant', 'ultimate-performance' ),
			'manage_options',
			'ultimate-performance-ai',
			array( $this, 'render_ai_page' )
		);

		$this->page_hooks[] = add_submenu_page(
			'ultimate-performance',
			__( 'Static Site', 'ultimate-performance' ),
			__( 'Static Site', 'ultimate-performance' ),
			'manage_options',
			'ultimate-performance-static-site',
			array( $this, 'render_static_site_page' )
		);

	}

	/**
	 * Register settings with WordPress Settings API.
	 *
	 * @since 1.0.0
	 */
	public function register_settings() {
		register_setting(
			'up_settings_group',
			self::OPTION_NAME,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize_settings' ),
				'default'           => self::get_defaults(),
			)
		);
	}

	/**
	 * Add Settings link to the Plugins page.
	 *
	 * @since  1.0.0
	 * @param  array $links Existing plugin action links.
	 * @return array Modified links.
	 */
	public function add_action_links( $links ) {
		$settings_link = sprintf(
			'<a href="%s">%s</a>',
			esc_url( admin_url( 'admin.php?page=ultimate-performance-settings' ) ),
			esc_html__( 'Settings', 'ultimate-performance' )
		);
		array_unshift( $links, $settings_link );
		return $links;
	}

	/**
	 * Render the dashboard page.
	 *
	 * @since 1.0.0
	 */
	public function render_dashboard_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include UP_PLUGIN_DIR . 'admin/partials/dashboard-tab.php';
	}

	/**
	 * Render the Optimization Presets page.
	 *
	 * @since 1.1.0
	 */
	public function render_presets_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include UP_PLUGIN_DIR . 'admin/partials/presets-page.php';
	}

	/**
	 * Render the tabbed settings page.
	 *
	 * @since 1.0.0
	 */
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include UP_PLUGIN_DIR . 'admin/partials/settings-page.php';
	}


	/**
	 * Render the Static Site generator page.
	 *
	 * @since 1.2.0
	 */
	public function render_static_site_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include UP_PLUGIN_DIR . 'admin/partials/static-site-page.php';
	}

	/**
	 * Render the Speed Test dedicated page.
	 *
	 * @since 1.2.0
	 */
	public function render_speed_test_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include UP_PLUGIN_DIR . 'admin/partials/speed-test-page.php';
	}

	/**
	 * Render the SEO dedicated page.
	 *
	 * @since 1.3.0
	 */
	public function render_seo_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include UP_PLUGIN_DIR . 'admin/partials/seo-page.php';
	}

	/**
	 * Render the AI Assistant dedicated page.
	 *
	 * @since 1.4.0
	 */
	public function render_ai_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include UP_PLUGIN_DIR . 'admin/partials/ai-page.php';
	}

	/**
	 * AJAX handler for saving settings.
	 *
	 * @since 1.0.0
	 */
	public function ajax_save_settings() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$settings = get_option( self::OPTION_NAME, self::get_defaults() );

		if ( isset( $_POST['module'] ) && isset( $_POST['settings'] ) ) {
			$module      = sanitize_key( wp_unslash( $_POST['module'] ) );
			$raw_settings = map_deep( wp_unslash( $_POST['settings'] ), 'sanitize_text_field' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized via map_deep.

			if ( ! is_array( $raw_settings ) ) {
				wp_send_json_error( array( 'message' => __( 'Invalid settings data.', 'ultimate-performance' ) ), 400 );
			}

			$defaults = self::get_defaults();
			if ( ! isset( $defaults[ $module ] ) ) {
				wp_send_json_error( array( 'message' => __( 'Unknown module.', 'ultimate-performance' ) ), 400 );
			}

			$sanitized = self::sanitize_module_settings( $module, $raw_settings );

			// Preserve existing API keys when the sentinel value '__KEEP__' is sent.
			$api_key_fields = array( 'api_key', 'openai_api_key', 'gemini_api_key', 'anthropic_api_key', 'cloudflare_api_key', 'bunnycdn_api_key' );
			$existing_module = isset( $settings[ $module ] ) ? $settings[ $module ] : array();
			foreach ( $api_key_fields as $key_field ) {
				if ( isset( $raw_settings[ $key_field ] ) && '__KEEP__' === $raw_settings[ $key_field ] && isset( $existing_module[ $key_field ] ) ) {
					$sanitized[ $key_field ] = $existing_module[ $key_field ];
				}
			}

			$settings[ $module ] = $sanitized;

			update_option( self::OPTION_NAME, $settings );

			wp_send_json_success( array( 'message' => __( 'Settings saved.', 'ultimate-performance' ) ) );
		}

		wp_send_json_error( array( 'message' => __( 'Missing parameters.', 'ultimate-performance' ) ), 400 );
	}

	/**
	 * AJAX handler for applying an optimization preset.
	 *
	 * Merges preset settings into the current settings, preserving
	 * text fields, API keys, URLs, and exclusion lists.
	 *
	 * @since 1.1.0
	 */
	public function ajax_apply_preset() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$preset_key = isset( $_POST['preset'] ) ? sanitize_key( wp_unslash( $_POST['preset'] ) ) : '';
		$presets    = self::get_presets();

		if ( ! isset( $presets[ $preset_key ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown preset.', 'ultimate-performance' ) ), 400 );
		}

		$preset           = $presets[ $preset_key ];
		$current_settings = get_option( self::OPTION_NAME, self::get_defaults() );
		$defaults         = self::get_defaults();

		foreach ( $preset['settings'] as $module => $preset_values ) {
			if ( ! isset( $current_settings[ $module ] ) ) {
				$current_settings[ $module ] = isset( $defaults[ $module ] ) ? $defaults[ $module ] : array();
			}
			foreach ( $preset_values as $key => $value ) {
				$current_settings[ $module ][ $key ] = $value;
			}
		}

		// Sanitize each module's settings before saving.
		foreach ( $current_settings as $mod => $mod_settings ) {
			if ( is_array( $mod_settings ) ) {
				$current_settings[ $mod ] = self::sanitize_module_settings( $mod, $mod_settings );
			}
		}

		update_option( self::OPTION_NAME, $current_settings );

		wp_send_json_success( array(
			'message' => sprintf(
				/* translators: %s: preset name */
				__( '%s preset applied successfully.', 'ultimate-performance' ),
				$preset['label']
			),
		) );
	}

	/**
	 * Sanitize the full settings array.
	 *
	 * @since  1.0.0
	 * @param  mixed $input Raw settings input.
	 * @return array Sanitized settings.
	 */
	public function sanitize_settings( $input ) {
		if ( ! is_array( $input ) ) {
			return self::get_defaults();
		}

		$sanitized = array();
		$defaults  = self::get_defaults();

		foreach ( $defaults as $module => $module_defaults ) {
			if ( isset( $input[ $module ] ) && is_array( $input[ $module ] ) ) {
				$sanitized[ $module ] = self::sanitize_module_settings( $module, $input[ $module ] );
			} else {
				$sanitized[ $module ] = $module_defaults;
			}
		}

		return $sanitized;
	}

	/**
	 * Sanitize settings for a specific module.
	 *
	 * @since  1.0.0
	 * @param  string $module   Module key.
	 * @param  array  $settings Raw module settings.
	 * @return array  Sanitized module settings.
	 */
	public static function sanitize_module_settings( $module, $settings ) {
		$defaults  = self::get_defaults();
		$sanitized = array();

		if ( ! isset( $defaults[ $module ] ) ) {
			return array();
		}

		$textarea_keys = array(
			'dns_prefetch', 'preconnect', 'preload_urls',
			'exclude_minify_css', 'exclude_minify_js',
			'exclude_async_css', 'exclude_defer_js', 'exclude_delay_js',
			'exclude_urls', 'exclude_cookies',
			'lazy_load_exclusions',
			'exclusion_patterns',
			'global_disabled_scripts',
			'global_disabled_styles',
			'permissions_policy',
			'additional_urls',
			'include_types',
			'serve_exclude_urls',
			'ucss_safelist', 'ucss_exclude_urls', 'ucss_exclude_handles',
		);

		$url_keys = array(
			'base_url',
			'schema_org_logo',
			'default_og_image',
		);

		$enum_keys = array(
			'delivery_method'       => array( 'zip', 'local_dir' ),
			'url_style'             => array( 'relative', 'offline', 'absolute' ),
			'active_provider'       => array( 'openai', 'gemini', 'anthropic' ),
			'ucss_generation_method' => array( 'php', 'api' ),
		);

		$clamped_int_keys = array(
			'batch_size' => array( 'min' => 10, 'max' => 200 ),
		);

		// Keys that intentionally contain raw HTML/script — only admins can save settings.
		$raw_script_keys = array(
			'custom_head_scripts',
			'custom_body_scripts',
			'custom_footer_scripts',
		);

		foreach ( $defaults[ $module ] as $key => $default_value ) {
			if ( ! isset( $settings[ $key ] ) ) {
				$sanitized[ $key ] = $default_value;
				continue;
			}

			if ( isset( $enum_keys[ $key ] ) ) {
				$value = sanitize_text_field( $settings[ $key ] );
				$sanitized[ $key ] = in_array( $value, $enum_keys[ $key ], true ) ? $value : $default_value;
			} elseif ( in_array( $key, $url_keys, true ) ) {
				$sanitized[ $key ] = esc_url_raw( $settings[ $key ] );
			} elseif ( isset( $clamped_int_keys[ $key ] ) ) {
				$val = absint( $settings[ $key ] );
				$sanitized[ $key ] = max( $clamped_int_keys[ $key ]['min'], min( $clamped_int_keys[ $key ]['max'], $val ) );
			} elseif ( is_bool( $default_value ) ) {
				$sanitized[ $key ] = filter_var( $settings[ $key ], FILTER_VALIDATE_BOOLEAN );
			} elseif ( is_int( $default_value ) ) {
				$sanitized[ $key ] = absint( $settings[ $key ] );
			} elseif ( in_array( $key, $raw_script_keys, true ) ) {
				// Preserve raw script content — capability checks enforce admin-only access.
				$sanitized[ $key ] = current_user_can( 'unfiltered_html' )
					? trim( $settings[ $key ] )
					: sanitize_textarea_field( $settings[ $key ] );
			} elseif ( in_array( $key, $textarea_keys, true ) ) {
				$sanitized[ $key ] = sanitize_textarea_field( $settings[ $key ] );
			} else {
				$sanitized[ $key ] = sanitize_text_field( $settings[ $key ] );
			}
		}

		return $sanitized;
	}

	/**
	 * Get a specific module's settings.
	 *
	 * @since  1.0.0
	 * @param  string $module Module key.
	 * @return array  Module settings merged with defaults.
	 */
	public static function get_module_settings( $module ) {
		$settings = get_option( self::OPTION_NAME, self::get_defaults() );
		$defaults = self::get_defaults();

		if ( isset( $settings[ $module ] ) ) {
			return wp_parse_args( $settings[ $module ], $defaults[ $module ] ?? array() );
		}

		return $defaults[ $module ] ?? array();
	}

	/**
	 * Check if a module is enabled.
	 *
	 * @since  1.0.0
	 * @param  string $module Module key.
	 * @return bool
	 */
	public static function is_module_enabled( $module ) {
		$module_settings = self::get_module_settings( $module );
		return ! empty( $module_settings['enabled'] );
	}

	/**
	 * Get all default settings for every module.
	 *
	 * @since  1.0.0
	 * @return array Complete default settings.
	 */
	public static function get_defaults() {
		return array(
			'bloat_removal'      => array(
				'enabled'                 => false,
				'disable_emojis'          => false,
				'disable_embeds'          => false,
				'disable_xmlrpc'          => false,
				'remove_dashicons'        => false,
				'remove_jquery_migrate'   => false,
				'disable_rest_api_links'  => false,
				'disable_rss_feeds'       => false,
				'remove_wlw_manifest'     => false,
				'remove_shortlinks'       => false,
				'remove_rsd_link'         => false,
				'remove_wp_version'       => false,
				'disable_self_pingbacks'  => false,
				'heartbeat_frontend'      => 'default',
				'heartbeat_admin'         => 'default',
				'heartbeat_editor'        => 'default',
				'disable_global_styles'   => false,
				'remove_comment_reply_js' => false,
				'disable_login_language'  => false,
			),
			'database'           => array(
				'enabled'           => false,
				'schedule'          => 'disabled',
				'revisions_keep'    => 5,
				'clean_auto_drafts' => true,
				'clean_trashed'     => true,
				'clean_spam'        => true,
				'clean_transients'  => true,
				'optimize_tables'   => true,
				'clean_orphans'     => true,
			),
			'caching'            => array(
				'enabled'              => false,
				'page_cache'           => false,
				'browser_cache'        => false,
				'gzip_compression'     => false,
				'cache_lifespan'       => '1 year',
				'exclude_urls'         => '',
				'exclude_cookies'      => '',
				'purge_on_post_update' => true,
			),
			'css_js'             => array(
				'enabled'                => false,
				'minify_css'             => false,
				'minify_js'              => false,
				'minify_html'            => false,
				'async_css'              => false,
				'defer_js'               => false,
				'delay_js'               => false,
				'move_jquery_to_footer'  => false,
				'remove_query_strings'   => false,
				'exclude_minify_css'     => '',
				'exclude_minify_js'      => '',
				'exclude_async_css'      => '',
				'exclude_defer_js'       => '',
				'exclude_delay_js'       => '',
				'ucss_enabled'           => false,
				'ucss_critical_css'      => false,
				'ucss_cache_lifespan'    => 7,
				'ucss_safelist'          => '',
				'ucss_exclude_urls'      => '',
				'ucss_exclude_handles'   => '',
				'ucss_generation_method' => 'php',
			),
			'image_optimization' => array(
				'enabled'                 => false,
				'lazy_load_images'        => false,
				'lazy_load_iframes'       => false,
				'lazy_load_exclude_first' => 3,
				'lazy_load_exclusions'    => '',
				'add_missing_dimensions'  => false,
				'webp_conversion'         => false,
				'webp_quality'            => 80,
				'compression_enabled'     => false,
				'compression_quality'     => 82,
			),
			'webfonts'           => array(
				'enabled'            => false,
				'local_google_fonts' => false,
				'font_display_swap'  => false,
				'preload_fonts'      => false,
			),
			'preloading'         => array(
				'enabled'               => false,
				'dns_prefetch'          => '',
				'preconnect'            => '',
				'preload_urls'          => '',
				'instant_page'          => false,
				'speculation_rules'     => false,
				'speculation_eagerness' => 'moderate',
			),
			'cdn'                => array(
				'enabled'              => false,
				'cdn_provider'         => 'custom',
				'cdn_url'              => '',
				'included_extensions'  => '.css,.js,.jpg,.jpeg,.png,.gif,.webp,.avif,.woff,.woff2,.svg,.ico',
				'exclusion_patterns'   => '',
				'cloudflare_email'     => '',
				'cloudflare_api_key'   => '',
				'cloudflare_zone_id'   => '',
				'bunnycdn_api_key'     => '',
				'bunnycdn_pullzone_id' => '',
				'offload_media'        => false,
				'offload_provider'     => 's3',
				'offload_access_key'   => '',
				'offload_secret_key'   => '',
				'offload_bucket'       => '',
				'offload_region'       => 'us-east-1',
				'offload_endpoint'     => '',
				'offload_path_prefix'  => 'wp-content/uploads/',
				'offload_serve_url'    => '',
				'offload_remove_local' => false,
			),
			'third_party'        => array(
				'enabled'                  => false,
				'ga4_id'                   => '',
				'gtm_id'                   => '',
				'clarity_id'               => '',
				'meta_pixel_id'            => '',
				'custom_head_scripts'      => '',
				'custom_body_scripts'      => '',
				'custom_footer_scripts'    => '',
				'delay_third_party'        => false,
				'dns_prefetch_third_party' => false,
			),
			'script_manager'     => array(
				'enabled'                  => false,
				'global_disabled_scripts'  => '',
				'global_disabled_styles'   => '',
			),
			'speed_test'         => array(
				'enabled' => false,
				'api_key' => '',
			),
			'woocommerce'        => array(
				'enabled'                   => false,
				'disable_cart_fragments'    => false,
				'dequeue_wc_scripts'        => false,
				'disable_password_strength' => false,
				'disable_wc_widgets_css'    => false,
			),
			'security_headers'   => array(
				'enabled'                 => false,
				'x_content_type_options'  => true,
				'x_frame_options'         => 'SAMEORIGIN',
				'referrer_policy'         => 'strict-origin-when-cross-origin',
				'permissions_policy'      => '',
				'hsts_enabled'            => false,
				'hsts_max_age'            => 31536000,
				'hsts_include_subdomains' => false,
				'x_xss_protection'        => true,
			),
			'seo'                => array(
				'enabled'           => false,
				'meta_title'        => true,
				'meta_description'  => true,
				'og_tags'           => true,
				'twitter_cards'     => true,
				'twitter_site'      => '',
				'canonical_urls'    => true,
				'robots_meta'       => true,
				'noindex_search'    => true,
				'noindex_archives'  => false,
				'noindex_author'    => false,
				'schema_markup'     => true,
				'schema_org_name'   => '',
				'schema_org_logo'   => '',
				'default_og_image'  => '',
			),
			'ai'                 => array(
				'enabled'           => false,
				'active_provider'   => 'openai',
				'openai_api_key'    => '',
				'openai_model'      => 'gpt-4o-mini',
				'gemini_api_key'    => '',
				'gemini_model'      => 'gemini-2.0-flash',
				'anthropic_api_key' => '',
				'anthropic_model'   => 'claude-sonnet-4-20250514',
				'auto_analyze'      => false,
			),
			'static_site'        => array(
				'delivery_method'    => 'zip',
				'output_dir'         => '',
				'url_style'          => 'relative',
				'base_url'           => '',
				'include_types'      => 'posts,pages,archives,categories,tags,author_pages,custom_post_types,theme_assets,plugin_assets,uploads',
				'additional_urls'    => '',
				'exclude_urls'       => '',
				'batch_size'         => 50,
				'serve_enabled'      => false,
				'serve_logged_in'    => false,
				'serve_exclude_urls' => '',
			),
		);
	}

	/**
	 * Get the list of all modules with metadata for the UI.
	 *
	 * @since  1.0.0
	 * @return array Module definitions.
	 */
	public static function get_modules() {
		return array(
			'bloat_removal'      => array(
				'label'       => __( 'Bloat Removal', 'ultimate-performance' ),
				'description' => __( 'Remove unnecessary WordPress scripts, styles, and features.', 'ultimate-performance' ),
				'icon'        => 'dashicons-trash',
				'tab'         => 'bloat-removal',
			),
			'database'           => array(
				'label'       => __( 'Database', 'ultimate-performance' ),
				'description' => __( 'Clean up and optimize your WordPress database.', 'ultimate-performance' ),
				'icon'        => 'dashicons-database',
				'tab'         => 'database',
			),
			'caching'            => array(
				'label'       => __( 'Caching', 'ultimate-performance' ),
				'description' => __( 'Page cache, browser cache, and cache preloading.', 'ultimate-performance' ),
				'icon'        => 'dashicons-performance',
				'tab'         => 'caching',
			),
			'css_js'             => array(
				'label'       => __( 'CSS / JS', 'ultimate-performance' ),
				'description' => __( 'Minify, combine, defer, and optimize CSS/JS files.', 'ultimate-performance' ),
				'icon'        => 'dashicons-editor-code',
				'tab'         => 'css-js',
			),
			'image_optimization' => array(
				'label'       => __( 'Images', 'ultimate-performance' ),
				'description' => __( 'Compress images, convert to WebP/AVIF, and lazy load.', 'ultimate-performance' ),
				'icon'        => 'dashicons-format-image',
				'tab'         => 'images',
			),
			'webfonts'           => array(
				'label'       => __( 'Web Fonts', 'ultimate-performance' ),
				'description' => __( 'Optimize and locally host Google Fonts.', 'ultimate-performance' ),
				'icon'        => 'dashicons-editor-textcolor',
				'tab'         => 'webfonts',
			),
			'preloading'         => array(
				'label'       => __( 'Preloading', 'ultimate-performance' ),
				'description' => __( 'DNS prefetch, preconnect, and speculative loading.', 'ultimate-performance' ),
				'icon'        => 'dashicons-superhero',
				'tab'         => 'preloading',
			),
			'cdn'                => array(
				'label'       => __( 'CDN', 'ultimate-performance' ),
				'description' => __( 'CDN URL rewriting and Cloudflare integration.', 'ultimate-performance' ),
				'icon'        => 'dashicons-networking',
				'tab'         => 'cdn',
			),
			'third_party'        => array(
				'label'       => __( 'Third-Party Scripts', 'ultimate-performance' ),
				'description' => __( 'Manage GA4, Clarity, Meta Pixel, and custom scripts.', 'ultimate-performance' ),
				'icon'        => 'dashicons-admin-plugins',
				'tab'         => 'third-party',
			),
			'script_manager'     => array(
				'label'       => __( 'Script Manager', 'ultimate-performance' ),
				'description' => __( 'Disable scripts and styles per page.', 'ultimate-performance' ),
				'icon'        => 'dashicons-list-view',
				'tab'         => 'script-manager',
			),
			'woocommerce'        => array(
				'label'       => __( 'WooCommerce', 'ultimate-performance' ),
				'description' => __( 'WooCommerce-specific performance optimizations.', 'ultimate-performance' ),
				'icon'        => 'dashicons-cart',
				'tab'         => 'woocommerce',
			),
			'security_headers'   => array(
				'label'       => __( 'Security Headers', 'ultimate-performance' ),
				'description' => __( 'HTTP security response headers.', 'ultimate-performance' ),
				'icon'        => 'dashicons-shield',
				'tab'         => 'security-headers',
			),
		);
	}

	/**
	 * Determine which preset (if any) matches the current settings.
	 *
	 * Compares each preset's settings against the stored values.
	 * Returns the slug of the matching preset, or empty string if none match.
	 *
	 * @since  1.1.0
	 * @return string Preset slug or empty string.
	 */
	public static function get_active_preset() {
		$current  = get_option( self::OPTION_NAME, self::get_defaults() );
		$presets  = self::get_presets();

		foreach ( $presets as $slug => $preset ) {
			$match = true;

			foreach ( $preset['settings'] as $module => $preset_values ) {
				if ( ! isset( $current[ $module ] ) ) {
					$match = false;
					break;
				}

				foreach ( $preset_values as $key => $expected ) {
					$actual = isset( $current[ $module ][ $key ] ) ? $current[ $module ][ $key ] : null;

					// Normalise for comparison (bool / string / int).
					if ( is_bool( $expected ) ) {
						$actual = filter_var( $actual, FILTER_VALIDATE_BOOLEAN );
					} elseif ( is_int( $expected ) ) {
						$actual = (int) $actual;
					} else {
						$actual   = (string) $actual;
						$expected = (string) $expected;
					}

					if ( $actual !== $expected ) {
						$match = false;
						break 2;
					}
				}
			}

			if ( $match ) {
				return $slug;
			}
		}

		return '';
	}

	/**
	 * Get all optimization preset definitions.
	 *
	 * Each preset contains only boolean/enum settings. Text fields,
	 * API keys, URLs, and exclusion lists are never modified by presets.
	 *
	 * @since  1.1.0
	 * @return array Preset definitions keyed by slug.
	 */
	public static function get_presets() {
		return array(
			'safe'        => array(
				'label'       => __( 'Safe', 'ultimate-performance' ),
				'description' => __( 'Zero-risk settings safe for any WordPress site. No visual or functional changes.', 'ultimate-performance' ),
				'icon'        => 'dashicons-shield',
				'features'    => array(
					__( 'Remove WLW manifest, RSD & shortlinks', 'ultimate-performance' ),
					__( 'Disable WordPress emojis', 'ultimate-performance' ),
					__( 'Disable XML-RPC & self-pingbacks', 'ultimate-performance' ),
					__( 'Remove WordPress version number', 'ultimate-performance' ),
					__( 'Basic security headers', 'ultimate-performance' ),
					__( 'Remove REST API link tags', 'ultimate-performance' ),
				),
				'settings'    => array(
					'bloat_removal'    => array(
						'enabled'                 => true,
						'disable_emojis'          => true,
						'disable_embeds'          => false,
						'disable_xmlrpc'          => true,
						'remove_dashicons'        => false,
						'remove_jquery_migrate'   => false,
						'disable_rest_api_links'  => true,
						'disable_rss_feeds'       => false,
						'remove_wlw_manifest'     => true,
						'remove_shortlinks'       => true,
						'remove_rsd_link'         => true,
						'remove_wp_version'       => true,
						'disable_self_pingbacks'  => true,
						'disable_global_styles'   => false,
						'remove_comment_reply_js' => false,
						'disable_login_language'  => false,
						'heartbeat_frontend'      => 'default',
						'heartbeat_admin'         => 'default',
						'heartbeat_editor'        => 'default',
					),
					'database'         => array(
						'enabled' => false,
					),
					'caching'          => array(
						'enabled' => false,
					),
					'css_js'           => array(
						'enabled' => false,
					),
					'image_optimization' => array(
						'enabled' => false,
					),
					'webfonts'         => array(
						'enabled' => false,
					),
					'preloading'       => array(
						'enabled' => false,
					),
					'cdn'              => array(
						'enabled' => false,
					),
					'third_party'      => array(
						'enabled'                  => false,
						'delay_third_party'        => false,
						'dns_prefetch_third_party' => false,
					),
					'script_manager'   => array(
						'enabled' => false,
					),
					'speed_test'       => array(
						'enabled' => false,
					),
					'woocommerce'      => array(
						'enabled'                   => false,
						'disable_cart_fragments'    => false,
						'dequeue_wc_scripts'        => false,
						'disable_password_strength' => false,
						'disable_wc_widgets_css'    => false,
					),
					'security_headers' => array(
						'enabled'                 => true,
						'x_content_type_options'  => true,
						'x_frame_options'         => 'SAMEORIGIN',
						'referrer_policy'         => 'strict-origin-when-cross-origin',
						'hsts_enabled'            => false,
						'hsts_include_subdomains' => false,
						'x_xss_protection'        => true,
					),
					'seo'              => array(
						'enabled' => false,
					),
					'ai'               => array(
						'enabled' => false,
					),
				),
			),
			'basic'       => array(
				'label'       => __( 'Basic', 'ultimate-performance' ),
				'description' => __( 'Low-risk optimizations for beginners. Safe bloat removal plus lazy loading and browser caching.', 'ultimate-performance' ),
				'icon'        => 'dashicons-admin-generic',
				'features'    => array(
					__( 'Everything in Safe preset', 'ultimate-performance' ),
					__( 'Lazy load images & iframes', 'ultimate-performance' ),
					__( 'Browser caching & GZIP compression', 'ultimate-performance' ),
					__( 'Remove query strings from static assets', 'ultimate-performance' ),
					__( 'Font display swap for web fonts', 'ultimate-performance' ),
					__( 'Disable frontend Heartbeat API', 'ultimate-performance' ),
					__( 'Database cleanup scheduling (weekly)', 'ultimate-performance' ),
				),
				'settings'    => array(
					'bloat_removal'    => array(
						'enabled'                 => true,
						'disable_emojis'          => true,
						'disable_embeds'          => false,
						'disable_xmlrpc'          => true,
						'remove_dashicons'        => false,
						'remove_jquery_migrate'   => false,
						'disable_rest_api_links'  => true,
						'disable_rss_feeds'       => false,
						'remove_wlw_manifest'     => true,
						'remove_shortlinks'       => true,
						'remove_rsd_link'         => true,
						'remove_wp_version'       => true,
						'disable_self_pingbacks'  => true,
						'disable_global_styles'   => false,
						'remove_comment_reply_js' => false,
						'disable_login_language'  => false,
						'heartbeat_frontend'      => 'disable',
						'heartbeat_admin'         => 'default',
						'heartbeat_editor'        => 'default',
					),
					'database'         => array(
						'enabled'           => true,
						'schedule'          => 'weekly',
						'revisions_keep'    => 5,
						'clean_auto_drafts' => true,
						'clean_trashed'     => true,
						'clean_spam'        => true,
						'clean_transients'  => true,
						'optimize_tables'   => true,
						'clean_orphans'     => true,
					),
					'caching'          => array(
						'enabled'              => true,
						'page_cache'           => false,
						'browser_cache'        => true,
						'gzip_compression'     => true,
						'purge_on_post_update' => true,
					),
					'css_js'           => array(
						'enabled'               => true,
						'minify_css'            => false,
						'minify_js'             => false,
						'minify_html'           => false,
						'async_css'             => false,
						'defer_js'              => false,
						'delay_js'              => false,
						'move_jquery_to_footer' => false,
						'remove_query_strings'  => true,
					),
					'image_optimization' => array(
						'enabled'                 => true,
						'lazy_load_images'        => true,
						'lazy_load_iframes'       => true,
						'lazy_load_exclude_first' => 3,
						'add_missing_dimensions'  => false,
						'webp_conversion'         => false,
						'compression_enabled'     => false,
					),
					'webfonts'         => array(
						'enabled'            => true,
						'local_google_fonts' => false,
						'font_display_swap'  => true,
						'preload_fonts'      => false,
					),
					'preloading'       => array(
						'enabled'           => false,
						'instant_page'      => false,
						'speculation_rules' => false,
					),
					'cdn'              => array(
						'enabled' => false,
					),
					'third_party'      => array(
						'enabled'                  => false,
						'delay_third_party'        => false,
						'dns_prefetch_third_party' => false,
					),
					'script_manager'   => array(
						'enabled' => false,
					),
					'speed_test'       => array(
						'enabled' => false,
					),
					'woocommerce'      => array(
						'enabled'                   => false,
						'disable_cart_fragments'    => false,
						'dequeue_wc_scripts'        => false,
						'disable_password_strength' => false,
						'disable_wc_widgets_css'    => false,
					),
					'security_headers' => array(
						'enabled'                 => true,
						'x_content_type_options'  => true,
						'x_frame_options'         => 'SAMEORIGIN',
						'referrer_policy'         => 'strict-origin-when-cross-origin',
						'hsts_enabled'            => false,
						'hsts_include_subdomains' => false,
						'x_xss_protection'        => true,
					),
					'seo'              => array(
						'enabled' => false,
					),
					'ai'               => array(
						'enabled' => false,
					),
				),
			),
			'recommended' => array(
				'label'       => __( 'Recommended', 'ultimate-performance' ),
				'description' => __( 'The best balance of performance and compatibility. Ideal for most WordPress sites.', 'ultimate-performance' ),
				'icon'        => 'dashicons-star-filled',
				'features'    => array(
					__( 'Everything in Basic preset', 'ultimate-performance' ),
					__( 'Full page caching', 'ultimate-performance' ),
					__( 'Minify CSS, JS & HTML', 'ultimate-performance' ),
					__( 'Defer JavaScript loading', 'ultimate-performance' ),
					__( 'Local Google Fonts with preloading', 'ultimate-performance' ),
					__( 'Instant page prefetch on hover', 'ultimate-performance' ),
					__( 'Add missing image dimensions', 'ultimate-performance' ),
					__( 'Throttle admin Heartbeat to 60s', 'ultimate-performance' ),
				),
				'settings'    => array(
					'bloat_removal'    => array(
						'enabled'                 => true,
						'disable_emojis'          => true,
						'disable_embeds'          => true,
						'disable_xmlrpc'          => true,
						'remove_dashicons'        => true,
						'remove_jquery_migrate'   => false,
						'disable_rest_api_links'  => true,
						'disable_rss_feeds'       => false,
						'remove_wlw_manifest'     => true,
						'remove_shortlinks'       => true,
						'remove_rsd_link'         => true,
						'remove_wp_version'       => true,
						'disable_self_pingbacks'  => true,
						'disable_global_styles'   => false,
						'remove_comment_reply_js' => true,
						'disable_login_language'  => true,
						'heartbeat_frontend'      => 'disable',
						'heartbeat_admin'         => '60',
						'heartbeat_editor'        => 'default',
					),
					'database'         => array(
						'enabled'           => true,
						'schedule'          => 'weekly',
						'revisions_keep'    => 5,
						'clean_auto_drafts' => true,
						'clean_trashed'     => true,
						'clean_spam'        => true,
						'clean_transients'  => true,
						'optimize_tables'   => true,
						'clean_orphans'     => true,
					),
					'caching'          => array(
						'enabled'              => true,
						'page_cache'           => true,
						'browser_cache'        => true,
						'gzip_compression'     => true,
						'purge_on_post_update' => true,
					),
					'css_js'           => array(
						'enabled'               => true,
						'minify_css'            => true,
						'minify_js'             => true,
						'minify_html'           => true,
						'async_css'             => false,
						'defer_js'              => true,
						'delay_js'              => false,
						'move_jquery_to_footer' => true,
						'remove_query_strings'  => true,
					),
					'image_optimization' => array(
						'enabled'                 => true,
						'lazy_load_images'        => true,
						'lazy_load_iframes'       => true,
						'lazy_load_exclude_first' => 3,
						'add_missing_dimensions'  => true,
						'webp_conversion'         => true,
						'compression_enabled'     => false,
					),
					'webfonts'         => array(
						'enabled'            => true,
						'local_google_fonts' => true,
						'font_display_swap'  => true,
						'preload_fonts'      => true,
					),
					'preloading'       => array(
						'enabled'               => true,
						'instant_page'          => true,
						'speculation_rules'     => false,
						'speculation_eagerness' => 'moderate',
					),
					'cdn'              => array(
						'enabled' => false,
					),
					'third_party'      => array(
						'enabled'                  => false,
						'delay_third_party'        => false,
						'dns_prefetch_third_party' => true,
					),
					'script_manager'   => array(
						'enabled' => true,
					),
					'speed_test'       => array(
						'enabled' => true,
					),
					'woocommerce'      => array(
						'enabled'                   => true,
						'disable_cart_fragments'    => true,
						'dequeue_wc_scripts'        => false,
						'disable_password_strength' => false,
						'disable_wc_widgets_css'    => false,
					),
					'security_headers' => array(
						'enabled'                 => true,
						'x_content_type_options'  => true,
						'x_frame_options'         => 'SAMEORIGIN',
						'referrer_policy'         => 'strict-origin-when-cross-origin',
						'hsts_enabled'            => false,
						'hsts_include_subdomains' => false,
						'x_xss_protection'        => true,
					),
					'seo'              => array(
						'enabled'          => true,
						'meta_title'       => true,
						'meta_description' => true,
						'og_tags'          => true,
						'twitter_cards'    => true,
						'canonical_urls'   => true,
						'robots_meta'      => true,
						'noindex_search'   => true,
						'noindex_archives' => false,
						'noindex_author'   => false,
						'schema_markup'    => true,
					),
					'ai'               => array(
						'enabled' => false,
					),
				),
			),
			'aggressive'  => array(
				'label'       => __( 'Aggressive', 'ultimate-performance' ),
				'description' => __( 'High performance for experienced users. May require adding exclusions for compatibility.', 'ultimate-performance' ),
				'icon'        => 'dashicons-performance',
				'features'    => array(
					__( 'Everything in Recommended preset', 'ultimate-performance' ),
					__( 'Async CSS loading (render-blocking removal)', 'ultimate-performance' ),
					__( 'Delay JavaScript execution', 'ultimate-performance' ),
					__( 'WebP image conversion', 'ultimate-performance' ),
					__( 'Image compression enabled', 'ultimate-performance' ),
					__( 'Speculation rules prefetching', 'ultimate-performance' ),
					__( 'WooCommerce script dequeuing', 'ultimate-performance' ),
					__( 'Delay third-party scripts', 'ultimate-performance' ),
				),
				'settings'    => array(
					'bloat_removal'    => array(
						'enabled'                 => true,
						'disable_emojis'          => true,
						'disable_embeds'          => true,
						'disable_xmlrpc'          => true,
						'remove_dashicons'        => true,
						'remove_jquery_migrate'   => true,
						'disable_rest_api_links'  => true,
						'disable_rss_feeds'       => false,
						'remove_wlw_manifest'     => true,
						'remove_shortlinks'       => true,
						'remove_rsd_link'         => true,
						'remove_wp_version'       => true,
						'disable_self_pingbacks'  => true,
						'disable_global_styles'   => true,
						'remove_comment_reply_js' => true,
						'disable_login_language'  => true,
						'heartbeat_frontend'      => 'disable',
						'heartbeat_admin'         => '60',
						'heartbeat_editor'        => '30',
					),
					'database'         => array(
						'enabled'           => true,
						'schedule'          => 'daily',
						'revisions_keep'    => 3,
						'clean_auto_drafts' => true,
						'clean_trashed'     => true,
						'clean_spam'        => true,
						'clean_transients'  => true,
						'optimize_tables'   => true,
						'clean_orphans'     => true,
					),
					'caching'          => array(
						'enabled'              => true,
						'page_cache'           => true,
						'browser_cache'        => true,
						'gzip_compression'     => true,
						'purge_on_post_update' => true,
					),
					'css_js'           => array(
						'enabled'               => true,
						'minify_css'            => true,
						'minify_js'             => true,
						'minify_html'           => true,
						'async_css'             => true,
						'defer_js'              => true,
						'delay_js'              => true,
						'move_jquery_to_footer' => true,
						'remove_query_strings'  => true,
					),
					'image_optimization' => array(
						'enabled'                 => true,
						'lazy_load_images'        => true,
						'lazy_load_iframes'       => true,
						'lazy_load_exclude_first' => 3,
						'add_missing_dimensions'  => true,
						'webp_conversion'         => true,
						'webp_quality'            => 80,
						'compression_enabled'     => true,
						'compression_quality'     => 82,
					),
					'webfonts'         => array(
						'enabled'            => true,
						'local_google_fonts' => true,
						'font_display_swap'  => true,
						'preload_fonts'      => true,
					),
					'preloading'       => array(
						'enabled'               => true,
						'instant_page'          => true,
						'speculation_rules'     => true,
						'speculation_eagerness' => 'moderate',
					),
					'cdn'              => array(
						'enabled' => false,
					),
					'third_party'      => array(
						'enabled'                  => false,
						'delay_third_party'        => true,
						'dns_prefetch_third_party' => true,
					),
					'script_manager'   => array(
						'enabled' => true,
					),
					'speed_test'       => array(
						'enabled' => true,
					),
					'woocommerce'      => array(
						'enabled'                   => true,
						'disable_cart_fragments'    => true,
						'dequeue_wc_scripts'        => true,
						'disable_password_strength' => false,
						'disable_wc_widgets_css'    => true,
					),
					'security_headers' => array(
						'enabled'                 => true,
						'x_content_type_options'  => true,
						'x_frame_options'         => 'SAMEORIGIN',
						'referrer_policy'         => 'strict-origin-when-cross-origin',
						'hsts_enabled'            => true,
						'hsts_max_age'            => 31536000,
						'hsts_include_subdomains' => false,
						'x_xss_protection'        => true,
					),
					'seo'              => array(
						'enabled'          => true,
						'meta_title'       => true,
						'meta_description' => true,
						'og_tags'          => true,
						'twitter_cards'    => true,
						'canonical_urls'   => true,
						'robots_meta'      => true,
						'noindex_search'   => true,
						'noindex_archives' => true,
						'noindex_author'   => true,
						'schema_markup'    => true,
					),
					'ai'               => array(
						'enabled' => false,
					),
				),
			),
			'maximum'     => array(
				'label'       => __( 'Maximum', 'ultimate-performance' ),
				'description' => __( 'Every optimization enabled. Requires thorough testing and exclusion configuration.', 'ultimate-performance' ),
				'icon'        => 'dashicons-superhero',
				'features'    => array(
					__( 'Everything in Aggressive preset', 'ultimate-performance' ),
					__( 'Disable RSS feeds', 'ultimate-performance' ),
					__( 'Remove jQuery Migrate', 'ultimate-performance' ),
					__( 'Eager speculation rules prefetching', 'ultimate-performance' ),
					__( 'HSTS with subdomains', 'ultimate-performance' ),
					__( 'Disable WooCommerce password strength', 'ultimate-performance' ),
					__( 'Maximum image compression (quality: 75)', 'ultimate-performance' ),
				),
				'settings'    => array(
					'bloat_removal'    => array(
						'enabled'                 => true,
						'disable_emojis'          => true,
						'disable_embeds'          => true,
						'disable_xmlrpc'          => true,
						'remove_dashicons'        => true,
						'remove_jquery_migrate'   => true,
						'disable_rest_api_links'  => true,
						'disable_rss_feeds'       => true,
						'remove_wlw_manifest'     => true,
						'remove_shortlinks'       => true,
						'remove_rsd_link'         => true,
						'remove_wp_version'       => true,
						'disable_self_pingbacks'  => true,
						'disable_global_styles'   => true,
						'remove_comment_reply_js' => true,
						'disable_login_language'  => true,
						'heartbeat_frontend'      => 'disable',
						'heartbeat_admin'         => '60',
						'heartbeat_editor'        => '15',
					),
					'database'         => array(
						'enabled'           => true,
						'schedule'          => 'daily',
						'revisions_keep'    => 2,
						'clean_auto_drafts' => true,
						'clean_trashed'     => true,
						'clean_spam'        => true,
						'clean_transients'  => true,
						'optimize_tables'   => true,
						'clean_orphans'     => true,
					),
					'caching'          => array(
						'enabled'              => true,
						'page_cache'           => true,
						'browser_cache'        => true,
						'gzip_compression'     => true,
						'purge_on_post_update' => true,
					),
					'css_js'           => array(
						'enabled'               => true,
						'minify_css'            => true,
						'minify_js'             => true,
						'minify_html'           => true,
						'async_css'             => true,
						'defer_js'              => true,
						'delay_js'              => true,
						'move_jquery_to_footer' => true,
						'remove_query_strings'  => true,
					),
					'image_optimization' => array(
						'enabled'                 => true,
						'lazy_load_images'        => true,
						'lazy_load_iframes'       => true,
						'lazy_load_exclude_first' => 2,
						'add_missing_dimensions'  => true,
						'webp_conversion'         => true,
						'webp_quality'            => 75,
						'compression_enabled'     => true,
						'compression_quality'     => 75,
					),
					'webfonts'         => array(
						'enabled'            => true,
						'local_google_fonts' => true,
						'font_display_swap'  => true,
						'preload_fonts'      => true,
					),
					'preloading'       => array(
						'enabled'               => true,
						'instant_page'          => true,
						'speculation_rules'     => true,
						'speculation_eagerness' => 'eager',
					),
					'cdn'              => array(
						'enabled' => false,
					),
					'third_party'      => array(
						'enabled'                  => false,
						'delay_third_party'        => true,
						'dns_prefetch_third_party' => true,
					),
					'script_manager'   => array(
						'enabled' => true,
					),
					'speed_test'       => array(
						'enabled' => true,
					),
					'woocommerce'      => array(
						'enabled'                   => true,
						'disable_cart_fragments'    => true,
						'dequeue_wc_scripts'        => true,
						'disable_password_strength' => true,
						'disable_wc_widgets_css'    => true,
					),
					'security_headers' => array(
						'enabled'                 => true,
						'x_content_type_options'  => true,
						'x_frame_options'         => 'SAMEORIGIN',
						'referrer_policy'         => 'strict-origin-when-cross-origin',
						'hsts_enabled'            => true,
						'hsts_max_age'            => 31536000,
						'hsts_include_subdomains' => true,
						'x_xss_protection'        => true,
					),
					'seo'              => array(
						'enabled'          => true,
						'meta_title'       => true,
						'meta_description' => true,
						'og_tags'          => true,
						'twitter_cards'    => true,
						'canonical_urls'   => true,
						'robots_meta'      => true,
						'noindex_search'   => true,
						'noindex_archives' => true,
						'noindex_author'   => true,
						'schema_markup'    => true,
					),
					'ai'               => array(
						'enabled' => false,
					),
				),
			),
		);
	}
}
