<?php
/**
 * Basic SEO module.
 *
 * Handles meta titles, descriptions, Open Graph, Twitter Cards,
 * canonical URLs, robots meta, and JSON-LD schema markup.
 *
 * All output is fully disabled when the module is off or when
 * a third-party SEO plugin is detected — preventing conflicts.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Seo
 *
 * @since 1.3.0
 */
class Ultimate_Performance_Seo {

	/**
	 * Module settings.
	 *
	 * @since 1.3.0
	 * @var   array
	 */
	private $settings = array();

	/**
	 * Detected conflicting SEO plugin name, or false.
	 *
	 * @since 1.3.0
	 * @var   string|false
	 */
	private $conflict = false;

	/**
	 * Known SEO plugins that conflict with this module.
	 *
	 * @since 1.3.0
	 * @var   array
	 */
	private static $seo_plugins = array(
		'wordpress-seo/wp-seo.php'                       => 'Yoast SEO',
		'wordpress-seo-premium/wp-seo-premium.php'       => 'Yoast SEO Premium',
		'seo-by-rank-math/rank-math.php'                 => 'Rank Math',
		'all-in-one-seo-pack/all_in_one_seo_pack.php'    => 'All in One SEO',
		'wp-seopress/seopress.php'                       => 'SEOPress',
		'autodescription/autodescription.php'             => 'The SEO Framework',
		'slim-seo/slim-seo.php'                          => 'Slim SEO',
	);

	/**
	 * Initialize module hooks.
	 *
	 * @since 1.3.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'seo' );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		$this->conflict = $this->detect_seo_conflict();

		// Show admin notice when conflict detected.
		if ( $this->conflict ) {
			add_action( 'admin_notices', array( $this, 'render_conflict_notice' ) );
			return; // Do not register any frontend hooks.
		}

		// Meta box (admin only).
		if ( is_admin() ) {
			add_action( 'add_meta_boxes', array( $this, 'register_meta_box' ) );
			add_action( 'save_post', array( $this, 'save_meta_box' ), 10, 2 );
			return;
		}

		// Frontend hooks.
		if ( ! empty( $this->settings['meta_title'] ) ) {
			add_theme_support( 'title-tag' );
			add_filter( 'document_title_parts', array( $this, 'filter_title_parts' ), 20 );
		}

		if ( ! empty( $this->settings['meta_description'] ) ) {
			add_action( 'wp_head', array( $this, 'output_meta_description' ), 1 );
		}

		if ( ! empty( $this->settings['canonical_urls'] ) ) {
			remove_action( 'wp_head', 'rel_canonical' );
			add_action( 'wp_head', array( $this, 'output_canonical' ), 1 );
		}

		if ( ! empty( $this->settings['robots_meta'] ) ) {
			add_action( 'wp_head', array( $this, 'output_robots_meta' ), 1 );
		}

		if ( ! empty( $this->settings['og_tags'] ) ) {
			add_action( 'wp_head', array( $this, 'output_og_tags' ), 2 );
		}

		if ( ! empty( $this->settings['twitter_cards'] ) ) {
			add_action( 'wp_head', array( $this, 'output_twitter_cards' ), 2 );
		}

		if ( ! empty( $this->settings['schema_markup'] ) ) {
			add_action( 'wp_head', array( $this, 'output_schema_markup' ), 3 );
		}
	}

	/**
	 * Detect active third-party SEO plugin.
	 *
	 * @since  1.3.0
	 * @return string|false Plugin name or false.
	 */
	private function detect_seo_conflict() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		foreach ( self::$seo_plugins as $path => $name ) {
			if ( is_plugin_active( $path ) ) {
				return $name;
			}
		}

		return false;
	}

	/**
	 * Render admin notice when an SEO plugin conflict is detected.
	 *
	 * Only shows on the SEO settings tab.
	 *
	 * @since 1.3.0
	 */
	public function render_conflict_notice() {
		$screen = get_current_screen();
		if ( ! $screen || false === strpos( $screen->id, 'ultimate-performance' ) ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			sprintf(
				/* translators: %s: SEO plugin name */
				esc_html__( 'Ultimate Performance Basic SEO is disabled because %s is active. Deactivate it to use our SEO features, or disable our SEO module to avoid conflicts.', 'ultimate-performance' ),
				'<strong>' . esc_html( $this->conflict ) . '</strong>'
			)
		);
	}

	// ------------------------------------------------------------------
	// Meta Title
	// ------------------------------------------------------------------

	/**
	 * Filter document title parts.
	 *
	 * @since  1.3.0
	 * @param  array $title_parts Title parts.
	 * @return array
	 */
	public function filter_title_parts( $title_parts ) {
		if ( is_singular() ) {
			$custom = get_post_meta( get_the_ID(), '_up_seo_title', true );
			if ( ! empty( $custom ) ) {
				$title_parts['title'] = $custom;
			}
		}

		return $title_parts;
	}

	// ------------------------------------------------------------------
	// Meta Description
	// ------------------------------------------------------------------

	/**
	 * Output meta description tag.
	 *
	 * @since 1.3.0
	 */
	public function output_meta_description() {
		$description = $this->get_description();
		if ( empty( $description ) ) {
			return;
		}

		printf(
			'<meta name="description" content="%s" />' . "\n",
			esc_attr( $description )
		);
	}

	/**
	 * Get the meta description for the current page.
	 *
	 * @since  1.3.0
	 * @return string
	 */
	private function get_description() {
		if ( is_singular() ) {
			$custom = get_post_meta( get_the_ID(), '_up_seo_description', true );
			if ( ! empty( $custom ) ) {
				return $this->truncate( $custom, 160 );
			}

			$post = get_post();
			if ( $post ) {
				if ( ! empty( $post->post_excerpt ) ) {
					return $this->truncate( wp_strip_all_tags( $post->post_excerpt ), 160 );
				}
				return $this->truncate( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 160 );
			}
		}

		if ( is_category() || is_tag() || is_tax() ) {
			$term_desc = term_description();
			if ( ! empty( $term_desc ) ) {
				return $this->truncate( wp_strip_all_tags( $term_desc ), 160 );
			}
		}

		if ( is_home() || is_front_page() ) {
			$tagline = get_bloginfo( 'description' );
			if ( ! empty( $tagline ) ) {
				return $this->truncate( $tagline, 160 );
			}
		}

		return '';
	}

	// ------------------------------------------------------------------
	// Canonical URL
	// ------------------------------------------------------------------

	/**
	 * Output canonical link tag.
	 *
	 * @since 1.3.0
	 */
	public function output_canonical() {
		$url = $this->get_canonical_url();
		if ( empty( $url ) ) {
			return;
		}

		printf( '<link rel="canonical" href="%s" />' . "\n", esc_url( $url ) );
	}

	/**
	 * Get canonical URL for the current page.
	 *
	 * @since  1.3.0
	 * @return string
	 */
	private function get_canonical_url() {
		if ( is_singular() ) {
			return wp_get_canonical_url();
		}

		if ( is_home() && ! is_front_page() ) {
			return get_permalink( get_option( 'page_for_posts' ) );
		}

		if ( is_front_page() ) {
			return home_url( '/' );
		}

		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( $term ) {
				return get_term_link( $term );
			}
		}

		if ( is_author() ) {
			return get_author_posts_url( get_queried_object_id() );
		}

		return '';
	}

	// ------------------------------------------------------------------
	// Robots Meta
	// ------------------------------------------------------------------

	/**
	 * Output robots meta tag.
	 *
	 * @since 1.3.0
	 */
	public function output_robots_meta() {
		$directives = array();

		// Per-post overrides.
		if ( is_singular() ) {
			$noindex  = get_post_meta( get_the_ID(), '_up_seo_noindex', true );
			$nofollow = get_post_meta( get_the_ID(), '_up_seo_nofollow', true );

			if ( ! empty( $noindex ) ) {
				$directives[] = 'noindex';
			}
			if ( ! empty( $nofollow ) ) {
				$directives[] = 'nofollow';
			}
		}

		// Global settings.
		if ( is_search() && ! empty( $this->settings['noindex_search'] ) ) {
			$directives[] = 'noindex';
		}

		if ( ! empty( $this->settings['noindex_archives'] ) && ( is_date() || is_category() || is_tag() || is_tax() ) ) {
			$directives[] = 'noindex';
		}

		if ( is_author() && ! empty( $this->settings['noindex_author'] ) ) {
			$directives[] = 'noindex';
		}

		$directives = array_unique( $directives );

		if ( empty( $directives ) ) {
			return;
		}

		printf(
			'<meta name="robots" content="%s" />' . "\n",
			esc_attr( implode( ', ', $directives ) )
		);
	}

	// ------------------------------------------------------------------
	// Open Graph
	// ------------------------------------------------------------------

	/**
	 * Output Open Graph meta tags.
	 *
	 * @since 1.3.0
	 */
	public function output_og_tags() {
		$tags = array();

		$tags['og:site_name'] = get_bloginfo( 'name' );
		$tags['og:locale']    = get_locale();

		if ( is_singular() ) {
			$post = get_post();

			$tags['og:type'] = ( 'post' === $post->post_type ) ? 'article' : 'website';
			$tags['og:url']  = get_permalink();

			// Title.
			$og_title = get_post_meta( get_the_ID(), '_up_seo_og_title', true );
			if ( empty( $og_title ) ) {
				$og_title = get_post_meta( get_the_ID(), '_up_seo_title', true );
			}
			if ( empty( $og_title ) ) {
				$og_title = get_the_title();
			}
			$tags['og:title'] = $og_title;

			// Description.
			$og_desc = get_post_meta( get_the_ID(), '_up_seo_og_description', true );
			if ( empty( $og_desc ) ) {
				$og_desc = $this->get_description();
			}
			if ( ! empty( $og_desc ) ) {
				$tags['og:description'] = $og_desc;
			}

			// Image.
			$og_image = get_post_meta( get_the_ID(), '_up_seo_og_image', true );
			if ( empty( $og_image ) && has_post_thumbnail() ) {
				$og_image = get_the_post_thumbnail_url( null, 'large' );
			}
			if ( empty( $og_image ) && ! empty( $this->settings['default_og_image'] ) ) {
				$og_image = $this->settings['default_og_image'];
			}
			if ( ! empty( $og_image ) ) {
				$tags['og:image'] = $og_image;
			}
		} else {
			$tags['og:type']  = 'website';
			$tags['og:url']   = home_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) ) );
			$tags['og:title'] = wp_get_document_title();

			$desc = $this->get_description();
			if ( ! empty( $desc ) ) {
				$tags['og:description'] = $desc;
			}

			if ( ! empty( $this->settings['default_og_image'] ) ) {
				$tags['og:image'] = $this->settings['default_og_image'];
			}
		}

		foreach ( $tags as $property => $content ) {
			if ( ! empty( $content ) ) {
				printf(
					'<meta property="%s" content="%s" />' . "\n",
					esc_attr( $property ),
					esc_attr( $content )
				);
			}
		}
	}

	// ------------------------------------------------------------------
	// Twitter Cards
	// ------------------------------------------------------------------

	/**
	 * Output Twitter Card meta tags.
	 *
	 * @since 1.3.0
	 */
	public function output_twitter_cards() {
		$tags = array();

		// Determine image first to choose card type.
		$image = '';
		if ( is_singular() ) {
			$image = get_post_meta( get_the_ID(), '_up_seo_og_image', true );
			if ( empty( $image ) && has_post_thumbnail() ) {
				$image = get_the_post_thumbnail_url( null, 'large' );
			}
		}
		if ( empty( $image ) && ! empty( $this->settings['default_og_image'] ) ) {
			$image = $this->settings['default_og_image'];
		}

		$tags['twitter:card'] = ! empty( $image ) ? 'summary_large_image' : 'summary';

		// Title.
		if ( is_singular() ) {
			$title = get_post_meta( get_the_ID(), '_up_seo_og_title', true );
			if ( empty( $title ) ) {
				$title = get_post_meta( get_the_ID(), '_up_seo_title', true );
			}
			if ( empty( $title ) ) {
				$title = get_the_title();
			}
		} else {
			$title = wp_get_document_title();
		}
		$tags['twitter:title'] = $title;

		// Description.
		$desc = '';
		if ( is_singular() ) {
			$desc = get_post_meta( get_the_ID(), '_up_seo_og_description', true );
		}
		if ( empty( $desc ) ) {
			$desc = $this->get_description();
		}
		if ( ! empty( $desc ) ) {
			$tags['twitter:description'] = $desc;
		}

		if ( ! empty( $image ) ) {
			$tags['twitter:image'] = $image;
		}

		if ( ! empty( $this->settings['twitter_site'] ) ) {
			$handle = $this->settings['twitter_site'];
			if ( 0 !== strpos( $handle, '@' ) ) {
				$handle = '@' . $handle;
			}
			$tags['twitter:site'] = $handle;
		}

		foreach ( $tags as $name => $content ) {
			if ( ! empty( $content ) ) {
				printf(
					'<meta name="%s" content="%s" />' . "\n",
					esc_attr( $name ),
					esc_attr( $content )
				);
			}
		}
	}

	// ------------------------------------------------------------------
	// JSON-LD Schema
	// ------------------------------------------------------------------

	/**
	 * Output JSON-LD structured data.
	 *
	 * @since 1.3.0
	 */
	public function output_schema_markup() {
		$schemas = array();

		// WebSite schema (homepage).
		if ( is_front_page() || is_home() ) {
			$website = array(
				'@type' => 'WebSite',
				'@id'   => home_url( '/#website' ),
				'url'   => home_url( '/' ),
				'name'  => get_bloginfo( 'name' ),
			);

			$tagline = get_bloginfo( 'description' );
			if ( ! empty( $tagline ) ) {
				$website['description'] = $tagline;
			}

			// Sitelinks search box.
			$website['potentialAction'] = array(
				'@type'       => 'SearchAction',
				'target'      => array(
					'@type'        => 'EntryPoint',
					'urlTemplate'  => home_url( '/?s={search_term_string}' ),
				),
				'query-input' => 'required name=search_term_string',
			);

			$schemas[] = $website;
		}

		// Organization schema.
		$org_name = ! empty( $this->settings['schema_org_name'] )
			? $this->settings['schema_org_name']
			: get_bloginfo( 'name' );

		$organization = array(
			'@type' => 'Organization',
			'@id'   => home_url( '/#organization' ),
			'name'  => $org_name,
			'url'   => home_url( '/' ),
		);

		if ( ! empty( $this->settings['schema_org_logo'] ) ) {
			$organization['logo'] = array(
				'@type' => 'ImageObject',
				'url'   => $this->settings['schema_org_logo'],
			);
		}

		$schemas[] = $organization;

		// Article schema (single posts).
		if ( is_singular( 'post' ) ) {
			$post = get_post();

			$article = array(
				'@type'         => 'Article',
				'@id'           => get_permalink() . '#article',
				'headline'      => get_the_title(),
				'datePublished' => get_the_date( 'c' ),
				'dateModified'  => get_the_modified_date( 'c' ),
				'mainEntityOfPage' => array(
					'@type' => 'WebPage',
					'@id'   => get_permalink(),
				),
				'author'        => array(
					'@type' => 'Person',
					'name'  => get_the_author(),
				),
				'publisher'     => array(
					'@type' => 'Organization',
					'name'  => $org_name,
				),
			);

			if ( ! empty( $this->settings['schema_org_logo'] ) ) {
				$article['publisher']['logo'] = array(
					'@type' => 'ImageObject',
					'url'   => $this->settings['schema_org_logo'],
				);
			}

			if ( has_post_thumbnail() ) {
				$article['image'] = get_the_post_thumbnail_url( null, 'large' );
			}

			$desc = $this->get_description();
			if ( ! empty( $desc ) ) {
				$article['description'] = $desc;
			}

			$schemas[] = $article;
		}

		// BreadcrumbList (singular pages).
		if ( is_singular() ) {
			$breadcrumbs = array(
				array(
					'@type'    => 'ListItem',
					'position' => 1,
					'name'     => __( 'Home', 'ultimate-performance' ),
					'item'     => home_url( '/' ),
				),
			);

			$position = 2;

			// Add category for posts.
			if ( is_singular( 'post' ) ) {
				$categories = get_the_category();
				if ( ! empty( $categories ) ) {
					$cat = $categories[0];
					$breadcrumbs[] = array(
						'@type'    => 'ListItem',
						'position' => $position,
						'name'     => $cat->name,
						'item'     => get_category_link( $cat->term_id ),
					);
					$position++;
				}
			}

			$breadcrumbs[] = array(
				'@type'    => 'ListItem',
				'position' => $position,
				'name'     => get_the_title(),
				'item'     => get_permalink(),
			);

			$schemas[] = array(
				'@type'           => 'BreadcrumbList',
				'itemListElement' => $breadcrumbs,
			);
		}

		if ( empty( $schemas ) ) {
			return;
		}

		$graph = array(
			'@context' => 'https://schema.org',
			'@graph'   => $schemas,
		);

		printf(
			'<script type="application/ld+json">%s</script>' . "\n",
			wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
		);
	}

	// ------------------------------------------------------------------
	// Meta Box
	// ------------------------------------------------------------------

	/**
	 * Register the SEO meta box on post types.
	 *
	 * @since 1.3.0
	 */
	public function register_meta_box() {
		$post_types = get_post_types( array( 'public' => true ), 'names' );

		foreach ( $post_types as $post_type ) {
			add_meta_box(
				'up-seo-meta-box',
				__( 'Ultimate Performance — SEO', 'ultimate-performance' ),
				array( $this, 'render_meta_box' ),
				$post_type,
				'normal',
				'default'
			);
		}
	}

	/**
	 * Render the SEO meta box.
	 *
	 * @since 1.3.0
	 * @param WP_Post $post Current post.
	 */
	public function render_meta_box( $post ) {
		// Enqueue meta box styles inline (instead of an inline <style> tag in the template).
		$css = '.up-seo-meta { display: flex; flex-direction: column; gap: 14px; }'
			. '.up-seo-meta label { display: block; font-weight: 600; margin-bottom: 4px; }'
			. '.up-seo-meta .description { color: #646970; font-size: 12px; margin-top: 2px; }'
			. '.up-seo-meta input[type="text"], .up-seo-meta input[type="url"], .up-seo-meta textarea { width: 100%; }'
			. '.up-seo-meta hr { margin: 6px 0; border: 0; border-top: 1px solid #dcdcde; }'
			. '.up-seo-meta .up-seo-checkbox { display: flex; align-items: center; gap: 6px; }'
			. '.up-seo-meta .up-seo-checkbox label { font-weight: 400; margin: 0; }'
			. '.up-seo-meta .up-seo-char-count { color: #646970; font-size: 12px; text-align: right; margin-top: 2px; }'
			. '.up-seo-meta .up-seo-section-title { font-size: 13px; font-weight: 600; color: #1d2327; margin: 0; }';
		wp_add_inline_style( 'wp-admin', $css );

		include UP_PLUGIN_DIR . 'admin/partials/seo-metabox.php';
	}

	/**
	 * Save SEO meta box data.
	 *
	 * @since 1.3.0
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 */
	public function save_meta_box( $post_id, $post ) {
		if ( ! isset( $_POST['up_seo_meta_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['up_seo_meta_nonce'] ) ), 'up_seo_meta' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Text fields.
		$text_fields = array( '_up_seo_title', '_up_seo_description', '_up_seo_og_title', '_up_seo_og_description' );
		foreach ( $text_fields as $key ) {
			if ( isset( $_POST[ $key ] ) ) {
				$value = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
				if ( ! empty( $value ) ) {
					update_post_meta( $post_id, $key, $value );
				} else {
					delete_post_meta( $post_id, $key );
				}
			}
		}

		// URL field.
		if ( isset( $_POST['_up_seo_og_image'] ) ) {
			$url = esc_url_raw( wp_unslash( $_POST['_up_seo_og_image'] ) );
			if ( ! empty( $url ) ) {
				update_post_meta( $post_id, '_up_seo_og_image', $url );
			} else {
				delete_post_meta( $post_id, '_up_seo_og_image' );
			}
		}

		// Checkbox fields.
		$checkboxes = array( '_up_seo_noindex', '_up_seo_nofollow' );
		foreach ( $checkboxes as $key ) {
			if ( ! empty( $_POST[ $key ] ) ) {
				update_post_meta( $post_id, $key, '1' );
			} else {
				delete_post_meta( $post_id, $key );
			}
		}
	}

	// ------------------------------------------------------------------
	// Helpers
	// ------------------------------------------------------------------

	/**
	 * Truncate a string to a given length at word boundary.
	 *
	 * @since  1.3.0
	 * @param  string $text   Text to truncate.
	 * @param  int    $length Max length.
	 * @return string
	 */
	private function truncate( $text, $length = 160 ) {
		$text = trim( preg_replace( '/\s+/', ' ', $text ) );
		if ( mb_strlen( $text ) <= $length ) {
			return $text;
		}

		$text = mb_substr( $text, 0, $length );
		$last_space = mb_strrpos( $text, ' ' );
		if ( false !== $last_space && $last_space > $length * 0.8 ) {
			$text = mb_substr( $text, 0, $last_space );
		}

		return $text;
	}

	/**
	 * Check if the module has an active SEO plugin conflict.
	 *
	 * Public accessor for conflict detection (used by settings partial).
	 *
	 * @since  1.3.0
	 * @return string|false Plugin name or false.
	 */
	public function get_conflict() {
		if ( null === $this->conflict ) {
			$this->conflict = $this->detect_seo_conflict();
		}
		return $this->conflict;
	}

	/**
	 * Static helper to detect SEO plugin conflict without instantiation.
	 *
	 * @since  1.3.0
	 * @return string|false Plugin name or false.
	 */
	public static function check_seo_conflict() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		foreach ( self::$seo_plugins as $path => $name ) {
			if ( is_plugin_active( $path ) ) {
				return $name;
			}
		}

		return false;
	}
}
