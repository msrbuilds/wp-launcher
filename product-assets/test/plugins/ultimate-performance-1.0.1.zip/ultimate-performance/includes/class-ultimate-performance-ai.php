<?php
/**
 * AI Assistant module for analyzing performance and providing suggestions.
 *
 * Integrates with OpenAI, Google Gemini, and Anthropic APIs to analyze
 * speed test reports and scan websites for performance issues.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Ai
 *
 * @since 1.4.0
 */
class Ultimate_Performance_Ai {

	/**
	 * Module settings.
	 *
	 * @since 1.4.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Provider API endpoints.
	 *
	 * @since 1.4.0
	 * @var   array
	 */
	const PROVIDER_ENDPOINTS = array(
		'openai'    => 'https://api.openai.com/v1/chat/completions',
		'gemini'    => 'https://generativelanguage.googleapis.com/v1beta/models/',
		'anthropic' => 'https://api.anthropic.com/v1/messages',
	);

	/**
	 * Available models per provider.
	 *
	 * @since 1.4.0
	 * @var   array
	 */
	const PROVIDER_MODELS = array(
		'openai'    => array(
			'gpt-4o-mini'  => 'GPT-4o Mini',
			'gpt-4o'       => 'GPT-4o',
			'gpt-4.1-mini' => 'GPT-4.1 Mini',
			'gpt-4.1'      => 'GPT-4.1',
		),
		'gemini'    => array(
			'gemini-2.0-flash' => 'Gemini 2.0 Flash',
			'gemini-2.5-flash' => 'Gemini 2.5 Flash',
			'gemini-2.5-pro'   => 'Gemini 2.5 Pro',
		),
		'anthropic' => array(
			'claude-haiku-4-5-20251001' => 'Claude Haiku 4.5',
			'claude-sonnet-4-20250514'  => 'Claude Sonnet 4',
			'claude-opus-4-20250918'    => 'Claude Opus 4',
		),
	);

	/**
	 * Initialize the module.
	 *
	 * @since 1.4.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'ai' );

		// AJAX handlers — always loaded so the page works.
		add_action( 'wp_ajax_up_ai_test_connection', array( $this, 'ajax_test_connection' ) );
		add_action( 'wp_ajax_up_ai_analyze_speed_test', array( $this, 'ajax_analyze_speed_test' ) );
		add_action( 'wp_ajax_up_ai_scan_website', array( $this, 'ajax_scan_website' ) );
		add_action( 'wp_ajax_up_ai_get_reports', array( $this, 'ajax_get_reports' ) );
		add_action( 'wp_ajax_up_ai_delete_report', array( $this, 'ajax_delete_report' ) );
		add_action( 'wp_ajax_up_ai_fetch_models', array( $this, 'ajax_fetch_models' ) );
	}

	/**
	 * Call the active AI provider.
	 *
	 * @since  1.4.0
	 * @param  string $prompt   User prompt.
	 * @param  string $provider Optional provider override.
	 * @return string|WP_Error Response text or error.
	 */
	private function call_provider( $prompt, $provider = '' ) {
		if ( empty( $provider ) ) {
			$provider = $this->settings['active_provider'];
		}

		$model_key = $provider . '_model';
		$model     = isset( $this->settings[ $model_key ] ) ? $this->settings[ $model_key ] : '';

		switch ( $provider ) {
			case 'openai':
				return $this->call_openai( $prompt, $model );
			case 'gemini':
				return $this->call_gemini( $prompt, $model );
			case 'anthropic':
				return $this->call_anthropic( $prompt, $model );
			default:
				return new WP_Error( 'invalid_provider', __( 'Unknown AI provider.', 'ultimate-performance' ) );
		}
	}

	/**
	 * Call the OpenAI chat completions API.
	 *
	 * @since  1.4.0
	 * @param  string $prompt System+user prompt content.
	 * @param  string $model  Model ID.
	 * @return string|WP_Error Response text or error.
	 */
	private function call_openai( $prompt, $model ) {
		$api_key = $this->settings['openai_api_key'];
		if ( empty( $api_key ) ) {
			return new WP_Error( 'missing_key', __( 'OpenAI API key is not configured.', 'ultimate-performance' ) );
		}

		// Reasoning models (o-series, gpt-5+) don't support temperature or system role.
		$is_reasoning = (bool) preg_match( '/^(o[1-9]|gpt-5)/', $model );

		$messages = $is_reasoning
			? array( array( 'role' => 'user', 'content' => $this->get_system_prompt() . "\n\n" . $prompt ) )
			: array(
				array( 'role' => 'system', 'content' => $this->get_system_prompt() ),
				array( 'role' => 'user', 'content' => $prompt ),
			);

		$body = array(
			'model'                  => $model,
			'messages'               => $messages,
			'max_completion_tokens'  => 8192,
			'response_format'        => array( 'type' => 'json_object' ),
		);

		if ( ! $is_reasoning ) {
			$body['temperature'] = 0.3;
		}

		$response = wp_remote_post( self::PROVIDER_ENDPOINTS['openai'], array(
			'timeout' => 120,
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $api_key,
			),
			'body'    => wp_json_encode( $body ),
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$msg = isset( $body['error']['message'] ) ? $body['error']['message'] : __( 'OpenAI API error.', 'ultimate-performance' );
			return new WP_Error( 'api_error', $msg );
		}

		return isset( $body['choices'][0]['message']['content'] )
			? $body['choices'][0]['message']['content']
			: '';
	}

	/**
	 * Call the Google Gemini API.
	 *
	 * @since  1.4.0
	 * @param  string $prompt User prompt content.
	 * @param  string $model  Model ID.
	 * @return string|WP_Error Response text or error.
	 */
	private function call_gemini( $prompt, $model ) {
		$api_key = $this->settings['gemini_api_key'];
		if ( empty( $api_key ) ) {
			return new WP_Error( 'missing_key', __( 'Gemini API key is not configured.', 'ultimate-performance' ) );
		}

		$url = self::PROVIDER_ENDPOINTS['gemini'] . $model . ':generateContent?key=' . $api_key;

		$response = wp_remote_post( $url, array(
			'timeout' => 120,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( array(
				'systemInstruction' => array(
					'parts' => array( array( 'text' => $this->get_system_prompt() ) ),
				),
				'contents'          => array(
					array(
						'parts' => array( array( 'text' => $prompt ) ),
					),
				),
				'generationConfig'  => array(
					'maxOutputTokens'  => 8192,
					'temperature'      => 0.3,
					'responseMimeType' => 'application/json',
				),
			) ),
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$msg = isset( $body['error']['message'] ) ? $body['error']['message'] : __( 'Gemini API error.', 'ultimate-performance' );
			return new WP_Error( 'api_error', $msg );
		}

		return isset( $body['candidates'][0]['content']['parts'][0]['text'] )
			? $body['candidates'][0]['content']['parts'][0]['text']
			: '';
	}

	/**
	 * Call the Anthropic Messages API.
	 *
	 * @since  1.4.0
	 * @param  string $prompt User prompt content.
	 * @param  string $model  Model ID.
	 * @return string|WP_Error Response text or error.
	 */
	private function call_anthropic( $prompt, $model ) {
		$api_key = $this->settings['anthropic_api_key'];
		if ( empty( $api_key ) ) {
			return new WP_Error( 'missing_key', __( 'Anthropic API key is not configured.', 'ultimate-performance' ) );
		}

		$response = wp_remote_post( self::PROVIDER_ENDPOINTS['anthropic'], array(
			'timeout' => 120,
			'headers' => array(
				'Content-Type'      => 'application/json',
				'x-api-key'         => $api_key,
				'anthropic-version' => '2023-06-01',
			),
			'body'    => wp_json_encode( array(
				'model'       => $model,
				'max_tokens'  => 8192,
				'system'      => $this->get_system_prompt(),
				'messages'    => array(
					array( 'role' => 'user', 'content' => $prompt . "\n\nRespond with ONLY valid JSON. No markdown fences, no explanation text — just the raw JSON object." ),
					array( 'role' => 'assistant', 'content' => '{' ),
				),
				'temperature' => 0.3,
			) ),
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$msg = isset( $body['error']['message'] ) ? $body['error']['message'] : __( 'Anthropic API error.', 'ultimate-performance' );
			return new WP_Error( 'api_error', $msg );
		}

		if ( ! isset( $body['content'][0]['text'] ) ) {
			return '';
		}

		// Prepend the '{' from the assistant prefill since the API continues from it.
		$text = $body['content'][0]['text'];
		if ( '{' !== substr( ltrim( $text ), 0, 1 ) ) {
			$text = '{' . $text;
		}

		return $text;
	}

	/**
	 * Get the system prompt for all AI interactions.
	 *
	 * @since  1.4.0
	 * @return string System prompt.
	 */
	private function get_system_prompt() {
		return 'You are a WordPress performance and accessibility expert. You analyze website data and provide specific, actionable recommendations across Performance, Accessibility, Best Practices, and SEO. '
			. 'Format your response as JSON with the following structure: '
			. '{"summary": "Brief overall assessment (1-2 sentences)", "score_label": "good|needs_work|poor", "categories": [{"name": "Category Name", "icon": "dashicons-class", "items": [{"issue": "Brief issue description", "impact": "high|medium|low", "fix": "Specific fix with code if applicable", "code": "optional HTML/CSS/PHP code snippet showing the exact fix", "module": "plugin_module_key_or_null"}]}]}'
			. "\n\nIMPORTANT RULES FOR FIXES:\n"
			. '- For accessibility issues: ALWAYS include a "code" field with the exact HTML fix. Show the corrected element. Example: {"issue": "Image missing alt text", "fix": "Add descriptive alt attribute", "code": "<img src=\"logo.png\" alt=\"Company logo\">"} '
			. '- For ARIA issues: show the exact attribute to add/change in the "code" field. '
			. '- For color contrast issues: suggest specific hex color values that pass WCAG AA. '
			. '- For SEO issues: include the exact meta tag or HTML change needed. '
			. '- For performance issues handled by the plugin: reference the module and setting to enable. '
			. "\n\nAvailable plugin modules: "
			. 'bloat_removal, database, caching, css_js, image_optimization, webfonts, preloading, cdn, third_party, script_manager, woocommerce, security_headers. '
			. 'Only reference a module if the fix genuinely maps to it. Use null for fixes outside plugin scope. '
			. 'Include ALL categories with issues (Performance, Accessibility, SEO, Best Practices). Limit to top 20 most impactful issues total. Respond ONLY with valid JSON, no markdown fencing.';
	}

	/**
	 * Build prompt for analyzing a speed test report.
	 *
	 * @since  1.4.0
	 * @param  array $raw_response Full PSI API response.
	 * @return string Prompt.
	 */
	private function build_speed_test_prompt( $raw_response ) {
		$lighthouse = isset( $raw_response['lighthouseResult'] ) ? $raw_response['lighthouseResult'] : array();
		$categories = isset( $lighthouse['categories'] ) ? $lighthouse['categories'] : array();
		$audits     = isset( $lighthouse['audits'] ) ? $lighthouse['audits'] : array();

		// Extract scores.
		$scores = array();
		foreach ( $categories as $key => $cat ) {
			$scores[ $key ] = isset( $cat['score'] ) ? round( $cat['score'] * 100 ) : 0;
		}

		// Extract failing audits with details (performance-related).
		$failing = array();
		foreach ( $audits as $id => $audit ) {
			if ( ! isset( $audit['score'] ) || null === $audit['score'] || $audit['score'] >= 0.9 ) {
				continue;
			}
			$entry = array(
				'id'    => $id,
				'title' => isset( $audit['title'] ) ? $audit['title'] : $id,
				'score' => $audit['score'],
			);
			if ( isset( $audit['displayValue'] ) ) {
				$entry['value'] = $audit['displayValue'];
			}
			if ( isset( $audit['details']['overallSavingsMs'] ) ) {
				$entry['savings_ms'] = (int) $audit['details']['overallSavingsMs'];
			}
			if ( isset( $audit['details']['overallSavingsBytes'] ) ) {
				$entry['savings_bytes'] = (int) $audit['details']['overallSavingsBytes'];
			}
			// Include top 5 items for context.
			if ( isset( $audit['details']['items'] ) && is_array( $audit['details']['items'] ) ) {
				$entry['items'] = $this->extract_audit_items( $audit['details']['items'], 5 );
			}
			$failing[] = $entry;
		}

		usort( $failing, function ( $a, $b ) {
			return ( $a['score'] ?? 1 ) <=> ( $b['score'] ?? 1 );
		} );
		$failing = array_slice( $failing, 0, 20 );

		// Extract category-specific failing audits (accessibility, SEO, best-practices).
		$category_audits = array();
		foreach ( array( 'accessibility', 'best-practices', 'seo' ) as $cat_key ) {
			if ( ! isset( $categories[ $cat_key ]['auditRefs'] ) ) {
				continue;
			}
			$cat_failing = array();
			foreach ( $categories[ $cat_key ]['auditRefs'] as $ref ) {
				$audit_id = isset( $ref['id'] ) ? $ref['id'] : '';
				if ( empty( $audit_id ) || ! isset( $audits[ $audit_id ] ) ) {
					continue;
				}
				$audit       = $audits[ $audit_id ];
				$audit_score = isset( $audit['score'] ) ? $audit['score'] : null;
				if ( null === $audit_score || $audit_score >= 0.9 ) {
					continue;
				}
				if ( isset( $audit['scoreDisplayMode'] ) && 'manual' === $audit['scoreDisplayMode'] ) {
					continue;
				}
				$cat_entry = array(
					'id'    => $audit_id,
					'title' => isset( $audit['title'] ) ? $audit['title'] : $audit_id,
					'score' => $audit_score,
				);
				if ( isset( $audit['description'] ) ) {
					$cat_entry['description'] = $audit['description'];
				}
				if ( isset( $audit['details']['items'] ) && is_array( $audit['details']['items'] ) ) {
					$cat_entry['items'] = $this->extract_audit_items( $audit['details']['items'], 8 );
				}
				$cat_failing[] = $cat_entry;
			}
			if ( ! empty( $cat_failing ) ) {
				$category_audits[ $cat_key ] = $cat_failing;
			}
		}

		$data = array(
			'scores'          => $scores,
			'failing_audits'  => $failing,
			'category_audits' => $category_audits,
		);

		return "Analyze this Google PageSpeed Insights report and provide specific optimization recommendations for ALL categories: Performance, Accessibility, Best Practices, and SEO.\n\n"
			. "IMPORTANT: For accessibility issues, provide EXACT HTML code fixes. Show the broken element and the corrected version. For example, if an image is missing alt text, show: 'Change `<img src=\"...\">` to `<img src=\"...\" alt=\"Descriptive text\">`'. "
			. "For ARIA issues, show the exact attribute to add. For contrast issues, suggest specific color values. Be precise and code-oriented.\n\n"
			. "REPORT DATA:\n" . wp_json_encode( $data, JSON_PRETTY_PRINT );
	}

	/**
	 * Extract clean items from an audit's detail items array.
	 *
	 * Handles both performance-style items (URLs, bytes, ms) and
	 * accessibility-style items (DOM nodes, selectors, explanations).
	 *
	 * @since  1.5.0
	 * @param  array $items     Raw items from audit details.
	 * @param  int   $max_items Maximum items to extract.
	 * @return array Cleaned items.
	 */
	private function extract_audit_items( $items, $max_items = 5 ) {
		$items_slice = array_slice( $items, 0, $max_items );
		$clean_items = array();

		foreach ( $items_slice as $item ) {
			$clean = array();
			if ( isset( $item['url'] ) ) {
				$clean['url'] = $item['url'];
			}
			if ( isset( $item['wastedMs'] ) ) {
				$clean['wasted_ms'] = round( $item['wastedMs'], 1 );
			}
			if ( isset( $item['wastedBytes'] ) ) {
				$clean['wasted_bytes'] = (int) $item['wastedBytes'];
			}
			if ( isset( $item['totalBytes'] ) ) {
				$clean['total_bytes'] = (int) $item['totalBytes'];
			}
			// Node-based items (accessibility audits).
			if ( isset( $item['node'] ) && is_array( $item['node'] ) ) {
				if ( isset( $item['node']['snippet'] ) ) {
					$clean['element'] = $item['node']['snippet'];
				}
				if ( isset( $item['node']['selector'] ) ) {
					$clean['selector'] = $item['node']['selector'];
				}
				if ( isset( $item['node']['explanation'] ) ) {
					$clean['explanation'] = $item['node']['explanation'];
				}
			}
			// Generic scalar values.
			foreach ( $item as $dk => $dv ) {
				if ( 'node' === $dk ) {
					continue;
				}
				if ( is_scalar( $dv ) && ! isset( $clean[ $dk ] ) ) {
					$clean[ $dk ] = $dv;
				}
			}
			if ( ! empty( $clean ) ) {
				$clean_items[] = $clean;
			}
		}

		return $clean_items;
	}

	/**
	 * Build prompt for an independent website scan.
	 *
	 * @since  1.4.0
	 * @param  array $scan_data HTML/header scan results.
	 * @param  array $psi_data  Optional PSI data if available.
	 * @return string Prompt.
	 */
	private function build_website_scan_prompt( $scan_data, $psi_data = array() ) {
		$prompt = "Analyze this WordPress website scan data and provide comprehensive performance optimization recommendations.\n\n";
		$prompt .= "IMPORTANT: 'page_headers' are from the HTML document (no-cache is correct for HTML pages). ";
		$prompt .= "'static_asset_headers' are from a sampled CSS/JS file and represent the actual browser caching for static assets. ";
		$prompt .= "Only flag caching issues if static_asset_headers show short or missing cache lifetimes.\n\n";
		$prompt .= "WEBSITE SCAN DATA:\n" . wp_json_encode( $scan_data, JSON_PRETTY_PRINT );

		if ( ! empty( $psi_data ) ) {
			$prompt .= "\n\nADDITIONAL PSI DATA:\n" . wp_json_encode( $psi_data, JSON_PRETTY_PRINT );
		}

		return $prompt;
	}

	/**
	 * Perform an independent website scan.
	 *
	 * Fetches the URL's HTML and headers, then extracts performance-relevant data.
	 *
	 * @since  1.4.0
	 * @param  string $url URL to scan.
	 * @return array|WP_Error Scan data or error.
	 */
	private function scan_website_html( $url ) {
		$response = wp_remote_get( $url, array(
			'timeout'    => 30,
			'user-agent' => 'Ultimate-Performance-Scanner/1.0',
			'sslverify'  => ! defined( 'UP_DISABLE_SSL_VERIFY' ),
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code    = wp_remote_retrieve_response_code( $response );
		$headers = wp_remote_retrieve_headers( $response );
		$body    = wp_remote_retrieve_body( $response );

		if ( 200 !== $code ) {
			return new WP_Error( 'scan_error', sprintf(
				/* translators: %d: HTTP status code */
				__( 'Website returned HTTP %d.', 'ultimate-performance' ),
				$code
			) );
		}

		$scan = array(
			'url'         => $url,
			'status_code' => $code,
			'html_size'   => strlen( $body ),
		);

		// Analyze headers.
		$header_array = array();
		if ( is_object( $headers ) ) {
			$header_array = $headers->getAll();
		} elseif ( is_array( $headers ) ) {
			$header_array = $headers;
		}

		$scan['page_headers'] = array();

		// Caching headers (from the HTML page — typically no-cache, which is correct).
		$cache_headers = array( 'cache-control', 'expires', 'etag', 'last-modified', 'vary', 'x-cache' );
		foreach ( $cache_headers as $h ) {
			if ( isset( $header_array[ $h ] ) ) {
				$scan['page_headers'][ $h ] = is_array( $header_array[ $h ] ) ? implode( ', ', $header_array[ $h ] ) : $header_array[ $h ];
			}
		}

		// Compression.
		$scan['compression'] = isset( $header_array['content-encoding'] ) ? $header_array['content-encoding'] : 'none';

		// Security headers.
		$sec_headers            = array( 'x-content-type-options', 'x-frame-options', 'strict-transport-security', 'referrer-policy', 'permissions-policy', 'content-security-policy' );
		$scan['security_headers'] = array();
		foreach ( $sec_headers as $sh ) {
			$scan['security_headers'][ $sh ] = isset( $header_array[ $sh ] ) ? 'present' : 'missing';
		}

		// Server info.
		if ( isset( $header_array['server'] ) ) {
			$scan['server'] = is_array( $header_array['server'] ) ? implode( ', ', $header_array['server'] ) : $header_array['server'];
		}

		// HTML analysis.
		$scan['html_analysis'] = $this->analyze_html( $body );

		// Sample a static asset's headers to check browser caching for CSS/JS/images.
		$scan['static_asset_headers'] = $this->sample_static_asset_headers( $body, $url );

		return $scan;
	}

	/**
	 * Fetch headers from a static asset found in the page HTML.
	 *
	 * Picks the first local CSS or JS file, performs a HEAD request,
	 * and returns its caching headers so the AI can evaluate
	 * static asset caching separately from the HTML page.
	 *
	 * @since  1.4.0
	 * @param  string $html     Page HTML.
	 * @param  string $page_url The page URL (for resolving relative paths).
	 * @return array  Cache-relevant headers from the asset, or empty array.
	 */
	private function sample_static_asset_headers( $html, $page_url ) {
		$asset_url = '';

		// Try to find a local CSS file first.
		if ( preg_match_all( '/<link[^>]+href=["\']([^"\']+\.css[^"\']*)["\'][^>]*>/i', $html, $matches ) ) {
			$parsed_page = wp_parse_url( $page_url );
			$page_host   = isset( $parsed_page['host'] ) ? $parsed_page['host'] : '';

			foreach ( $matches[1] as $href ) {
				$parsed = wp_parse_url( $href );
				// Local asset: same host or relative path.
				if ( empty( $parsed['host'] ) || $parsed['host'] === $page_host ) {
					$asset_url = $href;
					break;
				}
			}
		}

		// Fallback: try a local JS file.
		if ( empty( $asset_url ) && preg_match_all( '/<script[^>]+src=["\']([^"\']+\.js[^"\']*)["\'][^>]*>/i', $html, $js_matches ) ) {
			$parsed_page = wp_parse_url( $page_url );
			$page_host   = isset( $parsed_page['host'] ) ? $parsed_page['host'] : '';

			foreach ( $js_matches[1] as $src ) {
				$parsed = wp_parse_url( $src );
				if ( empty( $parsed['host'] ) || $parsed['host'] === $page_host ) {
					$asset_url = $src;
					break;
				}
			}
		}

		if ( empty( $asset_url ) ) {
			return array();
		}

		// Resolve relative URLs.
		if ( 0 !== strpos( $asset_url, 'http' ) ) {
			$asset_url = rtrim( $page_url, '/' ) . '/' . ltrim( $asset_url, '/' );
		}

		$response = wp_remote_head( $asset_url, array(
			'timeout'    => 10,
			'sslverify'  => ! defined( 'UP_DISABLE_SSL_VERIFY' ),
			'user-agent' => 'Ultimate-Performance-Scanner/1.0',
		) );

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return array();
		}

		$headers      = wp_remote_retrieve_headers( $response );
		$header_array = is_object( $headers ) ? $headers->getAll() : (array) $headers;

		$result        = array( 'sampled_url' => $asset_url );
		$check_headers = array( 'cache-control', 'expires', 'etag', 'last-modified', 'x-cache' );

		foreach ( $check_headers as $h ) {
			if ( isset( $header_array[ $h ] ) ) {
				$result[ $h ] = is_array( $header_array[ $h ] ) ? implode( ', ', $header_array[ $h ] ) : $header_array[ $h ];
			}
		}

		return $result;
	}

	/**
	 * Analyze HTML content for performance issues.
	 *
	 * @since  1.4.0
	 * @param  string $html Page HTML.
	 * @return array Analysis results.
	 */
	private function analyze_html( $html ) {
		$analysis = array();

		// Count render-blocking stylesheets.
		preg_match_all( '/<link[^>]+rel=["\']stylesheet["\'][^>]*>/i', $html, $css_matches );
		$analysis['external_css_count'] = count( $css_matches[0] );

		// Count scripts in head vs body.
		$head_html = '';
		if ( preg_match( '/<head[^>]*>(.*?)<\/head>/is', $html, $head_match ) ) {
			$head_html = $head_match[1];
		}
		preg_match_all( '/<script[^>]*src=["\'][^"\']+["\'][^>]*>/i', $head_html, $head_scripts );
		preg_match_all( '/<script[^>]*src=["\'][^"\']+["\'][^>]*>/i', $html, $all_scripts );
		$analysis['scripts_in_head'] = count( $head_scripts[0] );
		$analysis['total_scripts']   = count( $all_scripts[0] );

		// Check for defer/async on scripts.
		preg_match_all( '/<script[^>]*(defer|async)[^>]*>/i', $html, $deferred );
		$analysis['deferred_scripts'] = count( $deferred[0] );

		// Count images.
		preg_match_all( '/<img[^>]*>/i', $html, $images );
		$analysis['total_images'] = count( $images[0] );

		// Check for lazy loading.
		preg_match_all( '/<img[^>]*loading=["\']lazy["\'][^>]*>/i', $html, $lazy );
		$analysis['lazy_loaded_images'] = count( $lazy[0] );

		// Check for missing width/height on images.
		$missing_dimensions = 0;
		foreach ( $images[0] as $img ) {
			if ( ! preg_match( '/width=/i', $img ) || ! preg_match( '/height=/i', $img ) ) {
				$missing_dimensions++;
			}
		}
		$analysis['images_missing_dimensions'] = $missing_dimensions;

		// Check for WebP/AVIF usage.
		preg_match_all( '/\.webp/i', $html, $webp );
		preg_match_all( '/\.avif/i', $html, $avif );
		$analysis['webp_usage'] = count( $webp[0] ) > 0;
		$analysis['avif_usage'] = count( $avif[0] ) > 0;

		// Check for Google Fonts.
		preg_match_all( '/fonts\.googleapis\.com/i', $html, $gfonts );
		$analysis['google_fonts_requests'] = count( $gfonts[0] );

		// Check for font-display: swap.
		$analysis['font_display_swap'] = (bool) preg_match( '/font-display\s*:\s*swap/i', $html );

		// Check inline styles/scripts size.
		preg_match_all( '/<style[^>]*>(.*?)<\/style>/is', $html, $inline_styles );
		$inline_css_size = 0;
		foreach ( $inline_styles[1] as $style ) {
			$inline_css_size += strlen( $style );
		}
		$analysis['inline_css_bytes'] = $inline_css_size;

		preg_match_all( '/<script[^>]*>([^<]+)<\/script>/is', $html, $inline_scripts );
		$inline_js_size = 0;
		foreach ( $inline_scripts[1] as $script ) {
			$inline_js_size += strlen( $script );
		}
		$analysis['inline_js_bytes'] = $inline_js_size;

		// Check for preconnect/prefetch/preload hints.
		preg_match_all( '/<link[^>]+rel=["\']preconnect["\'][^>]*>/i', $html, $preconnect );
		preg_match_all( '/<link[^>]+rel=["\']dns-prefetch["\'][^>]*>/i', $html, $prefetch );
		preg_match_all( '/<link[^>]+rel=["\']preload["\'][^>]*>/i', $html, $preload );
		$analysis['preconnect_hints']   = count( $preconnect[0] );
		$analysis['dns_prefetch_hints'] = count( $prefetch[0] );
		$analysis['preload_hints']      = count( $preload[0] );

		// Check for WordPress-specific bloat.
		$analysis['has_wp_emoji']        = (bool) strpos( $html, 'wp-emoji-release' );
		$analysis['has_wp_embed']        = (bool) strpos( $html, 'wp-embed.min.js' );
		$analysis['has_dashicons']       = (bool) strpos( $html, 'dashicons' );
		$analysis['has_wp_version']      = (bool) preg_match( '/\?ver=[\d.]+/i', $html );
		$analysis['has_jquery_migrate']  = (bool) strpos( $html, 'jquery-migrate' );

		return $analysis;
	}

	/**
	 * AJAX handler: Test connection to a provider.
	 *
	 * @since 1.4.0
	 */
	public function ajax_test_connection() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';

		if ( ! in_array( $provider, array( 'openai', 'gemini', 'anthropic' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid provider.', 'ultimate-performance' ) ) );
		}

		// Refresh settings to pick up any recent save.
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'ai' );

		$result = $this->call_provider( 'Respond with exactly: {"status":"ok"}', $provider );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array(
			'message' => sprintf(
				/* translators: %s: provider name */
				__( '%s connection successful!', 'ultimate-performance' ),
				ucfirst( $provider )
			),
		) );
	}

	/**
	 * AJAX handler: Analyze a speed test report with AI.
	 *
	 * @since 1.4.0
	 */
	public function ajax_analyze_speed_test() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$report_id = isset( $_POST['report_id'] ) ? absint( $_POST['report_id'] ) : 0;

		if ( ! $report_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid report ID.', 'ultimate-performance' ) ) );
		}

		// Refresh settings.
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'ai' );

		// Check for cached result.
		$cache_key = 'up_ai_analysis_' . $report_id;
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			wp_send_json_success( $cached );
		}

		// Fetch the report from DB.
		global $wpdb;
		$table = $wpdb->prefix . 'up_speed_tests';
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT url, strategy, raw_response FROM {$table} WHERE id = %d", $report_id ),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

		if ( ! $row || empty( $row['raw_response'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Report not found or has no data.', 'ultimate-performance' ) ) );
		}

		$raw = json_decode( $row['raw_response'], true );
		if ( ! is_array( $raw ) || ! isset( $raw['lighthouseResult'] ) ) {
			wp_send_json_error( array( 'message' => __( 'This report does not contain PSI data for AI analysis.', 'ultimate-performance' ) ) );
		}

		$prompt = $this->build_speed_test_prompt( $raw );
		$result = $this->call_provider( $prompt );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		if ( empty( $result ) ) {
			wp_send_json_error( array(
				'message' => __( 'The AI provider returned an empty response. Please verify your API key and model selection.', 'ultimate-performance' ),
			) );
		}

		$parsed = $this->parse_ai_response( $result );

		// Include truncated raw response for debugging when categories are empty.
		if ( empty( $parsed['categories'] ) ) {
			$parsed['_debug_raw'] = mb_substr( $result, 0, 2000 );
		}

		// Cache for 1 hour.
		set_transient( $cache_key, $parsed, HOUR_IN_SECONDS );

		// Save to AI reports.
		$reports = get_option( 'up_ai_reports', array() );
		$report  = array(
			'id'               => time(),
			'type'             => 'speed_test_analysis',
			'url'              => isset( $row['url'] ) ? $row['url'] : '',
			'speed_report_id'  => $report_id,
			'strategy'         => isset( $row['strategy'] ) ? $row['strategy'] : '',
			'data'             => $parsed,
			'created_at'       => current_time( 'mysql' ),
		);
		array_unshift( $reports, $report );
		$reports = array_slice( $reports, 0, 30 );
		update_option( 'up_ai_reports', $reports );

		$parsed['ai_report_id']  = $report['id'];
		$parsed['report_stored'] = true;

		wp_send_json_success( $parsed );
	}

	/**
	 * AJAX handler: Scan website with AI.
	 *
	 * @since 1.4.0
	 */
	public function ajax_scan_website() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : home_url( '/' );

		if ( empty( $url ) ) {
			$url = home_url( '/' );
		}

		// Refresh settings.
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'ai' );

		// 1. Perform independent HTML/header scan.
		$scan_data = $this->scan_website_html( $url );

		if ( is_wp_error( $scan_data ) ) {
			wp_send_json_error( array( 'message' => $scan_data->get_error_message() ) );
		}

		// 2. Optionally get latest PSI data if available.
		$psi_summary = array();
		global $wpdb;
		$table = $wpdb->prefix . 'up_speed_tests';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table query; not suitable for object cache.
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
			$latest_psi = $wpdb->get_row(
				"SELECT raw_response FROM {$table} WHERE raw_response IS NOT NULL ORDER BY created_at DESC LIMIT 1",
				ARRAY_A
			);
			// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

			if ( $latest_psi && ! empty( $latest_psi['raw_response'] ) ) {
				$raw = json_decode( $latest_psi['raw_response'], true );
				if ( is_array( $raw ) && isset( $raw['lighthouseResult'] ) ) {
					$lh   = $raw['lighthouseResult'];
					$cats = isset( $lh['categories'] ) ? $lh['categories'] : array();
					$psi_summary['scores'] = array();
					foreach ( $cats as $key => $cat ) {
						$psi_summary['scores'][ $key ] = isset( $cat['score'] ) ? round( $cat['score'] * 100 ) : 0;
					}

					// Top failing audits.
					$audits  = isset( $lh['audits'] ) ? $lh['audits'] : array();
					$failing = array();
					foreach ( $audits as $id => $audit ) {
						if ( ! isset( $audit['score'] ) || null === $audit['score'] || $audit['score'] >= 0.9 ) {
							continue;
						}
						$failing[] = array(
							'id'    => $id,
							'title' => isset( $audit['title'] ) ? $audit['title'] : $id,
							'score' => $audit['score'],
						);
					}
					usort( $failing, function ( $a, $b ) {
						return ( $a['score'] ?? 1 ) <=> ( $b['score'] ?? 1 );
					} );
					$psi_summary['top_failing_audits'] = array_slice( $failing, 0, 10 );
				}
			}
		}

		// 3. Build prompt and call AI.
		$prompt = $this->build_website_scan_prompt( $scan_data, $psi_summary );
		$result = $this->call_provider( $prompt );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		// If the provider returned empty, send an error immediately.
		if ( empty( $result ) ) {
			wp_send_json_error( array(
				'message' => __( 'The AI provider returned an empty response. Please verify your API key and model selection.', 'ultimate-performance' ),
			) );
		}

		$parsed            = $this->parse_ai_response( $result );
		$parsed['scan_data'] = $scan_data;
		$parsed['has_psi']   = ! empty( $psi_summary );

		// Include truncated raw response for debugging when categories are empty.
		if ( empty( $parsed['categories'] ) ) {
			$parsed['_debug_raw'] = mb_substr( $result, 0, 2000 );
		}

		// Store the report.
		$reports = get_option( 'up_ai_reports', array() );
		$report  = array(
			'id'         => time(),
			'type'       => 'website_scan',
			'url'        => $url,
			'data'       => $parsed,
			'created_at' => current_time( 'mysql' ),
		);
		array_unshift( $reports, $report );
		$reports = array_slice( $reports, 0, 20 );
		update_option( 'up_ai_reports', $reports );

		$parsed['report_stored'] = true;

		wp_send_json_success( $parsed );
	}

	/**
	 * AJAX handler: Get stored AI reports.
	 *
	 * @since 1.4.0
	 */
	public function ajax_get_reports() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$reports = get_option( 'up_ai_reports', array() );

		wp_send_json_success( array( 'reports' => $reports ) );
	}

	/**
	 * AJAX handler: Delete a stored AI report.
	 *
	 * @since 1.4.0
	 */
	public function ajax_delete_report() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$report_id = isset( $_POST['report_id'] ) ? absint( $_POST['report_id'] ) : 0;
		$reports   = get_option( 'up_ai_reports', array() );

		$reports = array_values( array_filter( $reports, function ( $r ) use ( $report_id ) {
			return ( isset( $r['id'] ) && (int) $r['id'] !== $report_id );
		} ) );

		update_option( 'up_ai_reports', $reports );

		wp_send_json_success( array( 'message' => __( 'Report deleted.', 'ultimate-performance' ) ) );
	}

	/**
	 * Parse AI response JSON into structured data.
	 *
	 * @since  1.4.0
	 * @param  string $response Raw AI response text.
	 * @return array  Parsed data.
	 */
	private function parse_ai_response( $response ) {
		// 1. Strip UTF-8 BOM (EF BB BF) — common cause of json_decode failure.
		$response = preg_replace( '/^\xEF\xBB\xBF/', '', $response );

		// 2. Remove invisible Unicode characters (zero-width spaces, word joiners, etc.).
		$response = preg_replace( '/[\x{200B}\x{200C}\x{200D}\x{200E}\x{200F}\x{2060}\x{FEFF}]/u', '', $response );

		// 3. Strip markdown code fences if present.
		$response = preg_replace( '/^```(?:json)?\s*\n?/m', '', $response );
		$response = preg_replace( '/\n?\s*```\s*$/m', '', $response );
		$response = trim( $response );

		// 4. Try direct JSON decode.
		$parsed = json_decode( $response, true );

		// 5. If that failed, extract JSON between the first { and last }.
		if ( ! is_array( $parsed ) ) {
			$first_brace = strpos( $response, '{' );
			$last_brace  = strrpos( $response, '}' );

			if ( false !== $first_brace && false !== $last_brace && $last_brace > $first_brace ) {
				$json_str = substr( $response, $first_brace, $last_brace - $first_brace + 1 );
				$parsed   = json_decode( $json_str, true );
			}
		}

		// 6. If still failing, strip control characters (except newlines/tabs) and retry.
		if ( ! is_array( $parsed ) ) {
			$cleaned = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $response );
			$first   = strpos( $cleaned, '{' );
			$last    = strrpos( $cleaned, '}' );

			if ( false !== $first && false !== $last && $last > $first ) {
				$json_str = substr( $cleaned, $first, $last - $first + 1 );
				$parsed   = json_decode( $json_str, true );
			}
		}

		// 7. Still failed — return as raw text with json_last_error info for debugging.
		if ( ! is_array( $parsed ) ) {
			return array(
				'summary'      => $response,
				'score_label'  => 'needs_work',
				'categories'   => array(),
				'raw'          => true,
				'_parse_error' => function_exists( 'json_last_error_msg' ) ? json_last_error_msg() : 'json_decode failed (error code: ' . json_last_error() . ')',
			);
		}

		return array(
			'summary'     => isset( $parsed['summary'] ) ? sanitize_text_field( $parsed['summary'] ) : '',
			'score_label' => isset( $parsed['score_label'] ) && in_array( $parsed['score_label'], array( 'good', 'needs_work', 'poor' ), true ) ? $parsed['score_label'] : 'needs_work',
			'categories'  => isset( $parsed['categories'] ) && is_array( $parsed['categories'] ) ? $this->sanitize_ai_categories( $parsed['categories'] ) : array(),
			'raw'         => false,
		);
	}

	/**
	 * Sanitize AI response categories.
	 *
	 * @since  1.4.0
	 * @param  array $categories Raw categories from AI.
	 * @return array Sanitized categories.
	 */
	private function sanitize_ai_categories( $categories ) {
		$sanitized = array();

		foreach ( $categories as $cat ) {
			if ( ! is_array( $cat ) ) {
				continue;
			}

			$clean_cat = array(
				'name'  => isset( $cat['name'] ) ? sanitize_text_field( $cat['name'] ) : '',
				'icon'  => isset( $cat['icon'] ) ? sanitize_html_class( $cat['icon'] ) : 'dashicons-admin-generic',
				'items' => array(),
			);

			if ( isset( $cat['items'] ) && is_array( $cat['items'] ) ) {
				foreach ( $cat['items'] as $item ) {
					if ( ! is_array( $item ) ) {
						continue;
					}
					$clean_item = array(
						'issue'  => isset( $item['issue'] ) ? sanitize_text_field( $item['issue'] ) : '',
						'impact' => isset( $item['impact'] ) && in_array( $item['impact'], array( 'high', 'medium', 'low' ), true ) ? $item['impact'] : 'medium',
						'fix'    => isset( $item['fix'] ) ? sanitize_text_field( $item['fix'] ) : '',
						'module' => isset( $item['module'] ) && ! empty( $item['module'] ) ? sanitize_key( $item['module'] ) : null,
					);
					if ( isset( $item['code'] ) && ! empty( $item['code'] ) ) {
						// Preserve code content as-is (escaped on output in JS).
						$clean_item['code'] = $item['code'];
					}
					$clean_cat['items'][] = $clean_item;
				}
			}

			$sanitized[] = $clean_cat;
		}

		return $sanitized;
	}

	/**
	 * AJAX handler: Fetch available models from a provider.
	 *
	 * @since 1.4.0
	 */
	public function ajax_fetch_models() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';
		$force    = isset( $_POST['force'] ) && filter_var( wp_unslash( $_POST['force'] ), FILTER_VALIDATE_BOOLEAN );

		if ( ! in_array( $provider, array( 'openai', 'gemini', 'anthropic' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid provider.', 'ultimate-performance' ) ) );
		}

		// Refresh settings.
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'ai' );

		// Check transient cache (unless force refresh).
		$cache_key = 'up_ai_models_' . $provider;
		if ( ! $force ) {
			$cached = get_transient( $cache_key );
			if ( false !== $cached ) {
				wp_send_json_success( array( 'models' => $cached ) );
			}
		}

		// Fetch from provider API.
		$models = array();
		switch ( $provider ) {
			case 'openai':
				$models = $this->fetch_openai_models();
				break;
			case 'gemini':
				$models = $this->fetch_gemini_models();
				break;
			case 'anthropic':
				$models = $this->fetch_anthropic_models();
				break;
		}

		if ( is_wp_error( $models ) ) {
			wp_send_json_error( array( 'message' => $models->get_error_message() ) );
		}

		// Merge with static defaults so they always appear.
		$static = self::PROVIDER_MODELS[ $provider ] ?? array();
		foreach ( $static as $id => $label ) {
			$exists = false;
			foreach ( $models as $m ) {
				if ( $m['id'] === $id ) {
					$exists = true;
					break;
				}
			}
			if ( ! $exists ) {
				$models[] = array( 'id' => $id, 'name' => $label );
			}
		}

		// Sort alphabetically by name.
		usort( $models, function ( $a, $b ) {
			return strcasecmp( $a['name'], $b['name'] );
		} );

		// Cache for 24 hours.
		set_transient( $cache_key, $models, DAY_IN_SECONDS );

		wp_send_json_success( array( 'models' => $models ) );
	}

	/**
	 * Fetch available models from OpenAI.
	 *
	 * @since  1.4.0
	 * @return array|WP_Error Array of {id, name} or error.
	 */
	private function fetch_openai_models() {
		$api_key = $this->settings['openai_api_key'];
		if ( empty( $api_key ) ) {
			return new WP_Error( 'missing_key', __( 'OpenAI API key is not configured.', 'ultimate-performance' ) );
		}

		$response = wp_remote_get( 'https://api.openai.com/v1/models', array(
			'timeout' => 30,
			'headers' => array(
				'Authorization' => 'Bearer ' . $api_key,
			),
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$msg = isset( $body['error']['message'] ) ? $body['error']['message'] : __( 'OpenAI API error.', 'ultimate-performance' );
			return new WP_Error( 'api_error', $msg );
		}

		$models        = array();
		$chat_prefixes = array( 'gpt-', 'o1-', 'o3-', 'o4-', 'chatgpt-' );
		$data          = isset( $body['data'] ) ? $body['data'] : array();

		foreach ( $data as $model ) {
			$id = isset( $model['id'] ) ? $model['id'] : '';
			if ( empty( $id ) ) {
				continue;
			}

			// Filter to chat-relevant models.
			$is_chat = false;
			foreach ( $chat_prefixes as $prefix ) {
				if ( 0 === strpos( $id, $prefix ) ) {
					$is_chat = true;
					break;
				}
			}
			if ( ! $is_chat ) {
				continue;
			}

			// Skip internal/system variants.
			if ( preg_match( '/(realtime|audio|search|instruct|vision|:)/i', $id ) ) {
				continue;
			}

			$models[] = array(
				'id'   => $id,
				'name' => $id,
			);
		}

		return $models;
	}

	/**
	 * Fetch available models from Google Gemini.
	 *
	 * @since  1.4.0
	 * @return array|WP_Error Array of {id, name} or error.
	 */
	private function fetch_gemini_models() {
		$api_key = $this->settings['gemini_api_key'];
		if ( empty( $api_key ) ) {
			return new WP_Error( 'missing_key', __( 'Gemini API key is not configured.', 'ultimate-performance' ) );
		}

		$url      = 'https://generativelanguage.googleapis.com/v1beta/models?key=' . $api_key . '&pageSize=100';
		$response = wp_remote_get( $url, array( 'timeout' => 30 ) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$msg = isset( $body['error']['message'] ) ? $body['error']['message'] : __( 'Gemini API error.', 'ultimate-performance' );
			return new WP_Error( 'api_error', $msg );
		}

		$models    = array();
		$raw_models = isset( $body['models'] ) ? $body['models'] : array();

		foreach ( $raw_models as $model ) {
			// Filter to models that support generateContent.
			$methods = isset( $model['supportedGenerationMethods'] ) ? $model['supportedGenerationMethods'] : array();
			if ( ! in_array( 'generateContent', $methods, true ) ) {
				continue;
			}

			$name_full = isset( $model['name'] ) ? $model['name'] : '';
			$id        = str_replace( 'models/', '', $name_full );
			$display   = isset( $model['displayName'] ) ? $model['displayName'] : $id;

			if ( empty( $id ) ) {
				continue;
			}

			$models[] = array(
				'id'   => $id,
				'name' => $display,
			);
		}

		return $models;
	}

	/**
	 * Fetch available models from Anthropic.
	 *
	 * @since  1.4.0
	 * @return array|WP_Error Array of {id, name} or error.
	 */
	private function fetch_anthropic_models() {
		$api_key = $this->settings['anthropic_api_key'];
		if ( empty( $api_key ) ) {
			return new WP_Error( 'missing_key', __( 'Anthropic API key is not configured.', 'ultimate-performance' ) );
		}

		$response = wp_remote_get( 'https://api.anthropic.com/v1/models?limit=100', array(
			'timeout' => 30,
			'headers' => array(
				'x-api-key'         => $api_key,
				'anthropic-version' => '2023-06-01',
			),
		) );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			// Fallback to static list if the models endpoint is not available.
			$msg = isset( $body['error']['message'] ) ? $body['error']['message'] : '';
			if ( ! empty( $msg ) ) {
				return new WP_Error( 'api_error', $msg );
			}
			// Return static models as fallback.
			$fallback = array();
			foreach ( self::PROVIDER_MODELS['anthropic'] as $id => $label ) {
				$fallback[] = array( 'id' => $id, 'name' => $label );
			}
			return $fallback;
		}

		$models = array();
		$data   = isset( $body['data'] ) ? $body['data'] : array();

		foreach ( $data as $model ) {
			$id      = isset( $model['id'] ) ? $model['id'] : '';
			$display = isset( $model['display_name'] ) ? $model['display_name'] : $id;

			if ( empty( $id ) ) {
				continue;
			}

			$models[] = array(
				'id'   => $id,
				'name' => $display,
			);
		}

		if ( empty( $models ) ) {
			// Fallback to static list.
			foreach ( self::PROVIDER_MODELS['anthropic'] as $id => $label ) {
				$models[] = array( 'id' => $id, 'name' => $label );
			}
		}

		return $models;
	}
}
