<?php
/**
 * Handles database optimization functionality.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Database
 *
 * Provides database cleanup tools (revisions, drafts, spam,
 * transients, orphaned data) and scheduled optimization.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Database {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Initialize the database module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'database' );

		// AJAX handlers (always available for admin tools page).
		add_action( 'wp_ajax_up_db_get_counts', array( $this, 'ajax_get_counts' ) );
		add_action( 'wp_ajax_up_db_run_cleanup', array( $this, 'ajax_run_cleanup' ) );
		add_action( 'wp_ajax_up_db_run_all', array( $this, 'ajax_run_all' ) );

		// Scheduled cleanup.
		add_action( 'up_scheduled_db_cleanup', array( $this, 'run_scheduled_cleanup' ) );

		// Register custom cron schedules.
		add_filter( 'cron_schedules', array( $this, 'add_cron_schedules' ) );

		// Manage cron based on settings.
		$this->manage_cron_schedule();
	}

	/**
	 * Add custom cron schedules.
	 *
	 * @since  1.0.0
	 * @param  array $schedules Existing cron schedules.
	 * @return array Modified schedules.
	 */
	public function add_cron_schedules( $schedules ) {
		$schedules['up_weekly'] = array(
			'interval' => WEEK_IN_SECONDS,
			'display'  => __( 'Once Weekly', 'ultimate-performance' ),
		);
		$schedules['up_monthly'] = array(
			'interval' => MONTH_IN_SECONDS,
			'display'  => __( 'Once Monthly', 'ultimate-performance' ),
		);
		return $schedules;
	}

	/**
	 * Manage the cron schedule based on current settings.
	 *
	 * @since 1.0.0
	 */
	private function manage_cron_schedule() {
		$schedule = $this->settings['schedule'] ?? 'disabled';

		if ( 'disabled' === $schedule || empty( $this->settings['enabled'] ) ) {
			wp_clear_scheduled_hook( 'up_scheduled_db_cleanup' );
			return;
		}

		$recurrence_map = array(
			'daily'   => 'daily',
			'weekly'  => 'up_weekly',
			'monthly' => 'up_monthly',
		);

		$recurrence = $recurrence_map[ $schedule ] ?? null;
		if ( ! $recurrence ) {
			return;
		}

		$next = wp_next_scheduled( 'up_scheduled_db_cleanup' );
		if ( ! $next ) {
			wp_schedule_event( time(), $recurrence, 'up_scheduled_db_cleanup' );
		}
	}

	/**
	 * Run the scheduled cleanup.
	 *
	 * @since 1.0.0
	 */
	public function run_scheduled_cleanup() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'database' );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		$keep = absint( $this->settings['revisions_keep'] ?? 5 );
		$this->clean_revisions( $keep );

		if ( ! empty( $this->settings['clean_auto_drafts'] ) ) {
			$this->clean_auto_drafts();
		}
		if ( ! empty( $this->settings['clean_trashed'] ) ) {
			$this->clean_trashed_posts();
			$this->clean_trashed_comments();
		}
		if ( ! empty( $this->settings['clean_spam'] ) ) {
			$this->clean_spam_comments();
		}
		if ( ! empty( $this->settings['clean_transients'] ) ) {
			$this->clean_expired_transients();
		}
		if ( ! empty( $this->settings['clean_orphans'] ) ) {
			$this->clean_orphaned_postmeta();
			$this->clean_orphaned_commentmeta();
			$this->clean_orphaned_relationships();
		}
		if ( ! empty( $this->settings['optimize_tables'] ) ) {
			$this->optimize_tables();
		}
	}

	/**
	 * AJAX: Get cleanup item counts.
	 *
	 * @since 1.0.0
	 */
	public function ajax_get_counts() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$keep = absint( Ultimate_Performance_Settings::get_module_settings( 'database' )['revisions_keep'] ?? 5 );

		$counts = array(
			'revisions'              => $this->count_revisions( $keep ),
			'auto_drafts'            => $this->count_auto_drafts(),
			'trashed_posts'          => $this->count_trashed_posts(),
			'spam_comments'          => $this->count_spam_comments(),
			'trashed_comments'       => $this->count_trashed_comments(),
			'expired_transients'     => $this->count_expired_transients(),
			'orphaned_postmeta'      => $this->count_orphaned_postmeta(),
			'orphaned_commentmeta'   => $this->count_orphaned_commentmeta(),
			'orphaned_relationships' => $this->count_orphaned_relationships(),
		);

		wp_send_json_success( array( 'counts' => $counts ) );
	}

	/**
	 * AJAX: Run a specific cleanup type.
	 *
	 * @since 1.0.0
	 */
	public function ajax_run_cleanup() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$type = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : '';
		$keep = absint( Ultimate_Performance_Settings::get_module_settings( 'database' )['revisions_keep'] ?? 5 );

		$deleted = 0;

		switch ( $type ) {
			case 'revisions':
				$deleted = $this->clean_revisions( $keep );
				break;
			case 'auto_drafts':
				$deleted = $this->clean_auto_drafts();
				break;
			case 'trashed_posts':
				$deleted = $this->clean_trashed_posts();
				break;
			case 'spam_comments':
				$deleted = $this->clean_spam_comments();
				break;
			case 'trashed_comments':
				$deleted = $this->clean_trashed_comments();
				break;
			case 'expired_transients':
				$deleted = $this->clean_expired_transients();
				break;
			case 'orphaned_postmeta':
				$deleted = $this->clean_orphaned_postmeta();
				break;
			case 'orphaned_commentmeta':
				$deleted = $this->clean_orphaned_commentmeta();
				break;
			case 'orphaned_relationships':
				$deleted = $this->clean_orphaned_relationships();
				break;
			case 'optimize_tables':
				$this->optimize_tables();
				$deleted = 0;
				break;
			default:
				wp_send_json_error( array( 'message' => __( 'Unknown cleanup type.', 'ultimate-performance' ) ), 400 );
		}

		/* translators: %d: number of items cleaned */
		$message = sprintf( __( 'Cleaned %d items.', 'ultimate-performance' ), $deleted );
		if ( 'optimize_tables' === $type ) {
			$message = __( 'Tables optimized successfully.', 'ultimate-performance' );
		}

		wp_send_json_success( array( 'message' => $message, 'deleted' => $deleted ) );
	}

	/**
	 * AJAX: Run all cleanup types.
	 *
	 * @since 1.0.0
	 */
	public function ajax_run_all() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$keep  = absint( Ultimate_Performance_Settings::get_module_settings( 'database' )['revisions_keep'] ?? 5 );
		$total = 0;

		$total += $this->clean_revisions( $keep );
		$total += $this->clean_auto_drafts();
		$total += $this->clean_trashed_posts();
		$total += $this->clean_spam_comments();
		$total += $this->clean_trashed_comments();
		$total += $this->clean_expired_transients();
		$total += $this->clean_orphaned_postmeta();
		$total += $this->clean_orphaned_commentmeta();
		$total += $this->clean_orphaned_relationships();
		$this->optimize_tables();

		wp_send_json_success( array(
			/* translators: %d: total number of items cleaned */
			'message' => sprintf( __( 'Cleaned %d items and optimized tables.', 'ultimate-performance' ), $total ),
			'deleted' => $total,
		) );
	}

	// =========================================================================
	// Count Methods
	// =========================================================================
	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Database optimization requires direct queries; caching is inappropriate for cleanup operations.

	/**
	 * Count deletable revisions.
	 *
	 * @since  1.0.0
	 * @param  int $keep Number of revisions to keep per post.
	 * @return int
	 */
	public function count_revisions( $keep = 5 ) {
		global $wpdb;

		if ( 0 === $keep ) {
			return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision'" );
		}

		// Count revisions beyond the keep-last-N per parent post.
		$count = 0;
		$parents = $wpdb->get_col( "SELECT DISTINCT post_parent FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_parent > 0" );

		foreach ( $parents as $parent_id ) {
			$total_revisions = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_parent = %d",
				$parent_id
			) );

			if ( $total_revisions > $keep ) {
				$count += ( $total_revisions - $keep );
			}
		}

		return $count;
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function count_auto_drafts() {
		global $wpdb;
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'auto-draft'" );
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function count_trashed_posts() {
		global $wpdb;
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'trash'" );
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function count_spam_comments() {
		global $wpdb;
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_approved = 'spam'" );
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function count_trashed_comments() {
		global $wpdb;
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_approved = 'trash'" );
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function count_expired_transients() {
		global $wpdb;
		$time = time();
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d",
			$wpdb->esc_like( '_transient_timeout_' ) . '%',
			$time
		) );
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function count_orphaned_postmeta() {
		global $wpdb;
		return (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID WHERE p.ID IS NULL"
		);
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function count_orphaned_commentmeta() {
		global $wpdb;
		return (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->commentmeta} cm LEFT JOIN {$wpdb->comments} c ON cm.comment_id = c.comment_ID WHERE c.comment_ID IS NULL"
		);
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function count_orphaned_relationships() {
		global $wpdb;
		return (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->term_relationships} tr LEFT JOIN {$wpdb->posts} p ON tr.object_id = p.ID WHERE p.ID IS NULL"
		);
	}

	// =========================================================================
	// Cleanup Methods
	// =========================================================================

	/**
	 * Clean post revisions, keeping the last N per post.
	 *
	 * @since  1.0.0
	 * @param  int $keep Number of revisions to keep per post.
	 * @return int Number of deleted revisions.
	 */
	public function clean_revisions( $keep = 5 ) {
		global $wpdb;

		if ( 0 === $keep ) {
			$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision'" );
			$wpdb->query( "DELETE FROM {$wpdb->posts} WHERE post_type = 'revision'" );
			return $count;
		}

		$deleted = 0;
		$parents = $wpdb->get_col( "SELECT DISTINCT post_parent FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_parent > 0" );

		foreach ( $parents as $parent_id ) {
			$revision_ids = $wpdb->get_col( $wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_parent = %d ORDER BY post_date DESC",
				$parent_id
			) );

			$to_delete = array_slice( $revision_ids, $keep );

			if ( ! empty( $to_delete ) ) {
				$placeholders = implode( ',', array_fill( 0, count( $to_delete ), '%d' ) );
				$wpdb->query( $wpdb->prepare(
					"DELETE FROM {$wpdb->posts} WHERE ID IN ($placeholders)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
					$to_delete
				) );
				$deleted += count( $to_delete );
			}
		}

		return $deleted;
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function clean_auto_drafts() {
		global $wpdb;
		$count = $this->count_auto_drafts();
		$wpdb->query( "DELETE FROM {$wpdb->posts} WHERE post_status = 'auto-draft'" );
		return $count;
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function clean_trashed_posts() {
		global $wpdb;
		$count = $this->count_trashed_posts();
		$wpdb->query( "DELETE FROM {$wpdb->posts} WHERE post_status = 'trash'" );
		return $count;
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function clean_spam_comments() {
		global $wpdb;
		$count = $this->count_spam_comments();
		$wpdb->query( "DELETE FROM {$wpdb->comments} WHERE comment_approved = 'spam'" );
		return $count;
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function clean_trashed_comments() {
		global $wpdb;
		$count = $this->count_trashed_comments();
		$wpdb->query( "DELETE FROM {$wpdb->comments} WHERE comment_approved = 'trash'" );
		return $count;
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function clean_expired_transients() {
		global $wpdb;
		$time  = time();
		$count = $this->count_expired_transients();

		// Get expired transient names.
		$expired = $wpdb->get_col( $wpdb->prepare(
			"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d",
			$wpdb->esc_like( '_transient_timeout_' ) . '%',
			$time
		) );

		foreach ( $expired as $transient_timeout ) {
			$transient_name = str_replace( '_transient_timeout_', '', $transient_timeout );
			delete_transient( $transient_name );
		}

		return $count;
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function clean_orphaned_postmeta() {
		global $wpdb;
		$count = $this->count_orphaned_postmeta();
		$wpdb->query(
			"DELETE pm FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID WHERE p.ID IS NULL"
		);
		return $count;
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function clean_orphaned_commentmeta() {
		global $wpdb;
		$count = $this->count_orphaned_commentmeta();
		$wpdb->query(
			"DELETE cm FROM {$wpdb->commentmeta} cm LEFT JOIN {$wpdb->comments} c ON cm.comment_id = c.comment_ID WHERE c.comment_ID IS NULL"
		);
		return $count;
	}

	/**
	 * @since  1.0.0
	 * @return int
	 */
	public function clean_orphaned_relationships() {
		global $wpdb;
		$count = $this->count_orphaned_relationships();
		$wpdb->query(
			"DELETE tr FROM {$wpdb->term_relationships} tr LEFT JOIN {$wpdb->posts} p ON tr.object_id = p.ID WHERE p.ID IS NULL"
		);
		return $count;
	}

	/**
	 * Optimize all WordPress database tables.
	 *
	 * @since 1.0.0
	 */
	public function optimize_tables() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$tables = $wpdb->get_col( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->esc_like( $wpdb->prefix ) . '%' ) );

		foreach ( $tables as $table ) {
			// Validate table name contains only safe characters before interpolation.
			if ( preg_match( '/^[a-zA-Z0-9_]+$/', $table ) ) {
				$wpdb->query( "OPTIMIZE TABLE `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter
			}
		}
	}
	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
}
