<?php
/**
 * Used CSS (UCSS) and Critical CSS generation.
 *
 * Strips unused CSS selectors per page and optionally extracts
 * above-the-fold critical CSS for inline injection.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_UCSS
 *
 * Hybrid UCSS engine: PHP-based DOMDocument selector matching
 * by default, with a filter hook for external API override.
 *
 * @since 1.5.0
 */
class Ultimate_Performance_UCSS {

	/**
	 * Module settings from up_settings['css_js'].
	 *
	 * @var array
	 */
	private $settings = array();

	/**
	 * Parsed safelist patterns.
	 *
	 * @var array
	 */
	private $safelist = array();

	/**
	 * Parsed excluded URL patterns.
	 *
	 * @var array
	 */
	private $excluded_urls = array();

	/**
	 * Parsed excluded stylesheet handles.
	 *
	 * @var array
	 */
	private $excluded_handles = array();

	/**
	 * Cache directory path.
	 *
	 * @var string
	 */
	private $cache_dir = '';

	/**
	 * Cache directory URL.
	 *
	 * @var string
	 */
	private $cache_url = '';

	/**
	 * Whether UCSS replacement has already been applied for this request.
	 *
	 * @var bool
	 */
	private $ucss_replaced = false;

	/**
	 * Collected stylesheet URLs during output buffer capture.
	 *
	 * @var array
	 */
	private $collected_stylesheets = array();

	/**
	 * Stylesheet handles that were collected into the UCSS file.
	 *
	 * Only these handles should be replaced/removed by replace_with_ucss().
	 *
	 * @var array
	 */
	private $collected_handles = array();

	/**
	 * Initialize the UCSS module.
	 *
	 * @since 1.5.0
	 */
	public function init() {
		$this->settings  = Ultimate_Performance_Settings::get_module_settings( 'css_js' );
		$this->cache_dir = WP_CONTENT_DIR . '/cache/ultimate-performance/ucss/';
		$this->cache_url = content_url( '/cache/ultimate-performance/ucss/' );

		// AJAX endpoints — always registered so the status panel works.
		add_action( 'wp_ajax_up_ucss_status', array( $this, 'ajax_ucss_status' ) );
		add_action( 'wp_ajax_up_ucss_purge', array( $this, 'ajax_ucss_purge' ) );

		// Ensure the DB table exists (covers upgrades without re-activation).
		$this->maybe_create_table();

		if ( empty( $this->settings['enabled'] ) || empty( $this->settings['ucss_enabled'] ) ) {
			return;
		}

		$this->parse_exclusions();

		// Output buffer to capture HTML for UCSS generation.
		add_action( 'template_redirect', array( $this, 'maybe_start_ucss_buffer' ), 2 );

		// Inject critical CSS in <head> if available.
		add_action( 'wp_head', array( $this, 'inject_critical_css' ), 1 );

		// Replace stylesheets with UCSS version.
		add_filter( 'style_loader_tag', array( $this, 'replace_with_ucss' ), 40, 4 );

		// Cache invalidation hooks.
		add_action( 'save_post', array( $this, 'purge_post_ucss' ), 10, 1 );
		add_action( 'switch_theme', array( $this, 'purge_all_ucss' ) );
		add_action( 'ultimate_performance_purge_all_cache', array( $this, 'purge_all_ucss' ) );
		add_action( 'customize_save_after', array( $this, 'purge_all_ucss' ) );

		// WP Cron for regeneration.
		add_action( 'up_ucss_regeneration', array( $this, 'regenerate_via_cron' ) );
		if ( ! wp_next_scheduled( 'up_ucss_regeneration' ) ) {
			wp_schedule_event( time(), 'daily', 'up_ucss_regeneration' );
		}
	}

	/**
	 * Create the UCSS cache table if it doesn't exist yet.
	 *
	 * Runs once per version bump so upgrades without re-activation are covered.
	 *
	 * @since 1.5.0
	 */
	private function maybe_create_table() {
		$installed_ver = get_option( 'up_ucss_db_version', '' );
		$current_ver   = '1.0.0';

		if ( $installed_ver === $current_ver ) {
			return;
		}

		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$wpdb->prefix}up_ucss_cache (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			url varchar(2083) NOT NULL,
			url_hash char(32) NOT NULL,
			post_id bigint(20) unsigned DEFAULT 0,
			ucss_path varchar(512) DEFAULT '',
			critical_path varchar(512) DEFAULT '',
			original_size bigint(20) unsigned DEFAULT 0,
			ucss_size bigint(20) unsigned DEFAULT 0,
			status varchar(20) NOT NULL DEFAULT 'pending',
			generated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			expires_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY url_hash (url_hash),
			KEY post_id (post_id),
			KEY status (status),
			KEY expires_at (expires_at)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		update_option( 'up_ucss_db_version', $current_ver );
	}

	// ------------------------------------------------------------------
	// Output Buffer & Generation
	// ------------------------------------------------------------------

	/**
	 * Start output buffer to capture HTML for UCSS generation.
	 *
	 * Only triggers when no UCSS cache exists for the current URL.
	 *
	 * @since 1.5.0
	 */
	public function maybe_start_ucss_buffer() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || defined( 'REST_REQUEST' ) ) {
			return;
		}

		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'GET' !== strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) ) {
			return;
		}

		$url = $this->get_current_url();

		if ( $this->is_excluded_url( $url ) ) {
			return;
		}

		// If cache already exists and not expired, skip buffer.
		if ( $this->has_valid_cache( $url ) ) {
			return;
		}

		ob_start( array( $this, 'process_ucss_from_html' ) );
	}

	/**
	 * Process captured HTML to generate UCSS.
	 *
	 * This is the output buffer callback. Returns HTML unmodified —
	 * UCSS is applied on the NEXT page load via replace_with_ucss().
	 *
	 * @since 1.5.0
	 * @param string $html Full page HTML.
	 * @return string Unmodified HTML.
	 */
	public function process_ucss_from_html( $html ) {
		if ( empty( $html ) || strlen( $html ) < 100 ) {
			return $html;
		}

		// Only process text/html responses.
		$content_type = '';
		foreach ( headers_list() as $header ) {
			if ( stripos( $header, 'content-type:' ) === 0 ) {
				$content_type = $header;
				break;
			}
		}
		if ( $content_type && stripos( $content_type, 'text/html' ) === false ) {
			return $html;
		}

		$url = $this->get_current_url();

		// Collect stylesheet URLs from the HTML.
		$css_sources = $this->collect_css_from_html( $html );
		if ( empty( $css_sources ) ) {
			return $html;
		}

		/**
		 * Filter to allow external API override of UCSS generation.
		 *
		 * Return a non-null string to override the PHP engine.
		 *
		 * @since 1.5.0
		 * @param null|string $ucss        Null to use PHP engine, or generated UCSS string.
		 * @param string      $html        Full page HTML.
		 * @param array       $css_sources Array of CSS source data.
		 * @param string      $url         Current page URL.
		 */
		$external_ucss = apply_filters( 'ultimate_performance_ucss_generation', null, $html, $css_sources, $url );

		if ( is_string( $external_ucss ) ) {
			$used_css = $external_ucss;
		} else {
			$used_css = $this->generate_ucss_php( $html, $css_sources );
		}

		if ( empty( $used_css ) ) {
			return $html;
		}

		// Calculate original size.
		$original_size = 0;
		foreach ( $css_sources as $source ) {
			$original_size += strlen( $source['content'] );
		}

		// Safety: if UCSS is larger than original, discard.
		if ( strlen( $used_css ) >= $original_size ) {
			return $html;
		}

		// Generate critical CSS if enabled.
		$critical_css = '';
		if ( ! empty( $this->settings['ucss_critical_css'] ) ) {
			$critical_css = $this->extract_critical_css( $used_css, $html );
		}

		// Collect handles that were included in the UCSS.
		$handles = array();
		foreach ( $css_sources as $source ) {
			if ( ! empty( $source['handle'] ) ) {
				$handles[] = $source['handle'];
			}
		}

		$this->save_ucss_cache( $url, $used_css, $critical_css, $original_size, $handles );

		return $html;
	}

	// ------------------------------------------------------------------
	// PHP UCSS Engine
	// ------------------------------------------------------------------

	/**
	 * Generate used CSS via PHP DOM parsing and selector matching.
	 *
	 * @since 1.5.0
	 * @param string $html        Full page HTML.
	 * @param array  $css_sources Array of CSS source data with 'content' key.
	 * @return string Used CSS rules concatenated and minified.
	 */
	private function generate_ucss_php( $html, $css_sources ) {
		$dom_data = $this->parse_dom_data( $html );
		if ( empty( $dom_data['tags'] ) ) {
			return '';
		}

		$used_css = '';

		foreach ( $css_sources as $source ) {
			$css = $source['content'];
			if ( empty( $css ) ) {
				continue;
			}

			$used_css .= $this->filter_used_rules( $css, $dom_data );
		}

		if ( empty( $used_css ) ) {
			return '';
		}

		return Ultimate_Performance_Minifier::minify_css( $used_css );
	}

	/**
	 * Parse HTML and extract DOM data for selector matching.
	 *
	 * Builds sets of all tag names, IDs, and classes found in the DOM.
	 *
	 * @since 1.5.0
	 * @param string $html Full page HTML.
	 * @return array Associative array with 'tags', 'ids', 'classes' keys.
	 */
	private function parse_dom_data( $html ) {
		$data = array(
			'tags'    => array(),
			'ids'     => array(),
			'classes' => array(),
		);

		$prev = libxml_use_internal_errors( true );
		$doc  = new DOMDocument();

		if ( ! $doc->loadHTML( '<?xml encoding="UTF-8">' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NOWARNING ) ) {
			libxml_use_internal_errors( $prev );
			return $data;
		}

		libxml_clear_errors();
		libxml_use_internal_errors( $prev );

		$xpath    = new DOMXPath( $doc );
		$elements = $xpath->query( '//*' );

		if ( false === $elements ) {
			return $data;
		}

		foreach ( $elements as $element ) {
			$data['tags'][ strtolower( $element->nodeName ) ] = true;

			$id = $element->getAttribute( 'id' );
			if ( '' !== $id ) {
				$data['ids'][ $id ] = true;
			}

			$class_attr = $element->getAttribute( 'class' );
			if ( '' !== $class_attr ) {
				$classes = preg_split( '/\s+/', trim( $class_attr ) );
				foreach ( $classes as $cls ) {
					if ( '' !== $cls ) {
						$data['classes'][ $cls ] = true;
					}
				}
			}
		}

		return $data;
	}

	/**
	 * Filter CSS to keep only rules that match the DOM or safelist.
	 *
	 * Handles nested @media, @keyframes, @font-face, and @supports blocks.
	 *
	 * @since 1.5.0
	 * @param string $css      Raw CSS content.
	 * @param array  $dom_data DOM data from parse_dom_data().
	 * @return string Filtered CSS.
	 */
	private function filter_used_rules( $css, $dom_data ) {
		$output = '';
		$len    = strlen( $css );
		$i      = 0;

		while ( $i < $len ) {
			// Skip whitespace.
			while ( $i < $len && ctype_space( $css[ $i ] ) ) {
				$i++;
			}

			if ( $i >= $len ) {
				break;
			}

			// Skip CSS comments.
			if ( $i + 1 < $len && '/' === $css[ $i ] && '*' === $css[ $i + 1 ] ) {
				$end = strpos( $css, '*/', $i + 2 );
				$i   = ( false === $end ) ? $len : $end + 2;
				continue;
			}

			// Handle @-rules.
			if ( '@' === $css[ $i ] ) {
				$at_rule = $this->extract_at_rule( $css, $i, $len );
				if ( false === $at_rule ) {
					$i++;
					continue;
				}

				$at_name = strtolower( $at_rule['name'] );

				// Always keep these at-rules entirely.
				if ( in_array( $at_name, array( '@keyframes', '@-webkit-keyframes', '@font-face', '@charset', '@import', '@namespace' ), true ) ) {
					$output .= $at_rule['content'];
				} elseif ( in_array( $at_name, array( '@media', '@supports', '@layer' ), true ) ) {
					// Recurse into conditional at-rules.
					$inner_css      = $at_rule['inner'];
					$filtered_inner = $this->filter_used_rules( $inner_css, $dom_data );
					if ( '' !== trim( $filtered_inner ) ) {
						$output .= $at_rule['prelude'] . '{' . $filtered_inner . '}';
					}
				} else {
					// Unknown at-rule — keep it (safe approach).
					$output .= $at_rule['content'];
				}

				$i = $at_rule['end'];
				continue;
			}

			// Regular rule: selector { declarations }.
			$brace_pos = strpos( $css, '{', $i );
			if ( false === $brace_pos ) {
				break;
			}

			$selector_text = trim( substr( $css, $i, $brace_pos - $i ) );
			$block_end     = $this->find_matching_brace( $css, $brace_pos, $len );
			$declarations  = substr( $css, $brace_pos, $block_end - $brace_pos + 1 );

			if ( $this->selector_group_matches( $selector_text, $dom_data ) ) {
				$output .= $selector_text . $declarations;
			}

			$i = $block_end + 1;
		}

		return $output;
	}

	/**
	 * Extract an at-rule block starting at position $i.
	 *
	 * @since 1.5.0
	 * @param string $css CSS content.
	 * @param int    $i   Start position.
	 * @param int    $len Total length.
	 * @return array|false At-rule data or false on failure.
	 */
	private function extract_at_rule( $css, $i, $len ) {
		// Extract the at-rule name (e.g., @media, @keyframes).
		$name_end = $i + 1;
		while ( $name_end < $len && preg_match( '/[a-zA-Z\-]/', $css[ $name_end ] ) ) {
			$name_end++;
		}
		$name = strtolower( substr( $css, $i, $name_end - $i ) );

		// Find the opening brace or semicolon.
		$brace_pos = strpos( $css, '{', $name_end );
		$semi_pos  = strpos( $css, ';', $name_end );

		// Statement at-rules (no block) like @import, @charset.
		if ( false === $brace_pos || ( false !== $semi_pos && $semi_pos < $brace_pos ) ) {
			$end_pos = ( false !== $semi_pos ) ? $semi_pos + 1 : $len;
			return array(
				'name'    => $name,
				'content' => substr( $css, $i, $end_pos - $i ),
				'prelude' => '',
				'inner'   => '',
				'end'     => $end_pos,
			);
		}

		$prelude   = trim( substr( $css, $i, $brace_pos - $i ) );
		$block_end = $this->find_matching_brace( $css, $brace_pos, $len );
		$inner     = substr( $css, $brace_pos + 1, $block_end - $brace_pos - 1 );

		return array(
			'name'    => $name,
			'content' => substr( $css, $i, $block_end - $i + 1 ),
			'prelude' => $prelude,
			'inner'   => $inner,
			'end'     => $block_end + 1,
		);
	}

	/**
	 * Find the position of the matching closing brace.
	 *
	 * @since 1.5.0
	 * @param string $css   CSS content.
	 * @param int    $start Position of opening brace.
	 * @param int    $len   Total length.
	 * @return int Position of matching closing brace.
	 */
	private function find_matching_brace( $css, $start, $len ) {
		$depth = 1;
		$j     = $start + 1;

		while ( $j < $len && $depth > 0 ) {
			if ( '{' === $css[ $j ] ) {
				$depth++;
			} elseif ( '}' === $css[ $j ] ) {
				$depth--;
			} elseif ( '/' === $css[ $j ] && $j + 1 < $len && '*' === $css[ $j + 1 ] ) {
				// Skip comments inside blocks.
				$end = strpos( $css, '*/', $j + 2 );
				$j   = ( false === $end ) ? $len : $end + 1;
			} elseif ( '"' === $css[ $j ] || "'" === $css[ $j ] ) {
				// Skip string literals.
				$quote = $css[ $j ];
				$j++;
				while ( $j < $len && $css[ $j ] !== $quote ) {
					if ( '\\' === $css[ $j ] ) {
						$j++;
					}
					$j++;
				}
			}
			$j++;
		}

		return min( $j - 1, $len - 1 );
	}

	/**
	 * Check if a comma-separated selector group matches the DOM.
	 *
	 * @since 1.5.0
	 * @param string $selector_text Comma-separated selectors.
	 * @param array  $dom_data      DOM data.
	 * @return bool True if any selector in the group matches.
	 */
	private function selector_group_matches( $selector_text, $dom_data ) {
		if ( empty( $selector_text ) ) {
			return false;
		}

		// Split by comma (top-level only, not inside parentheses).
		$selectors = $this->split_selector_group( $selector_text );

		foreach ( $selectors as $selector ) {
			$selector = trim( $selector );
			if ( '' === $selector ) {
				continue;
			}

			if ( $this->selector_matches_dom( $selector, $dom_data ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Split a comma-separated selector group respecting parentheses.
	 *
	 * @since 1.5.0
	 * @param string $text Selector group text.
	 * @return array Individual selectors.
	 */
	private function split_selector_group( $text ) {
		$selectors = array();
		$current   = '';
		$depth     = 0;
		$len       = strlen( $text );

		for ( $i = 0; $i < $len; $i++ ) {
			$ch = $text[ $i ];
			if ( '(' === $ch ) {
				$depth++;
			} elseif ( ')' === $ch ) {
				$depth--;
			} elseif ( ',' === $ch && 0 === $depth ) {
				$selectors[] = $current;
				$current     = '';
				continue;
			}
			$current .= $ch;
		}

		if ( '' !== $current ) {
			$selectors[] = $current;
		}

		return $selectors;
	}

	/**
	 * Check if a single CSS selector matches the DOM data.
	 *
	 * Conservative approach: keeps selector if unsure.
	 *
	 * @since 1.5.0
	 * @param string $selector Single CSS selector.
	 * @param array  $dom_data DOM data with tags, ids, classes.
	 * @return bool True if selector matches or is safelisted.
	 */
	private function selector_matches_dom( $selector, $dom_data ) {
		// Check safelist first.
		if ( $this->is_safelisted( $selector ) ) {
			return true;
		}

		// Universal/root selectors always match.
		if ( in_array( $selector, array( '*', ':root', 'html', 'body' ), true ) ) {
			return true;
		}

		// CSS custom properties on :root — always keep.
		if ( strpos( $selector, ':root' ) !== false ) {
			return true;
		}

		// Pseudo-elements — always keep if base matches (can't detect in static HTML).
		$has_pseudo_element = (bool) preg_match( '/::(?:before|after|placeholder|first-line|first-letter|selection|marker|backdrop|-webkit-|-moz-)/', $selector );

		// Strip pseudo-elements and pseudo-classes for matching,
		// handling nested parentheses in :is(), :not(), :where(), :nth-child(), etc.
		$clean = $this->strip_pseudo_selectors( $selector );
		$clean = trim( $clean );

		if ( '' === $clean || '*' === $clean ) {
			return true;
		}

		// Split compound selector by combinators (space, >, +, ~).
		$parts = preg_split( '/[\s>+~]+/', $clean, -1, PREG_SPLIT_NO_EMPTY );

		foreach ( $parts as $part ) {
			if ( ! $this->simple_selector_matches( $part, $dom_data ) ) {
				// If pseudo-element attached, be conservative and keep.
				if ( $has_pseudo_element ) {
					return true;
				}
				return false;
			}
		}

		return true;
	}

	/**
	 * Check if a simple selector (no combinators) matches DOM data.
	 *
	 * @since 1.5.0
	 * @param string $selector Simple selector like "div", ".foo", "#bar", "div.foo".
	 * @param array  $dom_data DOM data.
	 * @return bool True if it potentially matches.
	 */
	private function simple_selector_matches( $selector, $dom_data ) {
		// Extract tag, ids, classes from the simple selector.
		// Match tag name.
		$tag_match = array();
		if ( preg_match( '/^([a-zA-Z][a-zA-Z0-9\-]*)/', $selector, $tag_match ) ) {
			$tag = strtolower( $tag_match[1] );
			if ( ! isset( $dom_data['tags'][ $tag ] ) ) {
				return false;
			}
		}

		// Match IDs.
		$id_matches = array();
		if ( preg_match_all( '/#([a-zA-Z_][a-zA-Z0-9_\-]*)/', $selector, $id_matches ) ) {
			foreach ( $id_matches[1] as $id ) {
				if ( ! isset( $dom_data['ids'][ $id ] ) ) {
					return false;
				}
			}
		}

		// Match classes.
		$class_matches = array();
		if ( preg_match_all( '/\.([a-zA-Z_][a-zA-Z0-9_\-]*)/', $selector, $class_matches ) ) {
			foreach ( $class_matches[1] as $cls ) {
				if ( ! isset( $dom_data['classes'][ $cls ] ) ) {
					// Check safelist for this class.
					if ( $this->is_safelisted( '.' . $cls ) ) {
						continue;
					}
					return false;
				}
			}
		}

		// Attribute selectors — be conservative, keep them.
		if ( strpos( $selector, '[' ) !== false ) {
			return true;
		}

		return true;
	}

	/**
	 * Strip pseudo-classes and pseudo-elements from a selector.
	 *
	 * Handles nested parentheses correctly for :is(), :not(), :where(), etc.
	 *
	 * @since 1.5.0
	 * @param string $selector CSS selector.
	 * @return string Selector with pseudo-classes/elements removed.
	 */
	private function strip_pseudo_selectors( $selector ) {
		$result = '';
		$len    = strlen( $selector );
		$i      = 0;

		while ( $i < $len ) {
			// Detect pseudo-class or pseudo-element (single or double colon).
			if ( ':' === $selector[ $i ] ) {
				// Skip the colon(s).
				$i++;
				if ( $i < $len && ':' === $selector[ $i ] ) {
					$i++;
				}
				// Skip the pseudo name (letters, hyphens).
				while ( $i < $len && preg_match( '/[a-zA-Z\-]/', $selector[ $i ] ) ) {
					$i++;
				}
				// If followed by '(', skip the entire parenthesized content with nesting.
				if ( $i < $len && '(' === $selector[ $i ] ) {
					$depth = 1;
					$i++;
					while ( $i < $len && $depth > 0 ) {
						if ( '(' === $selector[ $i ] ) {
							$depth++;
						} elseif ( ')' === $selector[ $i ] ) {
							$depth--;
						}
						$i++;
					}
				}
				continue;
			}

			$result .= $selector[ $i ];
			$i++;
		}

		return $result;
	}

	/**
	 * Check if a selector or class matches any safelist pattern.
	 *
	 * @since 1.5.0
	 * @param string $selector Selector to check.
	 * @return bool True if safelisted.
	 */
	private function is_safelisted( $selector ) {
		foreach ( $this->safelist as $pattern ) {
			if ( $pattern === $selector ) {
				return true;
			}

			// Wildcard matching.
			if ( substr( $pattern, -1 ) === '*' ) {
				$prefix = substr( $pattern, 0, -1 );
				if ( strpos( $selector, $prefix ) !== false ) {
					return true;
				}
			}

			// Check if pattern matches inside the selector string.
			if ( strpos( $selector, $pattern ) !== false ) {
				return true;
			}
		}

		return false;
	}

	// ------------------------------------------------------------------
	// Critical CSS Extraction
	// ------------------------------------------------------------------

	/**
	 * Extract above-the-fold critical CSS from used CSS.
	 *
	 * Uses heuristic element detection for viewport-visible content.
	 *
	 * @since 1.5.0
	 * @param string $used_css Used CSS content.
	 * @param string $html     Full page HTML.
	 * @return string Critical CSS.
	 */
	private function extract_critical_css( $used_css, $html ) {
		// Identify above-the-fold element signatures.
		$critical_tags    = array( 'html', 'body', 'header', 'nav', 'main', 'h1', 'h2', 'h3', 'img', 'a', 'p', 'ul', 'ol', 'li', 'section', 'div', 'span', 'button', 'input', 'form' );
		$critical_classes = array();

		// Extract classes from known above-fold HTML patterns.
		$atf_patterns = array(
			'/<header[^>]*class=["\']([^"\']*)["\']/',
			'/<nav[^>]*class=["\']([^"\']*)["\']/',
			'/<section[^>]*class=["\']([^"\']*)["\']/',
			'/<div[^>]*class=["\']([^"\']*)["\']/',
		);

		// Only look at the first ~20KB of HTML (above the fold heuristic).
		$head_html = substr( $html, 0, 20000 );

		foreach ( $atf_patterns as $pattern ) {
			$matches = array();
			if ( preg_match_all( $pattern, $head_html, $matches ) ) {
				foreach ( $matches[1] as $class_string ) {
					$cls_list = preg_split( '/\s+/', trim( $class_string ) );
					foreach ( $cls_list as $cls ) {
						if ( '' !== $cls ) {
							$critical_classes[ $cls ] = true;
						}
					}
				}
			}
		}

		// Common above-fold class patterns.
		$atf_class_patterns = array( 'hero', 'header', 'nav', 'banner', 'masthead', 'topbar', 'top-bar', 'site-header', 'page-header', 'main-nav', 'primary-nav', 'logo', 'brand', 'menu' );
		foreach ( $atf_class_patterns as $pattern ) {
			$critical_classes[ $pattern ] = true;
		}

		// Build critical CSS: keep @font-face, :root vars, and rules targeting ATF elements.
		$critical = '';
		$dom_data = array(
			'tags'    => array_fill_keys( $critical_tags, true ),
			'ids'     => array(),
			'classes' => $critical_classes,
		);

		// Parse the used CSS and filter for critical rules.
		$critical = $this->filter_critical_rules( $used_css, $dom_data );

		if ( empty( $critical ) ) {
			return '';
		}

		return Ultimate_Performance_Minifier::minify_css( $critical );
	}

	/**
	 * Filter used CSS for critical (above-the-fold) rules.
	 *
	 * @since 1.5.0
	 * @param string $css      Used CSS content.
	 * @param array  $dom_data Above-fold DOM data.
	 * @return string Critical CSS rules.
	 */
	private function filter_critical_rules( $css, $dom_data ) {
		$output = '';
		$len    = strlen( $css );
		$i      = 0;

		while ( $i < $len ) {
			while ( $i < $len && ctype_space( $css[ $i ] ) ) {
				$i++;
			}

			if ( $i >= $len ) {
				break;
			}

			if ( $i + 1 < $len && '/' === $css[ $i ] && '*' === $css[ $i + 1 ] ) {
				$end = strpos( $css, '*/', $i + 2 );
				$i   = ( false === $end ) ? $len : $end + 2;
				continue;
			}

			if ( '@' === $css[ $i ] ) {
				$at_rule = $this->extract_at_rule( $css, $i, $len );
				if ( false === $at_rule ) {
					$i++;
					continue;
				}

				$at_name = strtolower( $at_rule['name'] );

				// Always include @font-face and @keyframes in critical CSS.
				if ( in_array( $at_name, array( '@font-face', '@keyframes', '@-webkit-keyframes', '@charset', '@import' ), true ) ) {
					$output .= $at_rule['content'];
				} elseif ( in_array( $at_name, array( '@media', '@supports', '@layer' ), true ) ) {
					$inner    = $this->filter_critical_rules( $at_rule['inner'], $dom_data );
					if ( '' !== trim( $inner ) ) {
						$output .= $at_rule['prelude'] . '{' . $inner . '}';
					}
				}

				$i = $at_rule['end'];
				continue;
			}

			$brace_pos = strpos( $css, '{', $i );
			if ( false === $brace_pos ) {
				break;
			}

			$selector_text = trim( substr( $css, $i, $brace_pos - $i ) );
			$block_end     = $this->find_matching_brace( $css, $brace_pos, $len );
			$declarations  = substr( $css, $brace_pos, $block_end - $brace_pos + 1 );

			// Keep :root/:root vars, html, body rules.
			if ( preg_match( '/^(:root|html|body|\*)/', $selector_text ) ) {
				$output .= $selector_text . $declarations;
			} elseif ( $this->selector_group_matches( $selector_text, $dom_data ) ) {
				$output .= $selector_text . $declarations;
			}

			$i = $block_end + 1;
		}

		return $output;
	}

	// ------------------------------------------------------------------
	// Stylesheet Replacement & Critical CSS Injection
	// ------------------------------------------------------------------

	/**
	 * Replace individual stylesheets with the single UCSS file.
	 *
	 * Runs on `style_loader_tag` filter at priority 40.
	 *
	 * @since 1.5.0
	 * @param string $tag    Full link tag HTML.
	 * @param string $handle Stylesheet handle.
	 * @param string $href   Stylesheet URL.
	 * @param string $media  Media attribute.
	 * @return string Modified or empty tag.
	 */
	public function replace_with_ucss( $tag, $handle, $href, $media ) {
		if ( is_admin() ) {
			return $tag;
		}

		// Skip excluded handles.
		if ( in_array( $handle, $this->excluded_handles, true ) ) {
			return $tag;
		}

		// Skip plugin's own styles.
		if ( strpos( $handle, 'up-' ) === 0 ) {
			return $tag;
		}

		$url = $this->get_current_url();

		if ( ! $this->has_valid_cache( $url ) ) {
			return $tag;
		}

		// Load collected handles from the manifest file on first call.
		if ( empty( $this->collected_handles ) ) {
			$cache_key    = $this->get_cache_key( $url );
			$handles_path = $this->cache_dir . $cache_key . '.handles.json';

			if ( file_exists( $handles_path ) ) {
				$stored = json_decode( file_get_contents( $handles_path ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				if ( is_array( $stored ) ) {
					$this->collected_handles = $stored;
				}
			}
		}

		// Only remove/replace stylesheets that were actually included in the UCSS.
		// External stylesheets (CDN, Google Fonts, etc.) that weren't collected
		// must remain untouched to avoid breaking layouts.
		if ( ! empty( $this->collected_handles ) && ! in_array( $handle, $this->collected_handles, true ) ) {
			return $tag;
		}

		// If no handles manifest exists (legacy cache), fall back to only
		// replacing local stylesheets (heuristic: skip if href is external).
		if ( empty( $this->collected_handles ) ) {
			$site_host = wp_parse_url( home_url(), PHP_URL_HOST );
			$href_host = wp_parse_url( $href, PHP_URL_HOST );

			if ( $href_host && $href_host !== $site_host ) {
				return $tag;
			}
		}

		// First collected stylesheet gets replaced with the UCSS link; rest get removed.
		if ( $this->ucss_replaced ) {
			return '';
		}

		$this->ucss_replaced = true;

		$cache_key = $this->get_cache_key( $url );
		$ucss_url  = $this->cache_url . $cache_key . '.css';

		// If critical CSS is active, async-load the UCSS file.
		// phpcs:disable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- UCSS replaces original stylesheets via output buffer; cannot use wp_enqueue_style().
		if ( ! empty( $this->settings['ucss_critical_css'] ) && $this->has_critical_cache( $url ) ) {
			$ucss_tag  = sprintf(
				'<link rel="stylesheet" id="up-ucss" href="%s" media="print" onload="this.media=\'all\'">' . "\n",
				esc_url( $ucss_url )
			);
			$ucss_tag .= sprintf(
				'<noscript><link rel="stylesheet" href="%s"></noscript>' . "\n",
				esc_url( $ucss_url )
			);
			return $ucss_tag;
		}

		return sprintf(
			'<link rel="stylesheet" id="up-ucss" href="%s" media="%s">' . "\n",
			esc_url( $ucss_url ),
			esc_attr( $media ? $media : 'all' )
		);
		// phpcs:enable WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet
	}

	/**
	 * Inject critical CSS inline in the head.
	 *
	 * @since 1.5.0
	 */
	public function inject_critical_css() {
		if ( is_admin() || empty( $this->settings['ucss_critical_css'] ) ) {
			return;
		}

		$url = $this->get_current_url();

		if ( ! $this->has_critical_cache( $url ) ) {
			return;
		}

		$cache_key    = $this->get_cache_key( $url );
		$critical_path = $this->cache_dir . $cache_key . '.critical.css';

		if ( ! file_exists( $critical_path ) ) {
			return;
		}

		$critical_css = file_get_contents( $critical_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		if ( empty( $critical_css ) ) {
			return;
		}

		echo '<style id="up-critical-css">' . $critical_css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSS content from our own cache file.
	}

	// ------------------------------------------------------------------
	// CSS Collection from HTML
	// ------------------------------------------------------------------

	/**
	 * Collect CSS content from stylesheet links in the HTML.
	 *
	 * @since 1.5.0
	 * @param string $html Full page HTML.
	 * @return array Array of CSS source data with 'url', 'content', 'handle' keys.
	 */
	private function collect_css_from_html( $html ) {
		$sources = array();
		$matches = array();

		// Match <link rel="stylesheet" ...> tags.
		if ( ! preg_match_all( '/<link[^>]+rel=["\']stylesheet["\'][^>]*>/i', $html, $matches ) ) {
			return $sources;
		}

		$css_js = new Ultimate_Performance_CSS_JS();

		foreach ( $matches[0] as $link_tag ) {
			$href_match = array();
			if ( ! preg_match( '/href=["\']([^"\']+)["\']/', $link_tag, $href_match ) ) {
				continue;
			}

			$href       = $href_match[1];
			$local_path = $css_js->url_to_local_path( $href );

			if ( ! $local_path || ! file_exists( $local_path ) ) {
				continue;
			}

			$css_content = file_get_contents( $local_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

			if ( empty( $css_content ) ) {
				continue;
			}

			// Resolve relative URLs in CSS.
			$css_content = $css_js->resolve_css_urls( $css_content, $local_path );

			// Extract handle from id attribute if present.
			$handle       = '';
			$id_match     = array();
			if ( preg_match( '/id=["\']([^"\']+)-css["\']/', $link_tag, $id_match ) ) {
				$handle = $id_match[1];
			}

			// Skip excluded handles.
			if ( $handle && in_array( $handle, $this->excluded_handles, true ) ) {
				continue;
			}

			// Track this handle as collected so replace_with_ucss() knows
		// which stylesheets are safe to remove.
		if ( $handle ) {
			$this->collected_handles[] = $handle;
		}

		$sources[] = array(
				'url'     => $href,
				'content' => $css_content,
				'handle'  => $handle,
			);
		}

		return $sources;
	}

	// ------------------------------------------------------------------
	// Cache Management
	// ------------------------------------------------------------------

	/**
	 * Get a normalized cache key for a URL.
	 *
	 * @since 1.5.0
	 * @param string $url Page URL.
	 * @return string MD5 hash cache key.
	 */
	private function get_cache_key( $url ) {
		$normalized = strtok( $url, '?' );
		$normalized = untrailingslashit( $normalized );
		return md5( $normalized );
	}

	/**
	 * Check if valid (non-expired) UCSS cache exists for a URL.
	 *
	 * @since 1.5.0
	 * @param string $url Page URL.
	 * @return bool True if valid cache exists.
	 */
	private function has_valid_cache( $url ) {
		$cache_key = $this->get_cache_key( $url );
		$file_path = $this->cache_dir . $cache_key . '.css';

		if ( ! file_exists( $file_path ) ) {
			return false;
		}

		// Check expiry via DB.
		global $wpdb;
		$url_hash = $cache_key;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table query; not suitable for object cache.
		$record   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT status, expires_at FROM {$wpdb->prefix}up_ucss_cache WHERE url_hash = %s",
				$url_hash
			)
		);

		if ( ! $record ) {
			return false;
		}

		if ( 'generated' !== $record->status ) {
			return false;
		}

		// Check if expired.
		if ( '0000-00-00 00:00:00' !== $record->expires_at && strtotime( $record->expires_at ) < time() ) {
			return false;
		}

		return true;
	}

	/**
	 * Check if critical CSS cache exists for a URL.
	 *
	 * @since 1.5.0
	 * @param string $url Page URL.
	 * @return bool True if critical CSS cache file exists.
	 */
	private function has_critical_cache( $url ) {
		$cache_key     = $this->get_cache_key( $url );
		$critical_path = $this->cache_dir . $cache_key . '.critical.css';
		return file_exists( $critical_path );
	}

	/**
	 * Save UCSS and optional critical CSS to cache.
	 *
	 * @since 1.5.0
	 * @param string $url           Page URL.
	 * @param string $ucss          Used CSS content.
	 * @param string $critical_css  Critical CSS content.
	 * @param int    $original_size Original combined CSS size in bytes.
	 * @param array  $handles       Stylesheet handles included in the UCSS.
	 */
	private function save_ucss_cache( $url, $ucss, $critical_css, $original_size, $handles = array() ) {
		$cache_key = $this->get_cache_key( $url );

		if ( ! wp_mkdir_p( $this->cache_dir ) ) {
			return;
		}

		// Write UCSS file.
		$ucss_path = $this->cache_dir . $cache_key . '.css';
		file_put_contents( $ucss_path, $ucss ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

		// Write critical CSS file.
		$critical_path = '';
		if ( ! empty( $critical_css ) ) {
			$critical_path = $this->cache_dir . $cache_key . '.critical.css';
			file_put_contents( $critical_path, $critical_css ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		// Write handles manifest so replace_with_ucss() knows which handles to remove.
		if ( ! empty( $handles ) ) {
			$handles_path = $this->cache_dir . $cache_key . '.handles.json';
			file_put_contents( $handles_path, wp_json_encode( $handles ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		// Calculate lifespan.
		$lifespan   = max( 1, absint( $this->settings['ucss_cache_lifespan'] ?? 7 ) );
		$expires_at = gmdate( 'Y-m-d H:i:s', time() + ( $lifespan * DAY_IN_SECONDS ) );

		// Determine post ID if applicable.
		$post_id = 0;
		if ( function_exists( 'url_to_postid' ) ) {
			$post_id = url_to_postid( $url );
		}

		// Upsert DB record.
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
		$wpdb->replace(
			$wpdb->prefix . 'up_ucss_cache',
			array(
				'url'           => $url,
				'url_hash'      => $cache_key,
				'post_id'       => $post_id,
				'ucss_path'     => $ucss_path,
				'critical_path' => $critical_path,
				'original_size' => $original_size,
				'ucss_size'     => strlen( $ucss ),
				'status'        => 'generated',
				'generated_at'  => current_time( 'mysql', true ),
				'expires_at'    => $expires_at,
			),
			array( '%s', '%s', '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s' )
		);
	}

	// ------------------------------------------------------------------
	// Cache Purge
	// ------------------------------------------------------------------

	/**
	 * Purge UCSS cache for a specific post.
	 *
	 * @since 1.5.0
	 * @param int $post_id Post ID.
	 */
	public function purge_post_ucss( $post_id ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		$post = get_post( $post_id );
		if ( ! $post || 'publish' !== $post->post_status ) {
			return;
		}

		$url       = get_permalink( $post_id );
		$cache_key = $this->get_cache_key( $url );

		// Delete cache files.
		$this->delete_cache_files( $cache_key );

		// Delete DB record.
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
		$wpdb->delete(
			$wpdb->prefix . 'up_ucss_cache',
			array( 'url_hash' => $cache_key ),
			array( '%s' )
		);

		// Also purge home page — post might appear there.
		$home_key = $this->get_cache_key( home_url( '/' ) );
		$this->delete_cache_files( $home_key );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
		$wpdb->delete(
			$wpdb->prefix . 'up_ucss_cache',
			array( 'url_hash' => $home_key ),
			array( '%s' )
		);
	}

	/**
	 * Purge all UCSS cache.
	 *
	 * @since 1.5.0
	 */
	public function purge_all_ucss() {
		// Delete cache directory.
		if ( is_dir( $this->cache_dir ) ) {
			$this->delete_directory( $this->cache_dir );
		}

		// Truncate DB table.
		global $wpdb;
		$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}up_ucss_cache" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Delete UCSS and critical CSS cache files for a cache key.
	 *
	 * @since 1.5.0
	 * @param string $cache_key MD5 cache key.
	 */
	private function delete_cache_files( $cache_key ) {
		$ucss_file     = $this->cache_dir . $cache_key . '.css';
		$critical_file = $this->cache_dir . $cache_key . '.critical.css';
		$handles_file  = $this->cache_dir . $cache_key . '.handles.json';

		if ( file_exists( $ucss_file ) ) {
			wp_delete_file( $ucss_file );
		}
		if ( file_exists( $critical_file ) ) {
			wp_delete_file( $critical_file );
		}
		if ( file_exists( $handles_file ) ) {
			wp_delete_file( $handles_file );
		}
	}

	/**
	 * Recursively delete a directory and its contents.
	 *
	 * @since 1.5.0
	 * @param string $dir Directory path.
	 */
	private function delete_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		global $wp_filesystem;
		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		if ( $wp_filesystem ) {
			$wp_filesystem->delete( $dir, true );
		}
	}

	// ------------------------------------------------------------------
	// WP Cron Regeneration
	// ------------------------------------------------------------------

	/**
	 * Regenerate expired UCSS cache via WP Cron.
	 *
	 * Processes up to 10 stale URLs per cron run to prevent timeouts.
	 *
	 * @since 1.5.0
	 */
	public function regenerate_via_cron() {
		if ( empty( $this->settings['ucss_enabled'] ) ) {
			return;
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table query; not suitable for object cache.
		$stale_records = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, url, url_hash FROM {$wpdb->prefix}up_ucss_cache
				 WHERE status = 'generated' AND expires_at < %s
				 ORDER BY expires_at ASC LIMIT 10",
				current_time( 'mysql', true )
			)
		);

		if ( empty( $stale_records ) ) {
			return;
		}

		foreach ( $stale_records as $record ) {
			// Delete old cache files.
			$this->delete_cache_files( $record->url_hash );

			// Fetch the page HTML via internal request.
			$response = wp_remote_get( $record->url, array(
				'timeout'   => 30,
				'sslverify' => false,
				'cookies'   => array(),
			) );

			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
				// Mark as failed, will retry next cron.
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
				$wpdb->update(
					$wpdb->prefix . 'up_ucss_cache',
					array( 'status' => 'failed' ),
					array( 'id' => $record->id ),
					array( '%s' ),
					array( '%d' )
				);
				continue;
			}

			$html = wp_remote_retrieve_body( $response );
			if ( empty( $html ) ) {
				continue;
			}

			$css_sources = $this->collect_css_from_html( $html );
			if ( empty( $css_sources ) ) {
				continue;
			}

			$used_css = $this->generate_ucss_php( $html, $css_sources );
			if ( empty( $used_css ) ) {
				continue;
			}

			$original_size = 0;
			foreach ( $css_sources as $source ) {
				$original_size += strlen( $source['content'] );
			}

			if ( strlen( $used_css ) >= $original_size ) {
				continue;
			}

			$critical_css = '';
			if ( ! empty( $this->settings['ucss_critical_css'] ) ) {
				$critical_css = $this->extract_critical_css( $used_css, $html );
			}

			$this->save_ucss_cache( $record->url, $used_css, $critical_css, $original_size );
		}
	}

	// ------------------------------------------------------------------
	// AJAX Handlers
	// ------------------------------------------------------------------

	/**
	 * AJAX: Return UCSS cache status and stats.
	 *
	 * @since 1.5.0
	 */
	public function ajax_ucss_status() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table query; not suitable for object cache.
		$total_pages = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->prefix}up_ucss_cache WHERE status = 'generated'"
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table query; not suitable for object cache.
		$total_original = (int) $wpdb->get_var(
			"SELECT COALESCE(SUM(original_size), 0) FROM {$wpdb->prefix}up_ucss_cache WHERE status = 'generated'"
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table query; not suitable for object cache.
		$total_ucss = (int) $wpdb->get_var(
			"SELECT COALESCE(SUM(ucss_size), 0) FROM {$wpdb->prefix}up_ucss_cache WHERE status = 'generated'"
		);

		$savings_percent = $total_original > 0
			? round( ( ( $total_original - $total_ucss ) / $total_original ) * 100, 1 )
			: 0;

		wp_send_json_success( array(
			'total_pages'      => $total_pages,
			'total_original'   => size_format( $total_original ),
			'total_ucss'       => size_format( $total_ucss ),
			'savings_percent'  => $savings_percent,
		) );
	}

	/**
	 * AJAX: Purge UCSS cache.
	 *
	 * @since 1.5.0
	 */
	public function ajax_ucss_purge() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$this->purge_all_ucss();

		wp_send_json_success( array(
			'message' => __( 'UCSS cache purged successfully.', 'ultimate-performance' ),
		) );
	}

	// ------------------------------------------------------------------
	// Helpers
	// ------------------------------------------------------------------

	/**
	 * Get the current page URL.
	 *
	 * @since 1.5.0
	 * @return string Current URL.
	 */
	private function get_current_url() {
		$scheme = is_ssl() ? 'https' : 'http';
		$host   = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		$uri    = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';

		// Strip query string for cache key consistency.
		$uri = strtok( $uri, '?' );

		return $scheme . '://' . $host . $uri;
	}

	/**
	 * Check if a URL matches any excluded URL pattern.
	 *
	 * @since 1.5.0
	 * @param string $url URL to check.
	 * @return bool True if excluded.
	 */
	private function is_excluded_url( $url ) {
		foreach ( $this->excluded_urls as $pattern ) {
			if ( $pattern === $url ) {
				return true;
			}

			// Wildcard support.
			if ( substr( $pattern, -1 ) === '*' ) {
				if ( strpos( $url, substr( $pattern, 0, -1 ) ) === 0 ) {
					return true;
				}
			}

			// Substring match.
			if ( strpos( $url, $pattern ) !== false ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Parse exclusion lists and safelist from settings.
	 *
	 * @since 1.5.0
	 */
	private function parse_exclusions() {
		$this->excluded_urls    = $this->parse_textarea_lines( $this->settings['ucss_exclude_urls'] ?? '' );
		$this->excluded_handles = $this->parse_textarea_lines( $this->settings['ucss_exclude_handles'] ?? '' );

		// Build safelist: user patterns + defaults.
		$user_safelist  = $this->parse_textarea_lines( $this->settings['ucss_safelist'] ?? '' );
		$this->safelist = array_merge( $this->get_default_safelist(), $user_safelist );
	}

	/**
	 * Get default safelist patterns.
	 *
	 * @since 1.5.0
	 * @return array Default safelist patterns.
	 */
	private function get_default_safelist() {
		return array(
			// Dynamic/JS-generated state classes.
			'wp-*',
			'is-*',
			'has-*',
			'active',
			'open',
			'show',
			'hide',
			'hidden',
			'visible',
			'current-*',
			'toggled',
			'expanded',
			'collapsed',
			'selected',
			'disabled',
			'focus',
			'hover',
			'checked',
			'loading',
			'loaded',
			'error',
			'success',
			'in',
			'out',
			'animate*',
			// WordPress body classes (conditional, may vary by page).
			'rtl',
			'ltr',
			'no-js',
			'js',
			'single*',
			'page-*',
			'home',
			'archive',
			'search',
			'logged-in',
			'admin-bar*',
			'customize-*',
			'wp-block-*',
			'block-editor-*',
			'entry-*',
			'alignwide',
			'alignfull',
			'wp-embed-*',
			// WooCommerce dynamic.
			'wc-*',
			'woocommerce*',
			'cart-*',
			'checkout-*',
			'product-*',
			'shop-*',
			// Common UI frameworks.
			'modal*',
			'dropdown*',
			'tooltip*',
			'popover*',
			'collapse*',
			'fade*',
			'slide*',
			'tab-*',
			'nav-*',
			'menu-*',
			'sub-menu',
			'mega-menu*',
			'swiper-*',
			'slick-*',
			'owl-*',
			'splide*',
			'glide*',
			'lightbox*',
			'fancybox*',
			// Responsive/visibility.
			'mobile-*',
			'desktop-*',
			'tablet-*',
			'sticky*',
			'fixed*',
			'offcanvas*',
			'off-canvas*',
			'sidebar-*',
			// Common page builder classes.
			'elementor-*',
			'fl-*',
			'et-*',
			'et_*',
			'divi-*',
			'vc_*',
			'wpb_*',
			'fusion-*',
			'avada-*',
			'beaver-*',
			'kadence-*',
			'astra-*',
			'generatepress-*',
			'oceanwp-*',
			// WordPress admin bar (rendered via JS).
			'#wpadminbar',
		);
	}

	/**
	 * Parse a textarea value into an array of trimmed, non-empty lines.
	 *
	 * @since 1.5.0
	 * @param string $text Textarea value.
	 * @return array Lines.
	 */
	private function parse_textarea_lines( $text ) {
		if ( empty( $text ) ) {
			return array();
		}

		$lines = preg_split( '/[\r\n]+/', $text );
		$lines = array_map( 'trim', $lines );
		return array_filter( $lines, function ( $line ) {
			return '' !== $line;
		} );
	}
}
