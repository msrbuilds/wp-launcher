<?php
/**
 * Handles Google PageSpeed Insights integration for speed testing.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Speed_Test
 *
 * Provides an AJAX-powered speed test tool that calls the Google
 * PageSpeed Insights API v5 and returns performance scores and
 * Core Web Vitals metrics. Supports saving, loading, comparing,
 * and deleting reports.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Speed_Test {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * PageSpeed Insights API endpoint.
	 *
	 * @since 1.0.0
	 * @var   string
	 */
	const API_URL = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';

	/**
	 * Initialize the module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'speed_test' );

		// Run DB upgrade if needed.
		$this->maybe_upgrade_db();

		// AJAX handlers.
		add_action( 'wp_ajax_up_run_speed_test', array( $this, 'ajax_run_speed_test' ) );
		add_action( 'wp_ajax_up_save_speed_report', array( $this, 'ajax_save_speed_report' ) );
		add_action( 'wp_ajax_up_load_speed_reports', array( $this, 'ajax_load_speed_reports' ) );
		add_action( 'wp_ajax_up_load_speed_report', array( $this, 'ajax_load_speed_report' ) );
		add_action( 'wp_ajax_up_delete_speed_report', array( $this, 'ajax_delete_speed_report' ) );
		add_action( 'wp_ajax_up_compare_speed_reports', array( $this, 'ajax_compare_speed_reports' ) );
		add_action( 'wp_ajax_up_save_quick_test', array( $this, 'ajax_save_quick_test' ) );
		add_action( 'wp_ajax_up_apply_fix', array( $this, 'ajax_apply_fix' ) );
	}

	/**
	 * Run DB schema upgrade if needed.
	 *
	 * @since 1.2.0
	 */
	private function maybe_upgrade_db() {
		$db_version = get_option( 'up_db_version', '1.0.0' );
		if ( version_compare( $db_version, '1.1.0', '<' ) ) {
			require_once UP_PLUGIN_DIR . 'includes/class-ultimate-performance-activator.php';
			Ultimate_Performance_Activator::create_tables();
		}
	}

	/**
	 * AJAX handler to run a PageSpeed Insights test.
	 *
	 * @since 1.0.0
	 */
	public function ajax_run_speed_test() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$url      = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';
		$strategy = isset( $_POST['strategy'] ) ? sanitize_key( wp_unslash( $_POST['strategy'] ) ) : 'mobile';

		if ( empty( $url ) ) {
			wp_send_json_error( array( 'message' => __( 'Please enter a valid URL.', 'ultimate-performance' ) ) );
		}

		if ( ! in_array( $strategy, array( 'mobile', 'desktop' ), true ) ) {
			$strategy = 'mobile';
		}

		// Check transient cache first (5 minute cache per URL + strategy).
		$cache_key = 'up_psi2_' . md5( $url . '|' . $strategy );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			wp_send_json_success( $cached );
		}

		// Build API request (request all categories for comprehensive report).
		$api_url = add_query_arg( array(
			'url'      => $url,
			'strategy' => $strategy,
		), self::API_URL );

		// Add API key if configured.
		$api_key = trim( $this->settings['api_key'] );
		if ( ! empty( $api_key ) ) {
			$api_url = add_query_arg( 'key', $api_key, $api_url );
		}

		// Append repeated category params LAST to avoid add_query_arg
		// mangling duplicate keys (it would keep only the last one).
		$api_url .= '&category=performance&category=accessibility&category=best-practices&category=seo';

		$response = wp_remote_get( $api_url, array(
			'timeout' => 60,
		) );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array(
				'message' => $response->get_error_message(),
			) );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code || empty( $body ) ) {
			$error_msg = __( 'PageSpeed Insights API error.', 'ultimate-performance' );
			if ( ! empty( $body['error']['message'] ) ) {
				$error_msg = $body['error']['message'];
			}
			wp_send_json_error( array( 'message' => $error_msg ) );
		}

		$result = $this->parse_psi_response_full( $body, $strategy );

		// Auto-save to database.
		$report_id = $this->save_to_database( $url, $strategy, $result, $body );
		$result['report_id'] = $report_id;

		// Cache for 5 minutes.
		set_transient( $cache_key, $result, 5 * MINUTE_IN_SECONDS );

		wp_send_json_success( $result );
	}

	/**
	 * Save a speed test result to the database.
	 *
	 * @since  1.2.0
	 * @param  string $url      Tested URL.
	 * @param  string $strategy 'mobile' or 'desktop'.
	 * @param  array  $result   Parsed result.
	 * @param  array  $raw_body Raw API response.
	 * @return int    Inserted row ID.
	 */
	private function save_to_database( $url, $strategy, $result, $raw_body ) {
		global $wpdb;
		$table = $wpdb->prefix . 'up_speed_tests';

		$lcp_ms = null;
		if ( isset( $result['metrics']['lcp']['numericValue'] ) ) {
			$lcp_ms = (int) $result['metrics']['lcp']['numericValue'];
		}
		$inp_ms = null;
		if ( isset( $result['metrics']['tbt']['numericValue'] ) ) {
			$inp_ms = (int) $result['metrics']['tbt']['numericValue'];
		}
		$cls_score = null;
		if ( isset( $result['metrics']['cls']['numericValue'] ) ) {
			$cls_score = $result['metrics']['cls']['numericValue'];
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
		$wpdb->insert(
			$table,
			array(
				'url'               => $url,
				'strategy'          => $strategy,
				'performance_score' => isset( $result['score'] ) ? (int) $result['score'] : null,
				'lcp_ms'            => $lcp_ms,
				'inp_ms'            => $inp_ms,
				'cls_score'         => $cls_score,
				'label'             => '',
				'raw_response'      => wp_json_encode( $raw_body ),
				'created_at'        => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%d', '%d', '%d', '%f', '%s', '%s', '%s' )
		);

		return $wpdb->insert_id;
	}

	/**
	 * AJAX handler to update a report's label.
	 *
	 * @since 1.2.0
	 */
	public function ajax_save_speed_report() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$report_id = isset( $_POST['report_id'] ) ? absint( $_POST['report_id'] ) : 0;
		$label     = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';

		if ( ! $report_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid report ID.', 'ultimate-performance' ) ) );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'up_speed_tests';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
		$wpdb->update(
			$table,
			array( 'label' => $label ),
			array( 'id' => $report_id ),
			array( '%s' ),
			array( '%d' )
		);

		wp_send_json_success( array( 'message' => __( 'Report saved.', 'ultimate-performance' ) ) );
	}

	/**
	 * AJAX handler to list saved reports (lightweight, no raw_response).
	 *
	 * @since 1.2.0
	 */
	public function ajax_load_speed_reports() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'up_speed_tests';

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
		$reports = $wpdb->get_results(
			"SELECT id, url, strategy, performance_score, lcp_ms, inp_ms, cls_score, label, created_at
			 FROM {$table} ORDER BY created_at DESC LIMIT 50",
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,PluginCheck.Security.DirectDB.UnescapedDBParameter

		wp_send_json_success( array( 'reports' => $reports ? $reports : array() ) );
	}

	/**
	 * AJAX handler to load a single saved report with full parsed data.
	 *
	 * @since 1.2.0
	 */
	public function ajax_load_speed_report() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$report_id = isset( $_POST['report_id'] ) ? absint( $_POST['report_id'] ) : 0;

		if ( ! $report_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid report ID.', 'ultimate-performance' ) ) );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'up_speed_tests';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $report_id ),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

		if ( ! $row ) {
			wp_send_json_error( array( 'message' => __( 'Report not found.', 'ultimate-performance' ) ) );
		}

		$raw = json_decode( $row['raw_response'], true );

		// Quick Test reports store browser timing data, not PSI API data.
		if ( 'quick' === $row['strategy'] ) {
			$parsed             = is_array( $raw ) ? $raw : array();
			$parsed['strategy'] = 'quick';
		} else {
			$parsed = $raw ? $this->parse_psi_response_full( $raw, $row['strategy'] ) : array();
		}

		$parsed['report_id']  = (int) $row['id'];
		$parsed['url']        = $row['url'];
		$parsed['label']      = isset( $row['label'] ) ? $row['label'] : '';
		$parsed['created_at'] = $row['created_at'];

		wp_send_json_success( $parsed );
	}

	/**
	 * AJAX handler to delete a saved report.
	 *
	 * @since 1.2.0
	 */
	public function ajax_delete_speed_report() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$report_id = isset( $_POST['report_id'] ) ? absint( $_POST['report_id'] ) : 0;

		if ( ! $report_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid report ID.', 'ultimate-performance' ) ) );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'up_speed_tests';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
		$wpdb->delete( $table, array( 'id' => $report_id ), array( '%d' ) );

		wp_send_json_success( array( 'message' => __( 'Report deleted.', 'ultimate-performance' ) ) );
	}

	/**
	 * AJAX handler to compare two saved reports.
	 *
	 * @since 1.2.0
	 */
	public function ajax_compare_speed_reports() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$id_a = isset( $_POST['report_a'] ) ? absint( $_POST['report_a'] ) : 0;
		$id_b = isset( $_POST['report_b'] ) ? absint( $_POST['report_b'] ) : 0;

		if ( ! $id_a || ! $id_b ) {
			wp_send_json_error( array( 'message' => __( 'Please select two reports to compare.', 'ultimate-performance' ) ) );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'up_speed_tests';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom table; name from $wpdb->prefix is safe.
		$row_a = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id_a ),
			ARRAY_A
		);
		$row_b = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id_b ),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter

		if ( ! $row_a || ! $row_b ) {
			wp_send_json_error( array( 'message' => __( 'One or both reports not found.', 'ultimate-performance' ) ) );
		}

		$raw_a = json_decode( $row_a['raw_response'], true );
		$raw_b = json_decode( $row_b['raw_response'], true );

		if ( 'quick' === $row_a['strategy'] ) {
			$parsed_a             = is_array( $raw_a ) ? $raw_a : array();
			$parsed_a['strategy'] = 'quick';
		} else {
			$parsed_a = $raw_a ? $this->parse_psi_response_full( $raw_a, $row_a['strategy'] ) : array();
		}

		if ( 'quick' === $row_b['strategy'] ) {
			$parsed_b             = is_array( $raw_b ) ? $raw_b : array();
			$parsed_b['strategy'] = 'quick';
		} else {
			$parsed_b = $raw_b ? $this->parse_psi_response_full( $raw_b, $row_b['strategy'] ) : array();
		}

		$parsed_a['report_id']  = (int) $row_a['id'];
		$parsed_a['url']        = $row_a['url'];
		$parsed_a['label']      = isset( $row_a['label'] ) ? $row_a['label'] : '';
		$parsed_a['created_at'] = $row_a['created_at'];

		$parsed_b['report_id']  = (int) $row_b['id'];
		$parsed_b['url']        = $row_b['url'];
		$parsed_b['label']      = isset( $row_b['label'] ) ? $row_b['label'] : '';
		$parsed_b['created_at'] = $row_b['created_at'];

		wp_send_json_success( array(
			'report_a' => $parsed_a,
			'report_b' => $parsed_b,
		) );
	}

	/**
	 * AJAX handler to save a browser Quick Test result.
	 *
	 * @since 1.2.0
	 */
	public function ajax_save_quick_test() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$url   = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';
		$score = isset( $_POST['score'] ) ? absint( $_POST['score'] ) : 0;
		$data  = isset( $_POST['data'] ) ? sanitize_text_field( wp_unslash( $_POST['data'] ) ) : '';

		if ( empty( $url ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid URL.', 'ultimate-performance' ) ) );
		}

		// Validate JSON.
		$decoded = json_decode( $data, true );
		if ( ! is_array( $decoded ) ) {
			$decoded = array();
			$data    = '{}';
		}

		global $wpdb;
		$table = $wpdb->prefix . 'up_speed_tests';

		$lcp_ms = null;
		if ( isset( $decoded['timing']['fcp'] ) ) {
			$lcp_ms = absint( $decoded['timing']['fcp'] );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Write operation; caching not applicable.
		$wpdb->insert(
			$table,
			array(
				'url'               => $url,
				'strategy'          => 'quick',
				'performance_score' => $score,
				'lcp_ms'            => $lcp_ms,
				'inp_ms'            => null,
				'cls_score'         => null,
				'label'             => '',
				'raw_response'      => $data,
				'created_at'        => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%d', '%d', '%d', '%f', '%s', '%s', '%s' )
		);

		wp_send_json_success( array(
			'report_id' => $wpdb->insert_id,
			'message'   => __( 'Quick Test report saved.', 'ultimate-performance' ),
		) );
	}

	/**
	 * Parse PSI API response into a comprehensive result.
	 *
	 * @since  1.2.0
	 * @param  array  $data     Raw API response.
	 * @param  string $strategy 'mobile' or 'desktop'.
	 * @return array  Full parsed result.
	 */
	private function parse_psi_response_full( $data, $strategy = 'mobile' ) {
		$lighthouse = isset( $data['lighthouseResult'] ) ? $data['lighthouseResult'] : array();
		$categories = isset( $lighthouse['categories'] ) ? $lighthouse['categories'] : array();
		$audits     = isset( $lighthouse['audits'] ) ? $lighthouse['audits'] : array();

		// Category scores.
		$scores = array(
			'performance'    => $this->extract_category_score( $categories, 'performance' ),
			'accessibility'  => $this->extract_category_score( $categories, 'accessibility' ),
			'best_practices' => $this->extract_category_score( $categories, 'best-practices' ),
			'seo'            => $this->extract_category_score( $categories, 'seo' ),
		);

		// Core Web Vitals metrics with scores for color-coding.
		$metrics = array(
			'fcp'  => $this->extract_metric_full( $audits, 'first-contentful-paint' ),
			'lcp'  => $this->extract_metric_full( $audits, 'largest-contentful-paint' ),
			'tbt'  => $this->extract_metric_full( $audits, 'total-blocking-time' ),
			'cls'  => $this->extract_metric_full( $audits, 'cumulative-layout-shift' ),
			'si'   => $this->extract_metric_full( $audits, 'speed-index' ),
			'ttfb' => $this->extract_metric_full( $audits, 'server-response-time' ),
		);

		// Opportunities (with detailed items).
		$opportunities = $this->extract_opportunities_detailed( $audits );

		// Passed audits count.
		$passed       = 0;
		$total_audits = 0;
		foreach ( $audits as $audit ) {
			if ( ! isset( $audit['score'] ) || null === $audit['score'] ) {
				continue;
			}
			$total_audits++;
			if ( 1 === (int) $audit['score'] || $audit['score'] >= 0.9 ) {
				$passed++;
			}
		}

		// Field data (Chrome UX Report).
		$field_data = $this->extract_field_data( $data );

		// Diagnostics.
		$diagnostics = $this->extract_diagnostics( $audits );

		// Screenshots & filmstrip.
		$screenshots = $this->extract_screenshots( $audits );

		// Stack packs (detected frameworks).
		$stack_packs = $this->extract_stack_packs( $lighthouse );

		// Fix suggestions mapped to plugin modules.
		$fix_suggestions = $this->build_fix_suggestions( $audits );

		// Category-specific audits (accessibility, best practices, SEO).
		$accessibility_audits  = $this->extract_category_audits( $categories, $audits, 'accessibility' );
		$best_practices_audits = $this->extract_category_audits( $categories, $audits, 'best-practices' );
		$seo_audits            = $this->extract_category_audits( $categories, $audits, 'seo' );

		return array(
			'strategy'             => $strategy,
			'score'                => $scores['performance'],
			'scores'               => $scores,
			'metrics'              => $metrics,
			'opportunities'        => $opportunities,
			'passed_audits'        => $passed,
			'total_audits'         => $total_audits,
			'field_data'           => $field_data,
			'diagnostics'          => $diagnostics,
			'screenshots'          => $screenshots,
			'stack_packs'          => $stack_packs,
			'fix_suggestions'      => $fix_suggestions,
			'accessibility_audits' => $accessibility_audits,
			'best_practices_audits' => $best_practices_audits,
			'seo_audits'           => $seo_audits,
		);
	}

	/**
	 * Extract Chrome UX Report (CrUX) field data.
	 *
	 * @since  1.2.0
	 * @param  array $data Raw API response.
	 * @return array Field data with distributions.
	 */
	private function extract_field_data( $data ) {
		$le      = isset( $data['loadingExperience'] ) ? $data['loadingExperience'] : array();
		$metrics = isset( $le['metrics'] ) ? $le['metrics'] : array();

		$result = array(
			'overall_category' => isset( $le['overall_category'] ) ? $le['overall_category'] : null,
			'metrics'          => array(),
		);

		$field_keys = array(
			'CUMULATIVE_LAYOUT_SHIFT_SCORE'    => array( 'label' => 'CLS',  'key' => 'cls' ),
			'EXPERIMENTAL_TIME_TO_FIRST_BYTE'  => array( 'label' => 'TTFB', 'key' => 'ttfb' ),
			'FIRST_CONTENTFUL_PAINT_MS'        => array( 'label' => 'FCP',  'key' => 'fcp' ),
			'INTERACTION_TO_NEXT_PAINT'        => array( 'label' => 'INP',  'key' => 'inp' ),
			'LARGEST_CONTENTFUL_PAINT_MS'      => array( 'label' => 'LCP',  'key' => 'lcp' ),
		);

		foreach ( $field_keys as $api_key => $info ) {
			if ( ! isset( $metrics[ $api_key ] ) ) {
				continue;
			}
			$m = $metrics[ $api_key ];

			$distributions = array();
			if ( isset( $m['distributions'] ) && is_array( $m['distributions'] ) ) {
				foreach ( $m['distributions'] as $dist ) {
					$distributions[] = array(
						'min'        => isset( $dist['min'] ) ? $dist['min'] : 0,
						'max'        => isset( $dist['max'] ) ? $dist['max'] : null,
						'proportion' => isset( $dist['proportion'] ) ? round( $dist['proportion'] * 100, 1 ) : 0,
					);
				}
			}

			$result['metrics'][ $info['key'] ] = array(
				'label'         => $info['label'],
				'percentile'    => isset( $m['percentile'] ) ? $m['percentile'] : null,
				'category'      => isset( $m['category'] ) ? $m['category'] : null,
				'distributions' => $distributions,
			);
		}

		return $result;
	}

	/**
	 * Extract opportunities with detailed items.
	 *
	 * @since  1.2.0
	 * @param  array $audits Lighthouse audits array.
	 * @return array Opportunities with per-resource breakdowns.
	 */
	private function extract_opportunities_detailed( $audits ) {
		$opportunity_keys = array(
			'render-blocking-resources',
			'unused-css-rules',
			'unused-javascript',
			'modern-image-formats',
			'uses-optimized-images',
			'uses-responsive-images',
			'offscreen-images',
			'unminified-css',
			'unminified-javascript',
			'efficient-animated-content',
			'uses-text-compression',
			'uses-rel-preconnect',
			'server-response-time',
			'redirects',
			'uses-rel-preload',
			'uses-http2',
			'dom-size',
			'critical-request-chains',
			'font-display',
			'third-party-summary',
			'largest-contentful-paint-element',
			'lcp-lazy-loaded',
			'layout-shift-elements',
			'long-tasks',
			'total-byte-weight',
			'bootup-time',
			'mainthread-work-breakdown',
		);

		$opportunities = array();

		foreach ( $opportunity_keys as $key ) {
			if ( ! isset( $audits[ $key ] ) ) {
				continue;
			}
			$audit       = $audits[ $key ];
			$audit_score = isset( $audit['score'] ) ? $audit['score'] : null;

			// Skip passed audits (score = 1) and informational/not-applicable.
			if ( null === $audit_score || 1 === (int) $audit_score ) {
				continue;
			}

			$item = array(
				'id'          => $key,
				'title'       => isset( $audit['title'] ) ? $audit['title'] : $key,
				'description' => isset( $audit['description'] ) ? $audit['description'] : '',
				'score'       => $audit_score,
			);

			if ( ! empty( $audit['displayValue'] ) ) {
				$item['value'] = $audit['displayValue'];
			}

			// Extract savings if available.
			if ( isset( $audit['details']['overallSavingsMs'] ) ) {
				$savings_ms = (int) $audit['details']['overallSavingsMs'];
				if ( $savings_ms >= 1000 ) {
					$item['savings'] = round( $savings_ms / 1000, 1 ) . ' s';
				} elseif ( $savings_ms > 0 ) {
					$item['savings'] = $savings_ms . ' ms';
				}
			}
			if ( isset( $audit['details']['overallSavingsBytes'] ) ) {
				$savings_bytes = (int) $audit['details']['overallSavingsBytes'];
				if ( $savings_bytes > 0 ) {
					$item['savings_size'] = $this->format_bytes( $savings_bytes );
				}
			}

			// Extract detailed items (capped at 10).
			if ( isset( $audit['details']['items'] ) && is_array( $audit['details']['items'] ) ) {
				$detail_items = array();
				$items_slice  = array_slice( $audit['details']['items'], 0, 10 );

				foreach ( $items_slice as $di ) {
					$detail = array();

					if ( isset( $di['url'] ) ) {
						$detail['url'] = $di['url'];
					}
					if ( isset( $di['wastedBytes'] ) ) {
						$detail['wastedBytes'] = (int) $di['wastedBytes'];
					}
					if ( isset( $di['wastedMs'] ) ) {
						$detail['wastedMs'] = round( (float) $di['wastedMs'], 1 );
					}
					if ( isset( $di['totalBytes'] ) ) {
						$detail['totalBytes'] = (int) $di['totalBytes'];
					}
					if ( isset( $di['node']['snippet'] ) ) {
						$detail['element'] = wp_kses_post( $di['node']['snippet'] );
					}
					if ( isset( $di['node']['selector'] ) ) {
						$detail['selector'] = sanitize_text_field( $di['node']['selector'] );
					}

					// Generic columns for table-type audits.
					if ( empty( $detail ) ) {
						foreach ( $di as $dk => $dv ) {
							if ( is_scalar( $dv ) ) {
								$detail[ $dk ] = $dv;
							}
						}
					}

					if ( ! empty( $detail ) ) {
						$detail_items[] = $detail;
					}
				}

				if ( ! empty( $detail_items ) ) {
					$item['items'] = $detail_items;
				}
			}

			$opportunities[] = $item;
		}

		// Sort by score ascending (worst first).
		usort( $opportunities, function ( $a, $b ) {
			return ( $a['score'] ?? 1 ) <=> ( $b['score'] ?? 1 );
		} );

		return $opportunities;
	}

	/**
	 * Extract diagnostic audits.
	 *
	 * @since  1.2.0
	 * @param  array $audits Lighthouse audits array.
	 * @return array Diagnostics with detail items.
	 */
	private function extract_diagnostics( $audits ) {
		$diagnostic_keys = array(
			'largest-contentful-paint-element',
			'layout-shift-elements',
			'third-party-summary',
			'bootup-time',
			'mainthread-work-breakdown',
			'long-tasks',
			'dom-size',
			'total-byte-weight',
			'legacy-javascript',
			'duplicated-javascript',
			'viewport',
		);

		$diagnostics = array();

		foreach ( $diagnostic_keys as $key ) {
			if ( ! isset( $audits[ $key ] ) ) {
				continue;
			}
			$audit = $audits[ $key ];

			// Include audits with issues (score < 1 or null with items).
			$audit_score = isset( $audit['score'] ) ? $audit['score'] : null;
			if ( null !== $audit_score && $audit_score >= 0.9 ) {
				continue;
			}

			$item = array(
				'id'           => $key,
				'title'        => isset( $audit['title'] ) ? $audit['title'] : $key,
				'description'  => isset( $audit['description'] ) ? $audit['description'] : '',
				'displayValue' => isset( $audit['displayValue'] ) ? $audit['displayValue'] : '',
				'score'        => $audit_score,
				'items'        => array(),
			);

			if ( isset( $audit['details']['items'] ) && is_array( $audit['details']['items'] ) ) {
				$detail_items = array_slice( $audit['details']['items'], 0, 15 );
				$clean_items  = array();

				foreach ( $detail_items as $di ) {
					$clean = array();
					foreach ( $di as $dk => $dv ) {
						if ( is_scalar( $dv ) ) {
							$clean[ $dk ] = $dv;
						} elseif ( 'node' === $dk && is_array( $dv ) ) {
							if ( isset( $dv['snippet'] ) ) {
								$clean['element'] = wp_kses_post( $dv['snippet'] );
							}
							if ( isset( $dv['selector'] ) ) {
								$clean['selector'] = sanitize_text_field( $dv['selector'] );
							}
						} elseif ( 'subItems' === $dk && is_array( $dv ) && isset( $dv['items'] ) ) {
							$clean['subItems'] = array_slice( $dv['items'], 0, 5 );
						}
					}
					if ( ! empty( $clean ) ) {
						$clean_items[] = $clean;
					}
				}

				$item['items'] = $clean_items;
			}

			$diagnostics[] = $item;
		}

		return $diagnostics;
	}

	/**
	 * Extract screenshots (final + filmstrip).
	 *
	 * @since  1.2.0
	 * @param  array $audits Lighthouse audits array.
	 * @return array Screenshots data.
	 */
	private function extract_screenshots( $audits ) {
		$result = array(
			'final'    => null,
			'filmstrip' => array(),
		);

		if ( isset( $audits['final-screenshot']['details']['data'] ) ) {
			$result['final'] = $audits['final-screenshot']['details']['data'];
		}

		if ( isset( $audits['screenshot-thumbnails']['details']['items'] ) ) {
			foreach ( $audits['screenshot-thumbnails']['details']['items'] as $frame ) {
				$result['filmstrip'][] = array(
					'timing' => isset( $frame['timing'] ) ? (int) $frame['timing'] : 0,
					'data'   => isset( $frame['data'] ) ? $frame['data'] : '',
				);
			}
		}

		return $result;
	}

	/**
	 * Extract detected stack packs (frameworks).
	 *
	 * @since  1.2.0
	 * @param  array $lighthouse Lighthouse result.
	 * @return array Stack pack info.
	 */
	private function extract_stack_packs( $lighthouse ) {
		if ( ! isset( $lighthouse['stackPacks'] ) || ! is_array( $lighthouse['stackPacks'] ) ) {
			return array();
		}

		$packs = array();
		foreach ( $lighthouse['stackPacks'] as $pack ) {
			$packs[] = array(
				'id'    => isset( $pack['id'] ) ? $pack['id'] : '',
				'title' => isset( $pack['title'] ) ? $pack['title'] : '',
			);
		}

		return $packs;
	}

	/**
	 * Get the canonical mapping from Lighthouse audit IDs to plugin fix actions.
	 *
	 * Each entry maps to a module key and one or more setting keys that should
	 * be set to true to address the audit finding.
	 *
	 * @since  1.3.0
	 * @return array Keyed by audit_id => array{ module, settings, tip }.
	 */
	public static function get_audit_fix_map() {
		return array(
			'render-blocking-resources' => array(
				'module'   => 'css_js',
				'settings' => array( 'async_css' => true, 'defer_js' => true, 'move_jquery_to_footer' => true ),
				'tip'      => __( 'Enable "Async CSS", "Defer JS", and "Move jQuery to Footer" in CSS/JS Optimization.', 'ultimate-performance' ),
			),
			'unused-css-rules' => array(
				'module'   => 'css_js',
				'settings' => array( 'minify_css' => true ),
				'tip'      => __( 'Enable CSS minification and use Script Manager to disable unused stylesheets.', 'ultimate-performance' ),
			),
			'unused-javascript' => array(
				'module'   => 'script_manager',
				'settings' => array( 'enabled' => true ),
				'tip'      => __( 'Use the Script Manager to disable unused JavaScript per page.', 'ultimate-performance' ),
			),
			'offscreen-images' => array(
				'module'   => 'image_optimization',
				'settings' => array( 'lazy_load_images' => true ),
				'tip'      => __( 'Enable "Lazy Load Images" in Image Optimization.', 'ultimate-performance' ),
			),
			'modern-image-formats' => array(
				'module'   => 'image_optimization',
				'settings' => array( 'webp_conversion' => true ),
				'tip'      => __( 'Enable WebP conversion in Image Optimization.', 'ultimate-performance' ),
			),
			'uses-optimized-images' => array(
				'module'   => 'image_optimization',
				'settings' => array( 'compression_enabled' => true ),
				'tip'      => __( 'Enable image compression in Image Optimization.', 'ultimate-performance' ),
			),
			'unminified-css' => array(
				'module'   => 'css_js',
				'settings' => array( 'minify_css' => true ),
				'tip'      => __( 'Enable "Minify CSS" in CSS/JS Optimization.', 'ultimate-performance' ),
			),
			'unminified-javascript' => array(
				'module'   => 'css_js',
				'settings' => array( 'minify_js' => true ),
				'tip'      => __( 'Enable "Minify JS" in CSS/JS Optimization.', 'ultimate-performance' ),
			),
			'uses-text-compression' => array(
				'module'   => 'caching',
				'settings' => array( 'gzip_compression' => true ),
				'tip'      => __( 'Enable "GZIP Compression" in the Caching module.', 'ultimate-performance' ),
			),
			'uses-rel-preconnect' => array(
				'module'   => 'preloading',
				'settings' => array(),
				'tip'      => __( 'Add third-party origins to "Preconnect" in Preloading settings.', 'ultimate-performance' ),
			),
			'font-display' => array(
				'module'   => 'webfonts',
				'settings' => array( 'font_display_swap' => true ),
				'tip'      => __( 'Enable "Font Display Swap" in Web Fonts.', 'ultimate-performance' ),
			),
			'server-response-time' => array(
				'module'   => 'caching',
				'settings' => array( 'page_cache' => true ),
				'tip'      => __( 'Enable "Page Cache" in Caching to reduce server response time.', 'ultimate-performance' ),
			),
			'lcp-lazy-loaded' => array(
				'module'   => 'image_optimization',
				'settings' => array(),
				'tip'      => __( 'Exclude above-the-fold images from lazy loading in Image Optimization.', 'ultimate-performance' ),
			),
			'dom-size' => array(
				'module'   => null,
				'settings' => array(),
				'tip'      => __( 'Reduce DOM size by simplifying page layout. Consider fewer plugins and a lighter theme.', 'ultimate-performance' ),
			),
		);
	}

	/**
	 * AJAX handler to apply a single PSI fix suggestion.
	 *
	 * Enables the target module and flips the specified boolean setting(s).
	 *
	 * @since 1.3.0
	 */
	public function ajax_apply_fix() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$audit_id = isset( $_POST['audit_id'] ) ? sanitize_key( wp_unslash( $_POST['audit_id'] ) ) : '';

		if ( empty( $audit_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Missing audit ID.', 'ultimate-performance' ) ) );
		}

		$fix_map = self::get_audit_fix_map();

		if ( ! isset( $fix_map[ $audit_id ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown audit ID.', 'ultimate-performance' ) ) );
		}

		$fix = $fix_map[ $audit_id ];

		if ( empty( $fix['module'] ) || empty( $fix['settings'] ) ) {
			wp_send_json_error( array( 'message' => __( 'This suggestion cannot be auto-applied.', 'ultimate-performance' ) ) );
		}

		$module   = $fix['module'];
		$defaults = Ultimate_Performance_Settings::get_defaults();

		if ( ! isset( $defaults[ $module ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown module.', 'ultimate-performance' ) ) );
		}

		$all_settings    = get_option( Ultimate_Performance_Settings::OPTION_NAME, $defaults );
		$module_settings = isset( $all_settings[ $module ] ) ? $all_settings[ $module ] : $defaults[ $module ];
		$module_settings = wp_parse_args( $module_settings, $defaults[ $module ] );

		// Enable the module itself.
		$module_settings['enabled'] = true;

		// Enable the specific setting(s).
		foreach ( $fix['settings'] as $key => $value ) {
			if ( isset( $defaults[ $module ][ $key ] ) ) {
				$module_settings[ $key ] = $value;
			}
		}

		$all_settings[ $module ] = Ultimate_Performance_Settings::sanitize_module_settings( $module, $module_settings );
		update_option( Ultimate_Performance_Settings::OPTION_NAME, $all_settings );

		$modules_meta  = Ultimate_Performance_Settings::get_modules();
		$module_label  = isset( $modules_meta[ $module ]['label'] ) ? $modules_meta[ $module ]['label'] : $module;

		wp_send_json_success( array(
			'message'  => sprintf(
				/* translators: %s: module label */
				__( 'Fix applied! %s settings updated.', 'ultimate-performance' ),
				$module_label
			),
			'module'   => $module,
			'audit_id' => $audit_id,
		) );
	}

	/**
	 * Build fix suggestions mapping audit failures to plugin modules.
	 *
	 * @since  1.2.0
	 * @param  array $audits Lighthouse audits.
	 * @return array Fix suggestions with module links.
	 */
	private function build_fix_suggestions( $audits ) {
		$audit_to_fix = self::get_audit_fix_map();
		$all_settings = get_option( Ultimate_Performance_Settings::OPTION_NAME, Ultimate_Performance_Settings::get_defaults() );

		$suggestions = array();

		foreach ( $audit_to_fix as $audit_id => $fix ) {
			if ( ! isset( $audits[ $audit_id ] ) ) {
				continue;
			}
			$audit = $audits[ $audit_id ];
			if ( ! isset( $audit['score'] ) || null === $audit['score'] || $audit['score'] >= 0.9 ) {
				continue;
			}

			$can_auto_fix    = ! empty( $fix['module'] ) && ! empty( $fix['settings'] );
			$already_applied = false;

			if ( ! empty( $fix['module'] ) ) {
				$mod = isset( $all_settings[ $fix['module'] ] ) ? $all_settings[ $fix['module'] ] : array();
				if ( ! empty( $mod['enabled'] ) ) {
					$already_applied = true;
					if ( $can_auto_fix ) {
						foreach ( $fix['settings'] as $fk => $fv ) {
							if ( empty( $mod[ $fk ] ) ) {
								$already_applied = false;
								break;
							}
						}
					}
				}
			}

			$suggestions[] = array(
				'audit_id'        => $audit_id,
				'audit_title'     => isset( $audit['title'] ) ? $audit['title'] : $audit_id,
				'score'           => $audit['score'],
				'module'          => $fix['module'],
				'tip'             => $fix['tip'],
				'can_auto_fix'    => $can_auto_fix,
				'already_applied' => $already_applied,
			);
		}

		// Sort by score ascending (worst first).
		usort( $suggestions, function ( $a, $b ) {
			return ( $a['score'] ?? 1 ) <=> ( $b['score'] ?? 1 );
		} );

		return $suggestions;
	}

	/**
	 * Get the current applied status for each fix in the audit fix map.
	 *
	 * Checks current plugin settings to determine which fixes are already
	 * enabled, so the UI can display "Applied" instead of "Apply Fix".
	 *
	 * @since  1.4.0
	 * @return array Map of audit_id => bool (true if already applied).
	 */
	public static function get_fix_applied_status() {
		$fix_map      = self::get_audit_fix_map();
		$all_settings = get_option( Ultimate_Performance_Settings::OPTION_NAME, Ultimate_Performance_Settings::get_defaults() );
		$status       = array();

		foreach ( $fix_map as $audit_id => $fix ) {
			$applied = false;

			if ( ! empty( $fix['module'] ) ) {
				$mod = isset( $all_settings[ $fix['module'] ] ) ? $all_settings[ $fix['module'] ] : array();

				if ( ! empty( $mod['enabled'] ) ) {
					$applied = true;

					if ( ! empty( $fix['settings'] ) ) {
						foreach ( $fix['settings'] as $fk => $fv ) {
							if ( empty( $mod[ $fk ] ) ) {
								$applied = false;
								break;
							}
						}
					}
				}
			}

			$status[ $audit_id ] = $applied;
		}

		return $status;
	}

	/**
	 * Extract failed/warning audits for a specific Lighthouse category.
	 *
	 * Reads auditRefs from the category to identify which audits belong
	 * to it, then returns those with score < 1 (failed or warning).
	 *
	 * @since  1.5.0
	 * @param  array  $categories Lighthouse categories data.
	 * @param  array  $audits     Lighthouse audits data.
	 * @param  string $category   Category key (e.g. 'accessibility', 'seo', 'best-practices').
	 * @return array  Failed audits with id, title, description, score, and detail items.
	 */
	private function extract_category_audits( $categories, $audits, $category ) {
		if ( ! isset( $categories[ $category ]['auditRefs'] ) ) {
			return array();
		}

		$audit_refs = $categories[ $category ]['auditRefs'];
		$results    = array();

		foreach ( $audit_refs as $ref ) {
			$audit_id = isset( $ref['id'] ) ? $ref['id'] : '';
			if ( empty( $audit_id ) || ! isset( $audits[ $audit_id ] ) ) {
				continue;
			}

			$audit       = $audits[ $audit_id ];
			$audit_score = isset( $audit['score'] ) ? $audit['score'] : null;

			// Skip passed audits (score = 1), not-applicable, and informational.
			if ( null === $audit_score || 1 === (int) $audit_score || $audit_score >= 0.9 ) {
				continue;
			}

			// Skip manual audits (scoreDisplayMode = 'manual').
			if ( isset( $audit['scoreDisplayMode'] ) && 'manual' === $audit['scoreDisplayMode'] ) {
				continue;
			}

			$item = array(
				'id'          => $audit_id,
				'title'       => isset( $audit['title'] ) ? $audit['title'] : $audit_id,
				'description' => isset( $audit['description'] ) ? $audit['description'] : '',
				'score'       => $audit_score,
				'group'       => isset( $ref['group'] ) ? $ref['group'] : '',
			);

			if ( ! empty( $audit['displayValue'] ) ) {
				$item['value'] = $audit['displayValue'];
			}

			// Extract detail items (capped at 10).
			if ( isset( $audit['details']['items'] ) && is_array( $audit['details']['items'] ) ) {
				$detail_items = array();
				$items_slice  = array_slice( $audit['details']['items'], 0, 10 );

				foreach ( $items_slice as $di ) {
					$detail = array();

					// Node-based items (common in accessibility audits).
					if ( isset( $di['node'] ) && is_array( $di['node'] ) ) {
						if ( isset( $di['node']['snippet'] ) ) {
							$detail['element'] = wp_kses_post( $di['node']['snippet'] );
						}
						if ( isset( $di['node']['selector'] ) ) {
							$detail['selector'] = sanitize_text_field( $di['node']['selector'] );
						}
						if ( isset( $di['node']['explanation'] ) ) {
							$detail['explanation'] = sanitize_text_field( $di['node']['explanation'] );
						}
					}

					// Generic scalar values.
					foreach ( $di as $dk => $dv ) {
						if ( 'node' === $dk ) {
							continue;
						}
						if ( is_scalar( $dv ) && ! isset( $detail[ $dk ] ) ) {
							$detail[ $dk ] = $dv;
						}
					}

					if ( ! empty( $detail ) ) {
						$detail_items[] = $detail;
					}
				}

				if ( ! empty( $detail_items ) ) {
					$item['items'] = $detail_items;
				}
			}

			$results[] = $item;
		}

		// Sort by score ascending (worst issues first).
		usort( $results, function ( $a, $b ) {
			return ( $a['score'] ?? 1 ) <=> ( $b['score'] ?? 1 );
		} );

		return $results;
	}

	/**
	 * Extract a category score (0-100) from categories data.
	 *
	 * @since  1.0.0
	 * @param  array  $categories Lighthouse categories.
	 * @param  string $key        Category key.
	 * @return int    Score 0-100.
	 */
	private function extract_category_score( $categories, $key ) {
		if ( isset( $categories[ $key ]['score'] ) ) {
			return (int) round( $categories[ $key ]['score'] * 100 );
		}
		return 0;
	}

	/**
	 * Extract metric display value, score, and numeric value.
	 *
	 * @since  1.0.0
	 * @param  array  $audits Lighthouse audits array.
	 * @param  string $key    Audit key name.
	 * @return array  { value, score, numericValue }.
	 */
	private function extract_metric_full( $audits, $key ) {
		$value        = '—';
		$score        = null;
		$numericValue = null;

		if ( isset( $audits[ $key ] ) ) {
			if ( isset( $audits[ $key ]['displayValue'] ) ) {
				$value = $audits[ $key ]['displayValue'];
			}
			if ( isset( $audits[ $key ]['score'] ) ) {
				$score = $audits[ $key ]['score'];
			}
			if ( isset( $audits[ $key ]['numericValue'] ) ) {
				$numericValue = $audits[ $key ]['numericValue'];
			}
		}

		return array(
			'value'        => $value,
			'score'        => $score,
			'numericValue' => $numericValue,
		);
	}

	/**
	 * Format bytes into human-readable string.
	 *
	 * @since  1.0.0
	 * @param  int    $bytes Byte count.
	 * @return string Formatted string (e.g., "150 KB", "1.2 MB").
	 */
	private function format_bytes( $bytes ) {
		if ( $bytes >= 1048576 ) {
			return round( $bytes / 1048576, 1 ) . ' MB';
		}
		if ( $bytes >= 1024 ) {
			return round( $bytes / 1024 ) . ' KB';
		}
		return $bytes . ' B';
	}
}
