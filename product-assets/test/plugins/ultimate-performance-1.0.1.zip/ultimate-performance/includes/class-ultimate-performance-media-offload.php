<?php
/**
 * Handles media offloading to S3-compatible cloud storage.
 *
 * Supports AWS S3, DigitalOcean Spaces, Cloudflare R2, and Backblaze B2.
 * Uses the S3 REST API with AWS Signature V4 signing — no SDK required.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Media_Offload
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Media_Offload {

	/**
	 * Module settings (from CDN module).
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Initialize the media offload module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'cdn' );

		// Always register AJAX handlers.
		add_action( 'wp_ajax_up_offload_test_connection', array( $this, 'ajax_test_connection' ) );
		add_action( 'wp_ajax_up_offload_bulk', array( $this, 'ajax_bulk_offload' ) );
		add_action( 'wp_ajax_up_offload_configure_bucket', array( $this, 'ajax_configure_bucket' ) );

		if ( empty( $this->settings['offload_media'] ) ) {
			return;
		}

		if ( empty( $this->settings['offload_access_key'] ) || empty( $this->settings['offload_secret_key'] ) || empty( $this->settings['offload_bucket'] ) ) {
			return;
		}

		// Hook into new uploads.
		add_filter( 'wp_generate_attachment_metadata', array( $this, 'handle_upload' ), 10, 2 );

		// Rewrite attachment URLs.
		add_filter( 'wp_get_attachment_url', array( $this, 'rewrite_attachment_url' ), 10, 2 );
		add_filter( 'wp_get_attachment_image_src', array( $this, 'rewrite_image_src' ), 10, 4 );
		add_filter( 'wp_calculate_image_srcset', array( $this, 'rewrite_srcset' ), 10, 5 );

		// Rewrite hardcoded media URLs in post content.
		add_filter( 'the_content', array( $this, 'rewrite_content_urls' ), 999 );

		// Rewrite URLs in custom CSS (Customizer, etc.).
		add_filter( 'wp_get_custom_css', array( $this, 'rewrite_custom_css_urls' ), 10 );

		// Delete from remote when attachment is deleted.
		add_action( 'delete_attachment', array( $this, 'handle_delete' ), 10 );
	}

	/**
	 * Get the S3-compatible endpoint for the configured provider.
	 *
	 * @since  1.0.0
	 * @return string Endpoint hostname.
	 */
	private function get_endpoint() {
		$provider = $this->settings['offload_provider'];
		$region   = $this->settings['offload_region'];
		$endpoint = trim( $this->settings['offload_endpoint'] );

		if ( ! empty( $endpoint ) ) {
			return rtrim( $endpoint, '/' );
		}

		switch ( $provider ) {
			case 'do_spaces':
				return $region . '.digitaloceanspaces.com';
			case 'r2':
				// R2 needs the account ID as the endpoint. User must provide it.
				return '';
			case 'b2':
				return 's3.' . $region . '.backblazeb2.com';
			case 's3':
			default:
				return 's3.' . $region . '.amazonaws.com';
		}
	}

	/**
	 * Get the public-facing URL base for offloaded files.
	 *
	 * @since  1.0.0
	 * @return string Base URL (no trailing slash).
	 */
	private function get_serve_url() {
		$serve_url = trim( $this->settings['offload_serve_url'] );
		if ( ! empty( $serve_url ) ) {
			return rtrim( $serve_url, '/' );
		}

		$endpoint = $this->get_endpoint();
		$bucket   = $this->settings['offload_bucket'];

		return 'https://' . $bucket . '.' . $endpoint;
	}

	/**
	 * Get the S3 object key for a file path relative to uploads dir.
	 *
	 * @since  1.0.0
	 * @param  string $file Path relative to uploads directory (e.g. 2024/01/photo.jpg).
	 * @return string S3 object key.
	 */
	private function get_object_key( $file ) {
		$prefix = trim( $this->settings['offload_path_prefix'], '/' );
		if ( ! empty( $prefix ) ) {
			$prefix .= '/';
		}
		return $prefix . ltrim( $file, '/' );
	}

	/**
	 * Upload a file to S3-compatible storage.
	 *
	 * @since  1.0.0
	 * @param  string $local_path Absolute local file path.
	 * @param  string $key        S3 object key.
	 * @return bool True on success.
	 */
	private function s3_put_object( $local_path, $key ) {
		if ( ! file_exists( $local_path ) ) {
			return false;
		}

		$endpoint    = $this->get_endpoint();
		$bucket      = $this->settings['offload_bucket'];
		$region      = $this->settings['offload_region'];
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
		$body        = file_get_contents( $local_path );
		$content_type = wp_check_filetype( basename( $local_path ) )['type'] ?: 'application/octet-stream';

		$url     = 'https://' . $endpoint . '/' . $bucket . '/' . $key;
		$headers = $this->sign_s3_request( 'PUT', '/' . $bucket . '/' . $key, $endpoint, $region, $body, $content_type );

		$response = wp_remote_request( $url, array(
			'method'  => 'PUT',
			'timeout' => 60,
			'headers' => $headers,
			'body'    => $body,
		) );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$code = wp_remote_retrieve_response_code( $response );
		return $code >= 200 && $code < 300;
	}

	/**
	 * Check if an object exists in S3.
	 *
	 * @since  1.0.0
	 * @param  string $key S3 object key.
	 * @return bool
	 */
	private function s3_head_object( $key ) {
		$endpoint = $this->get_endpoint();
		$bucket   = $this->settings['offload_bucket'];
		$region   = $this->settings['offload_region'];

		$url     = 'https://' . $endpoint . '/' . $bucket . '/' . $key;
		$headers = $this->sign_s3_request( 'HEAD', '/' . $bucket . '/' . $key, $endpoint, $region );

		$response = wp_remote_request( $url, array(
			'method'  => 'HEAD',
			'timeout' => 15,
			'headers' => $headers,
		) );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		return 200 === wp_remote_retrieve_response_code( $response );
	}

	/**
	 * Delete an object from S3.
	 *
	 * @since  1.0.0
	 * @param  string $key S3 object key.
	 * @return bool
	 */
	private function s3_delete_object( $key ) {
		$endpoint = $this->get_endpoint();
		$bucket   = $this->settings['offload_bucket'];
		$region   = $this->settings['offload_region'];

		$url     = 'https://' . $endpoint . '/' . $bucket . '/' . $key;
		$headers = $this->sign_s3_request( 'DELETE', '/' . $bucket . '/' . $key, $endpoint, $region );

		$response = wp_remote_request( $url, array(
			'method'  => 'DELETE',
			'timeout' => 15,
			'headers' => $headers,
		) );

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$code = wp_remote_retrieve_response_code( $response );
		return $code >= 200 && $code < 300;
	}

	/**
	 * Sign an S3 request using AWS Signature V4.
	 *
	 * @since  1.0.0
	 * @param  string $method        HTTP method.
	 * @param  string $path          URL path (e.g. /bucket/key).
	 * @param  string $host          Endpoint hostname.
	 * @param  string $region        AWS region.
	 * @param  string $payload       Request body (empty string for GET/HEAD/DELETE).
	 * @param  string $content_type  Content-Type header value.
	 * @param  array  $extra_headers Additional headers to sign and include.
	 * @param  string $query_string  Canonical query string (e.g. 'cors=' or 'policy=').
	 * @return array  Headers array for wp_remote_request.
	 */
	private function sign_s3_request( $method, $path, $host, $region, $payload = '', $content_type = '', $extra_headers = array(), $query_string = '' ) {
		$access_key = $this->settings['offload_access_key'];
		$secret_key = $this->settings['offload_secret_key'];
		$service    = 's3';

		$date       = gmdate( 'Ymd\THis\Z' );
		$date_short = gmdate( 'Ymd' );

		$payload_hash = hash( 'sha256', $payload );

		$headers = array(
			'host'                 => $host,
			'x-amz-content-sha256' => $payload_hash,
			'x-amz-date'          => $date,
		);

		if ( ! empty( $content_type ) ) {
			$headers['content-type'] = $content_type;
		}

		// Merge extra headers (e.g. x-amz-acl, content-md5).
		foreach ( $extra_headers as $k => $v ) {
			$headers[ strtolower( $k ) ] = $v;
		}

		// Build canonical headers (sorted).
		ksort( $headers );
		$canonical_headers = '';
		$signed_header_keys = array();
		foreach ( $headers as $k => $v ) {
			$canonical_headers .= strtolower( $k ) . ':' . trim( $v ) . "\n";
			$signed_header_keys[] = strtolower( $k );
		}
		$signed_headers = implode( ';', $signed_header_keys );

		// Canonical request.
		$canonical_request = implode( "\n", array(
			$method,
			$path,
			$query_string,
			$canonical_headers,
			$signed_headers,
			$payload_hash,
		) );

		// String to sign.
		$credential_scope = $date_short . '/' . $region . '/' . $service . '/aws4_request';
		$string_to_sign   = implode( "\n", array(
			'AWS4-HMAC-SHA256',
			$date,
			$credential_scope,
			hash( 'sha256', $canonical_request ),
		) );

		// Signing key.
		$k_date    = hash_hmac( 'sha256', $date_short, 'AWS4' . $secret_key, true );
		$k_region  = hash_hmac( 'sha256', $region, $k_date, true );
		$k_service = hash_hmac( 'sha256', $service, $k_region, true );
		$k_signing = hash_hmac( 'sha256', 'aws4_request', $k_service, true );

		$signature = hash_hmac( 'sha256', $string_to_sign, $k_signing );

		$authorization = sprintf(
			'AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s',
			$access_key,
			$credential_scope,
			$signed_headers,
			$signature
		);

		// Build the final request headers.
		$request_headers = array(
			'Host'                 => $host,
			'Authorization'        => $authorization,
			'x-amz-content-sha256' => $payload_hash,
			'x-amz-date'          => $date,
		);

		// Only include Content-Type when there is a body.
		if ( ! empty( $content_type ) ) {
			$request_headers['Content-Type'] = $content_type;
		}

		// Include extra headers in the actual request too.
		foreach ( $extra_headers as $k => $v ) {
			$request_headers[ $k ] = $v;
		}

		return $request_headers;
	}

	/**
	 * Extract error message from an S3 XML error response.
	 *
	 * @since  1.0.0
	 * @param  array|WP_Error $response wp_remote_request response.
	 * @return string Human-readable error detail or empty string.
	 */
	private function parse_s3_error( $response ) {
		if ( is_wp_error( $response ) ) {
			return $response->get_error_message();
		}

		$body = wp_remote_retrieve_body( $response );
		if ( empty( $body ) ) {
			return '';
		}

		// Try to extract <Code> and <Message> from S3 XML error.
		$code_match    = array();
		$message_match = array();
		preg_match( '/<Code>(.+?)<\/Code>/', $body, $code_match );
		preg_match( '/<Message>(.+?)<\/Message>/', $body, $message_match );

		$parts = array();
		if ( ! empty( $code_match[1] ) ) {
			$parts[] = $code_match[1];
		}
		if ( ! empty( $message_match[1] ) ) {
			$parts[] = $message_match[1];
		}

		return implode( ': ', $parts );
	}

	/**
	 * Remove the S3 Public Access Block on the bucket.
	 *
	 * This must be done before a bucket policy or ACLs can grant public access.
	 *
	 * @since  1.0.0
	 * @return array Result with 'success' bool and 'message' string.
	 */
	private function s3_delete_public_access_block() {
		$endpoint = $this->get_endpoint();
		$bucket   = $this->settings['offload_bucket'];
		$region   = $this->settings['offload_region'];

		$path    = '/' . $bucket;
		$url     = 'https://' . $endpoint . $path . '?publicAccessBlock';
		$headers = $this->sign_s3_request( 'DELETE', $path, $endpoint, $region, '', '', array(), 'publicAccessBlock=' );

		$response = wp_remote_request( $url, array(
			'method'  => 'DELETE',
			'timeout' => 15,
			'headers' => $headers,
		) );

		if ( is_wp_error( $response ) ) {
			return array( 'success' => false, 'message' => $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		// 204 = success, 404 = no config existed (also OK).
		if ( 204 === $code || 404 === $code ) {
			return array( 'success' => true, 'message' => __( 'Public Access Block removed.', 'ultimate-performance' ) );
		}

		$s3_error = $this->parse_s3_error( $response );

		if ( 403 === $code ) {
			return array(
				'success' => false,
				/* translators: %s: S3 error detail */
				'message' => sprintf( __( 'Permission denied removing Public Access Block. %s', 'ultimate-performance' ), $s3_error ),
			);
		}

		return array(
			'success' => false,
			/* translators: 1: HTTP code, 2: S3 error detail */
			'message' => sprintf( __( 'Public Access Block removal failed (HTTP %1$d). %2$s', 'ultimate-performance' ), $code, $s3_error ),
		);
	}

	/**
	 * Set a bucket policy that allows public read access to all objects.
	 *
	 * @since  1.0.0
	 * @return array Result with 'success' bool and 'message' string.
	 */
	private function s3_put_bucket_policy() {
		$endpoint = $this->get_endpoint();
		$bucket   = $this->settings['offload_bucket'];
		$region   = $this->settings['offload_region'];
		$provider = $this->settings['offload_provider'];

		// Build the ARN based on provider.
		if ( 'r2' === $provider ) {
			// R2 does not use bucket policies — use public access via R2 dashboard.
			return array( 'success' => true, 'message' => __( 'Skipped for R2 (enable public access in Cloudflare dashboard).', 'ultimate-performance' ) );
		}

		$arn = 'arn:aws:s3:::' . $bucket . '/*';
		if ( 'b2' === $provider ) {
			$arn = 'arn:aws:s3:::' . $bucket . '/*';
		}

		$policy = wp_json_encode( array(
			'Version'   => '2012-10-17',
			'Statement' => array(
				array(
					'Sid'       => 'PublicReadGetObject',
					'Effect'    => 'Allow',
					'Principal' => '*',
					'Action'    => 's3:GetObject',
					'Resource'  => $arn,
				),
			),
		) );

		$path    = '/' . $bucket;
		$url     = 'https://' . $endpoint . $path . '?policy';
		$headers = $this->sign_s3_request( 'PUT', $path, $endpoint, $region, $policy, 'application/json', array(), 'policy=' );

		$response = wp_remote_request( $url, array(
			'method'  => 'PUT',
			'timeout' => 15,
			'headers' => $headers,
			'body'    => $policy,
		) );

		if ( is_wp_error( $response ) ) {
			return array( 'success' => false, 'message' => $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code >= 200 && $code < 300 ) {
			return array( 'success' => true, 'message' => __( 'Bucket policy set for public read access.', 'ultimate-performance' ) );
		}

		$s3_error = $this->parse_s3_error( $response );

		if ( 403 === $code ) {
			return array(
				'success' => false,
				/* translators: %s: S3 error detail */
				'message' => sprintf( __( 'Permission denied setting bucket policy. %s Ensure "Block Public Access" is disabled at BOTH bucket AND account level.', 'ultimate-performance' ), $s3_error ),
			);
		}

		return array(
			'success' => false,
			/* translators: 1: HTTP code, 2: S3 error detail */
			'message' => sprintf( __( 'Bucket policy failed (HTTP %1$d). %2$s', 'ultimate-performance' ), $code, $s3_error ),
		);
	}

	/**
	 * Set CORS configuration on the bucket to allow cross-origin requests.
	 *
	 * @since  1.0.0
	 * @return array Result with 'success' bool and 'message' string.
	 */
	private function s3_put_cors() {
		$endpoint = $this->get_endpoint();
		$bucket   = $this->settings['offload_bucket'];
		$region   = $this->settings['offload_region'];
		$site_url = home_url();

		$cors_xml = '<?xml version="1.0" encoding="UTF-8"?>'
			. '<CORSConfiguration>'
			. '<CORSRule>'
			. '<AllowedOrigin>' . esc_xml( $site_url ) . '</AllowedOrigin>'
			. '<AllowedOrigin>*</AllowedOrigin>'
			. '<AllowedMethod>GET</AllowedMethod>'
			. '<AllowedMethod>HEAD</AllowedMethod>'
			. '<MaxAgeSeconds>3600</MaxAgeSeconds>'
			. '<AllowedHeader>*</AllowedHeader>'
			. '</CORSRule>'
			. '</CORSConfiguration>';

		// S3 requires Content-MD5 for CORS PUT.
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		$content_md5 = base64_encode( md5( $cors_xml, true ) );

		$extra_headers = array(
			'content-md5' => $content_md5,
		);

		$path    = '/' . $bucket;
		$url     = 'https://' . $endpoint . $path . '?cors';
		$headers = $this->sign_s3_request( 'PUT', $path, $endpoint, $region, $cors_xml, 'application/xml', $extra_headers, 'cors=' );

		$response = wp_remote_request( $url, array(
			'method'  => 'PUT',
			'timeout' => 15,
			'headers' => $headers,
			'body'    => $cors_xml,
		) );

		if ( is_wp_error( $response ) ) {
			return array( 'success' => false, 'message' => $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code >= 200 && $code < 300 ) {
			return array( 'success' => true, 'message' => __( 'CORS configuration applied.', 'ultimate-performance' ) );
		}

		$s3_error = $this->parse_s3_error( $response );

		if ( 403 === $code ) {
			return array(
				'success' => false,
				/* translators: %s: S3 error detail */
				'message' => sprintf( __( 'Permission denied for CORS. %s', 'ultimate-performance' ), $s3_error ),
			);
		}

		return array(
			'success' => false,
			/* translators: 1: HTTP code, 2: S3 error detail */
			'message' => sprintf( __( 'CORS configuration failed (HTTP %1$d). %2$s', 'ultimate-performance' ), $code, $s3_error ),
		);
	}

	/**
	 * AJAX: Configure bucket for public access (policy + CORS).
	 *
	 * Runs three operations in sequence:
	 * 1. Remove Public Access Block
	 * 2. Set bucket policy for public read
	 * 3. Set CORS configuration
	 *
	 * @since 1.0.0
	 */
	public function ajax_configure_bucket() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		// Use values from POST (form may not be saved yet).
		$this->settings['offload_provider']   = sanitize_text_field( wp_unslash( $_POST['provider'] ?? '' ) );
		$this->settings['offload_access_key'] = sanitize_text_field( wp_unslash( $_POST['access_key'] ?? '' ) );
		$this->settings['offload_secret_key'] = sanitize_text_field( wp_unslash( $_POST['secret_key'] ?? '' ) );
		$this->settings['offload_bucket']     = sanitize_text_field( wp_unslash( $_POST['bucket'] ?? '' ) );
		$this->settings['offload_region']     = sanitize_text_field( wp_unslash( $_POST['region'] ?? '' ) );
		$this->settings['offload_endpoint']   = sanitize_text_field( wp_unslash( $_POST['endpoint'] ?? '' ) );

		if ( empty( $this->settings['offload_access_key'] ) || empty( $this->settings['offload_secret_key'] ) || empty( $this->settings['offload_bucket'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Please fill in access key, secret key, and bucket name.', 'ultimate-performance' ) ) );
		}

		$endpoint = $this->get_endpoint();
		if ( empty( $endpoint ) ) {
			wp_send_json_error( array( 'message' => __( 'Could not determine endpoint. Please provide a custom endpoint URL.', 'ultimate-performance' ) ) );
		}

		$results = array();

		// Step 1: Remove Public Access Block.
		$results[] = $this->s3_delete_public_access_block();

		// Step 2: Set bucket policy.
		$results[] = $this->s3_put_bucket_policy();

		// Step 3: Set CORS.
		$results[] = $this->s3_put_cors();

		// Build response.
		$all_success = true;
		$messages    = array();
		foreach ( $results as $result ) {
			$messages[] = $result['message'];
			if ( ! $result['success'] ) {
				$all_success = false;
			}
		}

		if ( $all_success ) {
			wp_send_json_success( array(
				'message' => __( 'Bucket configured successfully! Public read access and CORS are now enabled.', 'ultimate-performance' ),
				'details' => $messages,
			) );
		}

		// Partial success or full failure — include step-by-step detail and account-level hint.
		$summary = implode( ' | ', $messages );
		wp_send_json_error( array(
			'message' => $summary . "\n\n" . __( 'Tip: Make sure "Block Public Access" is disabled at BOTH the bucket level AND the AWS account level (S3 > Block Public Access settings for this account).', 'ultimate-performance' ),
			'details' => $messages,
		) );
	}

	/**
	 * Handle new media uploads — offload to remote storage.
	 *
	 * @since  1.0.0
	 * @param  array $metadata      Attachment metadata.
	 * @param  int   $attachment_id Attachment post ID.
	 * @return array Metadata (unmodified).
	 */
	public function handle_upload( $metadata, $attachment_id ) {
		$file = get_attached_file( $attachment_id );
		if ( ! $file || ! file_exists( $file ) ) {
			return $metadata;
		}

		$upload_dir = wp_get_upload_dir();
		$rel_path   = str_replace( $upload_dir['basedir'] . '/', '', $file );
		$rel_path   = str_replace( $upload_dir['basedir'] . '\\', '', $rel_path );

		// Upload main file.
		$key     = $this->get_object_key( $rel_path );
		$success = $this->s3_put_object( $file, $key );

		if ( $success ) {
			update_post_meta( $attachment_id, '_up_offloaded', 1 );
			update_post_meta( $attachment_id, '_up_offload_key', $key );

			// Upload thumbnails.
			if ( ! empty( $metadata['sizes'] ) ) {
				$dir = dirname( $file );
				foreach ( $metadata['sizes'] as $size ) {
					$thumb_path = $dir . '/' . $size['file'];
					if ( file_exists( $thumb_path ) ) {
						$thumb_rel  = dirname( $rel_path ) . '/' . $size['file'];
						$thumb_key  = $this->get_object_key( $thumb_rel );
						$this->s3_put_object( $thumb_path, $thumb_key );
					}
				}
			}

			// Optionally remove local files.
			if ( ! empty( $this->settings['offload_remove_local'] ) ) {
				$this->remove_local_files( $file, $metadata );
			}
		}

		return $metadata;
	}

	/**
	 * Remove local files after successful offload.
	 *
	 * @since 1.0.0
	 * @param string $file     Main file path.
	 * @param array  $metadata Attachment metadata.
	 */
	private function remove_local_files( $file, $metadata ) {
		if ( file_exists( $file ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
			unlink( $file );
		}

		if ( ! empty( $metadata['sizes'] ) ) {
			$dir = dirname( $file );
			foreach ( $metadata['sizes'] as $size ) {
				$thumb = $dir . '/' . $size['file'];
				if ( file_exists( $thumb ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
					unlink( $thumb );
				}
			}
		}
	}

	/**
	 * Rewrite attachment URL to point to remote storage.
	 *
	 * @since  1.0.0
	 * @param  string $url           Original URL.
	 * @param  int    $attachment_id Attachment post ID.
	 * @return string Rewritten URL or original.
	 */
	public function rewrite_attachment_url( $url, $attachment_id ) {
		if ( ! get_post_meta( $attachment_id, '_up_offloaded', true ) ) {
			return $url;
		}

		$key = get_post_meta( $attachment_id, '_up_offload_key', true );
		if ( empty( $key ) ) {
			return $url;
		}

		return $this->get_serve_url() . '/' . $key;
	}

	/**
	 * Rewrite image src array for offloaded images.
	 *
	 * @since  1.0.0
	 * @param  array|false  $image         Image data array or false.
	 * @param  int          $attachment_id Attachment ID.
	 * @param  string|int[] $size          Image size.
	 * @param  bool         $icon          Whether it's an icon.
	 * @return array|false
	 */
	public function rewrite_image_src( $image, $attachment_id, $size, $icon ) {
		if ( ! $image || ! get_post_meta( $attachment_id, '_up_offloaded', true ) ) {
			return $image;
		}

		$upload_dir = wp_get_upload_dir();
		$base_url   = $upload_dir['baseurl'];
		$serve_url  = $this->get_serve_url();
		$prefix     = trim( $this->settings['offload_path_prefix'], '/' );
		if ( ! empty( $prefix ) ) {
			$prefix .= '/';
		}

		if ( ! empty( $image[0] ) && 0 === strpos( $image[0], $base_url ) ) {
			$rel_path  = str_replace( $base_url . '/', '', $image[0] );
			$image[0]  = $serve_url . '/' . $prefix . $rel_path;
		}

		return $image;
	}

	/**
	 * Rewrite srcset URLs for offloaded images.
	 *
	 * @since  1.0.0
	 * @param  array  $sources       Array of srcset sources.
	 * @param  int[]  $size_array    Width and height.
	 * @param  string $image_src     The src attribute.
	 * @param  array  $image_meta    Image metadata.
	 * @param  int    $attachment_id Attachment ID.
	 * @return array
	 */
	public function rewrite_srcset( $sources, $size_array, $image_src, $image_meta, $attachment_id ) {
		if ( ! get_post_meta( $attachment_id, '_up_offloaded', true ) ) {
			return $sources;
		}

		$upload_dir = wp_get_upload_dir();
		$base_url   = $upload_dir['baseurl'];
		$serve_url  = $this->get_serve_url();
		$prefix     = trim( $this->settings['offload_path_prefix'], '/' );
		if ( ! empty( $prefix ) ) {
			$prefix .= '/';
		}

		foreach ( $sources as &$source ) {
			if ( 0 === strpos( $source['url'], $base_url ) ) {
				$rel_path      = str_replace( $base_url . '/', '', $source['url'] );
				$source['url'] = $serve_url . '/' . $prefix . $rel_path;
			}
		}

		return $sources;
	}

	/**
	 * Rewrite hardcoded media URLs in post content (the_content).
	 *
	 * Handles images, links, and other media embedded directly in post HTML
	 * by replacing the local uploads base URL with the remote serve URL.
	 *
	 * @since  1.0.0
	 * @param  string $content Post content HTML.
	 * @return string Content with rewritten URLs.
	 */
	public function rewrite_content_urls( $content ) {
		if ( empty( $content ) ) {
			return $content;
		}

		$upload_dir = wp_get_upload_dir();
		$base_url   = $upload_dir['baseurl'];
		$serve_url  = $this->get_serve_url();
		$prefix     = trim( $this->settings['offload_path_prefix'], '/' );
		if ( ! empty( $prefix ) ) {
			$prefix = '/' . $prefix;
		}

		// Replace local upload URLs with remote serve URLs.
		// Handles both http and https versions of the base URL.
		$search  = array(
			$base_url,
			str_replace( 'https://', 'http://', $base_url ),
		);
		$replace = array(
			$serve_url . $prefix,
			$serve_url . $prefix,
		);

		return str_replace( $search, $replace, $content );
	}

	/**
	 * Rewrite media URLs in custom CSS (Customizer).
	 *
	 * @since  1.0.0
	 * @param  string $css Custom CSS content.
	 * @return string CSS with rewritten URLs.
	 */
	public function rewrite_custom_css_urls( $css ) {
		if ( empty( $css ) ) {
			return $css;
		}

		return $this->rewrite_content_urls( $css );
	}

	/**
	 * Delete remote files when an attachment is deleted.
	 *
	 * @since 1.0.0
	 * @param int $attachment_id Attachment post ID.
	 */
	public function handle_delete( $attachment_id ) {
		if ( ! get_post_meta( $attachment_id, '_up_offloaded', true ) ) {
			return;
		}

		$key = get_post_meta( $attachment_id, '_up_offload_key', true );
		if ( ! empty( $key ) ) {
			$this->s3_delete_object( $key );
		}

		// Delete thumbnails.
		$metadata = wp_get_attachment_metadata( $attachment_id );
		if ( ! empty( $metadata['sizes'] ) ) {
			$dir = dirname( $key );
			foreach ( $metadata['sizes'] as $size ) {
				$thumb_key = $dir . '/' . $size['file'];
				$this->s3_delete_object( $thumb_key );
			}
		}
	}

	/**
	 * AJAX: Test connection to the configured storage provider.
	 *
	 * @since 1.0.0
	 */
	public function ajax_test_connection() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		// Use values from POST (form may not be saved yet).
		$this->settings['offload_provider']   = sanitize_text_field( wp_unslash( $_POST['provider'] ?? '' ) );
		$this->settings['offload_access_key'] = sanitize_text_field( wp_unslash( $_POST['access_key'] ?? '' ) );
		$this->settings['offload_secret_key'] = sanitize_text_field( wp_unslash( $_POST['secret_key'] ?? '' ) );
		$this->settings['offload_bucket']     = sanitize_text_field( wp_unslash( $_POST['bucket'] ?? '' ) );
		$this->settings['offload_region']     = sanitize_text_field( wp_unslash( $_POST['region'] ?? '' ) );
		$this->settings['offload_endpoint']   = sanitize_text_field( wp_unslash( $_POST['endpoint'] ?? '' ) );

		if ( empty( $this->settings['offload_access_key'] ) || empty( $this->settings['offload_secret_key'] ) || empty( $this->settings['offload_bucket'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Please fill in access key, secret key, and bucket name.', 'ultimate-performance' ) ) );
		}

		$endpoint = $this->get_endpoint();
		if ( empty( $endpoint ) ) {
			wp_send_json_error( array( 'message' => __( 'Could not determine endpoint. Please provide a custom endpoint URL.', 'ultimate-performance' ) ) );
		}

		// Try a HEAD request on the bucket to verify access.
		$bucket  = $this->settings['offload_bucket'];
		$region  = $this->settings['offload_region'];
		$url     = 'https://' . $endpoint . '/' . $bucket;
		$headers = $this->sign_s3_request( 'HEAD', '/' . $bucket, $endpoint, $region );

		$response = wp_remote_request( $url, array(
			'method'  => 'HEAD',
			'timeout' => 15,
			'headers' => $headers,
		) );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array( 'message' => $response->get_error_message() ) );
		}

		$code = wp_remote_retrieve_response_code( $response );

		if ( 200 === $code || 301 === $code ) {
			wp_send_json_success( array(
				/* translators: %s: bucket name */
				'message' => sprintf( __( 'Connected successfully to bucket: %s', 'ultimate-performance' ), $bucket ),
			) );
		}

		if ( 403 === $code ) {
			wp_send_json_error( array( 'message' => __( 'Access denied. Check your access key, secret key, and bucket permissions.', 'ultimate-performance' ) ) );
		}

		if ( 404 === $code ) {
			wp_send_json_error( array( 'message' => __( 'Bucket not found. Check the bucket name and region.', 'ultimate-performance' ) ) );
		}

		/* translators: %d: HTTP response code */
		wp_send_json_error( array( 'message' => sprintf( __( 'Unexpected response (HTTP %d). Check your credentials and endpoint.', 'ultimate-performance' ), $code ) ) );
	}

	/**
	 * AJAX: Bulk offload existing media library images.
	 *
	 * @since 1.0.0
	 */
	public function ajax_bulk_offload() {
		check_ajax_referer( 'up_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'ultimate-performance' ) ), 403 );
		}

		$batch_size = 5;

		// Get images not yet offloaded.
		$query = new WP_Query( array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'posts_per_page' => $batch_size,
			'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'     => '_up_offloaded',
					'compare' => 'NOT EXISTS',
				),
			),
			'fields'         => 'ids',
		) );

		$ids       = $query->posts;
		$remaining = $query->found_posts;
		$offloaded = 0;

		foreach ( $ids as $attachment_id ) {
			$file = get_attached_file( $attachment_id );
			if ( ! $file || ! file_exists( $file ) ) {
				// Mark as offloaded to skip in future batches.
				update_post_meta( $attachment_id, '_up_offloaded', 0 );
				continue;
			}

			$upload_dir = wp_get_upload_dir();
			$rel_path   = str_replace( $upload_dir['basedir'] . '/', '', $file );
			$rel_path   = str_replace( $upload_dir['basedir'] . '\\', '', $rel_path );
			$key        = $this->get_object_key( $rel_path );

			if ( $this->s3_put_object( $file, $key ) ) {
				update_post_meta( $attachment_id, '_up_offloaded', 1 );
				update_post_meta( $attachment_id, '_up_offload_key', $key );

				// Upload thumbnails.
				$metadata = wp_get_attachment_metadata( $attachment_id );
				if ( ! empty( $metadata['sizes'] ) ) {
					$dir = dirname( $file );
					foreach ( $metadata['sizes'] as $size ) {
						$thumb_path = $dir . '/' . $size['file'];
						if ( file_exists( $thumb_path ) ) {
							$thumb_rel = dirname( $rel_path ) . '/' . $size['file'];
							$this->s3_put_object( $thumb_path, $this->get_object_key( $thumb_rel ) );
						}
					}
				}

				if ( ! empty( $this->settings['offload_remove_local'] ) ) {
					$this->remove_local_files( $file, $metadata ?? array() );
				}

				$offloaded++;
			} else {
				update_post_meta( $attachment_id, '_up_offloaded', 0 );
			}
		}

		$remaining_after = max( 0, $remaining - $batch_size );

		if ( 0 === $remaining ) {
			wp_send_json_success( array(
				'done'      => true,
				'offloaded' => $offloaded,
				'remaining' => 0,
				'total'     => 0,
				'message'   => __( 'All images have been offloaded.', 'ultimate-performance' ),
			) );
		}

		wp_send_json_success( array(
			'done'      => $remaining_after <= 0,
			'offloaded' => $offloaded,
			'remaining' => $remaining_after,
			'total'     => $remaining,
			/* translators: %d: number of remaining images */
			'message'   => sprintf( __( '%d images remaining...', 'ultimate-performance' ), $remaining_after ),
		) );
	}
}
