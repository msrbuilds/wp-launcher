<?php
/**
 * Handles third-party script management (analytics, tracking, custom scripts).
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/includes
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Third_Party
 *
 * Injects optimized tracking scripts (GA4, GTM, Clarity, Meta Pixel)
 * and custom scripts with optional delay-until-interaction support
 * and automatic DNS prefetch hints.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Third_Party {

	/**
	 * Module settings.
	 *
	 * @since 1.0.0
	 * @var   array
	 */
	private $settings;

	/**
	 * Whether any scripts were output (for delay restore script).
	 *
	 * @since 1.0.0
	 * @var   bool
	 */
	private $has_scripts = false;

	/**
	 * Initialize the module.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$this->settings = Ultimate_Performance_Settings::get_module_settings( 'third_party' );

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		if ( is_admin() ) {
			return;
		}

		$this->setup_head_scripts();
		$this->setup_body_scripts();
		$this->setup_footer_scripts();
		$this->setup_dns_prefetch();
		$this->setup_delay_restore();
	}

	/**
	 * Setup head script injection.
	 *
	 * @since 1.0.0
	 */
	private function setup_head_scripts() {
		$has_head = ! empty( $this->settings['ga4_id'] )
			|| ! empty( $this->settings['gtm_id'] )
			|| ! empty( $this->settings['clarity_id'] )
			|| ! empty( $this->settings['meta_pixel_id'] )
			|| ! empty( $this->settings['custom_head_scripts'] );

		if ( $has_head ) {
			add_action( 'wp_head', array( $this, 'inject_head_scripts' ), 1 );
		}
	}

	/**
	 * Setup body open script injection.
	 *
	 * @since 1.0.0
	 */
	private function setup_body_scripts() {
		$has_body = ! empty( $this->settings['gtm_id'] )
			|| ! empty( $this->settings['custom_body_scripts'] );

		if ( $has_body ) {
			add_action( 'wp_body_open', array( $this, 'inject_body_open_scripts' ), 1 );
		}
	}

	/**
	 * Setup footer script injection.
	 *
	 * @since 1.0.0
	 */
	private function setup_footer_scripts() {
		if ( ! empty( $this->settings['custom_footer_scripts'] ) ) {
			add_action( 'wp_footer', array( $this, 'inject_footer_scripts' ), 99 );
		}
	}

	/**
	 * Setup DNS prefetch hints.
	 *
	 * @since 1.0.0
	 */
	private function setup_dns_prefetch() {
		if ( ! empty( $this->settings['dns_prefetch_third_party'] ) ) {
			add_action( 'wp_head', array( $this, 'inject_dns_prefetch' ), 2 );
		}
	}

	/**
	 * Setup delay restore script in footer.
	 *
	 * @since 1.0.0
	 */
	private function setup_delay_restore() {
		if ( ! empty( $this->settings['delay_third_party'] ) ) {
			add_action( 'wp_footer', array( $this, 'output_delay_restore_script' ), 999 );
		}
	}

	/**
	 * Inject scripts into the document head.
	 *
	 * @since 1.0.0
	 */
	public function inject_head_scripts() {
		$delay = ! empty( $this->settings['delay_third_party'] );

		// Google Analytics 4.
		if ( ! empty( $this->settings['ga4_id'] ) ) {
			$ga4_id = sanitize_text_field( $this->settings['ga4_id'] );
			$this->output_ga4( $ga4_id, $delay );
		}

		// Google Tag Manager.
		if ( ! empty( $this->settings['gtm_id'] ) ) {
			$gtm_id = sanitize_text_field( $this->settings['gtm_id'] );
			$this->output_gtm_head( $gtm_id, $delay );
		}

		// Microsoft Clarity.
		if ( ! empty( $this->settings['clarity_id'] ) ) {
			$clarity_id = sanitize_text_field( $this->settings['clarity_id'] );
			$this->output_clarity( $clarity_id, $delay );
		}

		// Meta Pixel.
		if ( ! empty( $this->settings['meta_pixel_id'] ) ) {
			$pixel_id = sanitize_text_field( $this->settings['meta_pixel_id'] );
			$this->output_meta_pixel( $pixel_id, $delay );
		}

		// Custom head scripts.
		if ( ! empty( $this->settings['custom_head_scripts'] ) ) {
			$this->output_custom_scripts( $this->settings['custom_head_scripts'], $delay );
		}
	}

	/**
	 * Inject scripts after the body open tag.
	 *
	 * @since 1.0.0
	 */
	public function inject_body_open_scripts() {
		// GTM noscript fallback (never delayed — it's a noscript).
		if ( ! empty( $this->settings['gtm_id'] ) ) {
			$gtm_id = sanitize_text_field( $this->settings['gtm_id'] );
			$this->output_gtm_body( $gtm_id );
		}

		// Custom body scripts.
		if ( ! empty( $this->settings['custom_body_scripts'] ) ) {
			$delay = ! empty( $this->settings['delay_third_party'] );
			$this->output_custom_scripts( $this->settings['custom_body_scripts'], $delay );
		}
	}

	/**
	 * Inject scripts into the document footer (before </body>).
	 *
	 * @since 1.0.0
	 */
	public function inject_footer_scripts() {
		if ( ! empty( $this->settings['custom_footer_scripts'] ) ) {
			$delay = ! empty( $this->settings['delay_third_party'] );
			$this->output_custom_scripts( $this->settings['custom_footer_scripts'], $delay );
		}
	}

	/**
	 * Output GA4 (gtag.js) snippet.
	 *
	 * @since 1.0.0
	 * @param string $id    GA4 Measurement ID.
	 * @param bool   $delay Whether to delay until interaction.
	 */
	private function output_ga4( $id, $delay ) {
		$this->has_scripts = true;
		$src               = 'https://www.googletagmanager.com/gtag/js?id=' . rawurlencode( $id );

		if ( $delay ) {
			// phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Third-party analytics must be inline.
			echo '<script type="up-delay-third-party" data-up-src="' . esc_url( $src ) . '" async></script>' . "\n";
			echo '<script type="up-delay-third-party">' . "\n";
		} else {
			// phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Third-party analytics must be inline.
			echo '<script async src="' . esc_url( $src ) . '"></script>' . "\n";
			echo '<script>' . "\n";
		}

		echo 'window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());gtag("config","' . esc_js( $id ) . '");' . "\n";
		echo '</script>' . "\n";
	}

	/**
	 * Output GTM head snippet.
	 *
	 * @since 1.0.0
	 * @param string $id    GTM Container ID.
	 * @param bool   $delay Whether to delay until interaction.
	 */
	private function output_gtm_head( $id, $delay ) {
		$this->has_scripts = true;

		if ( $delay ) {
			echo '<script type="up-delay-third-party">' . "\n";
		} else {
			echo '<script>' . "\n";
		}

		echo "(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','" . esc_js( $id ) . "');\n";
		echo '</script>' . "\n";
	}

	/**
	 * Output GTM noscript body fallback.
	 *
	 * @since 1.0.0
	 * @param string $id GTM Container ID.
	 */
	private function output_gtm_body( $id ) {
		echo '<noscript><iframe src="' . esc_url( 'https://www.googletagmanager.com/ns.html?id=' . rawurlencode( $id ) ) . '" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>' . "\n";
	}

	/**
	 * Output Microsoft Clarity snippet.
	 *
	 * @since 1.0.0
	 * @param string $id    Clarity Project ID.
	 * @param bool   $delay Whether to delay until interaction.
	 */
	private function output_clarity( $id, $delay ) {
		$this->has_scripts = true;

		if ( $delay ) {
			echo '<script type="up-delay-third-party">' . "\n";
		} else {
			echo '<script>' . "\n";
		}

		echo "(function(c,l,a,r,i,t,y){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;t.src='https://www.clarity.ms/tag/'+i;y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);})(window,document,'clarity','script','" . esc_js( $id ) . "');\n";
		echo '</script>' . "\n";
	}

	/**
	 * Output Meta Pixel snippet.
	 *
	 * @since 1.0.0
	 * @param string $id    Meta Pixel ID.
	 * @param bool   $delay Whether to delay until interaction.
	 */
	private function output_meta_pixel( $id, $delay ) {
		$this->has_scripts = true;

		if ( $delay ) {
			echo '<script type="up-delay-third-party">' . "\n";
		} else {
			echo '<script>' . "\n";
		}

		echo "!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','" . esc_js( $id ) . "');fbq('track','PageView');\n";
		echo '</script>' . "\n";

		// Noscript fallback (never delayed).
		echo '<noscript><img height="1" width="1" style="display:none" src="' . esc_url( 'https://www.facebook.com/tr?id=' . rawurlencode( $id ) . '&ev=PageView&noscript=1' ) . '" alt=""></noscript>' . "\n";
	}

	/**
	 * Output custom user scripts.
	 *
	 * @since 1.0.0
	 * @param string $scripts Raw script content from settings.
	 * @param bool   $delay   Whether to delay until interaction.
	 */
	private function output_custom_scripts( $scripts, $delay ) {
		if ( empty( $scripts ) ) {
			return;
		}

		$this->has_scripts = true;

		if ( $delay ) {
			// Replace <script to <script type="up-delay-third-party" and
			// replace <script src="..." with data-up-src for external scripts.
			$output = preg_replace(
				'/<script(\s)/i',
				'<script type="up-delay-third-party"$1',
				$scripts
			);
			$output = preg_replace(
				'/\ssrc\s*=\s*(["\'])([^"\']+)\1/i',
				' data-up-src=$1$2$1',
				$output
			);
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Script tags must be output verbatim; content is admin-configured.
			echo $output . "\n";
		} else {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Script tags must be output verbatim; content is admin-configured.
			echo $scripts . "\n";
		}
	}

	/**
	 * Inject DNS prefetch hints for configured third-party services.
	 *
	 * @since 1.0.0
	 */
	public function inject_dns_prefetch() {
		$domains = array();

		if ( ! empty( $this->settings['ga4_id'] ) ) {
			$domains[] = 'www.googletagmanager.com';
			$domains[] = 'www.google-analytics.com';
		}

		if ( ! empty( $this->settings['gtm_id'] ) ) {
			$domains[] = 'www.googletagmanager.com';
		}

		if ( ! empty( $this->settings['clarity_id'] ) ) {
			$domains[] = 'www.clarity.ms';
		}

		if ( ! empty( $this->settings['meta_pixel_id'] ) ) {
			$domains[] = 'connect.facebook.net';
		}

		$domains = array_unique( $domains );

		foreach ( $domains as $domain ) {
			echo '<link rel="dns-prefetch" href="//' . esc_attr( $domain ) . '">' . "\n";
		}
	}

	/**
	 * Output the delay-until-interaction restore script.
	 *
	 * Mirrors the pattern from Ultimate_Performance_CSS_JS but uses
	 * a separate type (up-delay-third-party) to avoid conflicts.
	 *
	 * @since 1.0.0
	 */
	public function output_delay_restore_script() {
		if ( ! $this->has_scripts ) {
			return;
		}
		?>
		<script id="up-delay-third-party-restore">
		(function(){
			var events = ['mousemove','scroll','keydown','click','touchstart'];
			var loaded = false;

			function loadDelayed() {
				if (loaded) return;
				loaded = true;

				events.forEach(function(e) {
					document.removeEventListener(e, loadDelayed, {passive:true,capture:true});
				});

				var scripts = document.querySelectorAll('script[type="up-delay-third-party"]');
				scripts.forEach(function(old) {
					var s = document.createElement('script');
					var src = old.getAttribute('data-up-src');
					if (src) {
						s.src = src;
						if (old.hasAttribute('async')) s.async = true;
					} else {
						s.textContent = old.textContent;
					}
					if (old.id) s.id = old.id;
					s.type = 'text/javascript';
					old.parentNode.replaceChild(s, old);
				});
			}

			events.forEach(function(e) {
				document.addEventListener(e, loadDelayed, {passive:true,capture:true});
			});
		})();
		</script>
		<?php
	}
}
