=== Ultimate Performance ===
Contributors: ultimateperformance
Tags: performance, optimization, speed, cache, core-web-vitals
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A comprehensive WordPress performance optimization toolkit.

== Description ==

Ultimate Performance provides a complete suite of tools to optimize your WordPress site's speed, Core Web Vitals, and overall performance. It combines caching, asset optimization, image compression, database cleanup, and more into a single unified plugin with a modern admin interface.

**Features:**

* **Page Caching** — Full-page cache with .htaccess integration, automatic purge on content updates, and mobile-aware caching.
* **CSS & JS Optimization** — Minify, combine, defer, delay, and async-load stylesheets and scripts. Remove unused CSS with the built-in Used CSS (UCSS) generator.
* **Image Optimization** — Compress JPEG, PNG, and GIF images using CLI tools (jpegoptim, pngquant, optipng, gifsicle) or PHP GD as a fallback. Auto-generate WebP variants. Includes lazy loading.
* **Database Optimization** — Clean revisions, auto-drafts, trashed posts/comments, spam, expired transients, and orphaned meta. Schedule automatic cleanup daily, weekly, or monthly.
* **Bloat Removal** — Disable emojis, oEmbed, XML-RPC, dashicons on frontend, REST API user enumeration, self-pingbacks, RSS feeds, and other WordPress bloat.
* **Preloading & Resource Hints** — DNS prefetch, preconnect, preload, and prefetch hints. Speculation Rules API support. Hover-based link prefetching.
* **Web Fonts** — Self-host Google Fonts locally for GDPR compliance and performance. Preload critical fonts.
* **CDN Integration** — Rewrite static asset URLs to a CDN. Built-in Cloudflare and BunnyCDN API support, plus custom CDN.
* **Script Manager** — Selectively disable scripts and styles per page, post, or URL pattern.
* **Security Headers** — X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy, HSTS, and X-XSS-Protection.
* **WooCommerce Optimization** — Disable WooCommerce scripts/styles on non-shop pages.
* **Third-Party Script Management** — Load GA4, GTM, Clarity, and Meta Pixel with delay support. Custom head/body/footer scripts.
* **Speed Test** — Google PageSpeed Insights API and browser-based Quick Test. Save and compare reports.
* **Basic SEO** — Meta titles, descriptions, Open Graph, Twitter Cards, robots meta, XML sitemap, Schema.org, and canonical URLs.
* **AI Assistant** — Analyze performance with OpenAI, Google Gemini, or Anthropic Claude APIs.
* **Static Site Generator** — Generate static HTML copies for deployment or snapshots.
* **Media Offload** — Offload media to S3-compatible storage (AWS S3, DigitalOcean Spaces, Cloudflare R2, Backblaze B2).
* **Optimization Presets** — One-click Safe, Balanced, and Aggressive presets.

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/ultimate-performance` or install through the WordPress plugins screen.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Navigate to **Ultimate Performance** in the admin sidebar to configure modules.

== Frequently Asked Questions ==

= Does this plugin work with other caching plugins? =

We recommend disabling other page caching plugins to avoid conflicts. Ultimate Performance provides its own page caching module. Other optimization plugins (e.g., image-only or database-only tools) can coexist if their features don't overlap.

= Do I need an API key for speed tests? =

No, the PageSpeed Insights API works without a key (limited to ~25 requests/day). For higher limits (25,000/day), you can add a free Google Cloud API key in the settings. A setup guide is included in the plugin.

= Is an AI provider API key required? =

No. The AI Assistant module is entirely optional. If you want AI-powered analysis, you need an API key from OpenAI, Google Gemini, or Anthropic. Your API key is stored locally and requests are sent directly to the provider.

= Does this plugin support multisite? =

The plugin can be activated on individual sites within a multisite network. Network-wide activation is not officially supported yet.

= How does image optimization work? =

The plugin detects CLI image tools on your server (jpegoptim, pngquant, optipng, cwebp, gifsicle) and uses them for best-quality compression. If no CLI tools are available, it falls back to PHP's built-in GD library.

== External Services ==

This plugin connects to the following third-party services when the corresponding modules are enabled and configured by the user:

= Google PageSpeed Insights API =
Used by the Speed Test module to analyze page performance and Core Web Vitals.
Data sent: The URL you enter for testing.
[Terms of Service](https://developers.google.com/terms) | [Privacy Policy](https://policies.google.com/privacy)

= OpenAI API =
Used by the AI Assistant module (when OpenAI is selected) to analyze performance data and generate recommendations.
Data sent: Page performance data and/or HTML content for analysis. Your API key is sent for authentication.
[Terms of Use](https://openai.com/policies/terms-of-use) | [Privacy Policy](https://openai.com/policies/privacy-policy)

= Google Gemini API =
Used by the AI Assistant module (when Gemini is selected) to analyze performance data.
Data sent: Page performance data and/or HTML content. Your API key is sent as a URL parameter per Google's API design.
[Terms of Service](https://ai.google.dev/terms) | [Privacy Policy](https://policies.google.com/privacy)

= Anthropic API =
Used by the AI Assistant module (when Anthropic is selected) to analyze performance data.
Data sent: Page performance data and/or HTML content. Your API key is sent via request headers.
[Consumer Terms](https://www.anthropic.com/legal/consumer-terms) | [Privacy Policy](https://www.anthropic.com/legal/privacy)

= Cloudflare API =
Used by the CDN module to test connections and purge Cloudflare cache.
Data sent: Cloudflare email, API key, and Zone ID for authentication and cache management.
[Terms of Service](https://www.cloudflare.com/terms/) | [Privacy Policy](https://www.cloudflare.com/privacypolicy/)

= Bunny.net API =
Used by the CDN module to purge BunnyCDN cache.
Data sent: BunnyCDN API key and Pull Zone ID for authentication and cache management.
[Terms of Service](https://bunny.net/tos/) | [Privacy Policy](https://bunny.net/privacy/)

= Google Fonts API =
Used by the Web Fonts module to download Google Fonts for local self-hosting.
Data sent: Font family names to download. Fonts are cached locally after the initial download.
[Terms of Service](https://developers.google.com/terms) | [Privacy Policy](https://policies.google.com/privacy)

= S3-Compatible Object Storage =
Used by the Media Offload module to upload and serve media files from cloud storage (AWS S3, DigitalOcean Spaces, Cloudflare R2, Backblaze B2).
Data sent: Media files and metadata. Storage credentials are stored locally.
Refer to your chosen provider's Terms of Service and Privacy Policy.

All external service connections require explicit user configuration. No data is sent to any external service without user action.

== Screenshots ==

1. Dashboard with performance overview and Core Web Vitals summary.
2. Speed Test results with Lighthouse performance score and metrics.
3. Settings page with tabbed module configuration.
4. Image Optimization tools with CLI detection and batch processing.
5. Database cleanup tools with item counts and scheduled optimization.

== Changelog ==

= 1.0.0 =
* Initial release with 20+ optimization modules.
* Page caching with .htaccess integration and auto-purge.
* CSS/JS minification, defer, delay, and async loading.
* Used CSS (UCSS) and Critical CSS generation.
* Image compression via CLI tools with GD fallback and WebP generation.
* Database cleanup and scheduled optimization.
* Bloat removal (emojis, oEmbed, XML-RPC, dashicons, REST API enumeration).
* Preloading with DNS prefetch, preconnect, preload, and Speculation Rules API.
* Google Fonts local self-hosting.
* CDN URL rewriting with Cloudflare and BunnyCDN API integration.
* Script Manager for per-page asset control.
* HTTP security headers.
* WooCommerce script/style optimization.
* Third-party script management (GA4, GTM, Clarity, Meta Pixel) with delay support.
* Speed Test via PageSpeed Insights API and browser-based Quick Test.
* Basic SEO with meta tags, Open Graph, Twitter Cards, XML sitemap, and Schema.org.
* AI Assistant for performance analysis (OpenAI, Gemini, Anthropic).
* Static Site Generator for HTML snapshots.
* Media Offload to S3-compatible object storage.
* Optimization presets (Safe, Balanced, Aggressive).

== Upgrade Notice ==

= 1.0.0 =
Initial release.
