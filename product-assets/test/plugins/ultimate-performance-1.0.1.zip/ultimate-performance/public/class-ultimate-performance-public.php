<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @package    Ultimate_Performance
 * @subpackage Ultimate_Performance/public
 * @since      1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ultimate_Performance_Public
 *
 * Handles public-facing functionality including
 * enqueueing styles and scripts on the front end.
 *
 * @since 1.0.0
 */
class Ultimate_Performance_Public {

	/**
	 * Register the public stylesheets.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_styles() {
		// Only enqueue when needed (add conditions as features are built).
	}

	/**
	 * Register the public JavaScript.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts() {
		// Only enqueue when needed (add conditions as features are built).
	}
}
