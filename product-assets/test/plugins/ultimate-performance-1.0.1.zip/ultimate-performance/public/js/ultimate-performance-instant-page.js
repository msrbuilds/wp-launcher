/**
 * Ultimate Performance - Instant Page (Hover Prefetch)
 *
 * Prefetches pages on mouse hover with a 65ms delay.
 * Skips external links, admin URLs, anchors, and already-prefetched URLs.
 *
 * @package Ultimate_Performance
 * @since   1.0.0
 */

(function () {
	'use strict';

	var prefetched = {};
	var prefetchCount = 0;
	var maxPrefetch = 10;
	var timer = null;

	function prefetch( url ) {
		if ( prefetched[ url ] || prefetchCount >= maxPrefetch ) {
			return;
		}

		var link = document.createElement( 'link' );
		link.rel = 'prefetch';
		link.href = url;
		document.head.appendChild( link );

		prefetched[ url ] = true;
		prefetchCount++;
	}

	function isValidLink( el ) {
		if ( ! el || ! el.href ) {
			return false;
		}

		// Skip non-HTTP links.
		if ( el.protocol !== 'http:' && el.protocol !== 'https:' ) {
			return false;
		}

		// Skip external links.
		if ( el.hostname !== location.hostname ) {
			return false;
		}

		// Skip hash-only links.
		if ( el.pathname === location.pathname && el.hash ) {
			return false;
		}

		// Skip admin URLs.
		if ( el.pathname.indexOf( '/wp-admin' ) === 0 || el.pathname.indexOf( '/wp-login' ) === 0 ) {
			return false;
		}

		// Skip links with data-no-prefetch attribute.
		if ( el.hasAttribute( 'data-no-prefetch' ) ) {
			return false;
		}

		// Skip already prefetched.
		if ( prefetched[ el.href ] ) {
			return false;
		}

		return true;
	}

	document.addEventListener( 'mouseover', function ( e ) {
		var link = e.target.closest( 'a' );

		if ( ! isValidLink( link ) ) {
			return;
		}

		timer = setTimeout( function () {
			prefetch( link.href );
		}, 65 );
	});

	document.addEventListener( 'mouseout', function ( e ) {
		if ( e.target.closest( 'a' ) && timer ) {
			clearTimeout( timer );
			timer = null;
		}
	});

	// Also prefetch on touchstart for mobile.
	document.addEventListener( 'touchstart', function ( e ) {
		var link = e.target.closest( 'a' );

		if ( isValidLink( link ) ) {
			prefetch( link.href );
		}
	}, { passive: true });
})();
